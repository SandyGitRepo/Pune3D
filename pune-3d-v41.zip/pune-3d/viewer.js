var pc="160",hn={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Tn={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},vp=0,Xh=1,bp=2;var Cd=1,mc=2,si=3,Wn=0,zt=1,_t=2;var Ai=0,Rs=1,gr=2,qh=3,Yh=4,Mp=5,qi=100,wp=101,Sp=102,Kh=103,jh=104,Ep=200,Tp=201,Ap=202,Rp=203,Ll=204,Il=205,Cp=206,Pp=207,Lp=208,Ip=209,Dp=210,Np=211,Up=212,Op=213,Fp=214,Bp=0,kp=1,zp=2,Ra=3,Hp=4,Vp=5,Gp=6,Wp=7,Pd=0,Xp=1,qp=2,Ri=0,Yp=1,Kp=2,jp=3,gc=4,$p=5,Zp=6,$h="attached",Jp="detached",Ld=300,Ls=301,Is=302,Dl=303,Nl=304,ro=306,Zi=1e3,mn=1001,_r=1002,Rt=1003,Ca=1004;var ur=1005;var an=1006,_c=1007;var Pi=1008;var Ci=1009,Qp=1010,em=1011,xc=1012,Id=1013,Ei=1014,ri=1015,xr=1016,Dd=1017,Nd=1018,Ki=1020,tm=1021,bn=1023,nm=1024,im=1025,ji=1026,Ds=1027,sm=1028,Ud=1029,rm=1030,Od=1031,Fd=1033,Jo=33776,Qo=33777,el=33778,tl=33779,Zh=35840,Jh=35841,Qh=35842,eu=35843,Bd=36196,tu=37492,nu=37496,iu=37808,su=37809,ru=37810,au=37811,ou=37812,lu=37813,cu=37814,hu=37815,uu=37816,du=37817,fu=37818,pu=37819,mu=37820,gu=37821,nl=36492,_u=36494,xu=36495,am=36283,yu=36284,vu=36285,bu=36286,yc=2200,vc=2201,om=2202,Ns=2300,Ji=2301,il=2302,ws=2400,Ss=2401,Pa=2402,bc=2500,lm=2501,kd=0,ao=1,Nr=2,zd=3e3,$i=3001,cm=3200,hm=3201,Hd=0,um=1,Mn="",ut="srgb",Pt="srgb-linear",Mc="display-p3",oo="display-p3-linear",La="linear",mt="srgb",Ia="rec709",Da="p3";var as=7680;var Mu=519,dm=512,fm=513,pm=514,Vd=515,mm=516,gm=517,_m=518,xm=519,Ul=35044,Ur=35048;var wu="300 es",Ol=1035,ai=2e3,Na=2001,On=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let s=this._listeners[e];if(s!==void 0){let r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let n=this._listeners[e.type];if(n!==void 0){e.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}},$t=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Su=1234567,dr=Math.PI/180,Us=180/Math.PI;function Un(){let i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return($t[i&255]+$t[i>>8&255]+$t[i>>16&255]+$t[i>>24&255]+"-"+$t[e&255]+$t[e>>8&255]+"-"+$t[e>>16&15|64]+$t[e>>24&255]+"-"+$t[t&63|128]+$t[t>>8&255]+"-"+$t[t>>16&255]+$t[t>>24&255]+$t[n&255]+$t[n>>8&255]+$t[n>>16&255]+$t[n>>24&255]).toLowerCase()}function Vt(i,e,t){return Math.max(e,Math.min(t,i))}function wc(i,e){return(i%e+e)%e}function ym(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function vm(i,e,t){return i!==e?(t-i)/(e-i):0}function fr(i,e,t){return(1-t)*i+t*e}function bm(i,e,t,n){return fr(i,e,1-Math.exp(-t*n))}function Mm(i,e=1){return e-Math.abs(wc(i,e*2)-e)}function wm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function Sm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function Em(i,e){return i+Math.floor(Math.random()*(e-i+1))}function Tm(i,e){return i+Math.random()*(e-i)}function Am(i){return i*(.5-Math.random())}function Rm(i){i!==void 0&&(Su=i);let e=Su+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Cm(i){return i*dr}function Pm(i){return i*Us}function Fl(i){return(i&i-1)===0&&i!==0}function Lm(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Ua(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Im(i,e,t,n,s){let r=Math.cos,o=Math.sin,a=r(t/2),l=o(t/2),c=r((e+n)/2),h=o((e+n)/2),u=r((e-n)/2),d=o((e-n)/2),f=r((n-e)/2),g=o((n-e)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*g,l*f,a*c);break;case"YXY":i.set(l*f,a*h,l*g,a*c);break;case"ZYZ":i.set(l*g,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Gn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function lt(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var Dt={DEG2RAD:dr,RAD2DEG:Us,generateUUID:Un,clamp:Vt,euclideanModulo:wc,mapLinear:ym,inverseLerp:vm,lerp:fr,damp:bm,pingpong:Mm,smoothstep:wm,smootherstep:Sm,randInt:Em,randFloat:Tm,randFloatSpread:Am,seededRandom:Rm,degToRad:Cm,radToDeg:Pm,isPowerOfTwo:Fl,ceilPowerOfTwo:Lm,floorPowerOfTwo:Ua,setQuaternionFromProperEuler:Im,normalize:lt,denormalize:Gn},Re=class i{constructor(e=0,t=0){i.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Vt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Ke=class i{constructor(e,t,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c)}set(e,t,n,s,r,o,a,l,c){let h=this.elements;return h[0]=e,h[1]=s,h[2]=a,h[3]=t,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],_=s[0],m=s[3],p=s[6],y=s[1],x=s[4],M=s[7],A=s[2],T=s[5],R=s[8];return r[0]=o*_+a*y+l*A,r[3]=o*m+a*x+l*T,r[6]=o*p+a*M+l*R,r[1]=c*_+h*y+u*A,r[4]=c*m+h*x+u*T,r[7]=c*p+h*M+u*R,r[2]=d*_+f*y+g*A,r[5]=d*m+f*x+g*T,r[8]=d*p+f*M+g*R,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*r,f=c*r-o*l,g=t*u+n*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let _=1/g;return e[0]=u*_,e[1]=(s*c-h*n)*_,e[2]=(a*n-s*o)*_,e[3]=d*_,e[4]=(h*t-s*l)*_,e[5]=(s*r-a*t)*_,e[6]=f*_,e[7]=(n*l-c*t)*_,e[8]=(o*t-n*r)*_,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-s*c,s*l,-s*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(sl.makeScale(e,t)),this}rotate(e){return this.premultiply(sl.makeRotation(-e)),this}translate(e,t){return this.premultiply(sl.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},sl=new Ke;function Gd(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function yr(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Dm(){let i=yr("canvas");return i.style.display="block",i}var Eu={};function pr(i){i in Eu||(Eu[i]=!0,console.warn(i))}var Tu=new Ke().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Au=new Ke().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),ea={[Pt]:{transfer:La,primaries:Ia,toReference:i=>i,fromReference:i=>i},[ut]:{transfer:mt,primaries:Ia,toReference:i=>i.convertSRGBToLinear(),fromReference:i=>i.convertLinearToSRGB()},[oo]:{transfer:La,primaries:Da,toReference:i=>i.applyMatrix3(Au),fromReference:i=>i.applyMatrix3(Tu)},[Mc]:{transfer:mt,primaries:Da,toReference:i=>i.convertSRGBToLinear().applyMatrix3(Au),fromReference:i=>i.applyMatrix3(Tu).convertLinearToSRGB()}},Nm=new Set([Pt,oo]),at={enabled:!0,_workingColorSpace:Pt,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(i){if(!Nm.has(i))throw new Error(`Unsupported working color space, "${i}".`);this._workingColorSpace=i},convert:function(i,e,t){if(this.enabled===!1||e===t||!e||!t)return i;let n=ea[e].toReference,s=ea[t].fromReference;return s(n(i))},fromWorkingColorSpace:function(i,e){return this.convert(i,this._workingColorSpace,e)},toWorkingColorSpace:function(i,e){return this.convert(i,e,this._workingColorSpace)},getPrimaries:function(i){return ea[i].primaries},getTransfer:function(i){return i===Mn?La:ea[i].transfer}};function Cs(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function rl(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var os,Oa=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{os===void 0&&(os=yr("canvas")),os.width=e.width,os.height=e.height;let n=os.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=os}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=yr("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Cs(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Cs(t[n]/255)*255):t[n]=Cs(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Um=0,Fa=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Um++}),this.uuid=Un(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(al(s[o].image)):r.push(al(s[o]))}else r=al(s);n.url=r}return t||(e.images[this.uuid]=n),n}};function al(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Oa.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Om=0,Gt=class i extends On{constructor(e=i.DEFAULT_IMAGE,t=i.DEFAULT_MAPPING,n=mn,s=mn,r=an,o=Pi,a=bn,l=Ci,c=i.DEFAULT_ANISOTROPY,h=Mn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Om++}),this.uuid=Un(),this.name="",this.source=new Fa(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Re(0,0),this.repeat=new Re(1,1),this.center=new Re(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ke,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(pr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===$i?ut:Mn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Ld)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Zi:e.x=e.x-Math.floor(e.x);break;case mn:e.x=e.x<0?0:1;break;case _r:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Zi:e.y=e.y-Math.floor(e.y);break;case mn:e.y=e.y<0?0:1;break;case _r:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return pr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===ut?$i:zd}set encoding(e){pr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===$i?ut:Mn}};Gt.DEFAULT_IMAGE=null;Gt.DEFAULT_MAPPING=Ld;Gt.DEFAULT_ANISOTROPY=1;var dt=class i{constructor(e=0,t=0,n=0,s=1){i.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r,l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],_=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+_)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let x=(c+1)/2,M=(f+1)/2,A=(p+1)/2,T=(h+d)/4,R=(u+_)/4,N=(g+m)/4;return x>M&&x>A?x<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(x),s=T/n,r=R/n):M>A?M<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(M),n=T/s,r=N/s):A<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(A),n=R/r,s=N/r),this.set(n,s,r,t),this}let y=Math.sqrt((m-g)*(m-g)+(u-_)*(u-_)+(d-h)*(d-h));return Math.abs(y)<.001&&(y=1),this.x=(m-g)/y,this.y=(u-_)/y,this.z=(d-h)/y,this.w=Math.acos((c+f+p-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Bl=class extends On{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new dt(0,0,e,t),this.scissorTest=!1,this.viewport=new dt(0,0,e,t);let s={width:e,height:t,depth:1};n.encoding!==void 0&&(pr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===$i?ut:Mn),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:an,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new Gt(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(e,t,n=1){(this.width!==e||this.height!==t||this.depth!==n)&&(this.width=e,this.height=t,this.depth=n,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new Fa(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},oi=class extends Bl{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},Ba=class extends Gt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=Rt,this.minFilter=Rt,this.wrapR=mn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var kl=class extends Gt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=Rt,this.minFilter=Rt,this.wrapR=mn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var xt=class{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[o+0],f=r[o+1],g=r[o+2],_=r[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(a===1){e[t+0]=d,e[t+1]=f,e[t+2]=g,e[t+3]=_;return}if(u!==_||l!==d||c!==f||h!==g){let m=1-a,p=l*d+c*f+h*g+u*_,y=p>=0?1:-1,x=1-p*p;if(x>Number.EPSILON){let A=Math.sqrt(x),T=Math.atan2(A,p*y);m=Math.sin(m*T)/A,a=Math.sin(a*T)/A}let M=a*y;if(l=l*m+d*M,c=c*m+f*M,h=h*m+g*M,u=u*m+_*M,m===1-a){let A=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=A,c*=A,h*=A,u*=A}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],f=r[o+2],g=r[o+3];return e[t]=a*g+h*u+l*f-c*d,e[t+1]=l*g+h*d+c*u-a*f,e[t+2]=c*g+h*f+a*d-l*u,e[t+3]=h*g-a*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),f=l(s/2),g=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(o-s)*f}else if(n>a&&n>u){let f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+c)/f}else if(a>u){let f=2*Math.sqrt(1+a-n-u);this._w=(r-c)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-a);this._w=(o-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Vt(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,s=e._y,r=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*e._w+n*e._x+s*e._y+r*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*s+t*this._y,this._z=f*r+t*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=Math.random(),t=Math.sqrt(1-e),n=Math.sqrt(e),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(t*Math.cos(s),n*Math.sin(r),n*Math.cos(r),t*Math.sin(s))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},C=class i{constructor(e=0,t=0,n=0){i.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Ru.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Ru.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){let t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*s-a*n),h=2*(a*t-r*s),u=2*(r*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,s=e.y,r=e.z,o=t.x,a=t.y,l=t.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return ol.copy(this).projectOnVector(e),this.sub(ol)}reflect(e){return this.sub(ol.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Vt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,n=Math.sqrt(1-e**2);return this.x=n*Math.cos(t),this.y=n*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},ol=new C,Ru=new xt,wn=class{constructor(e=new C(1/0,1/0,1/0),t=new C(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Ln.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Ln.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Ln.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Ln):Ln.fromBufferAttribute(r,o),Ln.applyMatrix4(e.matrixWorld),this.expandByPoint(Ln);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),ta.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ta.copy(n.boundingBox)),ta.applyMatrix4(e.matrixWorld),this.union(ta)}let s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,Ln),Ln.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(sr),na.subVectors(this.max,sr),ls.subVectors(e.a,sr),cs.subVectors(e.b,sr),hs.subVectors(e.c,sr),vi.subVectors(cs,ls),bi.subVectors(hs,cs),Hi.subVectors(ls,hs);let t=[0,-vi.z,vi.y,0,-bi.z,bi.y,0,-Hi.z,Hi.y,vi.z,0,-vi.x,bi.z,0,-bi.x,Hi.z,0,-Hi.x,-vi.y,vi.x,0,-bi.y,bi.x,0,-Hi.y,Hi.x,0];return!ll(t,ls,cs,hs,na)||(t=[1,0,0,0,1,0,0,0,1],!ll(t,ls,cs,hs,na))?!1:(ia.crossVectors(vi,bi),t=[ia.x,ia.y,ia.z],ll(t,ls,cs,hs,na))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ln).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ln).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Jn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Jn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Jn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Jn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Jn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Jn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Jn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Jn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Jn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},Jn=[new C,new C,new C,new C,new C,new C,new C,new C],Ln=new C,ta=new wn,ls=new C,cs=new C,hs=new C,vi=new C,bi=new C,Hi=new C,sr=new C,na=new C,ia=new C,Vi=new C;function ll(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Vi.fromArray(i,r);let a=s.x*Math.abs(Vi.x)+s.y*Math.abs(Vi.y)+s.z*Math.abs(Vi.z),l=e.dot(Vi),c=t.dot(Vi),h=n.dot(Vi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var Fm=new wn,rr=new C,cl=new C,gn=class{constructor(e=new C,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t!==void 0?n.copy(t):Fm.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;rr.subVectors(e,this.center);let t=rr.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(rr,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(cl.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(rr.copy(e.center).add(cl)),this.expandByPoint(rr.copy(e.center).sub(cl))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},Qn=new C,hl=new C,sa=new C,Mi=new C,ul=new C,ra=new C,dl=new C,li=class{constructor(e=new C,t=new C(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Qn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Qn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Qn.copy(this.origin).addScaledVector(this.direction,t),Qn.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){hl.copy(e).add(t).multiplyScalar(.5),sa.copy(t).sub(e).normalize(),Mi.copy(this.origin).sub(hl);let r=e.distanceTo(t)*.5,o=-this.direction.dot(sa),a=Mi.dot(this.direction),l=-Mi.dot(sa),c=Mi.lengthSq(),h=Math.abs(1-o*o),u,d,f,g;if(h>0)if(u=o*l-a,d=o*a-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let _=1/h;u*=_,d*=_,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(hl).addScaledVector(sa,d),f}intersectSphere(e,t){Qn.subVectors(e.center,this.origin);let n=Qn.dot(this.direction),s=Qn.dot(Qn)-n*n,r=e.radius*e.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,s=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,s=(e.min.x-d.x)*c),h>=0?(r=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(r=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,Qn)!==null}intersectTriangle(e,t,n,s,r){ul.subVectors(t,e),ra.subVectors(n,e),dl.crossVectors(ul,ra);let o=this.direction.dot(dl),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Mi.subVectors(this.origin,e);let l=a*this.direction.dot(ra.crossVectors(Mi,ra));if(l<0)return null;let c=a*this.direction.dot(ul.cross(Mi));if(c<0||l+c>o)return null;let h=-a*Mi.dot(dl);return h<0?null:this.at(h/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ze=class i{constructor(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m)}set(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m){let p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,s=1/us.setFromMatrixColumn(e,0).length(),r=1/us.setFromMatrixColumn(e,1).length(),o=1/us.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(e.order==="XYZ"){let d=o*h,f=o*u,g=a*h,_=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+g*c,t[5]=d-_*c,t[9]=-a*l,t[2]=_-d*c,t[6]=g+f*c,t[10]=o*l}else if(e.order==="YXZ"){let d=l*h,f=l*u,g=c*h,_=c*u;t[0]=d+_*a,t[4]=g*a-f,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=f*a-g,t[6]=_+d*a,t[10]=o*l}else if(e.order==="ZXY"){let d=l*h,f=l*u,g=c*h,_=c*u;t[0]=d-_*a,t[4]=-o*u,t[8]=g+f*a,t[1]=f+g*a,t[5]=o*h,t[9]=_-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){let d=o*h,f=o*u,g=a*h,_=a*u;t[0]=l*h,t[4]=g*c-f,t[8]=d*c+_,t[1]=l*u,t[5]=_*c+d,t[9]=f*c-g,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){let d=o*l,f=o*c,g=a*l,_=a*c;t[0]=l*h,t[4]=_-d*u,t[8]=g*u+f,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=f*u+g,t[10]=d-_*u}else if(e.order==="XZY"){let d=o*l,f=o*c,g=a*l,_=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+_,t[5]=o*h,t[9]=f*u-g,t[2]=g*u-f,t[6]=a*h,t[10]=_*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Bm,e,km)}lookAt(e,t,n){let s=this.elements;return fn.subVectors(e,t),fn.lengthSq()===0&&(fn.z=1),fn.normalize(),wi.crossVectors(n,fn),wi.lengthSq()===0&&(Math.abs(n.z)===1?fn.x+=1e-4:fn.z+=1e-4,fn.normalize(),wi.crossVectors(n,fn)),wi.normalize(),aa.crossVectors(fn,wi),s[0]=wi.x,s[4]=aa.x,s[8]=fn.x,s[1]=wi.y,s[5]=aa.y,s[9]=fn.y,s[2]=wi.z,s[6]=aa.z,s[10]=fn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],y=n[3],x=n[7],M=n[11],A=n[15],T=s[0],R=s[4],N=s[8],b=s[12],E=s[1],O=s[5],W=s[9],ne=s[13],I=s[2],U=s[6],V=s[10],K=s[14],Y=s[3],q=s[7],ee=s[11],se=s[15];return r[0]=o*T+a*E+l*I+c*Y,r[4]=o*R+a*O+l*U+c*q,r[8]=o*N+a*W+l*V+c*ee,r[12]=o*b+a*ne+l*K+c*se,r[1]=h*T+u*E+d*I+f*Y,r[5]=h*R+u*O+d*U+f*q,r[9]=h*N+u*W+d*V+f*ee,r[13]=h*b+u*ne+d*K+f*se,r[2]=g*T+_*E+m*I+p*Y,r[6]=g*R+_*O+m*U+p*q,r[10]=g*N+_*W+m*V+p*ee,r[14]=g*b+_*ne+m*K+p*se,r[3]=y*T+x*E+M*I+A*Y,r[7]=y*R+x*O+M*U+A*q,r[11]=y*N+x*W+M*V+A*ee,r[15]=y*b+x*ne+M*K+A*se,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],g=e[3],_=e[7],m=e[11],p=e[15];return g*(+r*l*u-s*c*u-r*a*d+n*c*d+s*a*f-n*l*f)+_*(+t*l*f-t*c*d+r*o*d-s*o*f+s*c*h-r*l*h)+m*(+t*c*u-t*a*f-r*o*u+n*o*f+r*a*h-n*c*h)+p*(-s*a*h-t*l*u+t*a*d+s*o*u-n*o*d+n*l*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],g=e[12],_=e[13],m=e[14],p=e[15],y=u*m*c-_*d*c+_*l*f-a*m*f-u*l*p+a*d*p,x=g*d*c-h*m*c-g*l*f+o*m*f+h*l*p-o*d*p,M=h*_*c-g*u*c+g*a*f-o*_*f-h*a*p+o*u*p,A=g*u*l-h*_*l-g*a*d+o*_*d+h*a*m-o*u*m,T=t*y+n*x+s*M+r*A;if(T===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/T;return e[0]=y*R,e[1]=(_*d*r-u*m*r-_*s*f+n*m*f+u*s*p-n*d*p)*R,e[2]=(a*m*r-_*l*r+_*s*c-n*m*c-a*s*p+n*l*p)*R,e[3]=(u*l*r-a*d*r-u*s*c+n*d*c+a*s*f-n*l*f)*R,e[4]=x*R,e[5]=(h*m*r-g*d*r+g*s*f-t*m*f-h*s*p+t*d*p)*R,e[6]=(g*l*r-o*m*r-g*s*c+t*m*c+o*s*p-t*l*p)*R,e[7]=(o*d*r-h*l*r+h*s*c-t*d*c-o*s*f+t*l*f)*R,e[8]=M*R,e[9]=(g*u*r-h*_*r-g*n*f+t*_*f+h*n*p-t*u*p)*R,e[10]=(o*_*r-g*a*r+g*n*c-t*_*c-o*n*p+t*a*p)*R,e[11]=(h*a*r-o*u*r-h*n*c+t*u*c+o*n*f-t*a*f)*R,e[12]=A*R,e[13]=(h*_*s-g*u*s+g*n*d-t*_*d-h*n*m+t*u*m)*R,e[14]=(g*a*s-o*_*s-g*n*l+t*_*l+o*n*m-t*a*m)*R,e[15]=(o*u*s-h*a*s+h*n*l-t*u*l-o*n*d+t*a*d)*R,this}scale(e){let t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,a=e.y,l=e.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){let s=this.elements,r=t._x,o=t._y,a=t._z,l=t._w,c=r+r,h=o+o,u=a+a,d=r*c,f=r*h,g=r*u,_=o*h,m=o*u,p=a*u,y=l*c,x=l*h,M=l*u,A=n.x,T=n.y,R=n.z;return s[0]=(1-(_+p))*A,s[1]=(f+M)*A,s[2]=(g-x)*A,s[3]=0,s[4]=(f-M)*T,s[5]=(1-(d+p))*T,s[6]=(m+y)*T,s[7]=0,s[8]=(g+x)*R,s[9]=(m-y)*R,s[10]=(1-(d+_))*R,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){let s=this.elements,r=us.set(s[0],s[1],s[2]).length(),o=us.set(s[4],s[5],s[6]).length(),a=us.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],In.copy(this);let c=1/r,h=1/o,u=1/a;return In.elements[0]*=c,In.elements[1]*=c,In.elements[2]*=c,In.elements[4]*=h,In.elements[5]*=h,In.elements[6]*=h,In.elements[8]*=u,In.elements[9]*=u,In.elements[10]*=u,t.setFromRotationMatrix(In),n.x=r,n.y=o,n.z=a,this}makePerspective(e,t,n,s,r,o,a=ai){let l=this.elements,c=2*r/(t-e),h=2*r/(n-s),u=(t+e)/(t-e),d=(n+s)/(n-s),f,g;if(a===ai)f=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===Na)f=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,r,o,a=ai){let l=this.elements,c=1/(t-e),h=1/(n-s),u=1/(o-r),d=(t+e)*c,f=(n+s)*h,g,_;if(a===ai)g=(o+r)*u,_=-2*u;else if(a===Na)g=r*u,_=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=_,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},us=new C,In=new ze,Bm=new C(0,0,0),km=new C(1,1,1),wi=new C,aa=new C,fn=new C,Cu=new ze,Pu=new xt,Os=class i{constructor(e=0,t=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let s=e.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(Vt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Vt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Vt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Vt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Vt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Vt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Cu.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Cu,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Pu.setFromEuler(this),this.setFromQuaternion(Pu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Os.DEFAULT_ORDER="XYZ";var vr=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},zm=0,Lu=new C,ds=new xt,ei=new ze,oa=new C,ar=new C,Hm=new C,Vm=new xt,Iu=new C(1,0,0),Du=new C(0,1,0),Nu=new C(0,0,1),Gm={type:"added"},Wm={type:"removed"},vt=class i extends On{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:zm++}),this.uuid=Un(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let e=new C,t=new Os,n=new xt,s=new C(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ze},normalMatrix:{value:new Ke}}),this.matrix=new ze,this.matrixWorld=new ze,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new vr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ds.setFromAxisAngle(e,t),this.quaternion.multiply(ds),this}rotateOnWorldAxis(e,t){return ds.setFromAxisAngle(e,t),this.quaternion.premultiply(ds),this}rotateX(e){return this.rotateOnAxis(Iu,e)}rotateY(e){return this.rotateOnAxis(Du,e)}rotateZ(e){return this.rotateOnAxis(Nu,e)}translateOnAxis(e,t){return Lu.copy(e).applyQuaternion(this.quaternion),this.position.add(Lu.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Iu,e)}translateY(e){return this.translateOnAxis(Du,e)}translateZ(e){return this.translateOnAxis(Nu,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?oa.copy(e):oa.set(e,t,n);let s=this.parent;this.updateWorldMatrix(!0,!1),ar.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ei.lookAt(ar,oa,this.up):ei.lookAt(oa,ar,this.up),this.quaternion.setFromRotationMatrix(ei),s&&(ei.extractRotation(s.matrixWorld),ds.setFromRotationMatrix(ei),this.quaternion.premultiply(ds.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(Gm)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Wm)),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ei.multiply(e.parent.matrixWorld)),e.applyMatrix4(ei),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ar,e,Hm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ar,Vm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,s=t.length;n<s;n++){let r=t[n];(r.matrixWorldAutoUpdate===!0||e===!0)&&r.updateMatrixWorld(e)}}updateWorldMatrix(e,t){let n=this.parent;if(e===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++){let a=s[r];a.matrixWorldAutoUpdate===!0&&a.updateWorldMatrix(!1,!0)}}}toJSON(e){let t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(e.shapes,u)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(e.materials,this.material[l]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(e.animations,l))}}if(t){let a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),f=o(e.animations),g=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let s=e.children[n];this.add(s.clone())}return this}};vt.DEFAULT_UP=new C(0,1,0);vt.DEFAULT_MATRIX_AUTO_UPDATE=!0;vt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Dn=new C,ti=new C,fl=new C,ni=new C,fs=new C,ps=new C,Uu=new C,pl=new C,ml=new C,gl=new C,la=!1,Es=class i{constructor(e=new C,t=new C,n=new C){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),Dn.subVectors(e,t),s.cross(Dn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){Dn.subVectors(s,t),ti.subVectors(n,t),fl.subVectors(e,t);let o=Dn.dot(Dn),a=Dn.dot(ti),l=Dn.dot(fl),c=ti.dot(ti),h=ti.dot(fl),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-a*h)*d,g=(o*h-a*l)*d;return r.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,ni)===null?!1:ni.x>=0&&ni.y>=0&&ni.x+ni.y<=1}static getUV(e,t,n,s,r,o,a,l){return la===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),la=!0),this.getInterpolation(e,t,n,s,r,o,a,l)}static getInterpolation(e,t,n,s,r,o,a,l){return this.getBarycoord(e,t,n,s,ni)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,ni.x),l.addScaledVector(o,ni.y),l.addScaledVector(a,ni.z),l)}static isFrontFacing(e,t,n,s){return Dn.subVectors(n,t),ti.subVectors(e,t),Dn.cross(ti).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Dn.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),Dn.cross(ti).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return i.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return i.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,n,s,r){return la===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),la=!0),i.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}getInterpolation(e,t,n,s,r){return i.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return i.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return i.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,s=this.b,r=this.c,o,a;fs.subVectors(s,n),ps.subVectors(r,n),pl.subVectors(e,n);let l=fs.dot(pl),c=ps.dot(pl);if(l<=0&&c<=0)return t.copy(n);ml.subVectors(e,s);let h=fs.dot(ml),u=ps.dot(ml);if(h>=0&&u<=h)return t.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector(fs,o);gl.subVectors(e,r);let f=fs.dot(gl),g=ps.dot(gl);if(g>=0&&f<=g)return t.copy(r);let _=f*c-l*g;if(_<=0&&c>=0&&g<=0)return a=c/(c-g),t.copy(n).addScaledVector(ps,a);let m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return Uu.subVectors(r,s),a=(u-h)/(u-h+(f-g)),t.copy(s).addScaledVector(Uu,a);let p=1/(m+_+d);return o=_*p,a=d*p,t.copy(n).addScaledVector(fs,o).addScaledVector(ps,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Wd={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Si={h:0,s:0,l:0},ca={h:0,s:0,l:0};function _l(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}var Te=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=ut){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,at.toWorkingColorSpace(this,t),this}setRGB(e,t,n,s=at.workingColorSpace){return this.r=e,this.g=t,this.b=n,at.toWorkingColorSpace(this,s),this}setHSL(e,t,n,s=at.workingColorSpace){if(e=wc(e,1),t=Vt(t,0,1),n=Vt(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=_l(o,r,e+1/3),this.g=_l(o,r,e),this.b=_l(o,r,e-1/3)}return at.toWorkingColorSpace(this,s),this}setStyle(e,t=ut){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=ut){let n=Wd[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Cs(e.r),this.g=Cs(e.g),this.b=Cs(e.b),this}copyLinearToSRGB(e){return this.r=rl(e.r),this.g=rl(e.g),this.b=rl(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=ut){return at.fromWorkingColorSpace(Zt.copy(this),e),Math.round(Vt(Zt.r*255,0,255))*65536+Math.round(Vt(Zt.g*255,0,255))*256+Math.round(Vt(Zt.b*255,0,255))}getHexString(e=ut){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=at.workingColorSpace){at.fromWorkingColorSpace(Zt.copy(this),t);let n=Zt.r,s=Zt.g,r=Zt.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=at.workingColorSpace){return at.fromWorkingColorSpace(Zt.copy(this),t),e.r=Zt.r,e.g=Zt.g,e.b=Zt.b,e}getStyle(e=ut){at.fromWorkingColorSpace(Zt.copy(this),e);let t=Zt.r,n=Zt.g,s=Zt.b;return e!==ut?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(Si),this.setHSL(Si.h+e,Si.s+t,Si.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Si),e.getHSL(ca);let n=fr(Si.h,ca.h,t),s=fr(Si.s,ca.s,t),r=fr(Si.l,ca.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Zt=new Te;Te.NAMES=Wd;var Xm=0,_n=class extends On{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Xm++}),this.uuid=Un(),this.name="",this.type="Material",this.blending=Rs,this.side=Wn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Ll,this.blendDst=Il,this.blendEquation=qi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Te(0,0,0),this.blendAlpha=0,this.depthFunc=Ra,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Mu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=as,this.stencilZFail=as,this.stencilZPass=as,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Rs&&(n.blending=this.blending),this.side!==Wn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Ll&&(n.blendSrc=this.blendSrc),this.blendDst!==Il&&(n.blendDst=this.blendDst),this.blendEquation!==qi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Ra&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Mu&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==as&&(n.stencilFail=this.stencilFail),this.stencilZFail!==as&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==as&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(t){let r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Wt=class extends _n{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Te(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Pd,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}};var Et=new C,ha=new Re,wt=class{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Ul,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=ri,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)ha.fromBufferAttribute(this,t),ha.applyMatrix3(e),this.setXY(t,ha.x,ha.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.applyMatrix3(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.applyMatrix4(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.applyNormalMatrix(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Et.fromBufferAttribute(this,t),Et.transformDirection(e),this.setXYZ(t,Et.x,Et.y,Et.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Gn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=lt(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Gn(t,this.array)),t}setX(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Gn(t,this.array)),t}setY(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Gn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Gn(t,this.array)),t}setW(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array),r=lt(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Ul&&(e.usage=this.usage),e}};var ka=class extends wt{constructor(e,t,n){super(new Uint16Array(e),t,n)}};var za=class extends wt{constructor(e,t,n){super(new Uint32Array(e),t,n)}};var ot=class extends wt{constructor(e,t,n){super(new Float32Array(e),t,n)}};var qm=0,vn=new ze,xl=new vt,ms=new C,pn=new wn,or=new wn,kt=new C,Tt=class i extends On{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:qm++}),this.uuid=Un(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Gd(e)?za:ka)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Ke().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return vn.makeRotationFromQuaternion(e),this.applyMatrix4(vn),this}rotateX(e){return vn.makeRotationX(e),this.applyMatrix4(vn),this}rotateY(e){return vn.makeRotationY(e),this.applyMatrix4(vn),this}rotateZ(e){return vn.makeRotationZ(e),this.applyMatrix4(vn),this}translate(e,t,n){return vn.makeTranslation(e,t,n),this.applyMatrix4(vn),this}scale(e,t,n){return vn.makeScale(e,t,n),this.applyMatrix4(vn),this}lookAt(e){return xl.lookAt(e),xl.updateMatrix(),this.applyMatrix4(xl.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ms).negate(),this.translate(ms.x,ms.y,ms.z),this}setFromPoints(e){let t=[];for(let n=0,s=e.length;n<s;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new ot(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new wn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new C(-1/0,-1/0,-1/0),new C(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){let r=t[n];pn.setFromBufferAttribute(r),this.morphTargetsRelative?(kt.addVectors(this.boundingBox.min,pn.min),this.boundingBox.expandByPoint(kt),kt.addVectors(this.boundingBox.max,pn.max),this.boundingBox.expandByPoint(kt)):(this.boundingBox.expandByPoint(pn.min),this.boundingBox.expandByPoint(pn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new gn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new C,1/0);return}if(e){let n=this.boundingSphere.center;if(pn.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){let a=t[r];or.setFromBufferAttribute(a),this.morphTargetsRelative?(kt.addVectors(pn.min,or.min),pn.expandByPoint(kt),kt.addVectors(pn.max,or.max),pn.expandByPoint(kt)):(pn.expandByPoint(or.min),pn.expandByPoint(or.max))}pn.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)kt.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(kt));if(t)for(let r=0,o=t.length;r<o;r++){let a=t[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)kt.fromBufferAttribute(a,c),l&&(ms.fromBufferAttribute(e,c),kt.add(ms)),s=Math.max(s,n.distanceToSquared(kt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.array,s=t.position.array,r=t.normal.array,o=t.uv.array,a=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new wt(new Float32Array(4*a),4));let l=this.getAttribute("tangent").array,c=[],h=[];for(let E=0;E<a;E++)c[E]=new C,h[E]=new C;let u=new C,d=new C,f=new C,g=new Re,_=new Re,m=new Re,p=new C,y=new C;function x(E,O,W){u.fromArray(s,E*3),d.fromArray(s,O*3),f.fromArray(s,W*3),g.fromArray(o,E*2),_.fromArray(o,O*2),m.fromArray(o,W*2),d.sub(u),f.sub(u),_.sub(g),m.sub(g);let ne=1/(_.x*m.y-m.x*_.y);isFinite(ne)&&(p.copy(d).multiplyScalar(m.y).addScaledVector(f,-_.y).multiplyScalar(ne),y.copy(f).multiplyScalar(_.x).addScaledVector(d,-m.x).multiplyScalar(ne),c[E].add(p),c[O].add(p),c[W].add(p),h[E].add(y),h[O].add(y),h[W].add(y))}let M=this.groups;M.length===0&&(M=[{start:0,count:n.length}]);for(let E=0,O=M.length;E<O;++E){let W=M[E],ne=W.start,I=W.count;for(let U=ne,V=ne+I;U<V;U+=3)x(n[U+0],n[U+1],n[U+2])}let A=new C,T=new C,R=new C,N=new C;function b(E){R.fromArray(r,E*3),N.copy(R);let O=c[E];A.copy(O),A.sub(R.multiplyScalar(R.dot(O))).normalize(),T.crossVectors(N,O);let ne=T.dot(h[E])<0?-1:1;l[E*4]=A.x,l[E*4+1]=A.y,l[E*4+2]=A.z,l[E*4+3]=ne}for(let E=0,O=M.length;E<O;++E){let W=M[E],ne=W.start,I=W.count;for(let U=ne,V=ne+I;U<V;U+=3)b(n[U+0]),b(n[U+1]),b(n[U+2])}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new wt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let s=new C,r=new C,o=new C,a=new C,l=new C,c=new C,h=new C,u=new C;if(e)for(let d=0,f=e.count;d<f;d+=3){let g=e.getX(d+0),_=e.getX(d+1),m=e.getX(d+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,_),o.fromBufferAttribute(t,m),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,_),c.fromBufferAttribute(n,m),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(_,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)kt.fromBufferAttribute(e,t),kt.normalize(),e.setXYZ(t,kt.x,kt.y,kt.z)}toNonIndexed(){function e(a,l){let c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h),f=0,g=0;for(let _=0,m=l.length;_<m;_++){a.isInterleavedBufferAttribute?f=l[_]*a.data.stride+a.offset:f=l[_]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new wt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=e(l,n);t.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=e(d,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let l in n){let c=n[l];e.data.attributes[l]=c.toJSON(e.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(s[l]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone(t));let s=e.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(t))}let r=e.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let o=e.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Ou=new ze,Gi=new li,ua=new gn,Fu=new C,gs=new C,_s=new C,xs=new C,yl=new C,da=new C,fa=new Re,pa=new Re,ma=new Re,Bu=new C,ku=new C,zu=new C,ga=new C,_a=new C,je=class extends vt{constructor(e=new Tt,t=new Wt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,t){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);let a=this.morphTargetInfluences;if(r&&a){da.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&(yl.fromBufferAttribute(u,e),o?da.addScaledVector(yl,h):da.addScaledVector(yl.sub(t),h))}t.add(da)}return t}raycast(e,t){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ua.copy(n.boundingSphere),ua.applyMatrix4(r),Gi.copy(e.ray).recast(e.near),!(ua.containsPoint(Gi.origin)===!1&&(Gi.intersectSphere(ua,Fu)===null||Gi.origin.distanceToSquared(Fu)>(e.far-e.near)**2))&&(Ou.copy(r).invert(),Gi.copy(e.ray).applyMatrix4(Ou),!(n.boundingBox!==null&&Gi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Gi)))}_computeIntersections(e,t,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){let m=d[g],p=o[m.materialIndex],y=Math.max(m.start,f.start),x=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let M=y,A=x;M<A;M+=3){let T=a.getX(M),R=a.getX(M+1),N=a.getX(M+2);s=xa(this,p,e,n,c,h,u,T,R,N),s&&(s.faceIndex=Math.floor(M/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{let g=Math.max(0,f.start),_=Math.min(a.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){let y=a.getX(m),x=a.getX(m+1),M=a.getX(m+2);s=xa(this,o,e,n,c,h,u,y,x,M),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){let m=d[g],p=o[m.materialIndex],y=Math.max(m.start,f.start),x=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let M=y,A=x;M<A;M+=3){let T=M,R=M+1,N=M+2;s=xa(this,p,e,n,c,h,u,T,R,N),s&&(s.faceIndex=Math.floor(M/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{let g=Math.max(0,f.start),_=Math.min(l.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){let y=m,x=m+1,M=m+2;s=xa(this,o,e,n,c,h,u,y,x,M),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}};function Ym(i,e,t,n,s,r,o,a){let l;if(e.side===zt?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,e.side===Wn,a),l===null)return null;_a.copy(a),_a.applyMatrix4(i.matrixWorld);let c=t.ray.origin.distanceTo(_a);return c<t.near||c>t.far?null:{distance:c,point:_a.clone(),object:i}}function xa(i,e,t,n,s,r,o,a,l,c){i.getVertexPosition(a,gs),i.getVertexPosition(l,_s),i.getVertexPosition(c,xs);let h=Ym(i,e,t,n,gs,_s,xs,ga);if(h){s&&(fa.fromBufferAttribute(s,a),pa.fromBufferAttribute(s,l),ma.fromBufferAttribute(s,c),h.uv=Es.getInterpolation(ga,gs,_s,xs,fa,pa,ma,new Re)),r&&(fa.fromBufferAttribute(r,a),pa.fromBufferAttribute(r,l),ma.fromBufferAttribute(r,c),h.uv1=Es.getInterpolation(ga,gs,_s,xs,fa,pa,ma,new Re),h.uv2=h.uv1),o&&(Bu.fromBufferAttribute(o,a),ku.fromBufferAttribute(o,l),zu.fromBufferAttribute(o,c),h.normal=Es.getInterpolation(ga,gs,_s,xs,Bu,ku,zu,new C),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let u={a,b:l,c,normal:new C,materialIndex:0};Es.getNormal(gs,_s,xs,u.normal),h.face=u}return h}var Xt=class i extends Tt{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],d=0,f=0;g("z","y","x",-1,-1,n,t,e,o,r,0),g("z","y","x",1,-1,n,t,-e,o,r,1),g("x","z","y",1,1,e,n,t,s,o,2),g("x","z","y",1,-1,e,n,-t,s,o,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new ot(c,3)),this.setAttribute("normal",new ot(h,3)),this.setAttribute("uv",new ot(u,2));function g(_,m,p,y,x,M,A,T,R,N,b){let E=M/R,O=A/N,W=M/2,ne=A/2,I=T/2,U=R+1,V=N+1,K=0,Y=0,q=new C;for(let ee=0;ee<V;ee++){let se=ee*O-ne;for(let me=0;me<U;me++){let G=me*E-W;q[_]=G*y,q[m]=se*x,q[p]=I,c.push(q.x,q.y,q.z),q[_]=0,q[m]=0,q[p]=T>0?1:-1,h.push(q.x,q.y,q.z),u.push(me/R),u.push(1-ee/N),K+=1}}for(let ee=0;ee<N;ee++)for(let se=0;se<R;se++){let me=d+se+U*ee,G=d+se+U*(ee+1),Z=d+(se+1)+U*(ee+1),fe=d+(se+1)+U*ee;l.push(me,G,fe),l.push(G,Z,fe),Y+=6}a.addGroup(f,Y,b),f+=Y,d+=K}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function Fs(i){let e={};for(let t in i){e[t]={};for(let n in i[t]){let s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function rn(i){let e={};for(let t=0;t<i.length;t++){let n=Fs(i[t]);for(let s in n)e[s]=n[s]}return e}function Km(i){let e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function Xd(i){return i.getRenderTarget()===null?i.outputColorSpace:at.workingColorSpace}var jm={clone:Fs,merge:rn},$m=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Zm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Fn=class extends _n{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=$m,this.fragmentShader=Zm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Fs(e.uniforms),this.uniformsGroups=Km(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}},Ha=class extends vt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ze,this.projectionMatrix=new ze,this.projectionMatrixInverse=new ze,this.coordinateSystem=ai}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Ct=class extends Ha{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=Us*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(dr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Us*2*Math.atan(Math.tan(dr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(dr*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,t-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},ys=-90,vs=1,zl=class extends vt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Ct(ys,vs,e,t);s.layers=this.layers,this.add(s);let r=new Ct(ys,vs,e,t);r.layers=this.layers,this.add(r);let o=new Ct(ys,vs,e,t);o.layers=this.layers,this.add(o);let a=new Ct(ys,vs,e,t);a.layers=this.layers,this.add(a);let l=new Ct(ys,vs,e,t);l.layers=this.layers,this.add(l);let c=new Ct(ys,vs,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,a,l]=t;for(let c of t)this.remove(c);if(e===ai)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Na)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;let _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,o),e.setRenderTarget(n,2,s),e.render(t,a),e.setRenderTarget(n,3,s),e.render(t,l),e.setRenderTarget(n,4,s),e.render(t,c),n.texture.generateMipmaps=_,e.setRenderTarget(n,5,s),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},Va=class extends Gt{constructor(e,t,n,s,r,o,a,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:Ls,super(e,t,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Hl=class extends oi{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];t.encoding!==void 0&&(pr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===$i?ut:Mn),this.texture=new Va(s,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:an}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Xt(5,5,5),r=new Fn({name:"CubemapFromEquirect",uniforms:Fs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:zt,blending:Ai});r.uniforms.tEquirect.value=t;let o=new je(s,r),a=t.minFilter;return t.minFilter===Pi&&(t.minFilter=an),new zl(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,s){let r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}},vl=new C,Jm=new C,Qm=new Ke,Nn=class{constructor(e=new C(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let s=vl.subVectors(n,t).cross(Jm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let n=e.delta(vl),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||Qm.getNormalMatrix(e),s=this.coplanarPoint(vl).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},Wi=new gn,ya=new C,br=class{constructor(e=new Nn,t=new Nn,n=new Nn,s=new Nn,r=new Nn,o=new Nn){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){let a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ai){let n=this.planes,s=e.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],f=s[8],g=s[9],_=s[10],m=s[11],p=s[12],y=s[13],x=s[14],M=s[15];if(n[0].setComponents(l-r,d-c,m-f,M-p).normalize(),n[1].setComponents(l+r,d+c,m+f,M+p).normalize(),n[2].setComponents(l+o,d+h,m+g,M+y).normalize(),n[3].setComponents(l-o,d-h,m-g,M-y).normalize(),n[4].setComponents(l-a,d-u,m-_,M-x).normalize(),t===ai)n[5].setComponents(l+a,d+u,m+_,M+x).normalize();else if(t===Na)n[5].setComponents(a,u,_,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Wi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Wi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Wi)}intersectsSprite(e){return Wi.center.set(0,0,0),Wi.radius=.7071067811865476,Wi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Wi)}intersectsSphere(e){let t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let s=t[n];if(ya.x=s.normal.x>0?e.max.x:e.min.x,ya.y=s.normal.y>0?e.max.y:e.min.y,ya.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(ya)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function qd(){let i=null,e=!1,t=null,n=null;function s(r,o){t(r,o),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function eg(i,e){let t=e.isWebGL2,n=new WeakMap;function s(c,h){let u=c.array,d=c.usage,f=u.byteLength,g=i.createBuffer();i.bindBuffer(h,g),i.bufferData(h,u,d),c.onUploadCallback();let _;if(u instanceof Float32Array)_=i.FLOAT;else if(u instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(t)_=i.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else _=i.UNSIGNED_SHORT;else if(u instanceof Int16Array)_=i.SHORT;else if(u instanceof Uint32Array)_=i.UNSIGNED_INT;else if(u instanceof Int32Array)_=i.INT;else if(u instanceof Int8Array)_=i.BYTE;else if(u instanceof Uint8Array)_=i.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)_=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:g,type:_,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:f}}function r(c,h,u){let d=h.array,f=h._updateRange,g=h.updateRanges;if(i.bindBuffer(u,c),f.count===-1&&g.length===0&&i.bufferSubData(u,0,d),g.length!==0){for(let _=0,m=g.length;_<m;_++){let p=g[_];t?i.bufferSubData(u,p.start*d.BYTES_PER_ELEMENT,d,p.start,p.count):i.bufferSubData(u,p.start*d.BYTES_PER_ELEMENT,d.subarray(p.start,p.start+p.count))}h.clearUpdateRanges()}f.count!==-1&&(t?i.bufferSubData(u,f.offset*d.BYTES_PER_ELEMENT,d,f.offset,f.count):i.bufferSubData(u,f.offset*d.BYTES_PER_ELEMENT,d.subarray(f.offset,f.offset+f.count)),f.count=-1),h.onUploadCallback()}function o(c){return c.isInterleavedBufferAttribute&&(c=c.data),n.get(c)}function a(c){c.isInterleavedBufferAttribute&&(c=c.data);let h=n.get(c);h&&(i.deleteBuffer(h.buffer),n.delete(c))}function l(c,h){if(c.isGLBufferAttribute){let d=n.get(c);(!d||d.version<c.version)&&n.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);let u=n.get(c);if(u===void 0)n.set(c,s(c,h));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,c,h),u.version=c.version}}return{get:o,remove:a,update:l}}var Qi=class i extends Tt{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};let r=e/2,o=t/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=e/a,d=t/l,f=[],g=[],_=[],m=[];for(let p=0;p<h;p++){let y=p*d-o;for(let x=0;x<c;x++){let M=x*u-r;g.push(M,-y,0),_.push(0,0,1),m.push(x/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let y=0;y<a;y++){let x=y+c*p,M=y+c*(p+1),A=y+1+c*(p+1),T=y+1+c*p;f.push(x,M,T),f.push(M,A,T)}this.setIndex(f),this.setAttribute("position",new ot(g,3)),this.setAttribute("normal",new ot(_,3)),this.setAttribute("uv",new ot(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.widthSegments,e.heightSegments)}},tg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,ng=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,ig=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,sg=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,rg=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,ag=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,og=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,lg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,cg=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,hg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,ug=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,dg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,fg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,pg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,mg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,gg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,_g=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,xg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,yg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,vg=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,bg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Mg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,wg=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Sg=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Eg=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Tg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Ag=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Rg=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Cg=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Pg=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Lg="gl_FragColor = linearToOutputTexel( gl_FragColor );",Ig=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Dg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Ng=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Ug=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Og=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Fg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Bg=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,kg=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,zg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Hg=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Vg=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Gg=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Wg=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Xg=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,qg=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Yg=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Kg=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,jg=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,$g=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Zg=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Jg=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Qg=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,e0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,t0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,n0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,i0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,s0=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,r0=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,a0=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,o0=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,l0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,c0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,h0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,u0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,d0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,f0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,p0=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,m0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,g0=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,_0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,x0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,y0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,v0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,b0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,M0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,w0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,S0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,E0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,T0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,A0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,R0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,C0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,P0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,L0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,I0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,D0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,N0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,U0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,O0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,F0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,B0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,k0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,z0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,H0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,V0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,G0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,W0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,X0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,q0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Y0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,K0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,j0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,$0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Z0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,J0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Q0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,e_=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,t_=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,n_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,i_=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,s_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,r_=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,a_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,o_=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,l_=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,c_=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,h_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,u_=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,d_=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,f_=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,p_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,m_=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,g_=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,__=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,x_=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,y_=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,v_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,b_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,M_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,w_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,S_=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,E_=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,T_=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,A_=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,R_=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,C_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,P_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,L_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,I_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,D_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ge={alphahash_fragment:tg,alphahash_pars_fragment:ng,alphamap_fragment:ig,alphamap_pars_fragment:sg,alphatest_fragment:rg,alphatest_pars_fragment:ag,aomap_fragment:og,aomap_pars_fragment:lg,batching_pars_vertex:cg,batching_vertex:hg,begin_vertex:ug,beginnormal_vertex:dg,bsdfs:fg,iridescence_fragment:pg,bumpmap_pars_fragment:mg,clipping_planes_fragment:gg,clipping_planes_pars_fragment:_g,clipping_planes_pars_vertex:xg,clipping_planes_vertex:yg,color_fragment:vg,color_pars_fragment:bg,color_pars_vertex:Mg,color_vertex:wg,common:Sg,cube_uv_reflection_fragment:Eg,defaultnormal_vertex:Tg,displacementmap_pars_vertex:Ag,displacementmap_vertex:Rg,emissivemap_fragment:Cg,emissivemap_pars_fragment:Pg,colorspace_fragment:Lg,colorspace_pars_fragment:Ig,envmap_fragment:Dg,envmap_common_pars_fragment:Ng,envmap_pars_fragment:Ug,envmap_pars_vertex:Og,envmap_physical_pars_fragment:Kg,envmap_vertex:Fg,fog_vertex:Bg,fog_pars_vertex:kg,fog_fragment:zg,fog_pars_fragment:Hg,gradientmap_pars_fragment:Vg,lightmap_fragment:Gg,lightmap_pars_fragment:Wg,lights_lambert_fragment:Xg,lights_lambert_pars_fragment:qg,lights_pars_begin:Yg,lights_toon_fragment:jg,lights_toon_pars_fragment:$g,lights_phong_fragment:Zg,lights_phong_pars_fragment:Jg,lights_physical_fragment:Qg,lights_physical_pars_fragment:e0,lights_fragment_begin:t0,lights_fragment_maps:n0,lights_fragment_end:i0,logdepthbuf_fragment:s0,logdepthbuf_pars_fragment:r0,logdepthbuf_pars_vertex:a0,logdepthbuf_vertex:o0,map_fragment:l0,map_pars_fragment:c0,map_particle_fragment:h0,map_particle_pars_fragment:u0,metalnessmap_fragment:d0,metalnessmap_pars_fragment:f0,morphcolor_vertex:p0,morphnormal_vertex:m0,morphtarget_pars_vertex:g0,morphtarget_vertex:_0,normal_fragment_begin:x0,normal_fragment_maps:y0,normal_pars_fragment:v0,normal_pars_vertex:b0,normal_vertex:M0,normalmap_pars_fragment:w0,clearcoat_normal_fragment_begin:S0,clearcoat_normal_fragment_maps:E0,clearcoat_pars_fragment:T0,iridescence_pars_fragment:A0,opaque_fragment:R0,packing:C0,premultiplied_alpha_fragment:P0,project_vertex:L0,dithering_fragment:I0,dithering_pars_fragment:D0,roughnessmap_fragment:N0,roughnessmap_pars_fragment:U0,shadowmap_pars_fragment:O0,shadowmap_pars_vertex:F0,shadowmap_vertex:B0,shadowmask_pars_fragment:k0,skinbase_vertex:z0,skinning_pars_vertex:H0,skinning_vertex:V0,skinnormal_vertex:G0,specularmap_fragment:W0,specularmap_pars_fragment:X0,tonemapping_fragment:q0,tonemapping_pars_fragment:Y0,transmission_fragment:K0,transmission_pars_fragment:j0,uv_pars_fragment:$0,uv_pars_vertex:Z0,uv_vertex:J0,worldpos_vertex:Q0,background_vert:e_,background_frag:t_,backgroundCube_vert:n_,backgroundCube_frag:i_,cube_vert:s_,cube_frag:r_,depth_vert:a_,depth_frag:o_,distanceRGBA_vert:l_,distanceRGBA_frag:c_,equirect_vert:h_,equirect_frag:u_,linedashed_vert:d_,linedashed_frag:f_,meshbasic_vert:p_,meshbasic_frag:m_,meshlambert_vert:g_,meshlambert_frag:__,meshmatcap_vert:x_,meshmatcap_frag:y_,meshnormal_vert:v_,meshnormal_frag:b_,meshphong_vert:M_,meshphong_frag:w_,meshphysical_vert:S_,meshphysical_frag:E_,meshtoon_vert:T_,meshtoon_frag:A_,points_vert:R_,points_frag:C_,shadow_vert:P_,shadow_frag:L_,sprite_vert:I_,sprite_frag:D_},ue={common:{diffuse:{value:new Te(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ke},alphaMap:{value:null},alphaMapTransform:{value:new Ke},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ke}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ke}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ke}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ke},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ke},normalScale:{value:new Re(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ke},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ke}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ke}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ke}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Te(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Te(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ke},alphaTest:{value:0},uvTransform:{value:new Ke}},sprite:{diffuse:{value:new Te(16777215)},opacity:{value:1},center:{value:new Re(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ke},alphaMap:{value:null},alphaMapTransform:{value:new Ke},alphaTest:{value:0}}},Vn={basic:{uniforms:rn([ue.common,ue.specularmap,ue.envmap,ue.aomap,ue.lightmap,ue.fog]),vertexShader:Ge.meshbasic_vert,fragmentShader:Ge.meshbasic_frag},lambert:{uniforms:rn([ue.common,ue.specularmap,ue.envmap,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.fog,ue.lights,{emissive:{value:new Te(0)}}]),vertexShader:Ge.meshlambert_vert,fragmentShader:Ge.meshlambert_frag},phong:{uniforms:rn([ue.common,ue.specularmap,ue.envmap,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.fog,ue.lights,{emissive:{value:new Te(0)},specular:{value:new Te(1118481)},shininess:{value:30}}]),vertexShader:Ge.meshphong_vert,fragmentShader:Ge.meshphong_frag},standard:{uniforms:rn([ue.common,ue.envmap,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.roughnessmap,ue.metalnessmap,ue.fog,ue.lights,{emissive:{value:new Te(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ge.meshphysical_vert,fragmentShader:Ge.meshphysical_frag},toon:{uniforms:rn([ue.common,ue.aomap,ue.lightmap,ue.emissivemap,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.gradientmap,ue.fog,ue.lights,{emissive:{value:new Te(0)}}]),vertexShader:Ge.meshtoon_vert,fragmentShader:Ge.meshtoon_frag},matcap:{uniforms:rn([ue.common,ue.bumpmap,ue.normalmap,ue.displacementmap,ue.fog,{matcap:{value:null}}]),vertexShader:Ge.meshmatcap_vert,fragmentShader:Ge.meshmatcap_frag},points:{uniforms:rn([ue.points,ue.fog]),vertexShader:Ge.points_vert,fragmentShader:Ge.points_frag},dashed:{uniforms:rn([ue.common,ue.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ge.linedashed_vert,fragmentShader:Ge.linedashed_frag},depth:{uniforms:rn([ue.common,ue.displacementmap]),vertexShader:Ge.depth_vert,fragmentShader:Ge.depth_frag},normal:{uniforms:rn([ue.common,ue.bumpmap,ue.normalmap,ue.displacementmap,{opacity:{value:1}}]),vertexShader:Ge.meshnormal_vert,fragmentShader:Ge.meshnormal_frag},sprite:{uniforms:rn([ue.sprite,ue.fog]),vertexShader:Ge.sprite_vert,fragmentShader:Ge.sprite_frag},background:{uniforms:{uvTransform:{value:new Ke},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ge.background_vert,fragmentShader:Ge.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ge.backgroundCube_vert,fragmentShader:Ge.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ge.cube_vert,fragmentShader:Ge.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ge.equirect_vert,fragmentShader:Ge.equirect_frag},distanceRGBA:{uniforms:rn([ue.common,ue.displacementmap,{referencePosition:{value:new C},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ge.distanceRGBA_vert,fragmentShader:Ge.distanceRGBA_frag},shadow:{uniforms:rn([ue.lights,ue.fog,{color:{value:new Te(0)},opacity:{value:1}}]),vertexShader:Ge.shadow_vert,fragmentShader:Ge.shadow_frag}};Vn.physical={uniforms:rn([Vn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ke},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ke},clearcoatNormalScale:{value:new Re(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ke},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ke},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ke},sheen:{value:0},sheenColor:{value:new Te(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ke},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ke},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ke},transmissionSamplerSize:{value:new Re},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ke},attenuationDistance:{value:0},attenuationColor:{value:new Te(0)},specularColor:{value:new Te(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ke},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ke},anisotropyVector:{value:new Re},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ke}}]),vertexShader:Ge.meshphysical_vert,fragmentShader:Ge.meshphysical_frag};var va={r:0,b:0,g:0};function N_(i,e,t,n,s,r,o){let a=new Te(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(m,p){let y=!1,x=p.isScene===!0?p.background:null;x&&x.isTexture&&(x=(p.backgroundBlurriness>0?t:e).get(x)),x===null?_(a,l):x&&x.isColor&&(_(x,1),y=!0);let M=i.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,o):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||y)&&i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil),x&&(x.isCubeTexture||x.mapping===ro)?(h===void 0&&(h=new je(new Xt(1,1,1),new Fn({name:"BackgroundCubeMaterial",uniforms:Fs(Vn.backgroundCube.uniforms),vertexShader:Vn.backgroundCube.vertexShader,fragmentShader:Vn.backgroundCube.fragmentShader,side:zt,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(A,T,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=x,h.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=p.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,h.material.toneMapped=at.getTransfer(x.colorSpace)!==mt,(u!==x||d!==x.version||f!==i.toneMapping)&&(h.material.needsUpdate=!0,u=x,d=x.version,f=i.toneMapping),h.layers.enableAll(),m.unshift(h,h.geometry,h.material,0,0,null)):x&&x.isTexture&&(c===void 0&&(c=new je(new Qi(2,2),new Fn({name:"BackgroundMaterial",uniforms:Fs(Vn.background.uniforms),vertexShader:Vn.background.vertexShader,fragmentShader:Vn.background.fragmentShader,side:Wn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=x,c.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,c.material.toneMapped=at.getTransfer(x.colorSpace)!==mt,x.matrixAutoUpdate===!0&&x.updateMatrix(),c.material.uniforms.uvTransform.value.copy(x.matrix),(u!==x||d!==x.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,u=x,d=x.version,f=i.toneMapping),c.layers.enableAll(),m.unshift(c,c.geometry,c.material,0,0,null))}function _(m,p){m.getRGB(va,Xd(i)),n.buffers.color.setClear(va.r,va.g,va.b,p,o)}return{getClearColor:function(){return a},setClearColor:function(m,p=1){a.set(m),l=p,_(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(m){l=m,_(a,l)},render:g}}function U_(i,e,t,n){let s=i.getParameter(i.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:e.get("OES_vertex_array_object"),o=n.isWebGL2||r!==null,a={},l=m(null),c=l,h=!1;function u(I,U,V,K,Y){let q=!1;if(o){let ee=_(K,V,U);c!==ee&&(c=ee,f(c.object)),q=p(I,K,V,Y),q&&y(I,K,V,Y)}else{let ee=U.wireframe===!0;(c.geometry!==K.id||c.program!==V.id||c.wireframe!==ee)&&(c.geometry=K.id,c.program=V.id,c.wireframe=ee,q=!0)}Y!==null&&t.update(Y,i.ELEMENT_ARRAY_BUFFER),(q||h)&&(h=!1,N(I,U,V,K),Y!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(Y).buffer))}function d(){return n.isWebGL2?i.createVertexArray():r.createVertexArrayOES()}function f(I){return n.isWebGL2?i.bindVertexArray(I):r.bindVertexArrayOES(I)}function g(I){return n.isWebGL2?i.deleteVertexArray(I):r.deleteVertexArrayOES(I)}function _(I,U,V){let K=V.wireframe===!0,Y=a[I.id];Y===void 0&&(Y={},a[I.id]=Y);let q=Y[U.id];q===void 0&&(q={},Y[U.id]=q);let ee=q[K];return ee===void 0&&(ee=m(d()),q[K]=ee),ee}function m(I){let U=[],V=[],K=[];for(let Y=0;Y<s;Y++)U[Y]=0,V[Y]=0,K[Y]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:U,enabledAttributes:V,attributeDivisors:K,object:I,attributes:{},index:null}}function p(I,U,V,K){let Y=c.attributes,q=U.attributes,ee=0,se=V.getAttributes();for(let me in se)if(se[me].location>=0){let Z=Y[me],fe=q[me];if(fe===void 0&&(me==="instanceMatrix"&&I.instanceMatrix&&(fe=I.instanceMatrix),me==="instanceColor"&&I.instanceColor&&(fe=I.instanceColor)),Z===void 0||Z.attribute!==fe||fe&&Z.data!==fe.data)return!0;ee++}return c.attributesNum!==ee||c.index!==K}function y(I,U,V,K){let Y={},q=U.attributes,ee=0,se=V.getAttributes();for(let me in se)if(se[me].location>=0){let Z=q[me];Z===void 0&&(me==="instanceMatrix"&&I.instanceMatrix&&(Z=I.instanceMatrix),me==="instanceColor"&&I.instanceColor&&(Z=I.instanceColor));let fe={};fe.attribute=Z,Z&&Z.data&&(fe.data=Z.data),Y[me]=fe,ee++}c.attributes=Y,c.attributesNum=ee,c.index=K}function x(){let I=c.newAttributes;for(let U=0,V=I.length;U<V;U++)I[U]=0}function M(I){A(I,0)}function A(I,U){let V=c.newAttributes,K=c.enabledAttributes,Y=c.attributeDivisors;V[I]=1,K[I]===0&&(i.enableVertexAttribArray(I),K[I]=1),Y[I]!==U&&((n.isWebGL2?i:e.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,U),Y[I]=U)}function T(){let I=c.newAttributes,U=c.enabledAttributes;for(let V=0,K=U.length;V<K;V++)U[V]!==I[V]&&(i.disableVertexAttribArray(V),U[V]=0)}function R(I,U,V,K,Y,q,ee){ee===!0?i.vertexAttribIPointer(I,U,V,Y,q):i.vertexAttribPointer(I,U,V,K,Y,q)}function N(I,U,V,K){if(n.isWebGL2===!1&&(I.isInstancedMesh||K.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;x();let Y=K.attributes,q=V.getAttributes(),ee=U.defaultAttributeValues;for(let se in q){let me=q[se];if(me.location>=0){let G=Y[se];if(G===void 0&&(se==="instanceMatrix"&&I.instanceMatrix&&(G=I.instanceMatrix),se==="instanceColor"&&I.instanceColor&&(G=I.instanceColor)),G!==void 0){let Z=G.normalized,fe=G.itemSize,we=t.get(G);if(we===void 0)continue;let ve=we.buffer,Oe=we.type,Fe=we.bytesPerElement,Le=n.isWebGL2===!0&&(Oe===i.INT||Oe===i.UNSIGNED_INT||G.gpuType===Id);if(G.isInterleavedBufferAttribute){let Ze=G.data,F=Ze.stride,Ot=G.offset;if(Ze.isInstancedInterleavedBuffer){for(let Ce=0;Ce<me.locationSize;Ce++)A(me.location+Ce,Ze.meshPerAttribute);I.isInstancedMesh!==!0&&K._maxInstanceCount===void 0&&(K._maxInstanceCount=Ze.meshPerAttribute*Ze.count)}else for(let Ce=0;Ce<me.locationSize;Ce++)M(me.location+Ce);i.bindBuffer(i.ARRAY_BUFFER,ve);for(let Ce=0;Ce<me.locationSize;Ce++)R(me.location+Ce,fe/me.locationSize,Oe,Z,F*Fe,(Ot+fe/me.locationSize*Ce)*Fe,Le)}else{if(G.isInstancedBufferAttribute){for(let Ze=0;Ze<me.locationSize;Ze++)A(me.location+Ze,G.meshPerAttribute);I.isInstancedMesh!==!0&&K._maxInstanceCount===void 0&&(K._maxInstanceCount=G.meshPerAttribute*G.count)}else for(let Ze=0;Ze<me.locationSize;Ze++)M(me.location+Ze);i.bindBuffer(i.ARRAY_BUFFER,ve);for(let Ze=0;Ze<me.locationSize;Ze++)R(me.location+Ze,fe/me.locationSize,Oe,Z,fe*Fe,fe/me.locationSize*Ze*Fe,Le)}}else if(ee!==void 0){let Z=ee[se];if(Z!==void 0)switch(Z.length){case 2:i.vertexAttrib2fv(me.location,Z);break;case 3:i.vertexAttrib3fv(me.location,Z);break;case 4:i.vertexAttrib4fv(me.location,Z);break;default:i.vertexAttrib1fv(me.location,Z)}}}}T()}function b(){W();for(let I in a){let U=a[I];for(let V in U){let K=U[V];for(let Y in K)g(K[Y].object),delete K[Y];delete U[V]}delete a[I]}}function E(I){if(a[I.id]===void 0)return;let U=a[I.id];for(let V in U){let K=U[V];for(let Y in K)g(K[Y].object),delete K[Y];delete U[V]}delete a[I.id]}function O(I){for(let U in a){let V=a[U];if(V[I.id]===void 0)continue;let K=V[I.id];for(let Y in K)g(K[Y].object),delete K[Y];delete V[I.id]}}function W(){ne(),h=!0,c!==l&&(c=l,f(c.object))}function ne(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:u,reset:W,resetDefaultState:ne,dispose:b,releaseStatesOfGeometry:E,releaseStatesOfProgram:O,initAttributes:x,enableAttribute:M,disableUnusedAttributes:T}}function O_(i,e,t,n){let s=n.isWebGL2,r;function o(h){r=h}function a(h,u){i.drawArrays(r,h,u),t.update(u,r,1)}function l(h,u,d){if(d===0)return;let f,g;if(s)f=i,g="drawArraysInstanced";else if(f=e.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",f===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}f[g](r,h,u,d),t.update(u,r,d)}function c(h,u,d){if(d===0)return;let f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<d;g++)this.render(h[g],u[g]);else{f.multiDrawArraysWEBGL(r,h,0,u,0,d);let g=0;for(let _=0;_<d;_++)g+=u[_];t.update(g,r,1)}}this.setMode=o,this.render=a,this.renderInstances=l,this.renderMultiDraw=c}function F_(i,e,t){let n;function s(){if(n!==void 0)return n;if(e.has("EXT_texture_filter_anisotropic")===!0){let R=e.get("EXT_texture_filter_anisotropic");n=i.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(R){if(R==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let o=typeof WebGL2RenderingContext<"u"&&i.constructor.name==="WebGL2RenderingContext",a=t.precision!==void 0?t.precision:"highp",l=r(a);l!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",l,"instead."),a=l);let c=o||e.has("WEBGL_draw_buffers"),h=t.logarithmicDepthBuffer===!0,u=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),d=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=i.getParameter(i.MAX_TEXTURE_SIZE),g=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),_=i.getParameter(i.MAX_VERTEX_ATTRIBS),m=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),p=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),x=d>0,M=o||e.has("OES_texture_float"),A=x&&M,T=o?i.getParameter(i.MAX_SAMPLES):0;return{isWebGL2:o,drawBuffers:c,getMaxAnisotropy:s,getMaxPrecision:r,precision:a,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:d,maxTextureSize:f,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:m,maxVaryings:p,maxFragmentUniforms:y,vertexTextures:x,floatFragmentTextures:M,floatVertexTextures:A,maxSamples:T}}function B_(i){let e=this,t=null,n=0,s=!1,r=!1,o=new Nn,a=new Ke,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){let g=u.clippingPlanes,_=u.clipIntersection,m=u.clipShadows,p=i.get(u);if(!s||g===null||g.length===0||r&&!m)r?h(null):c();else{let y=r?0:n,x=y*4,M=p.clippingState||null;l.value=M,M=h(g,d,x,f);for(let A=0;A!==x;++A)M[A]=t[A];p.clippingState=M,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=y}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,f,g){let _=u!==null?u.length:0,m=null;if(_!==0){if(m=l.value,g!==!0||m===null){let p=f+_*4,y=d.matrixWorldInverse;a.getNormalMatrix(y),(m===null||m.length<p)&&(m=new Float32Array(p));for(let x=0,M=f;x!==_;++x,M+=4)o.copy(u[x]).applyMatrix4(y,a),o.normal.toArray(m,M),m[M+3]=o.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,m}}function k_(i){let e=new WeakMap;function t(o,a){return a===Dl?o.mapping=Ls:a===Nl&&(o.mapping=Is),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Dl||a===Nl)if(e.has(o)){let l=e.get(o).texture;return t(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Hl(l.height/2);return c.fromEquirectangularTexture(i,o),e.set(o,c),o.addEventListener("dispose",s),t(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}var Bs=class extends Ha{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-e,o=n+e,a=s+t,l=s-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Ts=4,Hu=[.125,.215,.35,.446,.526,.582],Yi=20,bl=new Bs,Vu=new Te,Ml=null,wl=0,Sl=0,Xi=(1+Math.sqrt(5))/2,bs=1/Xi,Gu=[new C(1,1,1),new C(-1,1,1),new C(1,1,-1),new C(-1,1,-1),new C(0,Xi,bs),new C(0,Xi,-bs),new C(bs,0,Xi),new C(-bs,0,Xi),new C(Xi,bs,0),new C(-Xi,bs,0)],ks=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100){Ml=this._renderer.getRenderTarget(),wl=this._renderer.getActiveCubeFace(),Sl=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,n,s,r),t>0&&this._blur(r,0,0,t),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=qu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Xu(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Ml,wl,Sl),e.scissorTest=!1,ba(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Ls||e.mapping===Is?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Ml=this._renderer.getRenderTarget(),wl=this._renderer.getActiveCubeFace(),Sl=this._renderer.getActiveMipmapLevel();let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:an,minFilter:an,generateMipmaps:!1,type:xr,format:bn,colorSpace:Pt,depthBuffer:!1},s=Wu(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Wu(e,t,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=z_(r)),this._blurMaterial=H_(r,e,t)}return s}_compileMaterial(e){let t=new je(this._lodPlanes[0],e);this._renderer.compile(t,bl)}_sceneToCubeUV(e,t,n,s){let a=new Ct(90,1,t,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(Vu),h.toneMapping=Ri,h.autoClear=!1;let f=new Wt({name:"PMREM.Background",side:zt,depthWrite:!1,depthTest:!1}),g=new je(new Xt,f),_=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,_=!0):(f.color.copy(Vu),_=!0);for(let p=0;p<6;p++){let y=p%3;y===0?(a.up.set(0,l[p],0),a.lookAt(c[p],0,0)):y===1?(a.up.set(0,0,l[p]),a.lookAt(0,c[p],0)):(a.up.set(0,l[p],0),a.lookAt(0,0,c[p]));let x=this._cubeSize;ba(s,y*x,p>2?x:0,x,x),h.setRenderTarget(s),_&&h.render(g,a),h.render(e,a)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,s=e.mapping===Ls||e.mapping===Is;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=qu()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Xu());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new je(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=e;let l=this._cubeSize;ba(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,bl)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=Gu[(s-1)%Gu.length];this._blur(e,s-1,s,r,o)}t.autoClear=n}_blur(e,t,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,s,"latitudinal",r),this._halfBlur(o,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new je(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*Yi-1),_=r/g,m=isFinite(r)?1+Math.floor(h*_):Yi;m>Yi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Yi}`);let p=[],y=0;for(let R=0;R<Yi;++R){let N=R/_,b=Math.exp(-N*N/2);p.push(b),R===0?y+=b:R<m&&(y+=2*b)}for(let R=0;R<p.length;R++)p[R]=p[R]/y;d.envMap.value=e.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);let{_lodMax:x}=this;d.dTheta.value=g,d.mipInt.value=x-n;let M=this._sizeLods[s],A=3*M*(s>x-Ts?s-x+Ts:0),T=4*(this._cubeSize-M);ba(t,A,T,3*M,2*M),l.setRenderTarget(t),l.render(u,bl)}};function z_(i){let e=[],t=[],n=[],s=i,r=i-Ts+1+Hu.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);t.push(a);let l=1/a;o>i-Ts?l=Hu[o-i+Ts-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,_=3,m=2,p=1,y=new Float32Array(_*g*f),x=new Float32Array(m*g*f),M=new Float32Array(p*g*f);for(let T=0;T<f;T++){let R=T%3*2/3-1,N=T>2?0:-1,b=[R,N,0,R+2/3,N,0,R+2/3,N+1,0,R,N,0,R+2/3,N+1,0,R,N+1,0];y.set(b,_*g*T),x.set(d,m*g*T);let E=[T,T,T,T,T,T];M.set(E,p*g*T)}let A=new Tt;A.setAttribute("position",new wt(y,_)),A.setAttribute("uv",new wt(x,m)),A.setAttribute("faceIndex",new wt(M,p)),e.push(A),s>Ts&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function Wu(i,e,t){let n=new oi(i,e,t);return n.texture.mapping=ro,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ba(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function H_(i,e,t){let n=new Float32Array(Yi),s=new C(0,1,0);return new Fn({name:"SphericalGaussianBlur",defines:{n:Yi,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Sc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function Xu(){return new Fn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Sc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function qu(){return new Fn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Sc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function Sc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function V_(i){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Dl||l===Nl,h=l===Ls||l===Is;if(c||h)if(a.isRenderTargetTexture&&a.needsPMREMUpdate===!0){a.needsPMREMUpdate=!1;let u=e.get(a);return t===null&&(t=new ks(i)),u=c?t.fromEquirectangular(a,u):t.fromCubemap(a,u),e.set(a,u),u.texture}else{if(e.has(a))return e.get(a).texture;{let u=a.image;if(c&&u&&u.height>0||h&&u&&s(u)){t===null&&(t=new ks(i));let d=c?t.fromEquirectangular(a):t.fromCubemap(a);return e.set(a,d),a.addEventListener("dispose",r),d.texture}else return null}}}return a}function s(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function G_(i){let e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(n){n.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(n){let s=t(n);return s===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function W_(i,e,t,n){let s={},r=new WeakMap;function o(u){let d=u.target;d.index!==null&&e.remove(d.index);for(let g in d.attributes)e.remove(d.attributes[g]);for(let g in d.morphAttributes){let _=d.morphAttributes[g];for(let m=0,p=_.length;m<p;m++)e.remove(_[m])}d.removeEventListener("dispose",o),delete s[d.id];let f=r.get(d);f&&(e.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,t.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)e.update(d[g],i.ARRAY_BUFFER);let f=u.morphAttributes;for(let g in f){let _=f[g];for(let m=0,p=_.length;m<p;m++)e.update(_[m],i.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,g=u.attributes.position,_=0;if(f!==null){let y=f.array;_=f.version;for(let x=0,M=y.length;x<M;x+=3){let A=y[x+0],T=y[x+1],R=y[x+2];d.push(A,T,T,R,R,A)}}else if(g!==void 0){let y=g.array;_=g.version;for(let x=0,M=y.length/3-1;x<M;x+=3){let A=x+0,T=x+1,R=x+2;d.push(A,T,T,R,R,A)}}else return;let m=new(Gd(d)?za:ka)(d,1);m.version=_;let p=r.get(u);p&&e.remove(p),r.set(u,m)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function X_(i,e,t,n){let s=n.isWebGL2,r;function o(f){r=f}let a,l;function c(f){a=f.type,l=f.bytesPerElement}function h(f,g){i.drawElements(r,g,a,f*l),t.update(g,r,1)}function u(f,g,_){if(_===0)return;let m,p;if(s)m=i,p="drawElementsInstanced";else if(m=e.get("ANGLE_instanced_arrays"),p="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[p](r,g,a,f*l,_),t.update(g,r,_)}function d(f,g,_){if(_===0)return;let m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<_;p++)this.render(f[p]/l,g[p]);else{m.multiDrawElementsWEBGL(r,g,0,a,f,0,_);let p=0;for(let y=0;y<_;y++)p+=g[y];t.update(p,r,1)}}this.setMode=o,this.setIndex=c,this.render=h,this.renderInstances=u,this.renderMultiDraw=d}function q_(i){let e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(r/3);break;case i.LINES:t.lines+=a*(r/2);break;case i.LINE_STRIP:t.lines+=a*(r-1);break;case i.LINE_LOOP:t.lines+=a*r;break;case i.POINTS:t.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function Y_(i,e){return i[0]-e[0]}function K_(i,e){return Math.abs(e[1])-Math.abs(i[1])}function j_(i,e,t){let n={},s=new Float32Array(8),r=new WeakMap,o=new dt,a=[];for(let c=0;c<8;c++)a[c]=[c,0];function l(c,h,u){let d=c.morphTargetInfluences;if(e.isWebGL2===!0){let f=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=f!==void 0?f.length:0,_=r.get(h);if(_===void 0||_.count!==g){let I=function(){W.dispose(),r.delete(h),h.removeEventListener("dispose",I)};_!==void 0&&_.texture.dispose();let y=h.morphAttributes.position!==void 0,x=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,A=h.morphAttributes.position||[],T=h.morphAttributes.normal||[],R=h.morphAttributes.color||[],N=0;y===!0&&(N=1),x===!0&&(N=2),M===!0&&(N=3);let b=h.attributes.position.count*N,E=1;b>e.maxTextureSize&&(E=Math.ceil(b/e.maxTextureSize),b=e.maxTextureSize);let O=new Float32Array(b*E*4*g),W=new Ba(O,b,E,g);W.type=ri,W.needsUpdate=!0;let ne=N*4;for(let U=0;U<g;U++){let V=A[U],K=T[U],Y=R[U],q=b*E*4*U;for(let ee=0;ee<V.count;ee++){let se=ee*ne;y===!0&&(o.fromBufferAttribute(V,ee),O[q+se+0]=o.x,O[q+se+1]=o.y,O[q+se+2]=o.z,O[q+se+3]=0),x===!0&&(o.fromBufferAttribute(K,ee),O[q+se+4]=o.x,O[q+se+5]=o.y,O[q+se+6]=o.z,O[q+se+7]=0),M===!0&&(o.fromBufferAttribute(Y,ee),O[q+se+8]=o.x,O[q+se+9]=o.y,O[q+se+10]=o.z,O[q+se+11]=Y.itemSize===4?o.w:1)}}_={count:g,texture:W,size:new Re(b,E)},r.set(h,_),h.addEventListener("dispose",I)}let m=0;for(let y=0;y<d.length;y++)m+=d[y];let p=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(i,"morphTargetBaseInfluence",p),u.getUniforms().setValue(i,"morphTargetInfluences",d),u.getUniforms().setValue(i,"morphTargetsTexture",_.texture,t),u.getUniforms().setValue(i,"morphTargetsTextureSize",_.size)}else{let f=d===void 0?0:d.length,g=n[h.id];if(g===void 0||g.length!==f){g=[];for(let x=0;x<f;x++)g[x]=[x,0];n[h.id]=g}for(let x=0;x<f;x++){let M=g[x];M[0]=x,M[1]=d[x]}g.sort(K_);for(let x=0;x<8;x++)x<f&&g[x][1]?(a[x][0]=g[x][0],a[x][1]=g[x][1]):(a[x][0]=Number.MAX_SAFE_INTEGER,a[x][1]=0);a.sort(Y_);let _=h.morphAttributes.position,m=h.morphAttributes.normal,p=0;for(let x=0;x<8;x++){let M=a[x],A=M[0],T=M[1];A!==Number.MAX_SAFE_INTEGER&&T?(_&&h.getAttribute("morphTarget"+x)!==_[A]&&h.setAttribute("morphTarget"+x,_[A]),m&&h.getAttribute("morphNormal"+x)!==m[A]&&h.setAttribute("morphNormal"+x,m[A]),s[x]=T,p+=T):(_&&h.hasAttribute("morphTarget"+x)===!0&&h.deleteAttribute("morphTarget"+x),m&&h.hasAttribute("morphNormal"+x)===!0&&h.deleteAttribute("morphNormal"+x),s[x]=0)}let y=h.morphTargetsRelative?1:1-p;u.getUniforms().setValue(i,"morphTargetBaseInfluence",y),u.getUniforms().setValue(i,"morphTargetInfluences",s)}}return{update:l}}function $_(i,e,t,n){let s=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=e.get(l,h);if(s.get(u)!==c&&(e.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:r,dispose:o}}var Ga=class extends Gt{constructor(e,t,n,s,r,o,a,l,c,h){if(h=h!==void 0?h:ji,h!==ji&&h!==Ds)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===ji&&(n=Ei),n===void 0&&h===Ds&&(n=Ki),super(null,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:Rt,this.minFilter=l!==void 0?l:Rt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},Yd=new Gt,Kd=new Ga(1,1);Kd.compareFunction=Vd;var jd=new Ba,$d=new kl,Zd=new Va,Yu=[],Ku=[],ju=new Float32Array(16),$u=new Float32Array(9),Zu=new Float32Array(4);function qs(i,e,t){let n=i[0];if(n<=0||n>0)return i;let s=e*t,r=Yu[s];if(r===void 0&&(r=new Float32Array(s),Yu[s]=r),e!==0){n.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(r,a)}return r}function Lt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function It(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function lo(i,e){let t=Ku[e];t===void 0&&(t=new Int32Array(e),Ku[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Z_(i,e){let t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function J_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Lt(t,e))return;i.uniform2fv(this.addr,e),It(t,e)}}function Q_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Lt(t,e))return;i.uniform3fv(this.addr,e),It(t,e)}}function ex(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Lt(t,e))return;i.uniform4fv(this.addr,e),It(t,e)}}function tx(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(Lt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),It(t,e)}else{if(Lt(t,n))return;Zu.set(n),i.uniformMatrix2fv(this.addr,!1,Zu),It(t,n)}}function nx(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(Lt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),It(t,e)}else{if(Lt(t,n))return;$u.set(n),i.uniformMatrix3fv(this.addr,!1,$u),It(t,n)}}function ix(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(Lt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),It(t,e)}else{if(Lt(t,n))return;ju.set(n),i.uniformMatrix4fv(this.addr,!1,ju),It(t,n)}}function sx(i,e){let t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function rx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Lt(t,e))return;i.uniform2iv(this.addr,e),It(t,e)}}function ax(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Lt(t,e))return;i.uniform3iv(this.addr,e),It(t,e)}}function ox(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Lt(t,e))return;i.uniform4iv(this.addr,e),It(t,e)}}function lx(i,e){let t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function cx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Lt(t,e))return;i.uniform2uiv(this.addr,e),It(t,e)}}function hx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Lt(t,e))return;i.uniform3uiv(this.addr,e),It(t,e)}}function ux(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Lt(t,e))return;i.uniform4uiv(this.addr,e),It(t,e)}}function dx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r=this.type===i.SAMPLER_2D_SHADOW?Kd:Yd;t.setTexture2D(e||r,s)}function fx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||$d,s)}function px(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||Zd,s)}function mx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||jd,s)}function gx(i){switch(i){case 5126:return Z_;case 35664:return J_;case 35665:return Q_;case 35666:return ex;case 35674:return tx;case 35675:return nx;case 35676:return ix;case 5124:case 35670:return sx;case 35667:case 35671:return rx;case 35668:case 35672:return ax;case 35669:case 35673:return ox;case 5125:return lx;case 36294:return cx;case 36295:return hx;case 36296:return ux;case 35678:case 36198:case 36298:case 36306:case 35682:return dx;case 35679:case 36299:case 36307:return fx;case 35680:case 36300:case 36308:case 36293:return px;case 36289:case 36303:case 36311:case 36292:return mx}}function _x(i,e){i.uniform1fv(this.addr,e)}function xx(i,e){let t=qs(e,this.size,2);i.uniform2fv(this.addr,t)}function yx(i,e){let t=qs(e,this.size,3);i.uniform3fv(this.addr,t)}function vx(i,e){let t=qs(e,this.size,4);i.uniform4fv(this.addr,t)}function bx(i,e){let t=qs(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function Mx(i,e){let t=qs(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function wx(i,e){let t=qs(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function Sx(i,e){i.uniform1iv(this.addr,e)}function Ex(i,e){i.uniform2iv(this.addr,e)}function Tx(i,e){i.uniform3iv(this.addr,e)}function Ax(i,e){i.uniform4iv(this.addr,e)}function Rx(i,e){i.uniform1uiv(this.addr,e)}function Cx(i,e){i.uniform2uiv(this.addr,e)}function Px(i,e){i.uniform3uiv(this.addr,e)}function Lx(i,e){i.uniform4uiv(this.addr,e)}function Ix(i,e,t){let n=this.cache,s=e.length,r=lo(t,s);Lt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||Yd,r[o])}function Dx(i,e,t){let n=this.cache,s=e.length,r=lo(t,s);Lt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||$d,r[o])}function Nx(i,e,t){let n=this.cache,s=e.length,r=lo(t,s);Lt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Zd,r[o])}function Ux(i,e,t){let n=this.cache,s=e.length,r=lo(t,s);Lt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||jd,r[o])}function Ox(i){switch(i){case 5126:return _x;case 35664:return xx;case 35665:return yx;case 35666:return vx;case 35674:return bx;case 35675:return Mx;case 35676:return wx;case 5124:case 35670:return Sx;case 35667:case 35671:return Ex;case 35668:case 35672:return Tx;case 35669:case 35673:return Ax;case 5125:return Rx;case 36294:return Cx;case 36295:return Px;case 36296:return Lx;case 35678:case 36198:case 36298:case 36306:case 35682:return Ix;case 35679:case 36299:case 36307:return Dx;case 35680:case 36300:case 36308:case 36293:return Nx;case 36289:case 36303:case 36311:case 36292:return Ux}}var Vl=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=gx(t.type)}},Gl=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Ox(t.type)}},Wl=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(e,t[a.id],n)}}},El=/(\w+)(\])?(\[|\.)?/g;function Ju(i,e){i.seq.push(e),i.map[e.id]=e}function Fx(i,e,t){let n=i.name,s=n.length;for(El.lastIndex=0;;){let r=El.exec(n),o=El.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){Ju(t,c===void 0?new Vl(a,i,e):new Gl(a,i,e));break}else{let u=t.map[a];u===void 0&&(u=new Wl(a),Ju(t,u)),t=u}}}var Ps=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);Fx(r,o,this)}}setValue(e,t,n,s){let r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){let s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){let a=t[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,s)}}static seqWithValue(e,t){let n=[];for(let s=0,r=e.length;s!==r;++s){let o=e[s];o.id in t&&n.push(o)}return n}};function Qu(i,e,t){let n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}var Bx=37297,kx=0;function zx(i,e){let t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}function Hx(i){let e=at.getPrimaries(at.workingColorSpace),t=at.getPrimaries(i),n;switch(e===t?n="":e===Da&&t===Ia?n="LinearDisplayP3ToLinearSRGB":e===Ia&&t===Da&&(n="LinearSRGBToLinearDisplayP3"),i){case Pt:case oo:return[n,"LinearTransferOETF"];case ut:case Mc:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[n,"LinearTransferOETF"]}}function ed(i,e,t){let n=i.getShaderParameter(e,i.COMPILE_STATUS),s=i.getShaderInfoLog(e).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return t.toUpperCase()+`

`+s+`

`+zx(i.getShaderSource(e),o)}else return s}function Vx(i,e){let t=Hx(e);return`vec4 ${i}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function Gx(i,e){let t;switch(e){case Yp:t="Linear";break;case Kp:t="Reinhard";break;case jp:t="OptimizedCineon";break;case gc:t="ACESFilmic";break;case Zp:t="AgX";break;case $p:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function Wx(i){return[i.extensionDerivatives||i.envMapCubeUVHeight||i.bumpMap||i.normalMapTangentSpace||i.clearcoatNormalMap||i.flatShading||i.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(i.extensionFragDepth||i.logarithmicDepthBuffer)&&i.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",i.extensionDrawBuffers&&i.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(i.extensionShaderTextureLOD||i.envMap||i.transmission)&&i.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(As).join(`
`)}function Xx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(As).join(`
`)}function qx(i){let e=[];for(let t in i){let n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Yx(i,e){let t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(e,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function As(i){return i!==""}function td(i,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function nd(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var Kx=/^[ \t]*#include +<([\w\d./]+)>/gm;function Xl(i){return i.replace(Kx,$x)}var jx=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function $x(i,e){let t=Ge[e];if(t===void 0){let n=jx.get(e);if(n!==void 0)t=Ge[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Xl(t)}var Zx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function id(i){return i.replace(Zx,Jx)}function Jx(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function sd(i){let e="precision "+i.precision+` float;
precision `+i.precision+" int;";return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Qx(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Cd?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===mc?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===si&&(e="SHADOWMAP_TYPE_VSM"),e}function ey(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Ls:case Is:e="ENVMAP_TYPE_CUBE";break;case ro:e="ENVMAP_TYPE_CUBE_UV";break}return e}function ty(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Is:e="ENVMAP_MODE_REFRACTION";break}return e}function ny(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Pd:e="ENVMAP_BLENDING_MULTIPLY";break;case Xp:e="ENVMAP_BLENDING_MIX";break;case qp:e="ENVMAP_BLENDING_ADD";break}return e}function iy(i){let e=i.envMapCubeUVHeight;if(e===null)return null;let t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function sy(i,e,t,n){let s=i.getContext(),r=t.defines,o=t.vertexShader,a=t.fragmentShader,l=Qx(t),c=ey(t),h=ty(t),u=ny(t),d=iy(t),f=t.isWebGL2?"":Wx(t),g=Xx(t),_=qx(r),m=s.createProgram(),p,y,x=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_].filter(As).join(`
`),p.length>0&&(p+=`
`),y=[f,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_].filter(As).join(`
`),y.length>0&&(y+=`
`)):(p=[sd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(As).join(`
`),y=[f,sd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ri?"#define TONE_MAPPING":"",t.toneMapping!==Ri?Ge.tonemapping_pars_fragment:"",t.toneMapping!==Ri?Gx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ge.colorspace_pars_fragment,Vx("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(As).join(`
`)),o=Xl(o),o=td(o,t),o=nd(o,t),a=Xl(a),a=td(a,t),a=nd(a,t),o=id(o),a=id(a),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,p=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,y=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===wu?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===wu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+y);let M=x+p+o,A=x+y+a,T=Qu(s,s.VERTEX_SHADER,M),R=Qu(s,s.FRAGMENT_SHADER,A);s.attachShader(m,T),s.attachShader(m,R),t.index0AttributeName!==void 0?s.bindAttribLocation(m,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(m,0,"position"),s.linkProgram(m);function N(W){if(i.debug.checkShaderErrors){let ne=s.getProgramInfoLog(m).trim(),I=s.getShaderInfoLog(T).trim(),U=s.getShaderInfoLog(R).trim(),V=!0,K=!0;if(s.getProgramParameter(m,s.LINK_STATUS)===!1)if(V=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,m,T,R);else{let Y=ed(s,T,"vertex"),q=ed(s,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(m,s.VALIDATE_STATUS)+`

Program Info Log: `+ne+`
`+Y+`
`+q)}else ne!==""?console.warn("THREE.WebGLProgram: Program Info Log:",ne):(I===""||U==="")&&(K=!1);K&&(W.diagnostics={runnable:V,programLog:ne,vertexShader:{log:I,prefix:p},fragmentShader:{log:U,prefix:y}})}s.deleteShader(T),s.deleteShader(R),b=new Ps(s,m),E=Yx(s,m)}let b;this.getUniforms=function(){return b===void 0&&N(this),b};let E;this.getAttributes=function(){return E===void 0&&N(this),E};let O=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return O===!1&&(O=s.getProgramParameter(m,Bx)),O},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(m),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=kx++,this.cacheKey=e,this.usedTimes=1,this.program=m,this.vertexShader=T,this.fragmentShader=R,this}var ry=0,ql=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Yl(e),t.set(e,n)),n}},Yl=class{constructor(e){this.id=ry++,this.code=e,this.usedTimes=0}};function ay(i,e,t,n,s,r,o){let a=new vr,l=new ql,c=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,d=s.vertexTextures,f=s.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(b){return b===0?"uv":`uv${b}`}function m(b,E,O,W,ne){let I=W.fog,U=ne.geometry,V=b.isMeshStandardMaterial?W.environment:null,K=(b.isMeshStandardMaterial?t:e).get(b.envMap||V),Y=K&&K.mapping===ro?K.image.height:null,q=g[b.type];b.precision!==null&&(f=s.getMaxPrecision(b.precision),f!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",f,"instead."));let ee=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,se=ee!==void 0?ee.length:0,me=0;U.morphAttributes.position!==void 0&&(me=1),U.morphAttributes.normal!==void 0&&(me=2),U.morphAttributes.color!==void 0&&(me=3);let G,Z,fe,we;if(q){let tn=Vn[q];G=tn.vertexShader,Z=tn.fragmentShader}else G=b.vertexShader,Z=b.fragmentShader,l.update(b),fe=l.getVertexShaderID(b),we=l.getFragmentShaderID(b);let ve=i.getRenderTarget(),Oe=ne.isInstancedMesh===!0,Fe=ne.isBatchedMesh===!0,Le=!!b.map,Ze=!!b.matcap,F=!!K,Ot=!!b.aoMap,Ce=!!b.lightMap,Ne=!!b.bumpMap,xe=!!b.normalMap,pt=!!b.displacementMap,Be=!!b.emissiveMap,S=!!b.metalnessMap,v=!!b.roughnessMap,B=b.anisotropy>0,ie=b.clearcoat>0,Q=b.iridescence>0,te=b.sheen>0,ye=b.transmission>0,de=B&&!!b.anisotropyMap,_e=ie&&!!b.clearcoatMap,Ie=ie&&!!b.clearcoatNormalMap,He=ie&&!!b.clearcoatRoughnessMap,J=Q&&!!b.iridescenceMap,Je=Q&&!!b.iridescenceThicknessMap,P=te&&!!b.sheenColorMap,$=te&&!!b.sheenRoughnessMap,he=!!b.specularMap,re=!!b.specularColorMap,be=!!b.specularIntensityMap,qe=ye&&!!b.transmissionMap,Qe=ye&&!!b.thicknessMap,We=!!b.gradientMap,ce=!!b.alphaMap,L=b.alphaTest>0,oe=!!b.alphaHash,le=!!b.extensions,Pe=!!U.attributes.uv1,Se=!!U.attributes.uv2,it=!!U.attributes.uv3,rt=Ri;return b.toneMapped&&(ve===null||ve.isXRRenderTarget===!0)&&(rt=i.toneMapping),{isWebGL2:h,shaderID:q,shaderType:b.type,shaderName:b.name,vertexShader:G,fragmentShader:Z,defines:b.defines,customVertexShaderID:fe,customFragmentShaderID:we,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:f,batching:Fe,instancing:Oe,instancingColor:Oe&&ne.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:ve===null?i.outputColorSpace:ve.isXRRenderTarget===!0?ve.texture.colorSpace:Pt,map:Le,matcap:Ze,envMap:F,envMapMode:F&&K.mapping,envMapCubeUVHeight:Y,aoMap:Ot,lightMap:Ce,bumpMap:Ne,normalMap:xe,displacementMap:d&&pt,emissiveMap:Be,normalMapObjectSpace:xe&&b.normalMapType===um,normalMapTangentSpace:xe&&b.normalMapType===Hd,metalnessMap:S,roughnessMap:v,anisotropy:B,anisotropyMap:de,clearcoat:ie,clearcoatMap:_e,clearcoatNormalMap:Ie,clearcoatRoughnessMap:He,iridescence:Q,iridescenceMap:J,iridescenceThicknessMap:Je,sheen:te,sheenColorMap:P,sheenRoughnessMap:$,specularMap:he,specularColorMap:re,specularIntensityMap:be,transmission:ye,transmissionMap:qe,thicknessMap:Qe,gradientMap:We,opaque:b.transparent===!1&&b.blending===Rs,alphaMap:ce,alphaTest:L,alphaHash:oe,combine:b.combine,mapUv:Le&&_(b.map.channel),aoMapUv:Ot&&_(b.aoMap.channel),lightMapUv:Ce&&_(b.lightMap.channel),bumpMapUv:Ne&&_(b.bumpMap.channel),normalMapUv:xe&&_(b.normalMap.channel),displacementMapUv:pt&&_(b.displacementMap.channel),emissiveMapUv:Be&&_(b.emissiveMap.channel),metalnessMapUv:S&&_(b.metalnessMap.channel),roughnessMapUv:v&&_(b.roughnessMap.channel),anisotropyMapUv:de&&_(b.anisotropyMap.channel),clearcoatMapUv:_e&&_(b.clearcoatMap.channel),clearcoatNormalMapUv:Ie&&_(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:He&&_(b.clearcoatRoughnessMap.channel),iridescenceMapUv:J&&_(b.iridescenceMap.channel),iridescenceThicknessMapUv:Je&&_(b.iridescenceThicknessMap.channel),sheenColorMapUv:P&&_(b.sheenColorMap.channel),sheenRoughnessMapUv:$&&_(b.sheenRoughnessMap.channel),specularMapUv:he&&_(b.specularMap.channel),specularColorMapUv:re&&_(b.specularColorMap.channel),specularIntensityMapUv:be&&_(b.specularIntensityMap.channel),transmissionMapUv:qe&&_(b.transmissionMap.channel),thicknessMapUv:Qe&&_(b.thicknessMap.channel),alphaMapUv:ce&&_(b.alphaMap.channel),vertexTangents:!!U.attributes.tangent&&(xe||B),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,vertexUv1s:Pe,vertexUv2s:Se,vertexUv3s:it,pointsUvs:ne.isPoints===!0&&!!U.attributes.uv&&(Le||ce),fog:!!I,useFog:b.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:b.flatShading===!0,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:ne.isSkinnedMesh===!0,morphTargets:U.morphAttributes.position!==void 0,morphNormals:U.morphAttributes.normal!==void 0,morphColors:U.morphAttributes.color!==void 0,morphTargetsCount:se,morphTextureStride:me,numDirLights:E.directional.length,numPointLights:E.point.length,numSpotLights:E.spot.length,numSpotLightMaps:E.spotLightMap.length,numRectAreaLights:E.rectArea.length,numHemiLights:E.hemi.length,numDirLightShadows:E.directionalShadowMap.length,numPointLightShadows:E.pointShadowMap.length,numSpotLightShadows:E.spotShadowMap.length,numSpotLightShadowsWithMaps:E.numSpotLightShadowsWithMaps,numLightProbes:E.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:b.dithering,shadowMapEnabled:i.shadowMap.enabled&&O.length>0,shadowMapType:i.shadowMap.type,toneMapping:rt,useLegacyLights:i._useLegacyLights,decodeVideoTexture:Le&&b.map.isVideoTexture===!0&&at.getTransfer(b.map.colorSpace)===mt,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===_t,flipSided:b.side===zt,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionDerivatives:le&&b.extensions.derivatives===!0,extensionFragDepth:le&&b.extensions.fragDepth===!0,extensionDrawBuffers:le&&b.extensions.drawBuffers===!0,extensionShaderTextureLOD:le&&b.extensions.shaderTextureLOD===!0,extensionClipCullDistance:le&&b.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()}}function p(b){let E=[];if(b.shaderID?E.push(b.shaderID):(E.push(b.customVertexShaderID),E.push(b.customFragmentShaderID)),b.defines!==void 0)for(let O in b.defines)E.push(O),E.push(b.defines[O]);return b.isRawShaderMaterial===!1&&(y(E,b),x(E,b),E.push(i.outputColorSpace)),E.push(b.customProgramCacheKey),E.join()}function y(b,E){b.push(E.precision),b.push(E.outputColorSpace),b.push(E.envMapMode),b.push(E.envMapCubeUVHeight),b.push(E.mapUv),b.push(E.alphaMapUv),b.push(E.lightMapUv),b.push(E.aoMapUv),b.push(E.bumpMapUv),b.push(E.normalMapUv),b.push(E.displacementMapUv),b.push(E.emissiveMapUv),b.push(E.metalnessMapUv),b.push(E.roughnessMapUv),b.push(E.anisotropyMapUv),b.push(E.clearcoatMapUv),b.push(E.clearcoatNormalMapUv),b.push(E.clearcoatRoughnessMapUv),b.push(E.iridescenceMapUv),b.push(E.iridescenceThicknessMapUv),b.push(E.sheenColorMapUv),b.push(E.sheenRoughnessMapUv),b.push(E.specularMapUv),b.push(E.specularColorMapUv),b.push(E.specularIntensityMapUv),b.push(E.transmissionMapUv),b.push(E.thicknessMapUv),b.push(E.combine),b.push(E.fogExp2),b.push(E.sizeAttenuation),b.push(E.morphTargetsCount),b.push(E.morphAttributeCount),b.push(E.numDirLights),b.push(E.numPointLights),b.push(E.numSpotLights),b.push(E.numSpotLightMaps),b.push(E.numHemiLights),b.push(E.numRectAreaLights),b.push(E.numDirLightShadows),b.push(E.numPointLightShadows),b.push(E.numSpotLightShadows),b.push(E.numSpotLightShadowsWithMaps),b.push(E.numLightProbes),b.push(E.shadowMapType),b.push(E.toneMapping),b.push(E.numClippingPlanes),b.push(E.numClipIntersection),b.push(E.depthPacking)}function x(b,E){a.disableAll(),E.isWebGL2&&a.enable(0),E.supportsVertexTextures&&a.enable(1),E.instancing&&a.enable(2),E.instancingColor&&a.enable(3),E.matcap&&a.enable(4),E.envMap&&a.enable(5),E.normalMapObjectSpace&&a.enable(6),E.normalMapTangentSpace&&a.enable(7),E.clearcoat&&a.enable(8),E.iridescence&&a.enable(9),E.alphaTest&&a.enable(10),E.vertexColors&&a.enable(11),E.vertexAlphas&&a.enable(12),E.vertexUv1s&&a.enable(13),E.vertexUv2s&&a.enable(14),E.vertexUv3s&&a.enable(15),E.vertexTangents&&a.enable(16),E.anisotropy&&a.enable(17),E.alphaHash&&a.enable(18),E.batching&&a.enable(19),b.push(a.mask),a.disableAll(),E.fog&&a.enable(0),E.useFog&&a.enable(1),E.flatShading&&a.enable(2),E.logarithmicDepthBuffer&&a.enable(3),E.skinning&&a.enable(4),E.morphTargets&&a.enable(5),E.morphNormals&&a.enable(6),E.morphColors&&a.enable(7),E.premultipliedAlpha&&a.enable(8),E.shadowMapEnabled&&a.enable(9),E.useLegacyLights&&a.enable(10),E.doubleSided&&a.enable(11),E.flipSided&&a.enable(12),E.useDepthPacking&&a.enable(13),E.dithering&&a.enable(14),E.transmission&&a.enable(15),E.sheen&&a.enable(16),E.opaque&&a.enable(17),E.pointsUvs&&a.enable(18),E.decodeVideoTexture&&a.enable(19),b.push(a.mask)}function M(b){let E=g[b.type],O;if(E){let W=Vn[E];O=jm.clone(W.uniforms)}else O=b.uniforms;return O}function A(b,E){let O;for(let W=0,ne=c.length;W<ne;W++){let I=c[W];if(I.cacheKey===E){O=I,++O.usedTimes;break}}return O===void 0&&(O=new sy(i,E,b,r),c.push(O)),O}function T(b){if(--b.usedTimes===0){let E=c.indexOf(b);c[E]=c[c.length-1],c.pop(),b.destroy()}}function R(b){l.remove(b)}function N(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:M,acquireProgram:A,releaseProgram:T,releaseShaderCache:R,programs:c,dispose:N}}function oy(){let i=new WeakMap;function e(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function t(r){i.delete(r)}function n(r,o,a){i.get(r)[o]=a}function s(){i=new WeakMap}return{get:e,remove:t,update:n,dispose:s}}function ly(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function rd(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function ad(){let i=[],e=0,t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(u,d,f,g,_,m){let p=i[e];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:_,group:m},i[e]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=_,p.group=m),e++,p}function a(u,d,f,g,_,m){let p=o(u,d,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):t.push(p)}function l(u,d,f,g,_,m){let p=o(u,d,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):t.unshift(p)}function c(u,d){t.length>1&&t.sort(u||ly),n.length>1&&n.sort(d||rd),s.length>1&&s.sort(d||rd)}function h(){for(let u=e,d=i.length;u<d;u++){let f=i[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function cy(){let i=new WeakMap;function e(n,s){let r=i.get(n),o;return r===void 0?(o=new ad,i.set(n,[o])):s>=r.length?(o=new ad,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function hy(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new C,color:new Te};break;case"SpotLight":t={position:new C,direction:new C,color:new Te,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new C,color:new Te,distance:0,decay:0};break;case"HemisphereLight":t={direction:new C,skyColor:new Te,groundColor:new Te};break;case"RectAreaLight":t={color:new Te,position:new C,halfWidth:new C,halfHeight:new C};break}return i[e.id]=t,t}}}function uy(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Re};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Re};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Re,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}var dy=0;function fy(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function py(i,e){let t=new hy,n=uy(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new C);let r=new C,o=new ze,a=new ze;function l(h,u){let d=0,f=0,g=0;for(let W=0;W<9;W++)s.probe[W].set(0,0,0);let _=0,m=0,p=0,y=0,x=0,M=0,A=0,T=0,R=0,N=0,b=0;h.sort(fy);let E=u===!0?Math.PI:1;for(let W=0,ne=h.length;W<ne;W++){let I=h[W],U=I.color,V=I.intensity,K=I.distance,Y=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)d+=U.r*V*E,f+=U.g*V*E,g+=U.b*V*E;else if(I.isLightProbe){for(let q=0;q<9;q++)s.probe[q].addScaledVector(I.sh.coefficients[q],V);b++}else if(I.isDirectionalLight){let q=t.get(I);if(q.color.copy(I.color).multiplyScalar(I.intensity*E),I.castShadow){let ee=I.shadow,se=n.get(I);se.shadowBias=ee.bias,se.shadowNormalBias=ee.normalBias,se.shadowRadius=ee.radius,se.shadowMapSize=ee.mapSize,s.directionalShadow[_]=se,s.directionalShadowMap[_]=Y,s.directionalShadowMatrix[_]=I.shadow.matrix,M++}s.directional[_]=q,_++}else if(I.isSpotLight){let q=t.get(I);q.position.setFromMatrixPosition(I.matrixWorld),q.color.copy(U).multiplyScalar(V*E),q.distance=K,q.coneCos=Math.cos(I.angle),q.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),q.decay=I.decay,s.spot[p]=q;let ee=I.shadow;if(I.map&&(s.spotLightMap[R]=I.map,R++,ee.updateMatrices(I),I.castShadow&&N++),s.spotLightMatrix[p]=ee.matrix,I.castShadow){let se=n.get(I);se.shadowBias=ee.bias,se.shadowNormalBias=ee.normalBias,se.shadowRadius=ee.radius,se.shadowMapSize=ee.mapSize,s.spotShadow[p]=se,s.spotShadowMap[p]=Y,T++}p++}else if(I.isRectAreaLight){let q=t.get(I);q.color.copy(U).multiplyScalar(V),q.halfWidth.set(I.width*.5,0,0),q.halfHeight.set(0,I.height*.5,0),s.rectArea[y]=q,y++}else if(I.isPointLight){let q=t.get(I);if(q.color.copy(I.color).multiplyScalar(I.intensity*E),q.distance=I.distance,q.decay=I.decay,I.castShadow){let ee=I.shadow,se=n.get(I);se.shadowBias=ee.bias,se.shadowNormalBias=ee.normalBias,se.shadowRadius=ee.radius,se.shadowMapSize=ee.mapSize,se.shadowCameraNear=ee.camera.near,se.shadowCameraFar=ee.camera.far,s.pointShadow[m]=se,s.pointShadowMap[m]=Y,s.pointShadowMatrix[m]=I.shadow.matrix,A++}s.point[m]=q,m++}else if(I.isHemisphereLight){let q=t.get(I);q.skyColor.copy(I.color).multiplyScalar(V*E),q.groundColor.copy(I.groundColor).multiplyScalar(V*E),s.hemi[x]=q,x++}}y>0&&(e.isWebGL2?i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=ue.LTC_FLOAT_1,s.rectAreaLTC2=ue.LTC_FLOAT_2):(s.rectAreaLTC1=ue.LTC_HALF_1,s.rectAreaLTC2=ue.LTC_HALF_2):i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=ue.LTC_FLOAT_1,s.rectAreaLTC2=ue.LTC_FLOAT_2):i.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=ue.LTC_HALF_1,s.rectAreaLTC2=ue.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=d,s.ambient[1]=f,s.ambient[2]=g;let O=s.hash;(O.directionalLength!==_||O.pointLength!==m||O.spotLength!==p||O.rectAreaLength!==y||O.hemiLength!==x||O.numDirectionalShadows!==M||O.numPointShadows!==A||O.numSpotShadows!==T||O.numSpotMaps!==R||O.numLightProbes!==b)&&(s.directional.length=_,s.spot.length=p,s.rectArea.length=y,s.point.length=m,s.hemi.length=x,s.directionalShadow.length=M,s.directionalShadowMap.length=M,s.pointShadow.length=A,s.pointShadowMap.length=A,s.spotShadow.length=T,s.spotShadowMap.length=T,s.directionalShadowMatrix.length=M,s.pointShadowMatrix.length=A,s.spotLightMatrix.length=T+R-N,s.spotLightMap.length=R,s.numSpotLightShadowsWithMaps=N,s.numLightProbes=b,O.directionalLength=_,O.pointLength=m,O.spotLength=p,O.rectAreaLength=y,O.hemiLength=x,O.numDirectionalShadows=M,O.numPointShadows=A,O.numSpotShadows=T,O.numSpotMaps=R,O.numLightProbes=b,s.version=dy++)}function c(h,u){let d=0,f=0,g=0,_=0,m=0,p=u.matrixWorldInverse;for(let y=0,x=h.length;y<x;y++){let M=h[y];if(M.isDirectionalLight){let A=s.directional[d];A.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),A.direction.sub(r),A.direction.transformDirection(p),d++}else if(M.isSpotLight){let A=s.spot[g];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(p),A.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),A.direction.sub(r),A.direction.transformDirection(p),g++}else if(M.isRectAreaLight){let A=s.rectArea[_];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(p),a.identity(),o.copy(M.matrixWorld),o.premultiply(p),a.extractRotation(o),A.halfWidth.set(M.width*.5,0,0),A.halfHeight.set(0,M.height*.5,0),A.halfWidth.applyMatrix4(a),A.halfHeight.applyMatrix4(a),_++}else if(M.isPointLight){let A=s.point[f];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(p),f++}else if(M.isHemisphereLight){let A=s.hemi[m];A.direction.setFromMatrixPosition(M.matrixWorld),A.direction.transformDirection(p),m++}}}return{setup:l,setupView:c,state:s}}function od(i,e){let t=new py(i,e),n=[],s=[];function r(){n.length=0,s.length=0}function o(u){n.push(u)}function a(u){s.push(u)}function l(u){t.setup(n,u)}function c(u){t.setupView(n,u)}return{init:r,state:{lightsArray:n,shadowsArray:s,lights:t},setupLights:l,setupLightsView:c,pushLight:o,pushShadow:a}}function my(i,e){let t=new WeakMap;function n(r,o=0){let a=t.get(r),l;return a===void 0?(l=new od(i,e),t.set(r,[l])):o>=a.length?(l=new od(i,e),a.push(l)):l=a[o],l}function s(){t=new WeakMap}return{get:n,dispose:s}}var Kl=class extends _n{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=cm,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},jl=class extends _n{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},gy=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,_y=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function xy(i,e,t){let n=new br,s=new Re,r=new Re,o=new dt,a=new Kl({depthPacking:hm}),l=new jl,c={},h=t.maxTextureSize,u={[Wn]:zt,[zt]:Wn,[_t]:_t},d=new Fn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Re},radius:{value:4}},vertexShader:gy,fragmentShader:_y}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let g=new Tt;g.setAttribute("position",new wt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let _=new je(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Cd;let p=this.type;this.render=function(T,R,N){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||T.length===0)return;let b=i.getRenderTarget(),E=i.getActiveCubeFace(),O=i.getActiveMipmapLevel(),W=i.state;W.setBlending(Ai),W.buffers.color.setClear(1,1,1,1),W.buffers.depth.setTest(!0),W.setScissorTest(!1);let ne=p!==si&&this.type===si,I=p===si&&this.type!==si;for(let U=0,V=T.length;U<V;U++){let K=T[U],Y=K.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",K,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;s.copy(Y.mapSize);let q=Y.getFrameExtents();if(s.multiply(q),r.copy(Y.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/q.x),s.x=r.x*q.x,Y.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/q.y),s.y=r.y*q.y,Y.mapSize.y=r.y)),Y.map===null||ne===!0||I===!0){let se=this.type!==si?{minFilter:Rt,magFilter:Rt}:{};Y.map!==null&&Y.map.dispose(),Y.map=new oi(s.x,s.y,se),Y.map.texture.name=K.name+".shadowMap",Y.camera.updateProjectionMatrix()}i.setRenderTarget(Y.map),i.clear();let ee=Y.getViewportCount();for(let se=0;se<ee;se++){let me=Y.getViewport(se);o.set(r.x*me.x,r.y*me.y,r.x*me.z,r.y*me.w),W.viewport(o),Y.updateMatrices(K,se),n=Y.getFrustum(),M(R,N,Y.camera,K,this.type)}Y.isPointLightShadow!==!0&&this.type===si&&y(Y,N),Y.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(b,E,O)};function y(T,R){let N=e.update(_);d.defines.VSM_SAMPLES!==T.blurSamples&&(d.defines.VSM_SAMPLES=T.blurSamples,f.defines.VSM_SAMPLES=T.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new oi(s.x,s.y)),d.uniforms.shadow_pass.value=T.map.texture,d.uniforms.resolution.value=T.mapSize,d.uniforms.radius.value=T.radius,i.setRenderTarget(T.mapPass),i.clear(),i.renderBufferDirect(R,null,N,d,_,null),f.uniforms.shadow_pass.value=T.mapPass.texture,f.uniforms.resolution.value=T.mapSize,f.uniforms.radius.value=T.radius,i.setRenderTarget(T.map),i.clear(),i.renderBufferDirect(R,null,N,f,_,null)}function x(T,R,N,b){let E=null,O=N.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(O!==void 0)E=O;else if(E=N.isPointLight===!0?l:a,i.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let W=E.uuid,ne=R.uuid,I=c[W];I===void 0&&(I={},c[W]=I);let U=I[ne];U===void 0&&(U=E.clone(),I[ne]=U,R.addEventListener("dispose",A)),E=U}if(E.visible=R.visible,E.wireframe=R.wireframe,b===si?E.side=R.shadowSide!==null?R.shadowSide:R.side:E.side=R.shadowSide!==null?R.shadowSide:u[R.side],E.alphaMap=R.alphaMap,E.alphaTest=R.alphaTest,E.map=R.map,E.clipShadows=R.clipShadows,E.clippingPlanes=R.clippingPlanes,E.clipIntersection=R.clipIntersection,E.displacementMap=R.displacementMap,E.displacementScale=R.displacementScale,E.displacementBias=R.displacementBias,E.wireframeLinewidth=R.wireframeLinewidth,E.linewidth=R.linewidth,N.isPointLight===!0&&E.isMeshDistanceMaterial===!0){let W=i.properties.get(E);W.light=N}return E}function M(T,R,N,b,E){if(T.visible===!1)return;if(T.layers.test(R.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&E===si)&&(!T.frustumCulled||n.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(N.matrixWorldInverse,T.matrixWorld);let ne=e.update(T),I=T.material;if(Array.isArray(I)){let U=ne.groups;for(let V=0,K=U.length;V<K;V++){let Y=U[V],q=I[Y.materialIndex];if(q&&q.visible){let ee=x(T,q,b,E);T.onBeforeShadow(i,T,R,N,ne,ee,Y),i.renderBufferDirect(N,null,ne,ee,T,Y),T.onAfterShadow(i,T,R,N,ne,ee,Y)}}}else if(I.visible){let U=x(T,I,b,E);T.onBeforeShadow(i,T,R,N,ne,U,null),i.renderBufferDirect(N,null,ne,U,T,null),T.onAfterShadow(i,T,R,N,ne,U,null)}}let W=T.children;for(let ne=0,I=W.length;ne<I;ne++)M(W[ne],R,N,b,E)}function A(T){T.target.removeEventListener("dispose",A);for(let N in c){let b=c[N],E=T.target.uuid;E in b&&(b[E].dispose(),delete b[E])}}}function yy(i,e,t){let n=t.isWebGL2;function s(){let L=!1,oe=new dt,le=null,Pe=new dt(0,0,0,0);return{setMask:function(Se){le!==Se&&!L&&(i.colorMask(Se,Se,Se,Se),le=Se)},setLocked:function(Se){L=Se},setClear:function(Se,it,rt,Ft,tn){tn===!0&&(Se*=Ft,it*=Ft,rt*=Ft),oe.set(Se,it,rt,Ft),Pe.equals(oe)===!1&&(i.clearColor(Se,it,rt,Ft),Pe.copy(oe))},reset:function(){L=!1,le=null,Pe.set(-1,0,0,0)}}}function r(){let L=!1,oe=null,le=null,Pe=null;return{setTest:function(Se){Se?Fe(i.DEPTH_TEST):Le(i.DEPTH_TEST)},setMask:function(Se){oe!==Se&&!L&&(i.depthMask(Se),oe=Se)},setFunc:function(Se){if(le!==Se){switch(Se){case Bp:i.depthFunc(i.NEVER);break;case kp:i.depthFunc(i.ALWAYS);break;case zp:i.depthFunc(i.LESS);break;case Ra:i.depthFunc(i.LEQUAL);break;case Hp:i.depthFunc(i.EQUAL);break;case Vp:i.depthFunc(i.GEQUAL);break;case Gp:i.depthFunc(i.GREATER);break;case Wp:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}le=Se}},setLocked:function(Se){L=Se},setClear:function(Se){Pe!==Se&&(i.clearDepth(Se),Pe=Se)},reset:function(){L=!1,oe=null,le=null,Pe=null}}}function o(){let L=!1,oe=null,le=null,Pe=null,Se=null,it=null,rt=null,Ft=null,tn=null;return{setTest:function(ft){L||(ft?Fe(i.STENCIL_TEST):Le(i.STENCIL_TEST))},setMask:function(ft){oe!==ft&&!L&&(i.stencilMask(ft),oe=ft)},setFunc:function(ft,nn,Hn){(le!==ft||Pe!==nn||Se!==Hn)&&(i.stencilFunc(ft,nn,Hn),le=ft,Pe=nn,Se=Hn)},setOp:function(ft,nn,Hn){(it!==ft||rt!==nn||Ft!==Hn)&&(i.stencilOp(ft,nn,Hn),it=ft,rt=nn,Ft=Hn)},setLocked:function(ft){L=ft},setClear:function(ft){tn!==ft&&(i.clearStencil(ft),tn=ft)},reset:function(){L=!1,oe=null,le=null,Pe=null,Se=null,it=null,rt=null,Ft=null,tn=null}}}let a=new s,l=new r,c=new o,h=new WeakMap,u=new WeakMap,d={},f={},g=new WeakMap,_=[],m=null,p=!1,y=null,x=null,M=null,A=null,T=null,R=null,N=null,b=new Te(0,0,0),E=0,O=!1,W=null,ne=null,I=null,U=null,V=null,K=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),Y=!1,q=0,ee=i.getParameter(i.VERSION);ee.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec(ee)[1]),Y=q>=1):ee.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec(ee)[1]),Y=q>=2);let se=null,me={},G=i.getParameter(i.SCISSOR_BOX),Z=i.getParameter(i.VIEWPORT),fe=new dt().fromArray(G),we=new dt().fromArray(Z);function ve(L,oe,le,Pe){let Se=new Uint8Array(4),it=i.createTexture();i.bindTexture(L,it),i.texParameteri(L,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(L,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let rt=0;rt<le;rt++)n&&(L===i.TEXTURE_3D||L===i.TEXTURE_2D_ARRAY)?i.texImage3D(oe,0,i.RGBA,1,1,Pe,0,i.RGBA,i.UNSIGNED_BYTE,Se):i.texImage2D(oe+rt,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Se);return it}let Oe={};Oe[i.TEXTURE_2D]=ve(i.TEXTURE_2D,i.TEXTURE_2D,1),Oe[i.TEXTURE_CUBE_MAP]=ve(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(Oe[i.TEXTURE_2D_ARRAY]=ve(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Oe[i.TEXTURE_3D]=ve(i.TEXTURE_3D,i.TEXTURE_3D,1,1)),a.setClear(0,0,0,1),l.setClear(1),c.setClear(0),Fe(i.DEPTH_TEST),l.setFunc(Ra),Be(!1),S(Xh),Fe(i.CULL_FACE),xe(Ai);function Fe(L){d[L]!==!0&&(i.enable(L),d[L]=!0)}function Le(L){d[L]!==!1&&(i.disable(L),d[L]=!1)}function Ze(L,oe){return f[L]!==oe?(i.bindFramebuffer(L,oe),f[L]=oe,n&&(L===i.DRAW_FRAMEBUFFER&&(f[i.FRAMEBUFFER]=oe),L===i.FRAMEBUFFER&&(f[i.DRAW_FRAMEBUFFER]=oe)),!0):!1}function F(L,oe){let le=_,Pe=!1;if(L)if(le=g.get(oe),le===void 0&&(le=[],g.set(oe,le)),L.isWebGLMultipleRenderTargets){let Se=L.texture;if(le.length!==Se.length||le[0]!==i.COLOR_ATTACHMENT0){for(let it=0,rt=Se.length;it<rt;it++)le[it]=i.COLOR_ATTACHMENT0+it;le.length=Se.length,Pe=!0}}else le[0]!==i.COLOR_ATTACHMENT0&&(le[0]=i.COLOR_ATTACHMENT0,Pe=!0);else le[0]!==i.BACK&&(le[0]=i.BACK,Pe=!0);Pe&&(t.isWebGL2?i.drawBuffers(le):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(le))}function Ot(L){return m!==L?(i.useProgram(L),m=L,!0):!1}let Ce={[qi]:i.FUNC_ADD,[wp]:i.FUNC_SUBTRACT,[Sp]:i.FUNC_REVERSE_SUBTRACT};if(n)Ce[Kh]=i.MIN,Ce[jh]=i.MAX;else{let L=e.get("EXT_blend_minmax");L!==null&&(Ce[Kh]=L.MIN_EXT,Ce[jh]=L.MAX_EXT)}let Ne={[Ep]:i.ZERO,[Tp]:i.ONE,[Ap]:i.SRC_COLOR,[Ll]:i.SRC_ALPHA,[Dp]:i.SRC_ALPHA_SATURATE,[Lp]:i.DST_COLOR,[Cp]:i.DST_ALPHA,[Rp]:i.ONE_MINUS_SRC_COLOR,[Il]:i.ONE_MINUS_SRC_ALPHA,[Ip]:i.ONE_MINUS_DST_COLOR,[Pp]:i.ONE_MINUS_DST_ALPHA,[Np]:i.CONSTANT_COLOR,[Up]:i.ONE_MINUS_CONSTANT_COLOR,[Op]:i.CONSTANT_ALPHA,[Fp]:i.ONE_MINUS_CONSTANT_ALPHA};function xe(L,oe,le,Pe,Se,it,rt,Ft,tn,ft){if(L===Ai){p===!0&&(Le(i.BLEND),p=!1);return}if(p===!1&&(Fe(i.BLEND),p=!0),L!==Mp){if(L!==y||ft!==O){if((x!==qi||T!==qi)&&(i.blendEquation(i.FUNC_ADD),x=qi,T=qi),ft)switch(L){case Rs:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case gr:i.blendFunc(i.ONE,i.ONE);break;case qh:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Yh:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",L);break}else switch(L){case Rs:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case gr:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case qh:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Yh:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",L);break}M=null,A=null,R=null,N=null,b.set(0,0,0),E=0,y=L,O=ft}return}Se=Se||oe,it=it||le,rt=rt||Pe,(oe!==x||Se!==T)&&(i.blendEquationSeparate(Ce[oe],Ce[Se]),x=oe,T=Se),(le!==M||Pe!==A||it!==R||rt!==N)&&(i.blendFuncSeparate(Ne[le],Ne[Pe],Ne[it],Ne[rt]),M=le,A=Pe,R=it,N=rt),(Ft.equals(b)===!1||tn!==E)&&(i.blendColor(Ft.r,Ft.g,Ft.b,tn),b.copy(Ft),E=tn),y=L,O=!1}function pt(L,oe){L.side===_t?Le(i.CULL_FACE):Fe(i.CULL_FACE);let le=L.side===zt;oe&&(le=!le),Be(le),L.blending===Rs&&L.transparent===!1?xe(Ai):xe(L.blending,L.blendEquation,L.blendSrc,L.blendDst,L.blendEquationAlpha,L.blendSrcAlpha,L.blendDstAlpha,L.blendColor,L.blendAlpha,L.premultipliedAlpha),l.setFunc(L.depthFunc),l.setTest(L.depthTest),l.setMask(L.depthWrite),a.setMask(L.colorWrite);let Pe=L.stencilWrite;c.setTest(Pe),Pe&&(c.setMask(L.stencilWriteMask),c.setFunc(L.stencilFunc,L.stencilRef,L.stencilFuncMask),c.setOp(L.stencilFail,L.stencilZFail,L.stencilZPass)),B(L.polygonOffset,L.polygonOffsetFactor,L.polygonOffsetUnits),L.alphaToCoverage===!0?Fe(i.SAMPLE_ALPHA_TO_COVERAGE):Le(i.SAMPLE_ALPHA_TO_COVERAGE)}function Be(L){W!==L&&(L?i.frontFace(i.CW):i.frontFace(i.CCW),W=L)}function S(L){L!==vp?(Fe(i.CULL_FACE),L!==ne&&(L===Xh?i.cullFace(i.BACK):L===bp?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Le(i.CULL_FACE),ne=L}function v(L){L!==I&&(Y&&i.lineWidth(L),I=L)}function B(L,oe,le){L?(Fe(i.POLYGON_OFFSET_FILL),(U!==oe||V!==le)&&(i.polygonOffset(oe,le),U=oe,V=le)):Le(i.POLYGON_OFFSET_FILL)}function ie(L){L?Fe(i.SCISSOR_TEST):Le(i.SCISSOR_TEST)}function Q(L){L===void 0&&(L=i.TEXTURE0+K-1),se!==L&&(i.activeTexture(L),se=L)}function te(L,oe,le){le===void 0&&(se===null?le=i.TEXTURE0+K-1:le=se);let Pe=me[le];Pe===void 0&&(Pe={type:void 0,texture:void 0},me[le]=Pe),(Pe.type!==L||Pe.texture!==oe)&&(se!==le&&(i.activeTexture(le),se=le),i.bindTexture(L,oe||Oe[L]),Pe.type=L,Pe.texture=oe)}function ye(){let L=me[se];L!==void 0&&L.type!==void 0&&(i.bindTexture(L.type,null),L.type=void 0,L.texture=void 0)}function de(){try{i.compressedTexImage2D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function _e(){try{i.compressedTexImage3D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function Ie(){try{i.texSubImage2D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function He(){try{i.texSubImage3D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function J(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function Je(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function P(){try{i.texStorage2D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function $(){try{i.texStorage3D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function he(){try{i.texImage2D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function re(){try{i.texImage3D.apply(i,arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function be(L){fe.equals(L)===!1&&(i.scissor(L.x,L.y,L.z,L.w),fe.copy(L))}function qe(L){we.equals(L)===!1&&(i.viewport(L.x,L.y,L.z,L.w),we.copy(L))}function Qe(L,oe){let le=u.get(oe);le===void 0&&(le=new WeakMap,u.set(oe,le));let Pe=le.get(L);Pe===void 0&&(Pe=i.getUniformBlockIndex(oe,L.name),le.set(L,Pe))}function We(L,oe){let Pe=u.get(oe).get(L);h.get(oe)!==Pe&&(i.uniformBlockBinding(oe,Pe,L.__bindingPointIndex),h.set(oe,Pe))}function ce(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),n===!0&&(i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null)),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),d={},se=null,me={},f={},g=new WeakMap,_=[],m=null,p=!1,y=null,x=null,M=null,A=null,T=null,R=null,N=null,b=new Te(0,0,0),E=0,O=!1,W=null,ne=null,I=null,U=null,V=null,fe.set(0,0,i.canvas.width,i.canvas.height),we.set(0,0,i.canvas.width,i.canvas.height),a.reset(),l.reset(),c.reset()}return{buffers:{color:a,depth:l,stencil:c},enable:Fe,disable:Le,bindFramebuffer:Ze,drawBuffers:F,useProgram:Ot,setBlending:xe,setMaterial:pt,setFlipSided:Be,setCullFace:S,setLineWidth:v,setPolygonOffset:B,setScissorTest:ie,activeTexture:Q,bindTexture:te,unbindTexture:ye,compressedTexImage2D:de,compressedTexImage3D:_e,texImage2D:he,texImage3D:re,updateUBOMapping:Qe,uniformBlockBinding:We,texStorage2D:P,texStorage3D:$,texSubImage2D:Ie,texSubImage3D:He,compressedTexSubImage2D:J,compressedTexSubImage3D:Je,scissor:be,viewport:qe,reset:ce}}function vy(i,e,t,n,s,r,o){let a=s.isWebGL2,l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(S,v){return f?new OffscreenCanvas(S,v):yr("canvas")}function _(S,v,B,ie){let Q=1;if((S.width>ie||S.height>ie)&&(Q=ie/Math.max(S.width,S.height)),Q<1||v===!0)if(typeof HTMLImageElement<"u"&&S instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&S instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&S instanceof ImageBitmap){let te=v?Ua:Math.floor,ye=te(Q*S.width),de=te(Q*S.height);u===void 0&&(u=g(ye,de));let _e=B?g(ye,de):u;return _e.width=ye,_e.height=de,_e.getContext("2d").drawImage(S,0,0,ye,de),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+S.width+"x"+S.height+") to ("+ye+"x"+de+")."),_e}else return"data"in S&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+S.width+"x"+S.height+")."),S;return S}function m(S){return Fl(S.width)&&Fl(S.height)}function p(S){return a?!1:S.wrapS!==mn||S.wrapT!==mn||S.minFilter!==Rt&&S.minFilter!==an}function y(S,v){return S.generateMipmaps&&v&&S.minFilter!==Rt&&S.minFilter!==an}function x(S){i.generateMipmap(S)}function M(S,v,B,ie,Q=!1){if(a===!1)return v;if(S!==null){if(i[S]!==void 0)return i[S];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+S+"'")}let te=v;if(v===i.RED&&(B===i.FLOAT&&(te=i.R32F),B===i.HALF_FLOAT&&(te=i.R16F),B===i.UNSIGNED_BYTE&&(te=i.R8)),v===i.RED_INTEGER&&(B===i.UNSIGNED_BYTE&&(te=i.R8UI),B===i.UNSIGNED_SHORT&&(te=i.R16UI),B===i.UNSIGNED_INT&&(te=i.R32UI),B===i.BYTE&&(te=i.R8I),B===i.SHORT&&(te=i.R16I),B===i.INT&&(te=i.R32I)),v===i.RG&&(B===i.FLOAT&&(te=i.RG32F),B===i.HALF_FLOAT&&(te=i.RG16F),B===i.UNSIGNED_BYTE&&(te=i.RG8)),v===i.RGBA){let ye=Q?La:at.getTransfer(ie);B===i.FLOAT&&(te=i.RGBA32F),B===i.HALF_FLOAT&&(te=i.RGBA16F),B===i.UNSIGNED_BYTE&&(te=ye===mt?i.SRGB8_ALPHA8:i.RGBA8),B===i.UNSIGNED_SHORT_4_4_4_4&&(te=i.RGBA4),B===i.UNSIGNED_SHORT_5_5_5_1&&(te=i.RGB5_A1)}return(te===i.R16F||te===i.R32F||te===i.RG16F||te===i.RG32F||te===i.RGBA16F||te===i.RGBA32F)&&e.get("EXT_color_buffer_float"),te}function A(S,v,B){return y(S,B)===!0||S.isFramebufferTexture&&S.minFilter!==Rt&&S.minFilter!==an?Math.log2(Math.max(v.width,v.height))+1:S.mipmaps!==void 0&&S.mipmaps.length>0?S.mipmaps.length:S.isCompressedTexture&&Array.isArray(S.image)?v.mipmaps.length:1}function T(S){return S===Rt||S===Ca||S===ur?i.NEAREST:i.LINEAR}function R(S){let v=S.target;v.removeEventListener("dispose",R),b(v),v.isVideoTexture&&h.delete(v)}function N(S){let v=S.target;v.removeEventListener("dispose",N),O(v)}function b(S){let v=n.get(S);if(v.__webglInit===void 0)return;let B=S.source,ie=d.get(B);if(ie){let Q=ie[v.__cacheKey];Q.usedTimes--,Q.usedTimes===0&&E(S),Object.keys(ie).length===0&&d.delete(B)}n.remove(S)}function E(S){let v=n.get(S);i.deleteTexture(v.__webglTexture);let B=S.source,ie=d.get(B);delete ie[v.__cacheKey],o.memory.textures--}function O(S){let v=S.texture,B=n.get(S),ie=n.get(v);if(ie.__webglTexture!==void 0&&(i.deleteTexture(ie.__webglTexture),o.memory.textures--),S.depthTexture&&S.depthTexture.dispose(),S.isWebGLCubeRenderTarget)for(let Q=0;Q<6;Q++){if(Array.isArray(B.__webglFramebuffer[Q]))for(let te=0;te<B.__webglFramebuffer[Q].length;te++)i.deleteFramebuffer(B.__webglFramebuffer[Q][te]);else i.deleteFramebuffer(B.__webglFramebuffer[Q]);B.__webglDepthbuffer&&i.deleteRenderbuffer(B.__webglDepthbuffer[Q])}else{if(Array.isArray(B.__webglFramebuffer))for(let Q=0;Q<B.__webglFramebuffer.length;Q++)i.deleteFramebuffer(B.__webglFramebuffer[Q]);else i.deleteFramebuffer(B.__webglFramebuffer);if(B.__webglDepthbuffer&&i.deleteRenderbuffer(B.__webglDepthbuffer),B.__webglMultisampledFramebuffer&&i.deleteFramebuffer(B.__webglMultisampledFramebuffer),B.__webglColorRenderbuffer)for(let Q=0;Q<B.__webglColorRenderbuffer.length;Q++)B.__webglColorRenderbuffer[Q]&&i.deleteRenderbuffer(B.__webglColorRenderbuffer[Q]);B.__webglDepthRenderbuffer&&i.deleteRenderbuffer(B.__webglDepthRenderbuffer)}if(S.isWebGLMultipleRenderTargets)for(let Q=0,te=v.length;Q<te;Q++){let ye=n.get(v[Q]);ye.__webglTexture&&(i.deleteTexture(ye.__webglTexture),o.memory.textures--),n.remove(v[Q])}n.remove(v),n.remove(S)}let W=0;function ne(){W=0}function I(){let S=W;return S>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+S+" texture units while this GPU supports only "+s.maxTextures),W+=1,S}function U(S){let v=[];return v.push(S.wrapS),v.push(S.wrapT),v.push(S.wrapR||0),v.push(S.magFilter),v.push(S.minFilter),v.push(S.anisotropy),v.push(S.internalFormat),v.push(S.format),v.push(S.type),v.push(S.generateMipmaps),v.push(S.premultiplyAlpha),v.push(S.flipY),v.push(S.unpackAlignment),v.push(S.colorSpace),v.join()}function V(S,v){let B=n.get(S);if(S.isVideoTexture&&pt(S),S.isRenderTargetTexture===!1&&S.version>0&&B.__version!==S.version){let ie=S.image;if(ie===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(ie.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{fe(B,S,v);return}}t.bindTexture(i.TEXTURE_2D,B.__webglTexture,i.TEXTURE0+v)}function K(S,v){let B=n.get(S);if(S.version>0&&B.__version!==S.version){fe(B,S,v);return}t.bindTexture(i.TEXTURE_2D_ARRAY,B.__webglTexture,i.TEXTURE0+v)}function Y(S,v){let B=n.get(S);if(S.version>0&&B.__version!==S.version){fe(B,S,v);return}t.bindTexture(i.TEXTURE_3D,B.__webglTexture,i.TEXTURE0+v)}function q(S,v){let B=n.get(S);if(S.version>0&&B.__version!==S.version){we(B,S,v);return}t.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+v)}let ee={[Zi]:i.REPEAT,[mn]:i.CLAMP_TO_EDGE,[_r]:i.MIRRORED_REPEAT},se={[Rt]:i.NEAREST,[Ca]:i.NEAREST_MIPMAP_NEAREST,[ur]:i.NEAREST_MIPMAP_LINEAR,[an]:i.LINEAR,[_c]:i.LINEAR_MIPMAP_NEAREST,[Pi]:i.LINEAR_MIPMAP_LINEAR},me={[dm]:i.NEVER,[xm]:i.ALWAYS,[fm]:i.LESS,[Vd]:i.LEQUAL,[pm]:i.EQUAL,[_m]:i.GEQUAL,[mm]:i.GREATER,[gm]:i.NOTEQUAL};function G(S,v,B){if(B?(i.texParameteri(S,i.TEXTURE_WRAP_S,ee[v.wrapS]),i.texParameteri(S,i.TEXTURE_WRAP_T,ee[v.wrapT]),(S===i.TEXTURE_3D||S===i.TEXTURE_2D_ARRAY)&&i.texParameteri(S,i.TEXTURE_WRAP_R,ee[v.wrapR]),i.texParameteri(S,i.TEXTURE_MAG_FILTER,se[v.magFilter]),i.texParameteri(S,i.TEXTURE_MIN_FILTER,se[v.minFilter])):(i.texParameteri(S,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(S,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),(S===i.TEXTURE_3D||S===i.TEXTURE_2D_ARRAY)&&i.texParameteri(S,i.TEXTURE_WRAP_R,i.CLAMP_TO_EDGE),(v.wrapS!==mn||v.wrapT!==mn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),i.texParameteri(S,i.TEXTURE_MAG_FILTER,T(v.magFilter)),i.texParameteri(S,i.TEXTURE_MIN_FILTER,T(v.minFilter)),v.minFilter!==Rt&&v.minFilter!==an&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),v.compareFunction&&(i.texParameteri(S,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(S,i.TEXTURE_COMPARE_FUNC,me[v.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){let ie=e.get("EXT_texture_filter_anisotropic");if(v.magFilter===Rt||v.minFilter!==ur&&v.minFilter!==Pi||v.type===ri&&e.has("OES_texture_float_linear")===!1||a===!1&&v.type===xr&&e.has("OES_texture_half_float_linear")===!1)return;(v.anisotropy>1||n.get(v).__currentAnisotropy)&&(i.texParameterf(S,ie.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(v.anisotropy,s.getMaxAnisotropy())),n.get(v).__currentAnisotropy=v.anisotropy)}}function Z(S,v){let B=!1;S.__webglInit===void 0&&(S.__webglInit=!0,v.addEventListener("dispose",R));let ie=v.source,Q=d.get(ie);Q===void 0&&(Q={},d.set(ie,Q));let te=U(v);if(te!==S.__cacheKey){Q[te]===void 0&&(Q[te]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,B=!0),Q[te].usedTimes++;let ye=Q[S.__cacheKey];ye!==void 0&&(Q[S.__cacheKey].usedTimes--,ye.usedTimes===0&&E(v)),S.__cacheKey=te,S.__webglTexture=Q[te].texture}return B}function fe(S,v,B){let ie=i.TEXTURE_2D;(v.isDataArrayTexture||v.isCompressedArrayTexture)&&(ie=i.TEXTURE_2D_ARRAY),v.isData3DTexture&&(ie=i.TEXTURE_3D);let Q=Z(S,v),te=v.source;t.bindTexture(ie,S.__webglTexture,i.TEXTURE0+B);let ye=n.get(te);if(te.version!==ye.__version||Q===!0){t.activeTexture(i.TEXTURE0+B);let de=at.getPrimaries(at.workingColorSpace),_e=v.colorSpace===Mn?null:at.getPrimaries(v.colorSpace),Ie=v.colorSpace===Mn||de===_e?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,v.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,v.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,v.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ie);let He=p(v)&&m(v.image)===!1,J=_(v.image,He,!1,s.maxTextureSize);J=Be(v,J);let Je=m(J)||a,P=r.convert(v.format,v.colorSpace),$=r.convert(v.type),he=M(v.internalFormat,P,$,v.colorSpace,v.isVideoTexture);G(ie,v,Je);let re,be=v.mipmaps,qe=a&&v.isVideoTexture!==!0&&he!==Bd,Qe=ye.__version===void 0||Q===!0,We=A(v,J,Je);if(v.isDepthTexture)he=i.DEPTH_COMPONENT,a?v.type===ri?he=i.DEPTH_COMPONENT32F:v.type===Ei?he=i.DEPTH_COMPONENT24:v.type===Ki?he=i.DEPTH24_STENCIL8:he=i.DEPTH_COMPONENT16:v.type===ri&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),v.format===ji&&he===i.DEPTH_COMPONENT&&v.type!==xc&&v.type!==Ei&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),v.type=Ei,$=r.convert(v.type)),v.format===Ds&&he===i.DEPTH_COMPONENT&&(he=i.DEPTH_STENCIL,v.type!==Ki&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),v.type=Ki,$=r.convert(v.type))),Qe&&(qe?t.texStorage2D(i.TEXTURE_2D,1,he,J.width,J.height):t.texImage2D(i.TEXTURE_2D,0,he,J.width,J.height,0,P,$,null));else if(v.isDataTexture)if(be.length>0&&Je){qe&&Qe&&t.texStorage2D(i.TEXTURE_2D,We,he,be[0].width,be[0].height);for(let ce=0,L=be.length;ce<L;ce++)re=be[ce],qe?t.texSubImage2D(i.TEXTURE_2D,ce,0,0,re.width,re.height,P,$,re.data):t.texImage2D(i.TEXTURE_2D,ce,he,re.width,re.height,0,P,$,re.data);v.generateMipmaps=!1}else qe?(Qe&&t.texStorage2D(i.TEXTURE_2D,We,he,J.width,J.height),t.texSubImage2D(i.TEXTURE_2D,0,0,0,J.width,J.height,P,$,J.data)):t.texImage2D(i.TEXTURE_2D,0,he,J.width,J.height,0,P,$,J.data);else if(v.isCompressedTexture)if(v.isCompressedArrayTexture){qe&&Qe&&t.texStorage3D(i.TEXTURE_2D_ARRAY,We,he,be[0].width,be[0].height,J.depth);for(let ce=0,L=be.length;ce<L;ce++)re=be[ce],v.format!==bn?P!==null?qe?t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,re.width,re.height,J.depth,P,re.data,0,0):t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ce,he,re.width,re.height,J.depth,0,re.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):qe?t.texSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,re.width,re.height,J.depth,P,$,re.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ce,he,re.width,re.height,J.depth,0,P,$,re.data)}else{qe&&Qe&&t.texStorage2D(i.TEXTURE_2D,We,he,be[0].width,be[0].height);for(let ce=0,L=be.length;ce<L;ce++)re=be[ce],v.format!==bn?P!==null?qe?t.compressedTexSubImage2D(i.TEXTURE_2D,ce,0,0,re.width,re.height,P,re.data):t.compressedTexImage2D(i.TEXTURE_2D,ce,he,re.width,re.height,0,re.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):qe?t.texSubImage2D(i.TEXTURE_2D,ce,0,0,re.width,re.height,P,$,re.data):t.texImage2D(i.TEXTURE_2D,ce,he,re.width,re.height,0,P,$,re.data)}else if(v.isDataArrayTexture)qe?(Qe&&t.texStorage3D(i.TEXTURE_2D_ARRAY,We,he,J.width,J.height,J.depth),t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,J.width,J.height,J.depth,P,$,J.data)):t.texImage3D(i.TEXTURE_2D_ARRAY,0,he,J.width,J.height,J.depth,0,P,$,J.data);else if(v.isData3DTexture)qe?(Qe&&t.texStorage3D(i.TEXTURE_3D,We,he,J.width,J.height,J.depth),t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,J.width,J.height,J.depth,P,$,J.data)):t.texImage3D(i.TEXTURE_3D,0,he,J.width,J.height,J.depth,0,P,$,J.data);else if(v.isFramebufferTexture){if(Qe)if(qe)t.texStorage2D(i.TEXTURE_2D,We,he,J.width,J.height);else{let ce=J.width,L=J.height;for(let oe=0;oe<We;oe++)t.texImage2D(i.TEXTURE_2D,oe,he,ce,L,0,P,$,null),ce>>=1,L>>=1}}else if(be.length>0&&Je){qe&&Qe&&t.texStorage2D(i.TEXTURE_2D,We,he,be[0].width,be[0].height);for(let ce=0,L=be.length;ce<L;ce++)re=be[ce],qe?t.texSubImage2D(i.TEXTURE_2D,ce,0,0,P,$,re):t.texImage2D(i.TEXTURE_2D,ce,he,P,$,re);v.generateMipmaps=!1}else qe?(Qe&&t.texStorage2D(i.TEXTURE_2D,We,he,J.width,J.height),t.texSubImage2D(i.TEXTURE_2D,0,0,0,P,$,J)):t.texImage2D(i.TEXTURE_2D,0,he,P,$,J);y(v,Je)&&x(ie),ye.__version=te.version,v.onUpdate&&v.onUpdate(v)}S.__version=v.version}function we(S,v,B){if(v.image.length!==6)return;let ie=Z(S,v),Q=v.source;t.bindTexture(i.TEXTURE_CUBE_MAP,S.__webglTexture,i.TEXTURE0+B);let te=n.get(Q);if(Q.version!==te.__version||ie===!0){t.activeTexture(i.TEXTURE0+B);let ye=at.getPrimaries(at.workingColorSpace),de=v.colorSpace===Mn?null:at.getPrimaries(v.colorSpace),_e=v.colorSpace===Mn||ye===de?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,v.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,v.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,v.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,_e);let Ie=v.isCompressedTexture||v.image[0].isCompressedTexture,He=v.image[0]&&v.image[0].isDataTexture,J=[];for(let ce=0;ce<6;ce++)!Ie&&!He?J[ce]=_(v.image[ce],!1,!0,s.maxCubemapSize):J[ce]=He?v.image[ce].image:v.image[ce],J[ce]=Be(v,J[ce]);let Je=J[0],P=m(Je)||a,$=r.convert(v.format,v.colorSpace),he=r.convert(v.type),re=M(v.internalFormat,$,he,v.colorSpace),be=a&&v.isVideoTexture!==!0,qe=te.__version===void 0||ie===!0,Qe=A(v,Je,P);G(i.TEXTURE_CUBE_MAP,v,P);let We;if(Ie){be&&qe&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Qe,re,Je.width,Je.height);for(let ce=0;ce<6;ce++){We=J[ce].mipmaps;for(let L=0;L<We.length;L++){let oe=We[L];v.format!==bn?$!==null?be?t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L,0,0,oe.width,oe.height,$,oe.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L,re,oe.width,oe.height,0,oe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):be?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L,0,0,oe.width,oe.height,$,he,oe.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L,re,oe.width,oe.height,0,$,he,oe.data)}}}else{We=v.mipmaps,be&&qe&&(We.length>0&&Qe++,t.texStorage2D(i.TEXTURE_CUBE_MAP,Qe,re,J[0].width,J[0].height));for(let ce=0;ce<6;ce++)if(He){be?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,0,0,J[ce].width,J[ce].height,$,he,J[ce].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,re,J[ce].width,J[ce].height,0,$,he,J[ce].data);for(let L=0;L<We.length;L++){let le=We[L].image[ce].image;be?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L+1,0,0,le.width,le.height,$,he,le.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L+1,re,le.width,le.height,0,$,he,le.data)}}else{be?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,0,0,$,he,J[ce]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,re,$,he,J[ce]);for(let L=0;L<We.length;L++){let oe=We[L];be?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L+1,0,0,$,he,oe.image[ce]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,L+1,re,$,he,oe.image[ce])}}}y(v,P)&&x(i.TEXTURE_CUBE_MAP),te.__version=Q.version,v.onUpdate&&v.onUpdate(v)}S.__version=v.version}function ve(S,v,B,ie,Q,te){let ye=r.convert(B.format,B.colorSpace),de=r.convert(B.type),_e=M(B.internalFormat,ye,de,B.colorSpace);if(!n.get(v).__hasExternalTextures){let He=Math.max(1,v.width>>te),J=Math.max(1,v.height>>te);Q===i.TEXTURE_3D||Q===i.TEXTURE_2D_ARRAY?t.texImage3D(Q,te,_e,He,J,v.depth,0,ye,de,null):t.texImage2D(Q,te,_e,He,J,0,ye,de,null)}t.bindFramebuffer(i.FRAMEBUFFER,S),xe(v)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ie,Q,n.get(B).__webglTexture,0,Ne(v)):(Q===i.TEXTURE_2D||Q>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&Q<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,ie,Q,n.get(B).__webglTexture,te),t.bindFramebuffer(i.FRAMEBUFFER,null)}function Oe(S,v,B){if(i.bindRenderbuffer(i.RENDERBUFFER,S),v.depthBuffer&&!v.stencilBuffer){let ie=a===!0?i.DEPTH_COMPONENT24:i.DEPTH_COMPONENT16;if(B||xe(v)){let Q=v.depthTexture;Q&&Q.isDepthTexture&&(Q.type===ri?ie=i.DEPTH_COMPONENT32F:Q.type===Ei&&(ie=i.DEPTH_COMPONENT24));let te=Ne(v);xe(v)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,te,ie,v.width,v.height):i.renderbufferStorageMultisample(i.RENDERBUFFER,te,ie,v.width,v.height)}else i.renderbufferStorage(i.RENDERBUFFER,ie,v.width,v.height);i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.RENDERBUFFER,S)}else if(v.depthBuffer&&v.stencilBuffer){let ie=Ne(v);B&&xe(v)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,ie,i.DEPTH24_STENCIL8,v.width,v.height):xe(v)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ie,i.DEPTH24_STENCIL8,v.width,v.height):i.renderbufferStorage(i.RENDERBUFFER,i.DEPTH_STENCIL,v.width,v.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.RENDERBUFFER,S)}else{let ie=v.isWebGLMultipleRenderTargets===!0?v.texture:[v.texture];for(let Q=0;Q<ie.length;Q++){let te=ie[Q],ye=r.convert(te.format,te.colorSpace),de=r.convert(te.type),_e=M(te.internalFormat,ye,de,te.colorSpace),Ie=Ne(v);B&&xe(v)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ie,_e,v.width,v.height):xe(v)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ie,_e,v.width,v.height):i.renderbufferStorage(i.RENDERBUFFER,_e,v.width,v.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Fe(S,v){if(v&&v.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,S),!(v.depthTexture&&v.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(v.depthTexture).__webglTexture||v.depthTexture.image.width!==v.width||v.depthTexture.image.height!==v.height)&&(v.depthTexture.image.width=v.width,v.depthTexture.image.height=v.height,v.depthTexture.needsUpdate=!0),V(v.depthTexture,0);let ie=n.get(v.depthTexture).__webglTexture,Q=Ne(v);if(v.depthTexture.format===ji)xe(v)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ie,0,Q):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ie,0);else if(v.depthTexture.format===Ds)xe(v)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ie,0,Q):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ie,0);else throw new Error("Unknown depthTexture format")}function Le(S){let v=n.get(S),B=S.isWebGLCubeRenderTarget===!0;if(S.depthTexture&&!v.__autoAllocateDepthBuffer){if(B)throw new Error("target.depthTexture not supported in Cube render targets");Fe(v.__webglFramebuffer,S)}else if(B){v.__webglDepthbuffer=[];for(let ie=0;ie<6;ie++)t.bindFramebuffer(i.FRAMEBUFFER,v.__webglFramebuffer[ie]),v.__webglDepthbuffer[ie]=i.createRenderbuffer(),Oe(v.__webglDepthbuffer[ie],S,!1)}else t.bindFramebuffer(i.FRAMEBUFFER,v.__webglFramebuffer),v.__webglDepthbuffer=i.createRenderbuffer(),Oe(v.__webglDepthbuffer,S,!1);t.bindFramebuffer(i.FRAMEBUFFER,null)}function Ze(S,v,B){let ie=n.get(S);v!==void 0&&ve(ie.__webglFramebuffer,S,S.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),B!==void 0&&Le(S)}function F(S){let v=S.texture,B=n.get(S),ie=n.get(v);S.addEventListener("dispose",N),S.isWebGLMultipleRenderTargets!==!0&&(ie.__webglTexture===void 0&&(ie.__webglTexture=i.createTexture()),ie.__version=v.version,o.memory.textures++);let Q=S.isWebGLCubeRenderTarget===!0,te=S.isWebGLMultipleRenderTargets===!0,ye=m(S)||a;if(Q){B.__webglFramebuffer=[];for(let de=0;de<6;de++)if(a&&v.mipmaps&&v.mipmaps.length>0){B.__webglFramebuffer[de]=[];for(let _e=0;_e<v.mipmaps.length;_e++)B.__webglFramebuffer[de][_e]=i.createFramebuffer()}else B.__webglFramebuffer[de]=i.createFramebuffer()}else{if(a&&v.mipmaps&&v.mipmaps.length>0){B.__webglFramebuffer=[];for(let de=0;de<v.mipmaps.length;de++)B.__webglFramebuffer[de]=i.createFramebuffer()}else B.__webglFramebuffer=i.createFramebuffer();if(te)if(s.drawBuffers){let de=S.texture;for(let _e=0,Ie=de.length;_e<Ie;_e++){let He=n.get(de[_e]);He.__webglTexture===void 0&&(He.__webglTexture=i.createTexture(),o.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(a&&S.samples>0&&xe(S)===!1){let de=te?v:[v];B.__webglMultisampledFramebuffer=i.createFramebuffer(),B.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let _e=0;_e<de.length;_e++){let Ie=de[_e];B.__webglColorRenderbuffer[_e]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,B.__webglColorRenderbuffer[_e]);let He=r.convert(Ie.format,Ie.colorSpace),J=r.convert(Ie.type),Je=M(Ie.internalFormat,He,J,Ie.colorSpace,S.isXRRenderTarget===!0),P=Ne(S);i.renderbufferStorageMultisample(i.RENDERBUFFER,P,Je,S.width,S.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+_e,i.RENDERBUFFER,B.__webglColorRenderbuffer[_e])}i.bindRenderbuffer(i.RENDERBUFFER,null),S.depthBuffer&&(B.__webglDepthRenderbuffer=i.createRenderbuffer(),Oe(B.__webglDepthRenderbuffer,S,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(Q){t.bindTexture(i.TEXTURE_CUBE_MAP,ie.__webglTexture),G(i.TEXTURE_CUBE_MAP,v,ye);for(let de=0;de<6;de++)if(a&&v.mipmaps&&v.mipmaps.length>0)for(let _e=0;_e<v.mipmaps.length;_e++)ve(B.__webglFramebuffer[de][_e],S,v,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+de,_e);else ve(B.__webglFramebuffer[de],S,v,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0);y(v,ye)&&x(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(te){let de=S.texture;for(let _e=0,Ie=de.length;_e<Ie;_e++){let He=de[_e],J=n.get(He);t.bindTexture(i.TEXTURE_2D,J.__webglTexture),G(i.TEXTURE_2D,He,ye),ve(B.__webglFramebuffer,S,He,i.COLOR_ATTACHMENT0+_e,i.TEXTURE_2D,0),y(He,ye)&&x(i.TEXTURE_2D)}t.unbindTexture()}else{let de=i.TEXTURE_2D;if((S.isWebGL3DRenderTarget||S.isWebGLArrayRenderTarget)&&(a?de=S.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(de,ie.__webglTexture),G(de,v,ye),a&&v.mipmaps&&v.mipmaps.length>0)for(let _e=0;_e<v.mipmaps.length;_e++)ve(B.__webglFramebuffer[_e],S,v,i.COLOR_ATTACHMENT0,de,_e);else ve(B.__webglFramebuffer,S,v,i.COLOR_ATTACHMENT0,de,0);y(v,ye)&&x(de),t.unbindTexture()}S.depthBuffer&&Le(S)}function Ot(S){let v=m(S)||a,B=S.isWebGLMultipleRenderTargets===!0?S.texture:[S.texture];for(let ie=0,Q=B.length;ie<Q;ie++){let te=B[ie];if(y(te,v)){let ye=S.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:i.TEXTURE_2D,de=n.get(te).__webglTexture;t.bindTexture(ye,de),x(ye),t.unbindTexture()}}}function Ce(S){if(a&&S.samples>0&&xe(S)===!1){let v=S.isWebGLMultipleRenderTargets?S.texture:[S.texture],B=S.width,ie=S.height,Q=i.COLOR_BUFFER_BIT,te=[],ye=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,de=n.get(S),_e=S.isWebGLMultipleRenderTargets===!0;if(_e)for(let Ie=0;Ie<v.length;Ie++)t.bindFramebuffer(i.FRAMEBUFFER,de.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,de.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,de.__webglMultisampledFramebuffer),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,de.__webglFramebuffer);for(let Ie=0;Ie<v.length;Ie++){te.push(i.COLOR_ATTACHMENT0+Ie),S.depthBuffer&&te.push(ye);let He=de.__ignoreDepthValues!==void 0?de.__ignoreDepthValues:!1;if(He===!1&&(S.depthBuffer&&(Q|=i.DEPTH_BUFFER_BIT),S.stencilBuffer&&(Q|=i.STENCIL_BUFFER_BIT)),_e&&i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,de.__webglColorRenderbuffer[Ie]),He===!0&&(i.invalidateFramebuffer(i.READ_FRAMEBUFFER,[ye]),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[ye])),_e){let J=n.get(v[Ie]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,J,0)}i.blitFramebuffer(0,0,B,ie,0,0,B,ie,Q,i.NEAREST),c&&i.invalidateFramebuffer(i.READ_FRAMEBUFFER,te)}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),_e)for(let Ie=0;Ie<v.length;Ie++){t.bindFramebuffer(i.FRAMEBUFFER,de.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.RENDERBUFFER,de.__webglColorRenderbuffer[Ie]);let He=n.get(v[Ie]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,de.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.TEXTURE_2D,He,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,de.__webglMultisampledFramebuffer)}}function Ne(S){return Math.min(s.maxSamples,S.samples)}function xe(S){let v=n.get(S);return a&&S.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&v.__useRenderToTexture!==!1}function pt(S){let v=o.render.frame;h.get(S)!==v&&(h.set(S,v),S.update())}function Be(S,v){let B=S.colorSpace,ie=S.format,Q=S.type;return S.isCompressedTexture===!0||S.isVideoTexture===!0||S.format===Ol||B!==Pt&&B!==Mn&&(at.getTransfer(B)===mt?a===!1?e.has("EXT_sRGB")===!0&&ie===bn?(S.format=Ol,S.minFilter=an,S.generateMipmaps=!1):v=Oa.sRGBToLinear(v):(ie!==bn||Q!==Ci)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",B)),v}this.allocateTextureUnit=I,this.resetTextureUnits=ne,this.setTexture2D=V,this.setTexture2DArray=K,this.setTexture3D=Y,this.setTextureCube=q,this.rebindTextures=Ze,this.setupRenderTarget=F,this.updateRenderTargetMipmap=Ot,this.updateMultisampleRenderTarget=Ce,this.setupDepthRenderbuffer=Le,this.setupFrameBufferTexture=ve,this.useMultisampledRTT=xe}function by(i,e,t){let n=t.isWebGL2;function s(r,o=Mn){let a,l=at.getTransfer(o);if(r===Ci)return i.UNSIGNED_BYTE;if(r===Dd)return i.UNSIGNED_SHORT_4_4_4_4;if(r===Nd)return i.UNSIGNED_SHORT_5_5_5_1;if(r===Qp)return i.BYTE;if(r===em)return i.SHORT;if(r===xc)return i.UNSIGNED_SHORT;if(r===Id)return i.INT;if(r===Ei)return i.UNSIGNED_INT;if(r===ri)return i.FLOAT;if(r===xr)return n?i.HALF_FLOAT:(a=e.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(r===tm)return i.ALPHA;if(r===bn)return i.RGBA;if(r===nm)return i.LUMINANCE;if(r===im)return i.LUMINANCE_ALPHA;if(r===ji)return i.DEPTH_COMPONENT;if(r===Ds)return i.DEPTH_STENCIL;if(r===Ol)return a=e.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(r===sm)return i.RED;if(r===Ud)return i.RED_INTEGER;if(r===rm)return i.RG;if(r===Od)return i.RG_INTEGER;if(r===Fd)return i.RGBA_INTEGER;if(r===Jo||r===Qo||r===el||r===tl)if(l===mt)if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(r===Jo)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Qo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===el)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===tl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=e.get("WEBGL_compressed_texture_s3tc"),a!==null){if(r===Jo)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Qo)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===el)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===tl)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Zh||r===Jh||r===Qh||r===eu)if(a=e.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(r===Zh)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===Jh)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Qh)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===eu)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Bd)return a=e.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===tu||r===nu)if(a=e.get("WEBGL_compressed_texture_etc"),a!==null){if(r===tu)return l===mt?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(r===nu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===iu||r===su||r===ru||r===au||r===ou||r===lu||r===cu||r===hu||r===uu||r===du||r===fu||r===pu||r===mu||r===gu)if(a=e.get("WEBGL_compressed_texture_astc"),a!==null){if(r===iu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===su)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===ru)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===au)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===ou)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===lu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===cu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===hu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===uu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===du)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===fu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===pu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===mu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===gu)return l===mt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===nl||r===_u||r===xu)if(a=e.get("EXT_texture_compression_bptc"),a!==null){if(r===nl)return l===mt?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===_u)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===xu)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===am||r===yu||r===vu||r===bu)if(a=e.get("EXT_texture_compression_rgtc"),a!==null){if(r===nl)return a.COMPRESSED_RED_RGTC1_EXT;if(r===yu)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===vu)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===bu)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Ki?n?i.UNSIGNED_INT_24_8:(a=e.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):i[r]!==void 0?i[r]:null}return{convert:s}}var $l=class extends Ct{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},Jt=class extends vt{constructor(){super(),this.isGroup=!0,this.type="Group"}},My={type:"move"},mr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Jt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Jt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new C,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new C),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Jt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new C,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new C),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(let _ of e.hand.values()){let m=t.getJointPose(_,n),p=this._getHandJoint(c,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(My)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new Jt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},Zl=class extends On{constructor(e,t){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null,_=t.getContextAttributes(),m=null,p=null,y=[],x=[],M=new Re,A=null,T=new Ct;T.layers.enable(1),T.viewport=new dt;let R=new Ct;R.layers.enable(2),R.viewport=new dt;let N=[T,R],b=new $l;b.layers.enable(1),b.layers.enable(2);let E=null,O=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(G){let Z=y[G];return Z===void 0&&(Z=new mr,y[G]=Z),Z.getTargetRaySpace()},this.getControllerGrip=function(G){let Z=y[G];return Z===void 0&&(Z=new mr,y[G]=Z),Z.getGripSpace()},this.getHand=function(G){let Z=y[G];return Z===void 0&&(Z=new mr,y[G]=Z),Z.getHandSpace()};function W(G){let Z=x.indexOf(G.inputSource);if(Z===-1)return;let fe=y[Z];fe!==void 0&&(fe.update(G.inputSource,G.frame,c||o),fe.dispatchEvent({type:G.type,data:G.inputSource}))}function ne(){s.removeEventListener("select",W),s.removeEventListener("selectstart",W),s.removeEventListener("selectend",W),s.removeEventListener("squeeze",W),s.removeEventListener("squeezestart",W),s.removeEventListener("squeezeend",W),s.removeEventListener("end",ne),s.removeEventListener("inputsourceschange",I);for(let G=0;G<y.length;G++){let Z=x[G];Z!==null&&(x[G]=null,y[G].disconnect(Z))}E=null,O=null,e.setRenderTarget(m),f=null,d=null,u=null,s=null,p=null,me.stop(),n.isPresenting=!1,e.setPixelRatio(A),e.setSize(M.width,M.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(G){r=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(G){a=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(G){c=G},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(G){if(s=G,s!==null){if(m=e.getRenderTarget(),s.addEventListener("select",W),s.addEventListener("selectstart",W),s.addEventListener("selectend",W),s.addEventListener("squeeze",W),s.addEventListener("squeezestart",W),s.addEventListener("squeezeend",W),s.addEventListener("end",ne),s.addEventListener("inputsourceschange",I),_.xrCompatible!==!0&&await t.makeXRCompatible(),A=e.getPixelRatio(),e.getSize(M),s.renderState.layers===void 0||e.capabilities.isWebGL2===!1){let Z={antialias:s.renderState.layers===void 0?_.antialias:!0,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,Z),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),p=new oi(f.framebufferWidth,f.framebufferHeight,{format:bn,type:Ci,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil})}else{let Z=null,fe=null,we=null;_.depth&&(we=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Z=_.stencil?Ds:ji,fe=_.stencil?Ki:Ei);let ve={colorFormat:t.RGBA8,depthFormat:we,scaleFactor:r};u=new XRWebGLBinding(s,t),d=u.createProjectionLayer(ve),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),p=new oi(d.textureWidth,d.textureHeight,{format:bn,type:Ci,depthTexture:new Ga(d.textureWidth,d.textureHeight,fe,void 0,void 0,void 0,void 0,void 0,void 0,Z),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0});let Oe=e.properties.get(p);Oe.__ignoreDepthValues=d.ignoreDepthValues}p.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),me.setContext(s),me.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function I(G){for(let Z=0;Z<G.removed.length;Z++){let fe=G.removed[Z],we=x.indexOf(fe);we>=0&&(x[we]=null,y[we].disconnect(fe))}for(let Z=0;Z<G.added.length;Z++){let fe=G.added[Z],we=x.indexOf(fe);if(we===-1){for(let Oe=0;Oe<y.length;Oe++)if(Oe>=x.length){x.push(fe),we=Oe;break}else if(x[Oe]===null){x[Oe]=fe,we=Oe;break}if(we===-1)break}let ve=y[we];ve&&ve.connect(fe)}}let U=new C,V=new C;function K(G,Z,fe){U.setFromMatrixPosition(Z.matrixWorld),V.setFromMatrixPosition(fe.matrixWorld);let we=U.distanceTo(V),ve=Z.projectionMatrix.elements,Oe=fe.projectionMatrix.elements,Fe=ve[14]/(ve[10]-1),Le=ve[14]/(ve[10]+1),Ze=(ve[9]+1)/ve[5],F=(ve[9]-1)/ve[5],Ot=(ve[8]-1)/ve[0],Ce=(Oe[8]+1)/Oe[0],Ne=Fe*Ot,xe=Fe*Ce,pt=we/(-Ot+Ce),Be=pt*-Ot;Z.matrixWorld.decompose(G.position,G.quaternion,G.scale),G.translateX(Be),G.translateZ(pt),G.matrixWorld.compose(G.position,G.quaternion,G.scale),G.matrixWorldInverse.copy(G.matrixWorld).invert();let S=Fe+pt,v=Le+pt,B=Ne-Be,ie=xe+(we-Be),Q=Ze*Le/v*S,te=F*Le/v*S;G.projectionMatrix.makePerspective(B,ie,Q,te,S,v),G.projectionMatrixInverse.copy(G.projectionMatrix).invert()}function Y(G,Z){Z===null?G.matrixWorld.copy(G.matrix):G.matrixWorld.multiplyMatrices(Z.matrixWorld,G.matrix),G.matrixWorldInverse.copy(G.matrixWorld).invert()}this.updateCamera=function(G){if(s===null)return;b.near=R.near=T.near=G.near,b.far=R.far=T.far=G.far,(E!==b.near||O!==b.far)&&(s.updateRenderState({depthNear:b.near,depthFar:b.far}),E=b.near,O=b.far);let Z=G.parent,fe=b.cameras;Y(b,Z);for(let we=0;we<fe.length;we++)Y(fe[we],Z);fe.length===2?K(b,T,R):b.projectionMatrix.copy(T.projectionMatrix),q(G,b,Z)};function q(G,Z,fe){fe===null?G.matrix.copy(Z.matrixWorld):(G.matrix.copy(fe.matrixWorld),G.matrix.invert(),G.matrix.multiply(Z.matrixWorld)),G.matrix.decompose(G.position,G.quaternion,G.scale),G.updateMatrixWorld(!0),G.projectionMatrix.copy(Z.projectionMatrix),G.projectionMatrixInverse.copy(Z.projectionMatrixInverse),G.isPerspectiveCamera&&(G.fov=Us*2*Math.atan(1/G.projectionMatrix.elements[5]),G.zoom=1)}this.getCamera=function(){return b},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(G){l=G,d!==null&&(d.fixedFoveation=G),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=G)};let ee=null;function se(G,Z){if(h=Z.getViewerPose(c||o),g=Z,h!==null){let fe=h.views;f!==null&&(e.setRenderTargetFramebuffer(p,f.framebuffer),e.setRenderTarget(p));let we=!1;fe.length!==b.cameras.length&&(b.cameras.length=0,we=!0);for(let ve=0;ve<fe.length;ve++){let Oe=fe[ve],Fe=null;if(f!==null)Fe=f.getViewport(Oe);else{let Ze=u.getViewSubImage(d,Oe);Fe=Ze.viewport,ve===0&&(e.setRenderTargetTextures(p,Ze.colorTexture,d.ignoreDepthValues?void 0:Ze.depthStencilTexture),e.setRenderTarget(p))}let Le=N[ve];Le===void 0&&(Le=new Ct,Le.layers.enable(ve),Le.viewport=new dt,N[ve]=Le),Le.matrix.fromArray(Oe.transform.matrix),Le.matrix.decompose(Le.position,Le.quaternion,Le.scale),Le.projectionMatrix.fromArray(Oe.projectionMatrix),Le.projectionMatrixInverse.copy(Le.projectionMatrix).invert(),Le.viewport.set(Fe.x,Fe.y,Fe.width,Fe.height),ve===0&&(b.matrix.copy(Le.matrix),b.matrix.decompose(b.position,b.quaternion,b.scale)),we===!0&&b.cameras.push(Le)}}for(let fe=0;fe<y.length;fe++){let we=x[fe],ve=y[fe];we!==null&&ve!==void 0&&ve.update(we,Z,c||o)}ee&&ee(G,Z),Z.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Z}),g=null}let me=new qd;me.setAnimationLoop(se),this.setAnimationLoop=function(G){ee=G},this.dispose=function(){}}};function wy(i,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Xd(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,y,x,M){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,M)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,y,x):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===zt&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===zt&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let y=e.get(p).envMap;if(y&&(m.envMap.value=y,m.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap){m.lightMap.value=p.lightMap;let x=i._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=p.lightMapIntensity*x,t(p.lightMap,m.lightMapTransform)}p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,y,x){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*y,m.scale.value=x*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),e.get(p).envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,y){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===zt&&m.clearcoatNormalScale.value.negate())),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=y.texture,m.transmissionSamplerSize.value.set(y.width,y.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){let y=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(y.matrixWorld),m.nearDistance.value=y.shadow.camera.near,m.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Sy(i,e,t,n){let s={},r={},o=[],a=t.isWebGL2?i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(y,x){let M=x.program;n.uniformBlockBinding(y,M)}function c(y,x){let M=s[y.id];M===void 0&&(g(y),M=h(y),s[y.id]=M,y.addEventListener("dispose",m));let A=x.program;n.updateUBOMapping(y,A);let T=e.render.frame;r[y.id]!==T&&(d(y),r[y.id]=T)}function h(y){let x=u();y.__bindingPointIndex=x;let M=i.createBuffer(),A=y.__size,T=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,M),i.bufferData(i.UNIFORM_BUFFER,A,T),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,x,M),M}function u(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(y){let x=s[y.id],M=y.uniforms,A=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,x);for(let T=0,R=M.length;T<R;T++){let N=Array.isArray(M[T])?M[T]:[M[T]];for(let b=0,E=N.length;b<E;b++){let O=N[b];if(f(O,T,b,A)===!0){let W=O.__offset,ne=Array.isArray(O.value)?O.value:[O.value],I=0;for(let U=0;U<ne.length;U++){let V=ne[U],K=_(V);typeof V=="number"||typeof V=="boolean"?(O.__data[0]=V,i.bufferSubData(i.UNIFORM_BUFFER,W+I,O.__data)):V.isMatrix3?(O.__data[0]=V.elements[0],O.__data[1]=V.elements[1],O.__data[2]=V.elements[2],O.__data[3]=0,O.__data[4]=V.elements[3],O.__data[5]=V.elements[4],O.__data[6]=V.elements[5],O.__data[7]=0,O.__data[8]=V.elements[6],O.__data[9]=V.elements[7],O.__data[10]=V.elements[8],O.__data[11]=0):(V.toArray(O.__data,I),I+=K.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,W,O.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(y,x,M,A){let T=y.value,R=x+"_"+M;if(A[R]===void 0)return typeof T=="number"||typeof T=="boolean"?A[R]=T:A[R]=T.clone(),!0;{let N=A[R];if(typeof T=="number"||typeof T=="boolean"){if(N!==T)return A[R]=T,!0}else if(N.equals(T)===!1)return N.copy(T),!0}return!1}function g(y){let x=y.uniforms,M=0,A=16;for(let R=0,N=x.length;R<N;R++){let b=Array.isArray(x[R])?x[R]:[x[R]];for(let E=0,O=b.length;E<O;E++){let W=b[E],ne=Array.isArray(W.value)?W.value:[W.value];for(let I=0,U=ne.length;I<U;I++){let V=ne[I],K=_(V),Y=M%A;Y!==0&&A-Y<K.boundary&&(M+=A-Y),W.__data=new Float32Array(K.storage/Float32Array.BYTES_PER_ELEMENT),W.__offset=M,M+=K.storage}}}let T=M%A;return T>0&&(M+=A-T),y.__size=M,y.__cache={},this}function _(y){let x={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(x.boundary=4,x.storage=4):y.isVector2?(x.boundary=8,x.storage=8):y.isVector3||y.isColor?(x.boundary=16,x.storage=12):y.isVector4?(x.boundary=16,x.storage=16):y.isMatrix3?(x.boundary=48,x.storage=48):y.isMatrix4?(x.boundary=64,x.storage=64):y.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",y),x}function m(y){let x=y.target;x.removeEventListener("dispose",m);let M=o.indexOf(x.__bindingPointIndex);o.splice(M,1),i.deleteBuffer(s[x.id]),delete s[x.id],delete r[x.id]}function p(){for(let y in s)i.deleteBuffer(s[y]);o=[],s={},r={}}return{bind:l,update:c,dispose:p}}var Mr=class{constructor(e={}){let{canvas:t=Dm(),context:n=null,depth:s=!0,stencil:r=!0,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=e;this.isWebGLRenderer=!0;let d;n!==null?d=n.getContextAttributes().alpha:d=o;let f=new Uint32Array(4),g=new Int32Array(4),_=null,m=null,p=[],y=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=ut,this._useLegacyLights=!1,this.toneMapping=Ri,this.toneMappingExposure=1;let x=this,M=!1,A=0,T=0,R=null,N=-1,b=null,E=new dt,O=new dt,W=null,ne=new Te(0),I=0,U=t.width,V=t.height,K=1,Y=null,q=null,ee=new dt(0,0,U,V),se=new dt(0,0,U,V),me=!1,G=new br,Z=!1,fe=!1,we=null,ve=new ze,Oe=new Re,Fe=new C,Le={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function Ze(){return R===null?K:1}let F=n;function Ot(w,D){for(let z=0;z<w.length;z++){let H=w[z],k=t.getContext(H,D);if(k!==null)return k}return null}try{let w={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${pc}`),t.addEventListener("webglcontextlost",ce,!1),t.addEventListener("webglcontextrestored",L,!1),t.addEventListener("webglcontextcreationerror",oe,!1),F===null){let D=["webgl2","webgl","experimental-webgl"];if(x.isWebGL1Renderer===!0&&D.shift(),F=Ot(D,w),F===null)throw Ot(D)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&F instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),F.getShaderPrecisionFormat===void 0&&(F.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(w){throw console.error("THREE.WebGLRenderer: "+w.message),w}let Ce,Ne,xe,pt,Be,S,v,B,ie,Q,te,ye,de,_e,Ie,He,J,Je,P,$,he,re,be,qe;function Qe(){Ce=new G_(F),Ne=new F_(F,Ce,e),Ce.init(Ne),re=new by(F,Ce,Ne),xe=new yy(F,Ce,Ne),pt=new q_(F),Be=new oy,S=new vy(F,Ce,xe,Be,Ne,re,pt),v=new k_(x),B=new V_(x),ie=new eg(F,Ne),be=new U_(F,Ce,ie,Ne),Q=new W_(F,ie,pt,be),te=new $_(F,Q,ie,pt),P=new j_(F,Ne,S),He=new B_(Be),ye=new ay(x,v,B,Ce,Ne,be,He),de=new wy(x,Be),_e=new cy,Ie=new my(Ce,Ne),Je=new N_(x,v,B,xe,te,d,l),J=new xy(x,te,Ne),qe=new Sy(F,pt,Ne,xe),$=new O_(F,Ce,pt,Ne),he=new X_(F,Ce,pt,Ne),pt.programs=ye.programs,x.capabilities=Ne,x.extensions=Ce,x.properties=Be,x.renderLists=_e,x.shadowMap=J,x.state=xe,x.info=pt}Qe();let We=new Zl(x,F);this.xr=We,this.getContext=function(){return F},this.getContextAttributes=function(){return F.getContextAttributes()},this.forceContextLoss=function(){let w=Ce.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){let w=Ce.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return K},this.setPixelRatio=function(w){w!==void 0&&(K=w,this.setSize(U,V,!1))},this.getSize=function(w){return w.set(U,V)},this.setSize=function(w,D,z=!0){if(We.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}U=w,V=D,t.width=Math.floor(w*K),t.height=Math.floor(D*K),z===!0&&(t.style.width=w+"px",t.style.height=D+"px"),this.setViewport(0,0,w,D)},this.getDrawingBufferSize=function(w){return w.set(U*K,V*K).floor()},this.setDrawingBufferSize=function(w,D,z){U=w,V=D,K=z,t.width=Math.floor(w*z),t.height=Math.floor(D*z),this.setViewport(0,0,w,D)},this.getCurrentViewport=function(w){return w.copy(E)},this.getViewport=function(w){return w.copy(ee)},this.setViewport=function(w,D,z,H){w.isVector4?ee.set(w.x,w.y,w.z,w.w):ee.set(w,D,z,H),xe.viewport(E.copy(ee).multiplyScalar(K).floor())},this.getScissor=function(w){return w.copy(se)},this.setScissor=function(w,D,z,H){w.isVector4?se.set(w.x,w.y,w.z,w.w):se.set(w,D,z,H),xe.scissor(O.copy(se).multiplyScalar(K).floor())},this.getScissorTest=function(){return me},this.setScissorTest=function(w){xe.setScissorTest(me=w)},this.setOpaqueSort=function(w){Y=w},this.setTransparentSort=function(w){q=w},this.getClearColor=function(w){return w.copy(Je.getClearColor())},this.setClearColor=function(){Je.setClearColor.apply(Je,arguments)},this.getClearAlpha=function(){return Je.getClearAlpha()},this.setClearAlpha=function(){Je.setClearAlpha.apply(Je,arguments)},this.clear=function(w=!0,D=!0,z=!0){let H=0;if(w){let k=!1;if(R!==null){let ge=R.texture.format;k=ge===Fd||ge===Od||ge===Ud}if(k){let ge=R.texture.type,Ee=ge===Ci||ge===Ei||ge===xc||ge===Ki||ge===Dd||ge===Nd,De=Je.getClearColor(),Ue=Je.getClearAlpha(),Xe=De.r,ke=De.g,Ve=De.b;Ee?(f[0]=Xe,f[1]=ke,f[2]=Ve,f[3]=Ue,F.clearBufferuiv(F.COLOR,0,f)):(g[0]=Xe,g[1]=ke,g[2]=Ve,g[3]=Ue,F.clearBufferiv(F.COLOR,0,g))}else H|=F.COLOR_BUFFER_BIT}D&&(H|=F.DEPTH_BUFFER_BIT),z&&(H|=F.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),F.clear(H)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ce,!1),t.removeEventListener("webglcontextrestored",L,!1),t.removeEventListener("webglcontextcreationerror",oe,!1),_e.dispose(),Ie.dispose(),Be.dispose(),v.dispose(),B.dispose(),te.dispose(),be.dispose(),qe.dispose(),ye.dispose(),We.dispose(),We.removeEventListener("sessionstart",tn),We.removeEventListener("sessionend",ft),we&&(we.dispose(),we=null),nn.stop()};function ce(w){w.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),M=!0}function L(){console.log("THREE.WebGLRenderer: Context Restored."),M=!1;let w=pt.autoReset,D=J.enabled,z=J.autoUpdate,H=J.needsUpdate,k=J.type;Qe(),pt.autoReset=w,J.enabled=D,J.autoUpdate=z,J.needsUpdate=H,J.type=k}function oe(w){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function le(w){let D=w.target;D.removeEventListener("dispose",le),Pe(D)}function Pe(w){Se(w),Be.remove(w)}function Se(w){let D=Be.get(w).programs;D!==void 0&&(D.forEach(function(z){ye.releaseProgram(z)}),w.isShaderMaterial&&ye.releaseShaderCache(w))}this.renderBufferDirect=function(w,D,z,H,k,ge){D===null&&(D=Le);let Ee=k.isMesh&&k.matrixWorld.determinant()<0,De=gp(w,D,z,H,k);xe.setMaterial(H,Ee);let Ue=z.index,Xe=1;if(H.wireframe===!0){if(Ue=Q.getWireframeAttribute(z),Ue===void 0)return;Xe=2}let ke=z.drawRange,Ve=z.attributes.position,St=ke.start*Xe,dn=(ke.start+ke.count)*Xe;ge!==null&&(St=Math.max(St,ge.start*Xe),dn=Math.min(dn,(ge.start+ge.count)*Xe)),Ue!==null?(St=Math.max(St,0),dn=Math.min(dn,Ue.count)):Ve!=null&&(St=Math.max(St,0),dn=Math.min(dn,Ve.count));let Bt=dn-St;if(Bt<0||Bt===1/0)return;be.setup(k,H,De,z,Ue);let Zn,yt=$;if(Ue!==null&&(Zn=ie.get(Ue),yt=he,yt.setIndex(Zn)),k.isMesh)H.wireframe===!0?(xe.setLineWidth(H.wireframeLinewidth*Ze()),yt.setMode(F.LINES)):yt.setMode(F.TRIANGLES);else if(k.isLine){let Ye=H.linewidth;Ye===void 0&&(Ye=1),xe.setLineWidth(Ye*Ze()),k.isLineSegments?yt.setMode(F.LINES):k.isLineLoop?yt.setMode(F.LINE_LOOP):yt.setMode(F.LINE_STRIP)}else k.isPoints?yt.setMode(F.POINTS):k.isSprite&&yt.setMode(F.TRIANGLES);if(k.isBatchedMesh)yt.renderMultiDraw(k._multiDrawStarts,k._multiDrawCounts,k._multiDrawCount);else if(k.isInstancedMesh)yt.renderInstances(St,Bt,k.count);else if(z.isInstancedBufferGeometry){let Ye=z._maxInstanceCount!==void 0?z._maxInstanceCount:1/0,Ko=Math.min(z.instanceCount,Ye);yt.renderInstances(St,Bt,Ko)}else yt.render(St,Bt)};function it(w,D,z){w.transparent===!0&&w.side===_t&&w.forceSinglePass===!1?(w.side=zt,w.needsUpdate=!0,Qr(w,D,z),w.side=Wn,w.needsUpdate=!0,Qr(w,D,z),w.side=_t):Qr(w,D,z)}this.compile=function(w,D,z=null){z===null&&(z=w),m=Ie.get(z),m.init(),y.push(m),z.traverseVisible(function(k){k.isLight&&k.layers.test(D.layers)&&(m.pushLight(k),k.castShadow&&m.pushShadow(k))}),w!==z&&w.traverseVisible(function(k){k.isLight&&k.layers.test(D.layers)&&(m.pushLight(k),k.castShadow&&m.pushShadow(k))}),m.setupLights(x._useLegacyLights);let H=new Set;return w.traverse(function(k){let ge=k.material;if(ge)if(Array.isArray(ge))for(let Ee=0;Ee<ge.length;Ee++){let De=ge[Ee];it(De,z,k),H.add(De)}else it(ge,z,k),H.add(ge)}),y.pop(),m=null,H},this.compileAsync=function(w,D,z=null){let H=this.compile(w,D,z);return new Promise(k=>{function ge(){if(H.forEach(function(Ee){Be.get(Ee).currentProgram.isReady()&&H.delete(Ee)}),H.size===0){k(w);return}setTimeout(ge,10)}Ce.get("KHR_parallel_shader_compile")!==null?ge():setTimeout(ge,10)})};let rt=null;function Ft(w){rt&&rt(w)}function tn(){nn.stop()}function ft(){nn.start()}let nn=new qd;nn.setAnimationLoop(Ft),typeof self<"u"&&nn.setContext(self),this.setAnimationLoop=function(w){rt=w,We.setAnimationLoop(w),w===null?nn.stop():nn.start()},We.addEventListener("sessionstart",tn),We.addEventListener("sessionend",ft),this.render=function(w,D){if(D!==void 0&&D.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(M===!0)return;w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),D.parent===null&&D.matrixWorldAutoUpdate===!0&&D.updateMatrixWorld(),We.enabled===!0&&We.isPresenting===!0&&(We.cameraAutoUpdate===!0&&We.updateCamera(D),D=We.getCamera()),w.isScene===!0&&w.onBeforeRender(x,w,D,R),m=Ie.get(w,y.length),m.init(),y.push(m),ve.multiplyMatrices(D.projectionMatrix,D.matrixWorldInverse),G.setFromProjectionMatrix(ve),fe=this.localClippingEnabled,Z=He.init(this.clippingPlanes,fe),_=_e.get(w,p.length),_.init(),p.push(_),Hn(w,D,0,x.sortObjects),_.finish(),x.sortObjects===!0&&_.sort(Y,q),this.info.render.frame++,Z===!0&&He.beginShadows();let z=m.state.shadowsArray;if(J.render(z,w,D),Z===!0&&He.endShadows(),this.info.autoReset===!0&&this.info.reset(),Je.render(_,w),m.setupLights(x._useLegacyLights),D.isArrayCamera){let H=D.cameras;for(let k=0,ge=H.length;k<ge;k++){let Ee=H[k];kh(_,w,Ee,Ee.viewport)}}else kh(_,w,D);R!==null&&(S.updateMultisampleRenderTarget(R),S.updateRenderTargetMipmap(R)),w.isScene===!0&&w.onAfterRender(x,w,D),be.resetDefaultState(),N=-1,b=null,y.pop(),y.length>0?m=y[y.length-1]:m=null,p.pop(),p.length>0?_=p[p.length-1]:_=null};function Hn(w,D,z,H){if(w.visible===!1)return;if(w.layers.test(D.layers)){if(w.isGroup)z=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(D);else if(w.isLight)m.pushLight(w),w.castShadow&&m.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||G.intersectsSprite(w)){H&&Fe.setFromMatrixPosition(w.matrixWorld).applyMatrix4(ve);let Ee=te.update(w),De=w.material;De.visible&&_.push(w,Ee,De,z,Fe.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||G.intersectsObject(w))){let Ee=te.update(w),De=w.material;if(H&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Fe.copy(w.boundingSphere.center)):(Ee.boundingSphere===null&&Ee.computeBoundingSphere(),Fe.copy(Ee.boundingSphere.center)),Fe.applyMatrix4(w.matrixWorld).applyMatrix4(ve)),Array.isArray(De)){let Ue=Ee.groups;for(let Xe=0,ke=Ue.length;Xe<ke;Xe++){let Ve=Ue[Xe],St=De[Ve.materialIndex];St&&St.visible&&_.push(w,Ee,St,z,Fe.z,Ve)}}else De.visible&&_.push(w,Ee,De,z,Fe.z,null)}}let ge=w.children;for(let Ee=0,De=ge.length;Ee<De;Ee++)Hn(ge[Ee],D,z,H)}function kh(w,D,z,H){let k=w.opaque,ge=w.transmissive,Ee=w.transparent;m.setupLightsView(z),Z===!0&&He.setGlobalState(x.clippingPlanes,z),ge.length>0&&mp(k,ge,D,z),H&&xe.viewport(E.copy(H)),k.length>0&&Jr(k,D,z),ge.length>0&&Jr(ge,D,z),Ee.length>0&&Jr(Ee,D,z),xe.buffers.depth.setTest(!0),xe.buffers.depth.setMask(!0),xe.buffers.color.setMask(!0),xe.setPolygonOffset(!1)}function mp(w,D,z,H){if((z.isScene===!0?z.overrideMaterial:null)!==null)return;let ge=Ne.isWebGL2;we===null&&(we=new oi(1,1,{generateMipmaps:!0,type:Ce.has("EXT_color_buffer_half_float")?xr:Ci,minFilter:Pi,samples:ge?4:0})),x.getDrawingBufferSize(Oe),ge?we.setSize(Oe.x,Oe.y):we.setSize(Ua(Oe.x),Ua(Oe.y));let Ee=x.getRenderTarget();x.setRenderTarget(we),x.getClearColor(ne),I=x.getClearAlpha(),I<1&&x.setClearColor(16777215,.5),x.clear();let De=x.toneMapping;x.toneMapping=Ri,Jr(w,z,H),S.updateMultisampleRenderTarget(we),S.updateRenderTargetMipmap(we);let Ue=!1;for(let Xe=0,ke=D.length;Xe<ke;Xe++){let Ve=D[Xe],St=Ve.object,dn=Ve.geometry,Bt=Ve.material,Zn=Ve.group;if(Bt.side===_t&&St.layers.test(H.layers)){let yt=Bt.side;Bt.side=zt,Bt.needsUpdate=!0,zh(St,z,H,dn,Bt,Zn),Bt.side=yt,Bt.needsUpdate=!0,Ue=!0}}Ue===!0&&(S.updateMultisampleRenderTarget(we),S.updateRenderTargetMipmap(we)),x.setRenderTarget(Ee),x.setClearColor(ne,I),x.toneMapping=De}function Jr(w,D,z){let H=D.isScene===!0?D.overrideMaterial:null;for(let k=0,ge=w.length;k<ge;k++){let Ee=w[k],De=Ee.object,Ue=Ee.geometry,Xe=H===null?Ee.material:H,ke=Ee.group;De.layers.test(z.layers)&&zh(De,D,z,Ue,Xe,ke)}}function zh(w,D,z,H,k,ge){w.onBeforeRender(x,D,z,H,k,ge),w.modelViewMatrix.multiplyMatrices(z.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),k.onBeforeRender(x,D,z,H,w,ge),k.transparent===!0&&k.side===_t&&k.forceSinglePass===!1?(k.side=zt,k.needsUpdate=!0,x.renderBufferDirect(z,D,H,k,w,ge),k.side=Wn,k.needsUpdate=!0,x.renderBufferDirect(z,D,H,k,w,ge),k.side=_t):x.renderBufferDirect(z,D,H,k,w,ge),w.onAfterRender(x,D,z,H,k,ge)}function Qr(w,D,z){D.isScene!==!0&&(D=Le);let H=Be.get(w),k=m.state.lights,ge=m.state.shadowsArray,Ee=k.state.version,De=ye.getParameters(w,k.state,ge,D,z),Ue=ye.getProgramCacheKey(De),Xe=H.programs;H.environment=w.isMeshStandardMaterial?D.environment:null,H.fog=D.fog,H.envMap=(w.isMeshStandardMaterial?B:v).get(w.envMap||H.environment),Xe===void 0&&(w.addEventListener("dispose",le),Xe=new Map,H.programs=Xe);let ke=Xe.get(Ue);if(ke!==void 0){if(H.currentProgram===ke&&H.lightsStateVersion===Ee)return Vh(w,De),ke}else De.uniforms=ye.getUniforms(w),w.onBuild(z,De,x),w.onBeforeCompile(De,x),ke=ye.acquireProgram(De,Ue),Xe.set(Ue,ke),H.uniforms=De.uniforms;let Ve=H.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Ve.clippingPlanes=He.uniform),Vh(w,De),H.needsLights=xp(w),H.lightsStateVersion=Ee,H.needsLights&&(Ve.ambientLightColor.value=k.state.ambient,Ve.lightProbe.value=k.state.probe,Ve.directionalLights.value=k.state.directional,Ve.directionalLightShadows.value=k.state.directionalShadow,Ve.spotLights.value=k.state.spot,Ve.spotLightShadows.value=k.state.spotShadow,Ve.rectAreaLights.value=k.state.rectArea,Ve.ltc_1.value=k.state.rectAreaLTC1,Ve.ltc_2.value=k.state.rectAreaLTC2,Ve.pointLights.value=k.state.point,Ve.pointLightShadows.value=k.state.pointShadow,Ve.hemisphereLights.value=k.state.hemi,Ve.directionalShadowMap.value=k.state.directionalShadowMap,Ve.directionalShadowMatrix.value=k.state.directionalShadowMatrix,Ve.spotShadowMap.value=k.state.spotShadowMap,Ve.spotLightMatrix.value=k.state.spotLightMatrix,Ve.spotLightMap.value=k.state.spotLightMap,Ve.pointShadowMap.value=k.state.pointShadowMap,Ve.pointShadowMatrix.value=k.state.pointShadowMatrix),H.currentProgram=ke,H.uniformsList=null,ke}function Hh(w){if(w.uniformsList===null){let D=w.currentProgram.getUniforms();w.uniformsList=Ps.seqWithValue(D.seq,w.uniforms)}return w.uniformsList}function Vh(w,D){let z=Be.get(w);z.outputColorSpace=D.outputColorSpace,z.batching=D.batching,z.instancing=D.instancing,z.instancingColor=D.instancingColor,z.skinning=D.skinning,z.morphTargets=D.morphTargets,z.morphNormals=D.morphNormals,z.morphColors=D.morphColors,z.morphTargetsCount=D.morphTargetsCount,z.numClippingPlanes=D.numClippingPlanes,z.numIntersection=D.numClipIntersection,z.vertexAlphas=D.vertexAlphas,z.vertexTangents=D.vertexTangents,z.toneMapping=D.toneMapping}function gp(w,D,z,H,k){D.isScene!==!0&&(D=Le),S.resetTextureUnits();let ge=D.fog,Ee=H.isMeshStandardMaterial?D.environment:null,De=R===null?x.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:Pt,Ue=(H.isMeshStandardMaterial?B:v).get(H.envMap||Ee),Xe=H.vertexColors===!0&&!!z.attributes.color&&z.attributes.color.itemSize===4,ke=!!z.attributes.tangent&&(!!H.normalMap||H.anisotropy>0),Ve=!!z.morphAttributes.position,St=!!z.morphAttributes.normal,dn=!!z.morphAttributes.color,Bt=Ri;H.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(Bt=x.toneMapping);let Zn=z.morphAttributes.position||z.morphAttributes.normal||z.morphAttributes.color,yt=Zn!==void 0?Zn.length:0,Ye=Be.get(H),Ko=m.state.lights;if(Z===!0&&(fe===!0||w!==b)){let yn=w===b&&H.id===N;He.setState(H,w,yn)}let Mt=!1;H.version===Ye.__version?(Ye.needsLights&&Ye.lightsStateVersion!==Ko.state.version||Ye.outputColorSpace!==De||k.isBatchedMesh&&Ye.batching===!1||!k.isBatchedMesh&&Ye.batching===!0||k.isInstancedMesh&&Ye.instancing===!1||!k.isInstancedMesh&&Ye.instancing===!0||k.isSkinnedMesh&&Ye.skinning===!1||!k.isSkinnedMesh&&Ye.skinning===!0||k.isInstancedMesh&&Ye.instancingColor===!0&&k.instanceColor===null||k.isInstancedMesh&&Ye.instancingColor===!1&&k.instanceColor!==null||Ye.envMap!==Ue||H.fog===!0&&Ye.fog!==ge||Ye.numClippingPlanes!==void 0&&(Ye.numClippingPlanes!==He.numPlanes||Ye.numIntersection!==He.numIntersection)||Ye.vertexAlphas!==Xe||Ye.vertexTangents!==ke||Ye.morphTargets!==Ve||Ye.morphNormals!==St||Ye.morphColors!==dn||Ye.toneMapping!==Bt||Ne.isWebGL2===!0&&Ye.morphTargetsCount!==yt)&&(Mt=!0):(Mt=!0,Ye.__version=H.version);let ki=Ye.currentProgram;Mt===!0&&(ki=Qr(H,D,k));let Gh=!1,ir=!1,jo=!1,jt=ki.getUniforms(),zi=Ye.uniforms;if(xe.useProgram(ki.program)&&(Gh=!0,ir=!0,jo=!0),H.id!==N&&(N=H.id,ir=!0),Gh||b!==w){jt.setValue(F,"projectionMatrix",w.projectionMatrix),jt.setValue(F,"viewMatrix",w.matrixWorldInverse);let yn=jt.map.cameraPosition;yn!==void 0&&yn.setValue(F,Fe.setFromMatrixPosition(w.matrixWorld)),Ne.logarithmicDepthBuffer&&jt.setValue(F,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(H.isMeshPhongMaterial||H.isMeshToonMaterial||H.isMeshLambertMaterial||H.isMeshBasicMaterial||H.isMeshStandardMaterial||H.isShaderMaterial)&&jt.setValue(F,"isOrthographic",w.isOrthographicCamera===!0),b!==w&&(b=w,ir=!0,jo=!0)}if(k.isSkinnedMesh){jt.setOptional(F,k,"bindMatrix"),jt.setOptional(F,k,"bindMatrixInverse");let yn=k.skeleton;yn&&(Ne.floatVertexTextures?(yn.boneTexture===null&&yn.computeBoneTexture(),jt.setValue(F,"boneTexture",yn.boneTexture,S)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}k.isBatchedMesh&&(jt.setOptional(F,k,"batchingTexture"),jt.setValue(F,"batchingTexture",k._matricesTexture,S));let $o=z.morphAttributes;if(($o.position!==void 0||$o.normal!==void 0||$o.color!==void 0&&Ne.isWebGL2===!0)&&P.update(k,z,ki),(ir||Ye.receiveShadow!==k.receiveShadow)&&(Ye.receiveShadow=k.receiveShadow,jt.setValue(F,"receiveShadow",k.receiveShadow)),H.isMeshGouraudMaterial&&H.envMap!==null&&(zi.envMap.value=Ue,zi.flipEnvMap.value=Ue.isCubeTexture&&Ue.isRenderTargetTexture===!1?-1:1),ir&&(jt.setValue(F,"toneMappingExposure",x.toneMappingExposure),Ye.needsLights&&_p(zi,jo),ge&&H.fog===!0&&de.refreshFogUniforms(zi,ge),de.refreshMaterialUniforms(zi,H,K,V,we),Ps.upload(F,Hh(Ye),zi,S)),H.isShaderMaterial&&H.uniformsNeedUpdate===!0&&(Ps.upload(F,Hh(Ye),zi,S),H.uniformsNeedUpdate=!1),H.isSpriteMaterial&&jt.setValue(F,"center",k.center),jt.setValue(F,"modelViewMatrix",k.modelViewMatrix),jt.setValue(F,"normalMatrix",k.normalMatrix),jt.setValue(F,"modelMatrix",k.matrixWorld),H.isShaderMaterial||H.isRawShaderMaterial){let yn=H.uniformsGroups;for(let Zo=0,yp=yn.length;Zo<yp;Zo++)if(Ne.isWebGL2){let Wh=yn[Zo];qe.update(Wh,ki),qe.bind(Wh,ki)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return ki}function _p(w,D){w.ambientLightColor.needsUpdate=D,w.lightProbe.needsUpdate=D,w.directionalLights.needsUpdate=D,w.directionalLightShadows.needsUpdate=D,w.pointLights.needsUpdate=D,w.pointLightShadows.needsUpdate=D,w.spotLights.needsUpdate=D,w.spotLightShadows.needsUpdate=D,w.rectAreaLights.needsUpdate=D,w.hemisphereLights.needsUpdate=D}function xp(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return A},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(w,D,z){Be.get(w.texture).__webglTexture=D,Be.get(w.depthTexture).__webglTexture=z;let H=Be.get(w);H.__hasExternalTextures=!0,H.__hasExternalTextures&&(H.__autoAllocateDepthBuffer=z===void 0,H.__autoAllocateDepthBuffer||Ce.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),H.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(w,D){let z=Be.get(w);z.__webglFramebuffer=D,z.__useDefaultFramebuffer=D===void 0},this.setRenderTarget=function(w,D=0,z=0){R=w,A=D,T=z;let H=!0,k=null,ge=!1,Ee=!1;if(w){let Ue=Be.get(w);Ue.__useDefaultFramebuffer!==void 0?(xe.bindFramebuffer(F.FRAMEBUFFER,null),H=!1):Ue.__webglFramebuffer===void 0?S.setupRenderTarget(w):Ue.__hasExternalTextures&&S.rebindTextures(w,Be.get(w.texture).__webglTexture,Be.get(w.depthTexture).__webglTexture);let Xe=w.texture;(Xe.isData3DTexture||Xe.isDataArrayTexture||Xe.isCompressedArrayTexture)&&(Ee=!0);let ke=Be.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(ke[D])?k=ke[D][z]:k=ke[D],ge=!0):Ne.isWebGL2&&w.samples>0&&S.useMultisampledRTT(w)===!1?k=Be.get(w).__webglMultisampledFramebuffer:Array.isArray(ke)?k=ke[z]:k=ke,E.copy(w.viewport),O.copy(w.scissor),W=w.scissorTest}else E.copy(ee).multiplyScalar(K).floor(),O.copy(se).multiplyScalar(K).floor(),W=me;if(xe.bindFramebuffer(F.FRAMEBUFFER,k)&&Ne.drawBuffers&&H&&xe.drawBuffers(w,k),xe.viewport(E),xe.scissor(O),xe.setScissorTest(W),ge){let Ue=Be.get(w.texture);F.framebufferTexture2D(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_CUBE_MAP_POSITIVE_X+D,Ue.__webglTexture,z)}else if(Ee){let Ue=Be.get(w.texture),Xe=D||0;F.framebufferTextureLayer(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,Ue.__webglTexture,z||0,Xe)}N=-1},this.readRenderTargetPixels=function(w,D,z,H,k,ge,Ee){if(!(w&&w.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let De=Be.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Ee!==void 0&&(De=De[Ee]),De){xe.bindFramebuffer(F.FRAMEBUFFER,De);try{let Ue=w.texture,Xe=Ue.format,ke=Ue.type;if(Xe!==bn&&re.convert(Xe)!==F.getParameter(F.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Ve=ke===xr&&(Ce.has("EXT_color_buffer_half_float")||Ne.isWebGL2&&Ce.has("EXT_color_buffer_float"));if(ke!==Ci&&re.convert(ke)!==F.getParameter(F.IMPLEMENTATION_COLOR_READ_TYPE)&&!(ke===ri&&(Ne.isWebGL2||Ce.has("OES_texture_float")||Ce.has("WEBGL_color_buffer_float")))&&!Ve){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}D>=0&&D<=w.width-H&&z>=0&&z<=w.height-k&&F.readPixels(D,z,H,k,re.convert(Xe),re.convert(ke),ge)}finally{let Ue=R!==null?Be.get(R).__webglFramebuffer:null;xe.bindFramebuffer(F.FRAMEBUFFER,Ue)}}},this.copyFramebufferToTexture=function(w,D,z=0){let H=Math.pow(2,-z),k=Math.floor(D.image.width*H),ge=Math.floor(D.image.height*H);S.setTexture2D(D,0),F.copyTexSubImage2D(F.TEXTURE_2D,z,0,0,w.x,w.y,k,ge),xe.unbindTexture()},this.copyTextureToTexture=function(w,D,z,H=0){let k=D.image.width,ge=D.image.height,Ee=re.convert(z.format),De=re.convert(z.type);S.setTexture2D(z,0),F.pixelStorei(F.UNPACK_FLIP_Y_WEBGL,z.flipY),F.pixelStorei(F.UNPACK_PREMULTIPLY_ALPHA_WEBGL,z.premultiplyAlpha),F.pixelStorei(F.UNPACK_ALIGNMENT,z.unpackAlignment),D.isDataTexture?F.texSubImage2D(F.TEXTURE_2D,H,w.x,w.y,k,ge,Ee,De,D.image.data):D.isCompressedTexture?F.compressedTexSubImage2D(F.TEXTURE_2D,H,w.x,w.y,D.mipmaps[0].width,D.mipmaps[0].height,Ee,D.mipmaps[0].data):F.texSubImage2D(F.TEXTURE_2D,H,w.x,w.y,Ee,De,D.image),H===0&&z.generateMipmaps&&F.generateMipmap(F.TEXTURE_2D),xe.unbindTexture()},this.copyTextureToTexture3D=function(w,D,z,H,k=0){if(x.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let ge=w.max.x-w.min.x+1,Ee=w.max.y-w.min.y+1,De=w.max.z-w.min.z+1,Ue=re.convert(H.format),Xe=re.convert(H.type),ke;if(H.isData3DTexture)S.setTexture3D(H,0),ke=F.TEXTURE_3D;else if(H.isDataArrayTexture||H.isCompressedArrayTexture)S.setTexture2DArray(H,0),ke=F.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}F.pixelStorei(F.UNPACK_FLIP_Y_WEBGL,H.flipY),F.pixelStorei(F.UNPACK_PREMULTIPLY_ALPHA_WEBGL,H.premultiplyAlpha),F.pixelStorei(F.UNPACK_ALIGNMENT,H.unpackAlignment);let Ve=F.getParameter(F.UNPACK_ROW_LENGTH),St=F.getParameter(F.UNPACK_IMAGE_HEIGHT),dn=F.getParameter(F.UNPACK_SKIP_PIXELS),Bt=F.getParameter(F.UNPACK_SKIP_ROWS),Zn=F.getParameter(F.UNPACK_SKIP_IMAGES),yt=z.isCompressedTexture?z.mipmaps[k]:z.image;F.pixelStorei(F.UNPACK_ROW_LENGTH,yt.width),F.pixelStorei(F.UNPACK_IMAGE_HEIGHT,yt.height),F.pixelStorei(F.UNPACK_SKIP_PIXELS,w.min.x),F.pixelStorei(F.UNPACK_SKIP_ROWS,w.min.y),F.pixelStorei(F.UNPACK_SKIP_IMAGES,w.min.z),z.isDataTexture||z.isData3DTexture?F.texSubImage3D(ke,k,D.x,D.y,D.z,ge,Ee,De,Ue,Xe,yt.data):z.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),F.compressedTexSubImage3D(ke,k,D.x,D.y,D.z,ge,Ee,De,Ue,yt.data)):F.texSubImage3D(ke,k,D.x,D.y,D.z,ge,Ee,De,Ue,Xe,yt),F.pixelStorei(F.UNPACK_ROW_LENGTH,Ve),F.pixelStorei(F.UNPACK_IMAGE_HEIGHT,St),F.pixelStorei(F.UNPACK_SKIP_PIXELS,dn),F.pixelStorei(F.UNPACK_SKIP_ROWS,Bt),F.pixelStorei(F.UNPACK_SKIP_IMAGES,Zn),k===0&&H.generateMipmaps&&F.generateMipmap(ke),xe.unbindTexture()},this.initTexture=function(w){w.isCubeTexture?S.setTextureCube(w,0):w.isData3DTexture?S.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?S.setTexture2DArray(w,0):S.setTexture2D(w,0),xe.unbindTexture()},this.resetState=function(){A=0,T=0,R=null,xe.reset(),be.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ai}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=e===Mc?"display-p3":"srgb",t.unpackColorSpace=at.workingColorSpace===oo?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===ut?$i:zd}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===$i?ut:Pt}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}},Jl=class extends Mr{};Jl.prototype.isWebGL1Renderer=!0;var Wa=class i{constructor(e,t=1,n=1e3){this.isFog=!0,this.name="",this.color=new Te(e),this.near=t,this.far=n}clone(){return new i(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},zs=class extends vt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}},wr=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Ul,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=Un()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Un()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Un()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},sn=new C,Sr=class i{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)sn.fromBufferAttribute(this,t),sn.applyMatrix4(e),this.setXYZ(t,sn.x,sn.y,sn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)sn.fromBufferAttribute(this,t),sn.applyNormalMatrix(e),this.setXYZ(t,sn.x,sn.y,sn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)sn.fromBufferAttribute(this,t),sn.transformDirection(e),this.setXYZ(t,sn.x,sn.y,sn.z);return this}setX(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Gn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Gn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Gn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Gn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array),r=lt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new wt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new i(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}};var ld=new C,cd=new dt,hd=new dt,Ey=new C,ud=new ze,Ma=new C,Tl=new gn,dd=new ze,Al=new li,Xa=class extends je{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=$h,this.bindMatrix=new ze,this.bindMatrixInverse=new ze,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new wn),this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Ma),this.boundingBox.expandByPoint(Ma)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new gn),this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Ma),this.boundingSphere.expandByPoint(Ma)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Tl.copy(this.boundingSphere),Tl.applyMatrix4(s),e.ray.intersectsSphere(Tl)!==!1&&(dd.copy(s).invert(),Al.copy(e.ray).applyMatrix4(dd),!(this.boundingBox!==null&&Al.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Al)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new dt,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);let r=1/e.manhattanLength();r!==1/0?e.multiplyScalar(r):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===$h?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Jp?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,s=this.geometry;cd.fromBufferAttribute(s.attributes.skinIndex,e),hd.fromBufferAttribute(s.attributes.skinWeight,e),ld.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let r=0;r<4;r++){let o=hd.getComponent(r);if(o!==0){let a=cd.getComponent(r);ud.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(Ey.copy(ld).applyMatrix4(ud),o)}}return t.applyMatrix4(this.bindMatrixInverse)}boneTransform(e,t){return console.warn("THREE.SkinnedMesh: .boneTransform() was renamed to .applyBoneTransform() in r151."),this.applyBoneTransform(e,t)}},Er=class extends vt{constructor(){super(),this.isBone=!0,this.type="Bone"}},Ql=class extends Gt{constructor(e=null,t=1,n=1,s,r,o,a,l,c=Rt,h=Rt,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},fd=new ze,Ty=new ze,qa=class i{constructor(e=[],t=[]){this.uuid=Un(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new ze)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let n=new ze;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let r=0,o=e.length;r<o;r++){let a=e[r]?e[r].matrixWorld:Ty;fd.multiplyMatrices(a,t[r]),fd.toArray(n,r*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new i(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new Ql(t,e,e,bn,ri);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){let r=e.bones[n],o=t[r];o===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",r),o=new Er),this.bones.push(o),this.boneInverses.push(new ze().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let s=0,r=t.length;s<r;s++){let o=t[s];e.bones.push(o.uuid);let a=n[s];e.boneInverses.push(a.toArray())}return e}},ci=class extends wt{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Ms=new ze,pd=new ze,wa=[],md=new wn,Ay=new ze,lr=new je,cr=new gn,Xn=class extends je{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new ci(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,Ay)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new wn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Ms),md.copy(e.boundingBox).applyMatrix4(Ms),this.boundingBox.union(md)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new gn),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Ms),cr.copy(e.boundingSphere).applyMatrix4(Ms),this.boundingSphere.union(cr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){let n=this.matrixWorld,s=this.count;if(lr.geometry=this.geometry,lr.material=this.material,lr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),cr.copy(this.boundingSphere),cr.applyMatrix4(n),e.ray.intersectsSphere(cr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ms),pd.multiplyMatrices(n,Ms),lr.matrixWorld=pd,lr.raycast(e,wa);for(let o=0,a=wa.length;o<a;o++){let l=wa[o];l.instanceId=r,l.object=this,t.push(l)}wa.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new ci(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Tr=class extends _n{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Te(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},gd=new C,_d=new C,xd=new ze,Rl=new li,Sa=new gn,Hs=class extends vt{constructor(e=new Tt,t=new Tr){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)gd.fromBufferAttribute(t,s-1),_d.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=gd.distanceTo(_d);e.setAttribute("lineDistance",new ot(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Sa.copy(n.boundingSphere),Sa.applyMatrix4(s),Sa.radius+=r,e.ray.intersectsSphere(Sa)===!1)return;xd.copy(s).invert(),Rl.copy(e.ray).applyMatrix4(xd);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=new C,h=new C,u=new C,d=new C,f=this.isLineSegments?2:1,g=n.index,m=n.attributes.position;if(g!==null){let p=Math.max(0,o.start),y=Math.min(g.count,o.start+o.count);for(let x=p,M=y-1;x<M;x+=f){let A=g.getX(x),T=g.getX(x+1);if(c.fromBufferAttribute(m,A),h.fromBufferAttribute(m,T),Rl.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let N=e.ray.origin.distanceTo(d);N<e.near||N>e.far||t.push({distance:N,point:u.clone().applyMatrix4(this.matrixWorld),index:x,face:null,faceIndex:null,object:this})}}else{let p=Math.max(0,o.start),y=Math.min(m.count,o.start+o.count);for(let x=p,M=y-1;x<M;x+=f){if(c.fromBufferAttribute(m,x),h.fromBufferAttribute(m,x+1),Rl.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let T=e.ray.origin.distanceTo(d);T<e.near||T>e.far||t.push({distance:T,point:u.clone().applyMatrix4(this.matrixWorld),index:x,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}},yd=new C,vd=new C,Ya=class extends Hs{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)yd.fromBufferAttribute(t,s),vd.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+yd.distanceTo(vd);e.setAttribute("lineDistance",new ot(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},Ka=class extends Hs{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}},Ar=class extends _n{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Te(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},bd=new ze,ec=new li,Ea=new gn,Ta=new C,ja=class extends vt{constructor(e=new Tt,t=new Ar){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ea.copy(n.boundingSphere),Ea.applyMatrix4(s),Ea.radius+=r,e.ray.intersectsSphere(Ea)===!1)return;bd.copy(s).invert(),ec.copy(e.ray).applyMatrix4(bd);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,o.start),f=Math.min(c.count,o.start+o.count);for(let g=d,_=f;g<_;g++){let m=c.getX(g);Ta.fromBufferAttribute(u,m),Md(Ta,m,l,s,e,t,this)}}else{let d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let g=d,_=f;g<_;g++)Ta.fromBufferAttribute(u,g),Md(Ta,g,l,s,e,t,this)}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Md(i,e,t,n,s,r,o){let a=ec.distanceSqToPoint(i);if(a<t){let l=new C;ec.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,object:o})}}var Rr=class extends Gt{constructor(e,t,n,s,r,o,a,l,c){super(e,t,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}};var cn=class i extends Tt{constructor(e=1,t=1,n=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],d=[],f=[],g=0,_=[],m=n/2,p=0;y(),o===!1&&(e>0&&x(!0),t>0&&x(!1)),this.setIndex(h),this.setAttribute("position",new ot(u,3)),this.setAttribute("normal",new ot(d,3)),this.setAttribute("uv",new ot(f,2));function y(){let M=new C,A=new C,T=0,R=(t-e)/n;for(let N=0;N<=r;N++){let b=[],E=N/r,O=E*(t-e)+e;for(let W=0;W<=s;W++){let ne=W/s,I=ne*l+a,U=Math.sin(I),V=Math.cos(I);A.x=O*U,A.y=-E*n+m,A.z=O*V,u.push(A.x,A.y,A.z),M.set(U,R,V).normalize(),d.push(M.x,M.y,M.z),f.push(ne,1-E),b.push(g++)}_.push(b)}for(let N=0;N<s;N++)for(let b=0;b<r;b++){let E=_[b][N],O=_[b+1][N],W=_[b+1][N+1],ne=_[b][N+1];h.push(E,O,ne),h.push(O,W,ne),T+=6}c.addGroup(p,T,0),p+=T}function x(M){let A=g,T=new Re,R=new C,N=0,b=M===!0?e:t,E=M===!0?1:-1;for(let W=1;W<=s;W++)u.push(0,m*E,0),d.push(0,E,0),f.push(.5,.5),g++;let O=g;for(let W=0;W<=s;W++){let I=W/s*l+a,U=Math.cos(I),V=Math.sin(I);R.x=b*V,R.y=m*E,R.z=b*U,u.push(R.x,R.y,R.z),d.push(0,E,0),T.x=U*.5+.5,T.y=V*.5*E+.5,f.push(T.x,T.y),g++}for(let W=0;W<s;W++){let ne=A+W,I=O+W;M===!0?h.push(I,I+1,ne):h.push(I+1,I,ne),N+=3}c.addGroup(p,N,M===!0?1:2),p+=N}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},Vs=class i extends cn{constructor(e=1,t=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,e,t,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(e){return new i(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}};var $a=class i extends Tt{constructor(e=.5,t=1,n=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:o},n=Math.max(3,n),s=Math.max(1,s);let a=[],l=[],c=[],h=[],u=e,d=(t-e)/s,f=new C,g=new Re;for(let _=0;_<=s;_++){for(let m=0;m<=n;m++){let p=r+m/n*o;f.x=u*Math.cos(p),f.y=u*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),g.x=(f.x/t+1)/2,g.y=(f.y/t+1)/2,h.push(g.x,g.y)}u+=d}for(let _=0;_<s;_++){let m=_*(n+1);for(let p=0;p<n;p++){let y=p+m,x=y,M=y+n+1,A=y+n+2,T=y+1;a.push(x,M,T),a.push(M,A,T)}}this.setIndex(a),this.setAttribute("position",new ot(l,3)),this.setAttribute("normal",new ot(c,3)),this.setAttribute("uv",new ot(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}};var qn=class i extends Tt{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],u=new C,d=new C,f=[],g=[],_=[],m=[];for(let p=0;p<=n;p++){let y=[],x=p/n,M=0;p===0&&o===0?M=.5/t:p===n&&l===Math.PI&&(M=-.5/t);for(let A=0;A<=t;A++){let T=A/t;u.x=-e*Math.cos(s+T*r)*Math.sin(o+x*a),u.y=e*Math.cos(o+x*a),u.z=e*Math.sin(s+T*r)*Math.sin(o+x*a),g.push(u.x,u.y,u.z),d.copy(u).normalize(),_.push(d.x,d.y,d.z),m.push(T+M,1-x),y.push(c++)}h.push(y)}for(let p=0;p<n;p++)for(let y=0;y<t;y++){let x=h[p][y+1],M=h[p][y],A=h[p+1][y],T=h[p+1][y+1];(p!==0||o>0)&&f.push(x,M,T),(p!==n-1||l<Math.PI)&&f.push(M,A,T)}this.setIndex(f),this.setAttribute("position",new ot(g,3)),this.setAttribute("normal",new ot(_,3)),this.setAttribute("uv",new ot(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}};var Cr=class i extends Tt{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);let o=[],a=[],l=[],c=[],h=new C,u=new C,d=new C;for(let f=0;f<=n;f++)for(let g=0;g<=s;g++){let _=g/s*r,m=f/n*Math.PI*2;u.x=(e+t*Math.cos(m))*Math.cos(_),u.y=(e+t*Math.cos(m))*Math.sin(_),u.z=t*Math.sin(m),a.push(u.x,u.y,u.z),h.x=e*Math.cos(_),h.y=e*Math.sin(_),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/s),c.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=s;g++){let _=(s+1)*f+g-1,m=(s+1)*(f-1)+g-1,p=(s+1)*(f-1)+g,y=(s+1)*f+g;o.push(_,m,y),o.push(m,p,y)}this.setIndex(o),this.setAttribute("position",new ot(a,3)),this.setAttribute("normal",new ot(l,3)),this.setAttribute("uv",new ot(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}};var et=class extends _n{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Te(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Te(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Hd,this.normalScale=new Re(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Sn=class extends et{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Re(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Vt(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Te(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Te(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Te(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}};function Aa(i,e,t){return!i||!t&&i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function Ry(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function Cy(i){function e(s,r){return i[s]-i[r]}let t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function wd(i,e,t){let n=i.length,s=new i.constructor(n);for(let r=0,o=0;o!==n;++r){let a=t[r]*e;for(let l=0;l!==e;++l)s[o++]=i[a+l]}return s}function Jd(i,e,t,n){let s=1,r=i[0];for(;r!==void 0&&r[n]===void 0;)r=i[s++];if(r===void 0)return;let o=r[n];if(o!==void 0)if(Array.isArray(o))do o=r[n],o!==void 0&&(e.push(r.time),t.push.apply(t,o)),r=i[s++];while(r!==void 0);else if(o.toArray!==void 0)do o=r[n],o!==void 0&&(e.push(r.time),o.toArray(t,t.length)),r=i[s++];while(r!==void 0);else do o=r[n],o!==void 0&&(e.push(r.time),t.push(o)),r=i[s++];while(r!==void 0)}var Li=class{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,s=t[n],r=t[n-1];e:{t:{let o;n:{i:if(!(e<s)){for(let a=n+2;;){if(s===void 0){if(e<r)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=t[++n],e<s)break t}o=t.length;break n}if(!(e>=r)){let a=t[1];e<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=t[--n-1],e>=r)break t}o=n,n=0;break n}break e}for(;n<o;){let a=n+o>>>1;e<t[a]?o=a:n=a+1}if(s=t[n],r=t[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s;for(let o=0;o!==s;++o)t[o]=n[r+o];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},tc=class extends Li{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:ws,endingEnd:ws}}intervalChanged_(e,t,n){let s=this.parameterPositions,r=e-2,o=e+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Ss:r=e,a=2*t-n;break;case Pa:r=s.length-2,a=t+s[r]-s[r+1];break;default:r=e,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Ss:o=e,l=2*n-t;break;case Pa:o=1,l=n+s[1]-s[0];break;default:o=e-1,l=t}let c=(n-t)*.5,h=this.valueSize;this._weightPrev=c/(t-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-t)/(s-t),_=g*g,m=_*g,p=-d*m+2*d*_-d*g,y=(1+d)*m+(-1.5-2*d)*_+(-.5+d)*g+1,x=(-1-f)*m+(1.5+f)*_+.5*g,M=f*m-f*_;for(let A=0;A!==a;++A)r[A]=p*o[h+A]+y*o[c+A]+x*o[l+A]+M*o[u+A];return r}},Za=class extends Li{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=(n-t)/(s-t),u=1-h;for(let d=0;d!==a;++d)r[d]=o[c+d]*u+o[l+d]*h;return r}},nc=class extends Li{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}},En=class{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Aa(t,this.TimeBufferType),this.values=Aa(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Aa(e.times,Array),values:Aa(e.values,Array)};let s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new nc(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Za(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new tc(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Ns:t=this.InterpolantFactoryMethodDiscrete;break;case Ji:t=this.InterpolantFactoryMethodLinear;break;case il:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ns;case this.InterpolantFactoryMethodLinear:return Ji;case this.InterpolantFactoryMethodSmooth:return il}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e}return this}trim(e,t){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<e;)++r;for(;o!==-1&&n[o]>t;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),e=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),e=!1;break}o=l}if(s!==void 0&&Ry(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===il,r=e.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=e[a],h=e[a+1];if(c!==h&&(a!==1||c!==e[0]))if(s)l=!0;else{let u=a*n,d=u-n,f=u+n;for(let g=0;g!==n;++g){let _=t[u+g];if(_!==t[d+g]||_!==t[f+g]){l=!0;break}}}if(l){if(a!==o){e[o]=e[a];let u=a*n,d=o*n;for(let f=0;f!==n;++f)t[d+f]=t[u+f]}++o}}if(r>0){e[o]=e[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)t[l+c]=t[a+c];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,s}};En.prototype.TimeBufferType=Float32Array;En.prototype.ValueBufferType=Float32Array;En.prototype.DefaultInterpolation=Ji;var Ii=class extends En{};Ii.prototype.ValueTypeName="bool";Ii.prototype.ValueBufferType=Array;Ii.prototype.DefaultInterpolation=Ns;Ii.prototype.InterpolantFactoryMethodLinear=void 0;Ii.prototype.InterpolantFactoryMethodSmooth=void 0;var Ja=class extends En{};Ja.prototype.ValueTypeName="color";var hi=class extends En{};hi.prototype.ValueTypeName="number";var ic=class extends Li{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-t)/(s-t),c=e*a;for(let h=c+a;c!==h;c+=4)xt.slerpFlat(r,0,o,c-a,o,c,l);return r}},Yn=class extends En{InterpolantFactoryMethodLinear(e){return new ic(this.times,this.values,this.getValueSize(),e)}};Yn.prototype.ValueTypeName="quaternion";Yn.prototype.DefaultInterpolation=Ji;Yn.prototype.InterpolantFactoryMethodSmooth=void 0;var Di=class extends En{};Di.prototype.ValueTypeName="string";Di.prototype.ValueBufferType=Array;Di.prototype.DefaultInterpolation=Ns;Di.prototype.InterpolantFactoryMethodLinear=void 0;Di.prototype.InterpolantFactoryMethodSmooth=void 0;var ui=class extends En{};ui.prototype.ValueTypeName="vector";var Gs=class{constructor(e,t=-1,n,s=bc){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=Un(),this.duration<0&&this.resetDuration()}static parse(e){let t=[],n=e.tracks,s=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(Ly(n[o]).scale(s));let r=new this(e.name,e.duration,t,e.blendMode);return r.uuid=e.uuid,r}static toJSON(e){let t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let r=0,o=n.length;r!==o;++r)t.push(En.toJSON(n[r]));return s}static CreateFromMorphTargetSequence(e,t,n,s){let r=t.length,o=[];for(let a=0;a<r;a++){let l=[],c=[];l.push((a+r-1)%r,a,(a+1)%r),c.push(0,1,0);let h=Cy(l);l=wd(l,1,h),c=wd(c,1,h),!s&&l[0]===0&&(l.push(r),c.push(c[0])),o.push(new hi(".morphTargetInfluences["+t[a].name+"]",l,c).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let s={},r=/^([\w-]*?)([\d]+)$/;for(let a=0,l=e.length;a<l;a++){let c=e[a],h=c.name.match(r);if(h&&h.length>1){let u=h[1],d=s[u];d||(s[u]=d=[]),d.push(c)}}let o=[];for(let a in s)o.push(this.CreateFromMorphTargetSequence(a,s[a],t,n));return o}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;let n=function(u,d,f,g,_){if(f.length!==0){let m=[],p=[];Jd(f,m,p,g),m.length!==0&&_.push(new u(d,m,p))}},s=[],r=e.name||"default",o=e.fps||30,a=e.blendMode,l=e.length||-1,c=e.hierarchy||[];for(let u=0;u<c.length;u++){let d=c[u].keys;if(!(!d||d.length===0))if(d[0].morphTargets){let f={},g;for(g=0;g<d.length;g++)if(d[g].morphTargets)for(let _=0;_<d[g].morphTargets.length;_++)f[d[g].morphTargets[_]]=-1;for(let _ in f){let m=[],p=[];for(let y=0;y!==d[g].morphTargets.length;++y){let x=d[g];m.push(x.time),p.push(x.morphTarget===_?1:0)}s.push(new hi(".morphTargetInfluence["+_+"]",m,p))}l=f.length*o}else{let f=".bones["+t[u].name+"]";n(ui,f+".position",d,"pos",s),n(Yn,f+".quaternion",d,"rot",s),n(ui,f+".scale",d,"scl",s)}}return s.length===0?null:new this(r,l,s,a)}resetDuration(){let e=this.tracks,t=0;for(let n=0,s=e.length;n!==s;++n){let r=this.tracks[n];t=Math.max(t,r.times[r.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}};function Py(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return hi;case"vector":case"vector2":case"vector3":case"vector4":return ui;case"color":return Ja;case"quaternion":return Yn;case"bool":case"boolean":return Ii;case"string":return Di}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function Ly(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");let e=Py(i.type);if(i.times===void 0){let t=[],n=[];Jd(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}var Ti={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}},sc=class{constructor(e,t,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null}}},Iy=new sc,di=class{constructor(e){this.manager=e!==void 0?e:Iy,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};di.DEFAULT_MATERIAL_NAME="__DEFAULT";var ii={},rc=class extends Error{constructor(e,t){super(e),this.response=t}},Pr=class extends di{constructor(e){super(e)}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=Ti.get(e);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(ii[e]!==void 0){ii[e].push({onLoad:t,onProgress:n,onError:s});return}ii[e]=[],ii[e].push({onLoad:t,onProgress:n,onError:s});let o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),a=this.mimeType,l=this.responseType;fetch(o).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;let h=ii[e],u=c.body.getReader(),d=c.headers.get("Content-Length")||c.headers.get("X-File-Size"),f=d?parseInt(d):0,g=f!==0,_=0,m=new ReadableStream({start(p){y();function y(){u.read().then(({done:x,value:M})=>{if(x)p.close();else{_+=M.byteLength;let A=new ProgressEvent("progress",{lengthComputable:g,loaded:_,total:f});for(let T=0,R=h.length;T<R;T++){let N=h[T];N.onProgress&&N.onProgress(A)}p.enqueue(M),y()}})}}});return new Response(m)}else throw new rc(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(h=>new DOMParser().parseFromString(h,a));case"json":return c.json();default:if(a===void 0)return c.text();{let u=/charset="?([^;"\s]*)"?/i.exec(a),d=u&&u[1]?u[1].toLowerCase():void 0,f=new TextDecoder(d);return c.arrayBuffer().then(g=>f.decode(g))}}}).then(c=>{Ti.add(e,c);let h=ii[e];delete ii[e];for(let u=0,d=h.length;u<d;u++){let f=h[u];f.onLoad&&f.onLoad(c)}}).catch(c=>{let h=ii[e];if(h===void 0)throw this.manager.itemError(e),c;delete ii[e];for(let u=0,d=h.length;u<d;u++){let f=h[u];f.onError&&f.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}};var ac=class extends di{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=Ti.get(e);if(o!==void 0)return r.manager.itemStart(e),setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o;let a=yr("img");function l(){h(),Ti.add(e,this),t&&t(this),r.manager.itemEnd(e)}function c(u){h(),s&&s(u),r.manager.itemError(e),r.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),r.manager.itemStart(e),a.src=e,a}};var Qa=class extends di{constructor(e){super(e)}load(e,t,n,s){let r=new Gt,o=new ac(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){r.image=a,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}},Ws=class extends vt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Te(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}},eo=class extends Ws{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(vt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Te(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},Cl=new ze,Sd=new C,Ed=new C,Lr=class{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Re(512,512),this.map=null,this.mapPass=null,this.matrix=new ze,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new br,this._frameExtents=new Re(1,1),this._viewportCount=1,this._viewports=[new dt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,n=this.matrix;Sd.setFromMatrixPosition(e.matrixWorld),t.position.copy(Sd),Ed.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ed),t.updateMatrixWorld(),Cl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Cl),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Cl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},oc=class extends Lr{constructor(){super(new Ct(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,n=Us*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height,r=e.distance||t.far;(n!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=n,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},to=class extends Ws{constructor(e,t,n=0,s=Math.PI/3,r=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(vt.DEFAULT_UP),this.updateMatrix(),this.target=new vt,this.distance=n,this.angle=s,this.penumbra=r,this.decay=o,this.map=null,this.shadow=new oc}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},Td=new ze,hr=new C,Pl=new C,lc=class extends Lr{constructor(){super(new Ct(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Re(4,2),this._viewportCount=6,this._viewports=[new dt(2,1,1,1),new dt(0,1,1,1),new dt(3,1,1,1),new dt(1,1,1,1),new dt(3,0,1,1),new dt(1,0,1,1)],this._cubeDirections=[new C(1,0,0),new C(-1,0,0),new C(0,0,1),new C(0,0,-1),new C(0,1,0),new C(0,-1,0)],this._cubeUps=[new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,0,1),new C(0,0,-1)]}updateMatrices(e,t=0){let n=this.camera,s=this.matrix,r=e.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),hr.setFromMatrixPosition(e.matrixWorld),n.position.copy(hr),Pl.copy(n.position),Pl.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(Pl),n.updateMatrixWorld(),s.makeTranslation(-hr.x,-hr.y,-hr.z),Td.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Td)}},Ni=class extends Ws{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new lc}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},cc=class extends Lr{constructor(){super(new Bs(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Xs=class extends Ws{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(vt.DEFAULT_UP),this.updateMatrix(),this.target=new vt,this.shadow=new cc}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var Ui=class{static decodeText(e){if(typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,s=e.length;n<s;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){let t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}};var no=class extends di{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=Ti.get(e);if(o!==void 0){if(r.manager.itemStart(e),o.then){o.then(c=>{t&&t(c),r.manager.itemEnd(e)}).catch(c=>{s&&s(c)});return}return setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o}let a={};a.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",a.headers=this.requestHeader;let l=fetch(e,a).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign(r.options,{colorSpaceConversion:"none"}))}).then(function(c){return Ti.add(e,c),t&&t(c),r.manager.itemEnd(e),c}).catch(function(c){s&&s(c),Ti.remove(e),r.manager.itemError(e),r.manager.itemEnd(e)});Ti.add(e,l),r.manager.itemStart(e)}};var io=class{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Ad(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let t=Ad();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}};function Ad(){return(typeof performance>"u"?Date:performance).now()}var hc=class{constructor(e,t,n){this.binding=e,this.valueSize=n;let s,r,o;switch(t){case"quaternion":s=this._slerp,r=this._slerpAdditive,o=this._setAdditiveIdentityQuaternion,this.buffer=new Float64Array(n*6),this._workIndex=5;break;case"string":case"bool":s=this._select,r=this._select,o=this._setAdditiveIdentityOther,this.buffer=new Array(n*5);break;default:s=this._lerp,r=this._lerpAdditive,o=this._setAdditiveIdentityNumeric,this.buffer=new Float64Array(n*5)}this._mixBufferRegion=s,this._mixBufferRegionAdditive=r,this._setIdentity=o,this._origIndex=3,this._addIndex=4,this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,this.useCount=0,this.referenceCount=0}accumulate(e,t){let n=this.buffer,s=this.valueSize,r=e*s+s,o=this.cumulativeWeight;if(o===0){for(let a=0;a!==s;++a)n[r+a]=n[a];o=t}else{o+=t;let a=t/o;this._mixBufferRegion(n,r,0,a,s)}this.cumulativeWeight=o}accumulateAdditive(e){let t=this.buffer,n=this.valueSize,s=n*this._addIndex;this.cumulativeWeightAdditive===0&&this._setIdentity(),this._mixBufferRegionAdditive(t,s,0,e,n),this.cumulativeWeightAdditive+=e}apply(e){let t=this.valueSize,n=this.buffer,s=e*t+t,r=this.cumulativeWeight,o=this.cumulativeWeightAdditive,a=this.binding;if(this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,r<1){let l=t*this._origIndex;this._mixBufferRegion(n,s,l,1-r,t)}o>0&&this._mixBufferRegionAdditive(n,s,this._addIndex*t,1,t);for(let l=t,c=t+t;l!==c;++l)if(n[l]!==n[l+t]){a.setValue(n,s);break}}saveOriginalState(){let e=this.binding,t=this.buffer,n=this.valueSize,s=n*this._origIndex;e.getValue(t,s);for(let r=n,o=s;r!==o;++r)t[r]=t[s+r%n];this._setIdentity(),this.cumulativeWeight=0,this.cumulativeWeightAdditive=0}restoreOriginalState(){let e=this.valueSize*3;this.binding.setValue(this.buffer,e)}_setAdditiveIdentityNumeric(){let e=this._addIndex*this.valueSize,t=e+this.valueSize;for(let n=e;n<t;n++)this.buffer[n]=0}_setAdditiveIdentityQuaternion(){this._setAdditiveIdentityNumeric(),this.buffer[this._addIndex*this.valueSize+3]=1}_setAdditiveIdentityOther(){let e=this._origIndex*this.valueSize,t=this._addIndex*this.valueSize;for(let n=0;n<this.valueSize;n++)this.buffer[t+n]=this.buffer[e+n]}_select(e,t,n,s,r){if(s>=.5)for(let o=0;o!==r;++o)e[t+o]=e[n+o]}_slerp(e,t,n,s){xt.slerpFlat(e,t,e,t,e,n,s)}_slerpAdditive(e,t,n,s,r){let o=this._workIndex*r;xt.multiplyQuaternionsFlat(e,o,e,t,e,n),xt.slerpFlat(e,t,e,t,e,o,s)}_lerp(e,t,n,s,r){let o=1-s;for(let a=0;a!==r;++a){let l=t+a;e[l]=e[l]*o+e[n+a]*s}}_lerpAdditive(e,t,n,s,r){for(let o=0;o!==r;++o){let a=t+o;e[a]=e[a]+e[n+o]*s}}},Ec="\\[\\]\\.:\\/",Dy=new RegExp("["+Ec+"]","g"),Tc="[^"+Ec+"]",Ny="[^"+Ec.replace("\\.","")+"]",Uy=/((?:WC+[\/:])*)/.source.replace("WC",Tc),Oy=/(WCOD+)?/.source.replace("WCOD",Ny),Fy=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Tc),By=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Tc),ky=new RegExp("^"+Uy+Oy+Fy+By+"$"),zy=["material","materials","bones","map"],uc=class{constructor(e,t,n){let s=n||ht.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},ht=class i{constructor(e,t,n){this.path=t,this.parsedPath=n||i.parseTrackName(t),this.node=i.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new i.Composite(e,t,n):new i(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Dy,"")}static parseTrackName(e){let t=ky.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);zy.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===t||a.uuid===t)return a;let l=n(a.children);if(l)return l}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,n=t.objectName,s=t.propertyName,r=t.propertyIndex;if(e||(e=i.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}let o=e[s];if(o===void 0){let c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};ht.Composite=uc;ht.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};ht.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};ht.prototype.GetterByBindingType=[ht.prototype._getValue_direct,ht.prototype._getValue_array,ht.prototype._getValue_arrayElement,ht.prototype._getValue_toArray];ht.prototype.SetterByBindingTypeAndVersioning=[[ht.prototype._setValue_direct,ht.prototype._setValue_direct_setNeedsUpdate,ht.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_array,ht.prototype._setValue_array_setNeedsUpdate,ht.prototype._setValue_array_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_arrayElement,ht.prototype._setValue_arrayElement_setNeedsUpdate,ht.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_fromArray,ht.prototype._setValue_fromArray_setNeedsUpdate,ht.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var dc=class{constructor(e,t,n=null,s=t.blendMode){this._mixer=e,this._clip=t,this._localRoot=n,this.blendMode=s;let r=t.tracks,o=r.length,a=new Array(o),l={endingStart:ws,endingEnd:ws};for(let c=0;c!==o;++c){let h=r[c].createInterpolant(null);a[c]=h,h.settings=l}this._interpolantSettings=l,this._interpolants=a,this._propertyBindings=new Array(o),this._cacheIndex=null,this._byClipCacheIndex=null,this._timeScaleInterpolant=null,this._weightInterpolant=null,this.loop=vc,this._loopCount=-1,this._startTime=null,this.time=0,this.timeScale=1,this._effectiveTimeScale=1,this.weight=1,this._effectiveWeight=1,this.repetitions=1/0,this.paused=!1,this.enabled=!0,this.clampWhenFinished=!1,this.zeroSlopeAtStart=!0,this.zeroSlopeAtEnd=!0}play(){return this._mixer._activateAction(this),this}stop(){return this._mixer._deactivateAction(this),this.reset()}reset(){return this.paused=!1,this.enabled=!0,this.time=0,this._loopCount=-1,this._startTime=null,this.stopFading().stopWarping()}isRunning(){return this.enabled&&!this.paused&&this.timeScale!==0&&this._startTime===null&&this._mixer._isActiveAction(this)}isScheduled(){return this._mixer._isActiveAction(this)}startAt(e){return this._startTime=e,this}setLoop(e,t){return this.loop=e,this.repetitions=t,this}setEffectiveWeight(e){return this.weight=e,this._effectiveWeight=this.enabled?e:0,this.stopFading()}getEffectiveWeight(){return this._effectiveWeight}fadeIn(e){return this._scheduleFading(e,0,1)}fadeOut(e){return this._scheduleFading(e,1,0)}crossFadeFrom(e,t,n){if(e.fadeOut(t),this.fadeIn(t),n){let s=this._clip.duration,r=e._clip.duration,o=r/s,a=s/r;e.warp(1,o,t),this.warp(a,1,t)}return this}crossFadeTo(e,t,n){return e.crossFadeFrom(this,t,n)}stopFading(){let e=this._weightInterpolant;return e!==null&&(this._weightInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this}setEffectiveTimeScale(e){return this.timeScale=e,this._effectiveTimeScale=this.paused?0:e,this.stopWarping()}getEffectiveTimeScale(){return this._effectiveTimeScale}setDuration(e){return this.timeScale=this._clip.duration/e,this.stopWarping()}syncWith(e){return this.time=e.time,this.timeScale=e.timeScale,this.stopWarping()}halt(e){return this.warp(this._effectiveTimeScale,0,e)}warp(e,t,n){let s=this._mixer,r=s.time,o=this.timeScale,a=this._timeScaleInterpolant;a===null&&(a=s._lendControlInterpolant(),this._timeScaleInterpolant=a);let l=a.parameterPositions,c=a.sampleValues;return l[0]=r,l[1]=r+n,c[0]=e/o,c[1]=t/o,this}stopWarping(){let e=this._timeScaleInterpolant;return e!==null&&(this._timeScaleInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this}getMixer(){return this._mixer}getClip(){return this._clip}getRoot(){return this._localRoot||this._mixer._root}_update(e,t,n,s){if(!this.enabled){this._updateWeight(e);return}let r=this._startTime;if(r!==null){let l=(e-r)*n;l<0||n===0?t=0:(this._startTime=null,t=n*l)}t*=this._updateTimeScale(e);let o=this._updateTime(t),a=this._updateWeight(e);if(a>0){let l=this._interpolants,c=this._propertyBindings;switch(this.blendMode){case lm:for(let h=0,u=l.length;h!==u;++h)l[h].evaluate(o),c[h].accumulateAdditive(a);break;case bc:default:for(let h=0,u=l.length;h!==u;++h)l[h].evaluate(o),c[h].accumulate(s,a)}}}_updateWeight(e){let t=0;if(this.enabled){t=this.weight;let n=this._weightInterpolant;if(n!==null){let s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(this.stopFading(),s===0&&(this.enabled=!1))}}return this._effectiveWeight=t,t}_updateTimeScale(e){let t=0;if(!this.paused){t=this.timeScale;let n=this._timeScaleInterpolant;if(n!==null){let s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(this.stopWarping(),t===0?this.paused=!0:this.timeScale=t)}}return this._effectiveTimeScale=t,t}_updateTime(e){let t=this._clip.duration,n=this.loop,s=this.time+e,r=this._loopCount,o=n===om;if(e===0)return r===-1?s:o&&(r&1)===1?t-s:s;if(n===yc){r===-1&&(this._loopCount=0,this._setEndings(!0,!0,!1));e:{if(s>=t)s=t;else if(s<0)s=0;else{this.time=s;break e}this.clampWhenFinished?this.paused=!0:this.enabled=!1,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e<0?-1:1})}}else{if(r===-1&&(e>=0?(r=0,this._setEndings(!0,this.repetitions===0,o)):this._setEndings(this.repetitions===0,!0,o)),s>=t||s<0){let a=Math.floor(s/t);s-=t*a,r+=Math.abs(a);let l=this.repetitions-r;if(l<=0)this.clampWhenFinished?this.paused=!0:this.enabled=!1,s=e>0?t:0,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e>0?1:-1});else{if(l===1){let c=e<0;this._setEndings(c,!c,o)}else this._setEndings(!1,!1,o);this._loopCount=r,this.time=s,this._mixer.dispatchEvent({type:"loop",action:this,loopDelta:a})}}else this.time=s;if(o&&(r&1)===1)return t-s}return s}_setEndings(e,t,n){let s=this._interpolantSettings;n?(s.endingStart=Ss,s.endingEnd=Ss):(e?s.endingStart=this.zeroSlopeAtStart?Ss:ws:s.endingStart=Pa,t?s.endingEnd=this.zeroSlopeAtEnd?Ss:ws:s.endingEnd=Pa)}_scheduleFading(e,t,n){let s=this._mixer,r=s.time,o=this._weightInterpolant;o===null&&(o=s._lendControlInterpolant(),this._weightInterpolant=o);let a=o.parameterPositions,l=o.sampleValues;return a[0]=r,l[0]=t,a[1]=r+e,l[1]=n,this}},Hy=new Float32Array(1),so=class extends On{constructor(e){super(),this._root=e,this._initMemoryManager(),this._accuIndex=0,this.time=0,this.timeScale=1}_bindAction(e,t){let n=e._localRoot||this._root,s=e._clip.tracks,r=s.length,o=e._propertyBindings,a=e._interpolants,l=n.uuid,c=this._bindingsByRootAndName,h=c[l];h===void 0&&(h={},c[l]=h);for(let u=0;u!==r;++u){let d=s[u],f=d.name,g=h[f];if(g!==void 0)++g.referenceCount,o[u]=g;else{if(g=o[u],g!==void 0){g._cacheIndex===null&&(++g.referenceCount,this._addInactiveBinding(g,l,f));continue}let _=t&&t._propertyBindings[u].binding.parsedPath;g=new hc(ht.create(n,f,_),d.ValueTypeName,d.getValueSize()),++g.referenceCount,this._addInactiveBinding(g,l,f),o[u]=g}a[u].resultBuffer=g.buffer}}_activateAction(e){if(!this._isActiveAction(e)){if(e._cacheIndex===null){let n=(e._localRoot||this._root).uuid,s=e._clip.uuid,r=this._actionsByClip[s];this._bindAction(e,r&&r.knownActions[0]),this._addInactiveAction(e,s,n)}let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];r.useCount++===0&&(this._lendBinding(r),r.saveOriginalState())}this._lendAction(e)}}_deactivateAction(e){if(this._isActiveAction(e)){let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];--r.useCount===0&&(r.restoreOriginalState(),this._takeBackBinding(r))}this._takeBackAction(e)}}_initMemoryManager(){this._actions=[],this._nActiveActions=0,this._actionsByClip={},this._bindings=[],this._nActiveBindings=0,this._bindingsByRootAndName={},this._controlInterpolants=[],this._nActiveControlInterpolants=0;let e=this;this.stats={actions:{get total(){return e._actions.length},get inUse(){return e._nActiveActions}},bindings:{get total(){return e._bindings.length},get inUse(){return e._nActiveBindings}},controlInterpolants:{get total(){return e._controlInterpolants.length},get inUse(){return e._nActiveControlInterpolants}}}}_isActiveAction(e){let t=e._cacheIndex;return t!==null&&t<this._nActiveActions}_addInactiveAction(e,t,n){let s=this._actions,r=this._actionsByClip,o=r[t];if(o===void 0)o={knownActions:[e],actionByRoot:{}},e._byClipCacheIndex=0,r[t]=o;else{let a=o.knownActions;e._byClipCacheIndex=a.length,a.push(e)}e._cacheIndex=s.length,s.push(e),o.actionByRoot[n]=e}_removeInactiveAction(e){let t=this._actions,n=t[t.length-1],s=e._cacheIndex;n._cacheIndex=s,t[s]=n,t.pop(),e._cacheIndex=null;let r=e._clip.uuid,o=this._actionsByClip,a=o[r],l=a.knownActions,c=l[l.length-1],h=e._byClipCacheIndex;c._byClipCacheIndex=h,l[h]=c,l.pop(),e._byClipCacheIndex=null;let u=a.actionByRoot,d=(e._localRoot||this._root).uuid;delete u[d],l.length===0&&delete o[r],this._removeInactiveBindingsForAction(e)}_removeInactiveBindingsForAction(e){let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];--r.referenceCount===0&&this._removeInactiveBinding(r)}}_lendAction(e){let t=this._actions,n=e._cacheIndex,s=this._nActiveActions++,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_takeBackAction(e){let t=this._actions,n=e._cacheIndex,s=--this._nActiveActions,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_addInactiveBinding(e,t,n){let s=this._bindingsByRootAndName,r=this._bindings,o=s[t];o===void 0&&(o={},s[t]=o),o[n]=e,e._cacheIndex=r.length,r.push(e)}_removeInactiveBinding(e){let t=this._bindings,n=e.binding,s=n.rootNode.uuid,r=n.path,o=this._bindingsByRootAndName,a=o[s],l=t[t.length-1],c=e._cacheIndex;l._cacheIndex=c,t[c]=l,t.pop(),delete a[r],Object.keys(a).length===0&&delete o[s]}_lendBinding(e){let t=this._bindings,n=e._cacheIndex,s=this._nActiveBindings++,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_takeBackBinding(e){let t=this._bindings,n=e._cacheIndex,s=--this._nActiveBindings,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_lendControlInterpolant(){let e=this._controlInterpolants,t=this._nActiveControlInterpolants++,n=e[t];return n===void 0&&(n=new Za(new Float32Array(2),new Float32Array(2),1,Hy),n.__cacheIndex=t,e[t]=n),n}_takeBackControlInterpolant(e){let t=this._controlInterpolants,n=e.__cacheIndex,s=--this._nActiveControlInterpolants,r=t[s];e.__cacheIndex=s,t[s]=e,r.__cacheIndex=n,t[n]=r}clipAction(e,t,n){let s=t||this._root,r=s.uuid,o=typeof e=="string"?Gs.findByName(s,e):e,a=o!==null?o.uuid:e,l=this._actionsByClip[a],c=null;if(n===void 0&&(o!==null?n=o.blendMode:n=bc),l!==void 0){let u=l.actionByRoot[r];if(u!==void 0&&u.blendMode===n)return u;c=l.knownActions[0],o===null&&(o=c._clip)}if(o===null)return null;let h=new dc(this,o,t,n);return this._bindAction(h,c),this._addInactiveAction(h,a,r),h}existingAction(e,t){let n=t||this._root,s=n.uuid,r=typeof e=="string"?Gs.findByName(n,e):e,o=r?r.uuid:e,a=this._actionsByClip[o];return a!==void 0&&a.actionByRoot[s]||null}stopAllAction(){let e=this._actions,t=this._nActiveActions;for(let n=t-1;n>=0;--n)e[n].stop();return this}update(e){e*=this.timeScale;let t=this._actions,n=this._nActiveActions,s=this.time+=e,r=Math.sign(e),o=this._accuIndex^=1;for(let c=0;c!==n;++c)t[c]._update(s,e,r,o);let a=this._bindings,l=this._nActiveBindings;for(let c=0;c!==l;++c)a[c].apply(o);return this}setTime(e){this.time=0;for(let t=0;t<this._actions.length;t++)this._actions[t].time=0;return this.update(e)}getRoot(){return this._root}uncacheClip(e){let t=this._actions,n=e.uuid,s=this._actionsByClip,r=s[n];if(r!==void 0){let o=r.knownActions;for(let a=0,l=o.length;a!==l;++a){let c=o[a];this._deactivateAction(c);let h=c._cacheIndex,u=t[t.length-1];c._cacheIndex=null,c._byClipCacheIndex=null,u._cacheIndex=h,t[h]=u,t.pop(),this._removeInactiveBindingsForAction(c)}delete s[n]}}uncacheRoot(e){let t=e.uuid,n=this._actionsByClip;for(let o in n){let a=n[o].actionByRoot,l=a[t];l!==void 0&&(this._deactivateAction(l),this._removeInactiveAction(l))}let s=this._bindingsByRootAndName,r=s[t];if(r!==void 0)for(let o in r){let a=r[o];a.restoreOriginalState(),this._removeInactiveBinding(a)}}uncacheAction(e,t){let n=this.existingAction(e,t);n!==null&&(this._deactivateAction(n),this._removeInactiveAction(n))}};var Ir=class{constructor(e,t,n=0,s=1/0){this.ray=new li(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new vr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,n=[]){return fc(e,this,n,t),n.sort(Rd),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)fc(e[s],this,n,t);return n.sort(Rd),n}};function Rd(i,e){return i.distance-e.distance}function fc(i,e,t,n){if(i.layers.test(e.layers)&&i.raycast(e,t),n===!0){let s=i.children;for(let r=0,o=s.length;r<o;r++)fc(s[r],e,t,!0)}}var Dr=class{constructor(e=1,t=0,n=0){return this.radius=e,this.phi=t,this.theta=n,this}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(Vt(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:pc}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=pc);function Ac(i,e){if(e===kd)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===Nr||e===ao){let t=i.getIndex();if(t===null){let o=[],a=i.getAttribute("position");if(a!==void 0){for(let l=0;l<a.count;l++)o.push(l);i.setIndex(o),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}let n=t.count-2,s=[];if(e===Nr)for(let o=1;o<=n;o++)s.push(t.getX(0)),s.push(t.getX(o)),s.push(t.getX(o+1));else for(let o=0;o<n;o++)o%2===0?(s.push(t.getX(o)),s.push(t.getX(o+1)),s.push(t.getX(o+2))):(s.push(t.getX(o+2)),s.push(t.getX(o+1)),s.push(t.getX(o)));s.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");let r=i.clone();return r.setIndex(s),r.clearGroups(),r}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}var co=class extends di{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new Nc(t)}),this.register(function(t){return new Gc(t)}),this.register(function(t){return new Wc(t)}),this.register(function(t){return new Xc(t)}),this.register(function(t){return new Oc(t)}),this.register(function(t){return new Fc(t)}),this.register(function(t){return new Bc(t)}),this.register(function(t){return new kc(t)}),this.register(function(t){return new Dc(t)}),this.register(function(t){return new zc(t)}),this.register(function(t){return new Uc(t)}),this.register(function(t){return new Vc(t)}),this.register(function(t){return new Hc(t)}),this.register(function(t){return new Lc(t)}),this.register(function(t){return new qc(t)}),this.register(function(t){return new Yc(t)})}load(e,t,n,s){let r=this,o;if(this.resourcePath!=="")o=this.resourcePath;else if(this.path!==""){let c=Ui.extractUrlBase(e);o=Ui.resolveURL(c,this.path)}else o=Ui.extractUrlBase(e);this.manager.itemStart(e);let a=function(c){s?s(c):console.error(c),r.manager.itemError(e),r.manager.itemEnd(e)},l=new Pr(this.manager);l.setPath(this.path),l.setResponseType("arraybuffer"),l.setRequestHeader(this.requestHeader),l.setWithCredentials(this.withCredentials),l.load(e,function(c){try{r.parse(c,o,function(h){t(h),r.manager.itemEnd(e)},a)}catch(h){a(h)}},n,a)}setDRACOLoader(e){return this.dracoLoader=e,this}setDDSLoader(){throw new Error('THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".')}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,s){let r,o={},a={},l=new TextDecoder;if(typeof e=="string")r=JSON.parse(e);else if(e instanceof ArrayBuffer)if(l.decode(new Uint8Array(e,0,4))===sf){try{o[$e.KHR_BINARY_GLTF]=new Kc(e)}catch(u){s&&s(u);return}r=JSON.parse(o[$e.KHR_BINARY_GLTF].content)}else r=JSON.parse(l.decode(e));else r=e;if(r.asset===void 0||r.asset.version[0]<2){s&&s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let c=new th(r,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let h=0;h<this.pluginCallbacks.length;h++){let u=this.pluginCallbacks[h](c);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),a[u.name]=u,o[u.name]=!0}if(r.extensionsUsed)for(let h=0;h<r.extensionsUsed.length;++h){let u=r.extensionsUsed[h],d=r.extensionsRequired||[];switch(u){case $e.KHR_MATERIALS_UNLIT:o[u]=new Ic;break;case $e.KHR_DRACO_MESH_COMPRESSION:o[u]=new jc(r,this.dracoLoader);break;case $e.KHR_TEXTURE_TRANSFORM:o[u]=new $c;break;case $e.KHR_MESH_QUANTIZATION:o[u]=new Zc;break;default:d.indexOf(u)>=0&&a[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}c.setExtensions(o),c.setPlugins(a),c.parse(n,s)}parseAsync(e,t){let n=this;return new Promise(function(s,r){n.parse(e,t,s,r)})}};function Gy(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}var $e={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"},Lc=class{constructor(e){this.parser=e,this.name=$e.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,s=t.length;n<s;n++){let r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n="light:"+e,s=t.cache.get(n);if(s)return s;let r=t.json,l=((r.extensions&&r.extensions[this.name]||{}).lights||[])[e],c,h=new Te(16777215);l.color!==void 0&&h.setRGB(l.color[0],l.color[1],l.color[2],Pt);let u=l.range!==void 0?l.range:0;switch(l.type){case"directional":c=new Xs(h),c.target.position.set(0,0,-1),c.add(c.target);break;case"point":c=new Ni(h),c.distance=u;break;case"spot":c=new to(h),c.distance=u,l.spot=l.spot||{},l.spot.innerConeAngle=l.spot.innerConeAngle!==void 0?l.spot.innerConeAngle:0,l.spot.outerConeAngle=l.spot.outerConeAngle!==void 0?l.spot.outerConeAngle:Math.PI/4,c.angle=l.spot.outerConeAngle,c.penumbra=1-l.spot.innerConeAngle/l.spot.outerConeAngle,c.target.position.set(0,0,-1),c.add(c.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+l.type)}return c.position.set(0,0,0),c.decay=2,Fi(c,l),l.intensity!==void 0&&(c.intensity=l.intensity),c.name=t.createUniqueName(l.name||"light_"+e),s=Promise.resolve(c),t.cache.add(n,s),s}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,r=n.json.nodes[e],a=(r.extensions&&r.extensions[this.name]||{}).light;return a===void 0?null:this._loadLight(a).then(function(l){return n._getNodeRef(t.cache,a,l)})}},Ic=class{constructor(){this.name=$e.KHR_MATERIALS_UNLIT}getMaterialType(){return Wt}extendParams(e,t,n){let s=[];e.color=new Te(1,1,1),e.opacity=1;let r=t.pbrMetallicRoughness;if(r){if(Array.isArray(r.baseColorFactor)){let o=r.baseColorFactor;e.color.setRGB(o[0],o[1],o[2],Pt),e.opacity=o[3]}r.baseColorTexture!==void 0&&s.push(n.assignTexture(e,"map",r.baseColorTexture,ut))}return Promise.all(s)}},Dc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name].emissiveStrength;return r!==void 0&&(t.emissiveIntensity=r),Promise.resolve()}},Nc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];if(o.clearcoatFactor!==void 0&&(t.clearcoat=o.clearcoatFactor),o.clearcoatTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatMap",o.clearcoatTexture)),o.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=o.clearcoatRoughnessFactor),o.clearcoatRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatRoughnessMap",o.clearcoatRoughnessTexture)),o.clearcoatNormalTexture!==void 0&&(r.push(n.assignTexture(t,"clearcoatNormalMap",o.clearcoatNormalTexture)),o.clearcoatNormalTexture.scale!==void 0)){let a=o.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new Re(a,a)}return Promise.all(r)}},Uc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.iridescenceFactor!==void 0&&(t.iridescence=o.iridescenceFactor),o.iridescenceTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceMap",o.iridescenceTexture)),o.iridescenceIor!==void 0&&(t.iridescenceIOR=o.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),o.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=o.iridescenceThicknessMinimum),o.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=o.iridescenceThicknessMaximum),o.iridescenceThicknessTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceThicknessMap",o.iridescenceThicknessTexture)),Promise.all(r)}},Oc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_SHEEN}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[];t.sheenColor=new Te(0,0,0),t.sheenRoughness=0,t.sheen=1;let o=s.extensions[this.name];if(o.sheenColorFactor!==void 0){let a=o.sheenColorFactor;t.sheenColor.setRGB(a[0],a[1],a[2],Pt)}return o.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=o.sheenRoughnessFactor),o.sheenColorTexture!==void 0&&r.push(n.assignTexture(t,"sheenColorMap",o.sheenColorTexture,ut)),o.sheenRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"sheenRoughnessMap",o.sheenRoughnessTexture)),Promise.all(r)}},Fc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.transmissionFactor!==void 0&&(t.transmission=o.transmissionFactor),o.transmissionTexture!==void 0&&r.push(n.assignTexture(t,"transmissionMap",o.transmissionTexture)),Promise.all(r)}},Bc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_VOLUME}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];t.thickness=o.thicknessFactor!==void 0?o.thicknessFactor:0,o.thicknessTexture!==void 0&&r.push(n.assignTexture(t,"thicknessMap",o.thicknessTexture)),t.attenuationDistance=o.attenuationDistance||1/0;let a=o.attenuationColor||[1,1,1];return t.attenuationColor=new Te().setRGB(a[0],a[1],a[2],Pt),Promise.all(r)}},kc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_IOR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name];return t.ior=r.ior!==void 0?r.ior:1.5,Promise.resolve()}},zc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_SPECULAR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];t.specularIntensity=o.specularFactor!==void 0?o.specularFactor:1,o.specularTexture!==void 0&&r.push(n.assignTexture(t,"specularIntensityMap",o.specularTexture));let a=o.specularColorFactor||[1,1,1];return t.specularColor=new Te().setRGB(a[0],a[1],a[2],Pt),o.specularColorTexture!==void 0&&r.push(n.assignTexture(t,"specularColorMap",o.specularColorTexture,ut)),Promise.all(r)}},Hc=class{constructor(e){this.parser=e,this.name=$e.EXT_MATERIALS_BUMP}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return t.bumpScale=o.bumpFactor!==void 0?o.bumpFactor:1,o.bumpTexture!==void 0&&r.push(n.assignTexture(t,"bumpMap",o.bumpTexture)),Promise.all(r)}},Vc=class{constructor(e){this.parser=e,this.name=$e.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Sn}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.anisotropyStrength!==void 0&&(t.anisotropy=o.anisotropyStrength),o.anisotropyRotation!==void 0&&(t.anisotropyRotation=o.anisotropyRotation),o.anisotropyTexture!==void 0&&r.push(n.assignTexture(t,"anisotropyMap",o.anisotropyTexture)),Promise.all(r)}},Gc=class{constructor(e){this.parser=e,this.name=$e.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,s=n.textures[e];if(!s.extensions||!s.extensions[this.name])return null;let r=s.extensions[this.name],o=t.options.ktx2Loader;if(!o){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,r.source,o)}},Wc=class{constructor(e){this.parser=e,this.name=$e.EXT_TEXTURE_WEBP,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],a=s.images[o.source],l=n.textureLoader;if(a.uri){let c=n.options.manager.getHandler(a.uri);c!==null&&(l=c)}return this.detectSupport().then(function(c){if(c)return n.loadTextureImage(e,o.source,l);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},Xc=class{constructor(e){this.parser=e,this.name=$e.EXT_TEXTURE_AVIF,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],a=s.images[o.source],l=n.textureLoader;if(a.uri){let c=n.options.manager.getHandler(a.uri);c!==null&&(l=c)}return this.detectSupport().then(function(c){if(c)return n.loadTextureImage(e,o.source,l);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},qc=class{constructor(e){this.name=$e.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let s=n.extensions[this.name],r=this.parser.getDependency("buffer",s.buffer),o=this.parser.options.meshoptDecoder;if(!o||!o.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return r.then(function(a){let l=s.byteOffset||0,c=s.byteLength||0,h=s.count,u=s.byteStride,d=new Uint8Array(a,l,c);return o.decodeGltfBufferAsync?o.decodeGltfBufferAsync(h,u,d,s.mode,s.filter).then(function(f){return f.buffer}):o.ready.then(function(){let f=new ArrayBuffer(h*u);return o.decodeGltfBuffer(new Uint8Array(f),h,u,d,s.mode,s.filter),f})})}else return null}},Yc=class{constructor(e){this.name=$e.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;let s=t.meshes[n.mesh];for(let c of s.primitives)if(c.mode!==An.TRIANGLES&&c.mode!==An.TRIANGLE_STRIP&&c.mode!==An.TRIANGLE_FAN&&c.mode!==void 0)return null;let o=n.extensions[this.name].attributes,a=[],l={};for(let c in o)a.push(this.parser.getDependency("accessor",o[c]).then(h=>(l[c]=h,l[c])));return a.length<1?null:(a.push(this.parser.createNodeMesh(e)),Promise.all(a).then(c=>{let h=c.pop(),u=h.isGroup?h.children:[h],d=c[0].count,f=[];for(let g of u){let _=new ze,m=new C,p=new xt,y=new C(1,1,1),x=new Xn(g.geometry,g.material,d);for(let M=0;M<d;M++)l.TRANSLATION&&m.fromBufferAttribute(l.TRANSLATION,M),l.ROTATION&&p.fromBufferAttribute(l.ROTATION,M),l.SCALE&&y.fromBufferAttribute(l.SCALE,M),x.setMatrixAt(M,_.compose(m,p,y));for(let M in l)if(M==="_COLOR_0"){let A=l[M];x.instanceColor=new ci(A.array,A.itemSize,A.normalized)}else M!=="TRANSLATION"&&M!=="ROTATION"&&M!=="SCALE"&&g.geometry.setAttribute(M,l[M]);vt.prototype.copy.call(x,g),this.parser.assignFinalMaterial(x),f.push(x)}return h.isGroup?(h.clear(),h.add(...f),h):f[0]}))}},sf="glTF",Or=12,Qd={JSON:1313821514,BIN:5130562},Kc=class{constructor(e){this.name=$e.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,Or),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==sf)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");let s=this.header.length-Or,r=new DataView(e,Or),o=0;for(;o<s;){let a=r.getUint32(o,!0);o+=4;let l=r.getUint32(o,!0);if(o+=4,l===Qd.JSON){let c=new Uint8Array(e,Or+o,a);this.content=n.decode(c)}else if(l===Qd.BIN){let c=Or+o;this.body=e.slice(c,c+a)}o+=a}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}},jc=class{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=$e.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,s=this.dracoLoader,r=e.extensions[this.name].bufferView,o=e.extensions[this.name].attributes,a={},l={},c={};for(let h in o){let u=Qc[h]||h.toLowerCase();a[u]=o[h]}for(let h in e.attributes){let u=Qc[h]||h.toLowerCase();if(o[h]!==void 0){let d=n.accessors[e.attributes[h]],f=Ys[d.componentType];c[u]=f.name,l[u]=d.normalized===!0}}return t.getDependency("bufferView",r).then(function(h){return new Promise(function(u,d){s.decodeDracoFile(h,function(f){for(let g in f.attributes){let _=f.attributes[g],m=l[g];m!==void 0&&(_.normalized=m)}u(f)},a,c,Pt,d)})})}},$c=class{constructor(){this.name=$e.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}},Zc=class{constructor(){this.name=$e.KHR_MESH_QUANTIZATION}},ho=class extends Li{constructor(e,t,n,s){super(e,t,n,s)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s*3+s;for(let o=0;o!==s;o++)t[o]=n[r+o];return t}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=a*2,c=a*3,h=s-t,u=(n-t)/h,d=u*u,f=d*u,g=e*c,_=g-c,m=-2*f+3*d,p=f-d,y=1-m,x=p-d+u;for(let M=0;M!==a;M++){let A=o[_+M+a],T=o[_+M+l]*h,R=o[g+M+a],N=o[g+M]*h;r[M]=y*A+x*T+m*R+p*N}return r}},Wy=new xt,Jc=class extends ho{interpolate_(e,t,n,s){let r=super.interpolate_(e,t,n,s);return Wy.fromArray(r).normalize().toArray(r),r}},An={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Ys={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},ef={9728:Rt,9729:an,9984:Ca,9985:_c,9986:ur,9987:Pi},tf={33071:mn,33648:_r,10497:Zi},Rc={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Qc={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},Oi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},Xy={CUBICSPLINE:void 0,LINEAR:Ji,STEP:Ns},Cc={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function qy(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new et({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:Wn})),i.DefaultMaterial}function es(i,e,t){for(let n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Fi(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function Yy(i,e,t){let n=!1,s=!1,r=!1;for(let c=0,h=e.length;c<h;c++){let u=e[c];if(u.POSITION!==void 0&&(n=!0),u.NORMAL!==void 0&&(s=!0),u.COLOR_0!==void 0&&(r=!0),n&&s&&r)break}if(!n&&!s&&!r)return Promise.resolve(i);let o=[],a=[],l=[];for(let c=0,h=e.length;c<h;c++){let u=e[c];if(n){let d=u.POSITION!==void 0?t.getDependency("accessor",u.POSITION):i.attributes.position;o.push(d)}if(s){let d=u.NORMAL!==void 0?t.getDependency("accessor",u.NORMAL):i.attributes.normal;a.push(d)}if(r){let d=u.COLOR_0!==void 0?t.getDependency("accessor",u.COLOR_0):i.attributes.color;l.push(d)}}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l)]).then(function(c){let h=c[0],u=c[1],d=c[2];return n&&(i.morphAttributes.position=h),s&&(i.morphAttributes.normal=u),r&&(i.morphAttributes.color=d),i.morphTargetsRelative=!0,i})}function Ky(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){let t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,s=t.length;n<s;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function jy(i){let e,t=i.extensions&&i.extensions[$e.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+Pc(t.attributes):e=i.indices+":"+Pc(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,s=i.targets.length;n<s;n++)e+=":"+Pc(i.targets[n]);return e}function Pc(i){let e="",t=Object.keys(i).sort();for(let n=0,s=t.length;n<s;n++)e+=t[n]+":"+i[t[n]]+";";return e}function eh(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function $y(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":"image/png"}var Zy=new ze,th=class{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new Gy,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,s=!1,r=-1;typeof navigator<"u"&&(n=/^((?!chrome|android).)*safari/i.test(navigator.userAgent)===!0,s=navigator.userAgent.indexOf("Firefox")>-1,r=s?navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1]:-1),typeof createImageBitmap>"u"||n||s&&r<98?this.textureLoader=new Qa(this.options.manager):this.textureLoader=new no(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new Pr(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,s=this.json,r=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(o){return o._markDefs&&o._markDefs()}),Promise.all(this._invokeAll(function(o){return o.beforeRoot&&o.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(o){let a={scene:o[0][s.scene||0],scenes:o[0],animations:o[1],cameras:o[2],asset:s.asset,parser:n,userData:{}};return es(r,a,s),Fi(a,s),Promise.all(n._invokeAll(function(l){return l.afterRoot&&l.afterRoot(a)})).then(function(){e(a)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let s=0,r=t.length;s<r;s++){let o=t[s].joints;for(let a=0,l=o.length;a<l;a++)e[o[a]].isBone=!0}for(let s=0,r=e.length;s<r;s++){let o=e[s];o.mesh!==void 0&&(this._addNodeRef(this.meshCache,o.mesh),o.skin!==void 0&&(n[o.mesh].isSkinnedMesh=!0)),o.camera!==void 0&&this._addNodeRef(this.cameraCache,o.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let s=n.clone(),r=(o,a)=>{let l=this.associations.get(o);l!=null&&this.associations.set(a,l);for(let[c,h]of o.children.entries())r(h,a.children[c])};return r(n,s),s.name+="_instance_"+e.uses[t]++,s}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let s=e(t[n]);if(s)return s}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let s=0;s<t.length;s++){let r=e(t[s]);r&&n.push(r)}return n}getDependency(e,t){let n=e+":"+t,s=this.cache.get(n);if(!s){switch(e){case"scene":s=this.loadScene(t);break;case"node":s=this._invokeOne(function(r){return r.loadNode&&r.loadNode(t)});break;case"mesh":s=this._invokeOne(function(r){return r.loadMesh&&r.loadMesh(t)});break;case"accessor":s=this.loadAccessor(t);break;case"bufferView":s=this._invokeOne(function(r){return r.loadBufferView&&r.loadBufferView(t)});break;case"buffer":s=this.loadBuffer(t);break;case"material":s=this._invokeOne(function(r){return r.loadMaterial&&r.loadMaterial(t)});break;case"texture":s=this._invokeOne(function(r){return r.loadTexture&&r.loadTexture(t)});break;case"skin":s=this.loadSkin(t);break;case"animation":s=this._invokeOne(function(r){return r.loadAnimation&&r.loadAnimation(t)});break;case"camera":s=this.loadCamera(t);break;default:if(s=this._invokeOne(function(r){return r!=this&&r.getDependency&&r.getDependency(e,t)}),!s)throw new Error("Unknown type: "+e);break}this.cache.add(n,s)}return s}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,s=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(s.map(function(r,o){return n.getDependency(e,o)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[$e.KHR_BINARY_GLTF].body);let s=this.options;return new Promise(function(r,o){n.load(Ui.resolveURL(t.uri,s.path),r,void 0,function(){o(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){let s=t.byteLength||0,r=t.byteOffset||0;return n.slice(r,r+s)})}loadAccessor(e){let t=this,n=this.json,s=this.json.accessors[e];if(s.bufferView===void 0&&s.sparse===void 0){let o=Rc[s.type],a=Ys[s.componentType],l=s.normalized===!0,c=new a(s.count*o);return Promise.resolve(new wt(c,o,l))}let r=[];return s.bufferView!==void 0?r.push(this.getDependency("bufferView",s.bufferView)):r.push(null),s.sparse!==void 0&&(r.push(this.getDependency("bufferView",s.sparse.indices.bufferView)),r.push(this.getDependency("bufferView",s.sparse.values.bufferView))),Promise.all(r).then(function(o){let a=o[0],l=Rc[s.type],c=Ys[s.componentType],h=c.BYTES_PER_ELEMENT,u=h*l,d=s.byteOffset||0,f=s.bufferView!==void 0?n.bufferViews[s.bufferView].byteStride:void 0,g=s.normalized===!0,_,m;if(f&&f!==u){let p=Math.floor(d/f),y="InterleavedBuffer:"+s.bufferView+":"+s.componentType+":"+p+":"+s.count,x=t.cache.get(y);x||(_=new c(a,p*f,s.count*f/h),x=new wr(_,f/h),t.cache.add(y,x)),m=new Sr(x,l,d%f/h,g)}else a===null?_=new c(s.count*l):_=new c(a,d,s.count*l),m=new wt(_,l,g);if(s.sparse!==void 0){let p=Rc.SCALAR,y=Ys[s.sparse.indices.componentType],x=s.sparse.indices.byteOffset||0,M=s.sparse.values.byteOffset||0,A=new y(o[1],x,s.sparse.count*p),T=new c(o[2],M,s.sparse.count*l);a!==null&&(m=new wt(m.array.slice(),m.itemSize,m.normalized));for(let R=0,N=A.length;R<N;R++){let b=A[R];if(m.setX(b,T[R*l]),l>=2&&m.setY(b,T[R*l+1]),l>=3&&m.setZ(b,T[R*l+2]),l>=4&&m.setW(b,T[R*l+3]),l>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}}return m})}loadTexture(e){let t=this.json,n=this.options,r=t.textures[e].source,o=t.images[r],a=this.textureLoader;if(o.uri){let l=n.manager.getHandler(o.uri);l!==null&&(a=l)}return this.loadTextureImage(e,r,a)}loadTextureImage(e,t,n){let s=this,r=this.json,o=r.textures[e],a=r.images[t],l=(a.uri||a.bufferView)+":"+o.sampler;if(this.textureCache[l])return this.textureCache[l];let c=this.loadImageSource(t,n).then(function(h){h.flipY=!1,h.name=o.name||a.name||"",h.name===""&&typeof a.uri=="string"&&a.uri.startsWith("data:image/")===!1&&(h.name=a.uri);let d=(r.samplers||{})[o.sampler]||{};return h.magFilter=ef[d.magFilter]||an,h.minFilter=ef[d.minFilter]||Pi,h.wrapS=tf[d.wrapS]||Zi,h.wrapT=tf[d.wrapT]||Zi,s.associations.set(h,{textures:e}),h}).catch(function(){return null});return this.textureCache[l]=c,c}loadImageSource(e,t){let n=this,s=this.json,r=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(u=>u.clone());let o=s.images[e],a=self.URL||self.webkitURL,l=o.uri||"",c=!1;if(o.bufferView!==void 0)l=n.getDependency("bufferView",o.bufferView).then(function(u){c=!0;let d=new Blob([u],{type:o.mimeType});return l=a.createObjectURL(d),l});else if(o.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");let h=Promise.resolve(l).then(function(u){return new Promise(function(d,f){let g=d;t.isImageBitmapLoader===!0&&(g=function(_){let m=new Gt(_);m.needsUpdate=!0,d(m)}),t.load(Ui.resolveURL(u,r.path),g,void 0,f)})}).then(function(u){return c===!0&&a.revokeObjectURL(l),u.userData.mimeType=o.mimeType||$y(o.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",l),u});return this.sourceCache[e]=h,h}assignTexture(e,t,n,s){let r=this;return this.getDependency("texture",n.index).then(function(o){if(!o)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(o=o.clone(),o.channel=n.texCoord),r.extensions[$e.KHR_TEXTURE_TRANSFORM]){let a=n.extensions!==void 0?n.extensions[$e.KHR_TEXTURE_TRANSFORM]:void 0;if(a){let l=r.associations.get(o);o=r.extensions[$e.KHR_TEXTURE_TRANSFORM].extendTexture(o,a),r.associations.set(o,l)}}return s!==void 0&&(o.colorSpace=s),e[t]=o,o})}assignFinalMaterial(e){let t=e.geometry,n=e.material,s=t.attributes.tangent===void 0,r=t.attributes.color!==void 0,o=t.attributes.normal===void 0;if(e.isPoints){let a="PointsMaterial:"+n.uuid,l=this.cache.get(a);l||(l=new Ar,_n.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,l.sizeAttenuation=!1,this.cache.add(a,l)),n=l}else if(e.isLine){let a="LineBasicMaterial:"+n.uuid,l=this.cache.get(a);l||(l=new Tr,_n.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,this.cache.add(a,l)),n=l}if(s||r||o){let a="ClonedMaterial:"+n.uuid+":";s&&(a+="derivative-tangents:"),r&&(a+="vertex-colors:"),o&&(a+="flat-shading:");let l=this.cache.get(a);l||(l=n.clone(),r&&(l.vertexColors=!0),o&&(l.flatShading=!0),s&&(l.normalScale&&(l.normalScale.y*=-1),l.clearcoatNormalScale&&(l.clearcoatNormalScale.y*=-1)),this.cache.add(a,l),this.associations.set(l,this.associations.get(n))),n=l}e.material=n}getMaterialType(){return et}loadMaterial(e){let t=this,n=this.json,s=this.extensions,r=n.materials[e],o,a={},l=r.extensions||{},c=[];if(l[$e.KHR_MATERIALS_UNLIT]){let u=s[$e.KHR_MATERIALS_UNLIT];o=u.getMaterialType(),c.push(u.extendParams(a,r,t))}else{let u=r.pbrMetallicRoughness||{};if(a.color=new Te(1,1,1),a.opacity=1,Array.isArray(u.baseColorFactor)){let d=u.baseColorFactor;a.color.setRGB(d[0],d[1],d[2],Pt),a.opacity=d[3]}u.baseColorTexture!==void 0&&c.push(t.assignTexture(a,"map",u.baseColorTexture,ut)),a.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,a.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(a,"metalnessMap",u.metallicRoughnessTexture)),c.push(t.assignTexture(a,"roughnessMap",u.metallicRoughnessTexture))),o=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(e,a)})))}r.doubleSided===!0&&(a.side=_t);let h=r.alphaMode||Cc.OPAQUE;if(h===Cc.BLEND?(a.transparent=!0,a.depthWrite=!1):(a.transparent=!1,h===Cc.MASK&&(a.alphaTest=r.alphaCutoff!==void 0?r.alphaCutoff:.5)),r.normalTexture!==void 0&&o!==Wt&&(c.push(t.assignTexture(a,"normalMap",r.normalTexture)),a.normalScale=new Re(1,1),r.normalTexture.scale!==void 0)){let u=r.normalTexture.scale;a.normalScale.set(u,u)}if(r.occlusionTexture!==void 0&&o!==Wt&&(c.push(t.assignTexture(a,"aoMap",r.occlusionTexture)),r.occlusionTexture.strength!==void 0&&(a.aoMapIntensity=r.occlusionTexture.strength)),r.emissiveFactor!==void 0&&o!==Wt){let u=r.emissiveFactor;a.emissive=new Te().setRGB(u[0],u[1],u[2],Pt)}return r.emissiveTexture!==void 0&&o!==Wt&&c.push(t.assignTexture(a,"emissiveMap",r.emissiveTexture,ut)),Promise.all(c).then(function(){let u=new o(a);return r.name&&(u.name=r.name),Fi(u,r),t.associations.set(u,{materials:e}),r.extensions&&es(s,u,r),u})}createUniqueName(e){let t=ht.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,n=this.extensions,s=this.primitiveCache;function r(a){return n[$e.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a,t).then(function(l){return nf(l,a,t)})}let o=[];for(let a=0,l=e.length;a<l;a++){let c=e[a],h=jy(c),u=s[h];if(u)o.push(u.promise);else{let d;c.extensions&&c.extensions[$e.KHR_DRACO_MESH_COMPRESSION]?d=r(c):d=nf(new Tt,c,t),s[h]={primitive:c,promise:d},o.push(d)}}return Promise.all(o)}loadMesh(e){let t=this,n=this.json,s=this.extensions,r=n.meshes[e],o=r.primitives,a=[];for(let l=0,c=o.length;l<c;l++){let h=o[l].material===void 0?qy(this.cache):this.getDependency("material",o[l].material);a.push(h)}return a.push(t.loadGeometries(o)),Promise.all(a).then(function(l){let c=l.slice(0,l.length-1),h=l[l.length-1],u=[];for(let f=0,g=h.length;f<g;f++){let _=h[f],m=o[f],p,y=c[f];if(m.mode===An.TRIANGLES||m.mode===An.TRIANGLE_STRIP||m.mode===An.TRIANGLE_FAN||m.mode===void 0)p=r.isSkinnedMesh===!0?new Xa(_,y):new je(_,y),p.isSkinnedMesh===!0&&p.normalizeSkinWeights(),m.mode===An.TRIANGLE_STRIP?p.geometry=Ac(p.geometry,ao):m.mode===An.TRIANGLE_FAN&&(p.geometry=Ac(p.geometry,Nr));else if(m.mode===An.LINES)p=new Ya(_,y);else if(m.mode===An.LINE_STRIP)p=new Hs(_,y);else if(m.mode===An.LINE_LOOP)p=new Ka(_,y);else if(m.mode===An.POINTS)p=new ja(_,y);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(p.geometry.morphAttributes).length>0&&Ky(p,r),p.name=t.createUniqueName(r.name||"mesh_"+e),Fi(p,r),m.extensions&&es(s,p,m),t.assignFinalMaterial(p),u.push(p)}for(let f=0,g=u.length;f<g;f++)t.associations.set(u[f],{meshes:e,primitives:f});if(u.length===1)return r.extensions&&es(s,u[0],r),u[0];let d=new Jt;r.extensions&&es(s,d,r),t.associations.set(d,{meshes:e});for(let f=0,g=u.length;f<g;f++)d.add(u[f]);return d})}loadCamera(e){let t,n=this.json.cameras[e],s=n[n.type];if(!s){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Ct(Dt.radToDeg(s.yfov),s.aspectRatio||1,s.znear||1,s.zfar||2e6):n.type==="orthographic"&&(t=new Bs(-s.xmag,s.xmag,s.ymag,-s.ymag,s.znear,s.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Fi(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let s=0,r=t.joints.length;s<r;s++)n.push(this._loadNodeShallow(t.joints[s]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(s){let r=s.pop(),o=s,a=[],l=[];for(let c=0,h=o.length;c<h;c++){let u=o[c];if(u){a.push(u);let d=new ze;r!==null&&d.fromArray(r.array,c*16),l.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[c])}return new qa(a,l)})}loadAnimation(e){let t=this.json,n=this,s=t.animations[e],r=s.name?s.name:"animation_"+e,o=[],a=[],l=[],c=[],h=[];for(let u=0,d=s.channels.length;u<d;u++){let f=s.channels[u],g=s.samplers[f.sampler],_=f.target,m=_.node,p=s.parameters!==void 0?s.parameters[g.input]:g.input,y=s.parameters!==void 0?s.parameters[g.output]:g.output;_.node!==void 0&&(o.push(this.getDependency("node",m)),a.push(this.getDependency("accessor",p)),l.push(this.getDependency("accessor",y)),c.push(g),h.push(_))}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l),Promise.all(c),Promise.all(h)]).then(function(u){let d=u[0],f=u[1],g=u[2],_=u[3],m=u[4],p=[];for(let y=0,x=d.length;y<x;y++){let M=d[y],A=f[y],T=g[y],R=_[y],N=m[y];if(M===void 0)continue;M.updateMatrix&&M.updateMatrix();let b=n._createAnimationTracks(M,A,T,R,N);if(b)for(let E=0;E<b.length;E++)p.push(b[E])}return new Gs(r,void 0,p)})}createNodeMesh(e){let t=this.json,n=this,s=t.nodes[e];return s.mesh===void 0?null:n.getDependency("mesh",s.mesh).then(function(r){let o=n._getNodeRef(n.meshCache,s.mesh,r);return s.weights!==void 0&&o.traverse(function(a){if(a.isMesh)for(let l=0,c=s.weights.length;l<c;l++)a.morphTargetInfluences[l]=s.weights[l]}),o})}loadNode(e){let t=this.json,n=this,s=t.nodes[e],r=n._loadNodeShallow(e),o=[],a=s.children||[];for(let c=0,h=a.length;c<h;c++)o.push(n.getDependency("node",a[c]));let l=s.skin===void 0?Promise.resolve(null):n.getDependency("skin",s.skin);return Promise.all([r,Promise.all(o),l]).then(function(c){let h=c[0],u=c[1],d=c[2];d!==null&&h.traverse(function(f){f.isSkinnedMesh&&f.bind(d,Zy)});for(let f=0,g=u.length;f<g;f++)h.add(u[f]);return h})}_loadNodeShallow(e){let t=this.json,n=this.extensions,s=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let r=t.nodes[e],o=r.name?s.createUniqueName(r.name):"",a=[],l=s._invokeOne(function(c){return c.createNodeMesh&&c.createNodeMesh(e)});return l&&a.push(l),r.camera!==void 0&&a.push(s.getDependency("camera",r.camera).then(function(c){return s._getNodeRef(s.cameraCache,r.camera,c)})),s._invokeAll(function(c){return c.createNodeAttachment&&c.createNodeAttachment(e)}).forEach(function(c){a.push(c)}),this.nodeCache[e]=Promise.all(a).then(function(c){let h;if(r.isBone===!0?h=new Er:c.length>1?h=new Jt:c.length===1?h=c[0]:h=new vt,h!==c[0])for(let u=0,d=c.length;u<d;u++)h.add(c[u]);if(r.name&&(h.userData.name=r.name,h.name=o),Fi(h,r),r.extensions&&es(n,h,r),r.matrix!==void 0){let u=new ze;u.fromArray(r.matrix),h.applyMatrix4(u)}else r.translation!==void 0&&h.position.fromArray(r.translation),r.rotation!==void 0&&h.quaternion.fromArray(r.rotation),r.scale!==void 0&&h.scale.fromArray(r.scale);return s.associations.has(h)||s.associations.set(h,{}),s.associations.get(h).nodes=e,h}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],s=this,r=new Jt;n.name&&(r.name=s.createUniqueName(n.name)),Fi(r,n),n.extensions&&es(t,r,n);let o=n.nodes||[],a=[];for(let l=0,c=o.length;l<c;l++)a.push(s.getDependency("node",o[l]));return Promise.all(a).then(function(l){for(let h=0,u=l.length;h<u;h++)r.add(l[h]);let c=h=>{let u=new Map;for(let[d,f]of s.associations)(d instanceof _n||d instanceof Gt)&&u.set(d,f);return h.traverse(d=>{let f=s.associations.get(d);f!=null&&u.set(d,f)}),u};return s.associations=c(r),r})}_createAnimationTracks(e,t,n,s,r){let o=[],a=e.name?e.name:e.uuid,l=[];Oi[r.path]===Oi.weights?e.traverse(function(d){d.morphTargetInfluences&&l.push(d.name?d.name:d.uuid)}):l.push(a);let c;switch(Oi[r.path]){case Oi.weights:c=hi;break;case Oi.rotation:c=Yn;break;case Oi.position:case Oi.scale:c=ui;break;default:switch(n.itemSize){case 1:c=hi;break;case 2:case 3:default:c=ui;break}break}let h=s.interpolation!==void 0?Xy[s.interpolation]:Ji,u=this._getArrayFromAccessor(n);for(let d=0,f=l.length;d<f;d++){let g=new c(l[d]+"."+Oi[r.path],t.array,u,h);s.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),o.push(g)}return o}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let n=eh(t.constructor),s=new Float32Array(t.length);for(let r=0,o=t.length;r<o;r++)s[r]=t[r]*n;t=s}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){let s=this instanceof Yn?Jc:ho;return new s(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}};function Jy(i,e,t){let n=e.attributes,s=new wn;if(n.POSITION!==void 0){let a=t.json.accessors[n.POSITION],l=a.min,c=a.max;if(l!==void 0&&c!==void 0){if(s.set(new C(l[0],l[1],l[2]),new C(c[0],c[1],c[2])),a.normalized){let h=eh(Ys[a.componentType]);s.min.multiplyScalar(h),s.max.multiplyScalar(h)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;let r=e.targets;if(r!==void 0){let a=new C,l=new C;for(let c=0,h=r.length;c<h;c++){let u=r[c];if(u.POSITION!==void 0){let d=t.json.accessors[u.POSITION],f=d.min,g=d.max;if(f!==void 0&&g!==void 0){if(l.setX(Math.max(Math.abs(f[0]),Math.abs(g[0]))),l.setY(Math.max(Math.abs(f[1]),Math.abs(g[1]))),l.setZ(Math.max(Math.abs(f[2]),Math.abs(g[2]))),d.normalized){let _=eh(Ys[d.componentType]);l.multiplyScalar(_)}a.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(a)}i.boundingBox=s;let o=new gn;s.getCenter(o.center),o.radius=s.min.distanceTo(s.max)/2,i.boundingSphere=o}function nf(i,e,t){let n=e.attributes,s=[];function r(o,a){return t.getDependency("accessor",o).then(function(l){i.setAttribute(a,l)})}for(let o in n){let a=Qc[o]||o.toLowerCase();a in i.attributes||s.push(r(n[o],a))}if(e.indices!==void 0&&!i.index){let o=t.getDependency("accessor",e.indices).then(function(a){i.setIndex(a)});s.push(o)}return at.workingColorSpace!==Pt&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${at.workingColorSpace}" not supported.`),Fi(i,e),Jy(i,e,t),Promise.all(s).then(function(){return e.targets!==void 0?Yy(i,e.targets,t):i})}var rf={type:"change"},nh={type:"start"},af={type:"end"},uo=new li,of=new Nn,Qy=Math.cos(70*Dt.DEG2RAD),fo=class extends On{constructor(e,t){super(),this.object=e,this.domElement=t,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new C,this.cursor=new C,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:hn.ROTATE,MIDDLE:hn.DOLLY,RIGHT:hn.PAN},this.touches={ONE:Tn.ROTATE,TWO:Tn.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return a.phi},this.getAzimuthalAngle=function(){return a.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(P){P.addEventListener("keydown",te),this._domElementKeyEvents=P},this.stopListenToKeyEvents=function(){this._domElementKeyEvents.removeEventListener("keydown",te),this._domElementKeyEvents=null},this.saveState=function(){n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=function(){n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(rf),n.update(),r=s.NONE},this.update=function(){let P=new C,$=new xt().setFromUnitVectors(e.up,new C(0,1,0)),he=$.clone().invert(),re=new C,be=new xt,qe=new C,Qe=2*Math.PI;return function(ce=null){let L=n.object.position;P.copy(L).sub(n.target),P.applyQuaternion($),a.setFromVector3(P),n.autoRotate&&r===s.NONE&&O(b(ce)),n.enableDamping?(a.theta+=l.theta*n.dampingFactor,a.phi+=l.phi*n.dampingFactor):(a.theta+=l.theta,a.phi+=l.phi);let oe=n.minAzimuthAngle,le=n.maxAzimuthAngle;isFinite(oe)&&isFinite(le)&&(oe<-Math.PI?oe+=Qe:oe>Math.PI&&(oe-=Qe),le<-Math.PI?le+=Qe:le>Math.PI&&(le-=Qe),oe<=le?a.theta=Math.max(oe,Math.min(le,a.theta)):a.theta=a.theta>(oe+le)/2?Math.max(oe,a.theta):Math.min(le,a.theta)),a.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,a.phi)),a.makeSafe(),n.enableDamping===!0?n.target.addScaledVector(h,n.dampingFactor):n.target.add(h),n.target.sub(n.cursor),n.target.clampLength(n.minTargetRadius,n.maxTargetRadius),n.target.add(n.cursor),n.zoomToCursor&&T||n.object.isOrthographicCamera?a.radius=q(a.radius):a.radius=q(a.radius*c),P.setFromSpherical(a),P.applyQuaternion(he),L.copy(n.target).add(P),n.object.lookAt(n.target),n.enableDamping===!0?(l.theta*=1-n.dampingFactor,l.phi*=1-n.dampingFactor,h.multiplyScalar(1-n.dampingFactor)):(l.set(0,0,0),h.set(0,0,0));let Pe=!1;if(n.zoomToCursor&&T){let Se=null;if(n.object.isPerspectiveCamera){let it=P.length();Se=q(it*c);let rt=it-Se;n.object.position.addScaledVector(M,rt),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let it=new C(A.x,A.y,0);it.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Pe=!0;let rt=new C(A.x,A.y,0);rt.unproject(n.object),n.object.position.sub(rt).add(it),n.object.updateMatrixWorld(),Se=P.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),n.zoomToCursor=!1;Se!==null&&(this.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(Se).add(n.object.position):(uo.origin.copy(n.object.position),uo.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(uo.direction))<Qy?e.lookAt(n.target):(of.setFromNormalAndCoplanarPoint(n.object.up,n.target),uo.intersectPlane(of,n.target))))}else n.object.isOrthographicCamera&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Pe=!0);return c=1,T=!1,Pe||re.distanceToSquared(n.object.position)>o||8*(1-be.dot(n.object.quaternion))>o||qe.distanceToSquared(n.target)>0?(n.dispatchEvent(rf),re.copy(n.object.position),be.copy(n.object.quaternion),qe.copy(n.target),!0):!1}}(),this.dispose=function(){n.domElement.removeEventListener("contextmenu",_e),n.domElement.removeEventListener("pointerdown",Be),n.domElement.removeEventListener("pointercancel",v),n.domElement.removeEventListener("wheel",Q),n.domElement.removeEventListener("pointermove",S),n.domElement.removeEventListener("pointerup",v),n._domElementKeyEvents!==null&&(n._domElementKeyEvents.removeEventListener("keydown",te),n._domElementKeyEvents=null)};let n=this,s={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},r=s.NONE,o=1e-6,a=new Dr,l=new Dr,c=1,h=new C,u=new Re,d=new Re,f=new Re,g=new Re,_=new Re,m=new Re,p=new Re,y=new Re,x=new Re,M=new C,A=new Re,T=!1,R=[],N={};function b(P){return P!==null?2*Math.PI/60*n.autoRotateSpeed*P:2*Math.PI/60/60*n.autoRotateSpeed}function E(P){let $=Math.abs(P)/(100*(window.devicePixelRatio|0));return Math.pow(.95,n.zoomSpeed*$)}function O(P){l.theta-=P}function W(P){l.phi-=P}let ne=function(){let P=new C;return function(he,re){P.setFromMatrixColumn(re,0),P.multiplyScalar(-he),h.add(P)}}(),I=function(){let P=new C;return function(he,re){n.screenSpacePanning===!0?P.setFromMatrixColumn(re,1):(P.setFromMatrixColumn(re,0),P.crossVectors(n.object.up,P)),P.multiplyScalar(he),h.add(P)}}(),U=function(){let P=new C;return function(he,re){let be=n.domElement;if(n.object.isPerspectiveCamera){let qe=n.object.position;P.copy(qe).sub(n.target);let Qe=P.length();Qe*=Math.tan(n.object.fov/2*Math.PI/180),ne(2*he*Qe/be.clientHeight,n.object.matrix),I(2*re*Qe/be.clientHeight,n.object.matrix)}else n.object.isOrthographicCamera?(ne(he*(n.object.right-n.object.left)/n.object.zoom/be.clientWidth,n.object.matrix),I(re*(n.object.top-n.object.bottom)/n.object.zoom/be.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}}();function V(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c/=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function K(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c*=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function Y(P,$){if(!n.zoomToCursor)return;T=!0;let he=n.domElement.getBoundingClientRect(),re=P-he.left,be=$-he.top,qe=he.width,Qe=he.height;A.x=re/qe*2-1,A.y=-(be/Qe)*2+1,M.set(A.x,A.y,1).unproject(n.object).sub(n.object.position).normalize()}function q(P){return Math.max(n.minDistance,Math.min(n.maxDistance,P))}function ee(P){u.set(P.clientX,P.clientY)}function se(P){Y(P.clientX,P.clientX),p.set(P.clientX,P.clientY)}function me(P){g.set(P.clientX,P.clientY)}function G(P){d.set(P.clientX,P.clientY),f.subVectors(d,u).multiplyScalar(n.rotateSpeed);let $=n.domElement;O(2*Math.PI*f.x/$.clientHeight),W(2*Math.PI*f.y/$.clientHeight),u.copy(d),n.update()}function Z(P){y.set(P.clientX,P.clientY),x.subVectors(y,p),x.y>0?V(E(x.y)):x.y<0&&K(E(x.y)),p.copy(y),n.update()}function fe(P){_.set(P.clientX,P.clientY),m.subVectors(_,g).multiplyScalar(n.panSpeed),U(m.x,m.y),g.copy(_),n.update()}function we(P){Y(P.clientX,P.clientY),P.deltaY<0?K(E(P.deltaY)):P.deltaY>0&&V(E(P.deltaY)),n.update()}function ve(P){let $=!1;switch(P.code){case n.keys.UP:P.ctrlKey||P.metaKey||P.shiftKey?W(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(0,n.keyPanSpeed),$=!0;break;case n.keys.BOTTOM:P.ctrlKey||P.metaKey||P.shiftKey?W(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(0,-n.keyPanSpeed),$=!0;break;case n.keys.LEFT:P.ctrlKey||P.metaKey||P.shiftKey?O(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(n.keyPanSpeed,0),$=!0;break;case n.keys.RIGHT:P.ctrlKey||P.metaKey||P.shiftKey?O(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(-n.keyPanSpeed,0),$=!0;break}$&&(P.preventDefault(),n.update())}function Oe(P){if(R.length===1)u.set(P.pageX,P.pageY);else{let $=Je(P),he=.5*(P.pageX+$.x),re=.5*(P.pageY+$.y);u.set(he,re)}}function Fe(P){if(R.length===1)g.set(P.pageX,P.pageY);else{let $=Je(P),he=.5*(P.pageX+$.x),re=.5*(P.pageY+$.y);g.set(he,re)}}function Le(P){let $=Je(P),he=P.pageX-$.x,re=P.pageY-$.y,be=Math.sqrt(he*he+re*re);p.set(0,be)}function Ze(P){n.enableZoom&&Le(P),n.enablePan&&Fe(P)}function F(P){n.enableZoom&&Le(P),n.enableRotate&&Oe(P)}function Ot(P){if(R.length==1)d.set(P.pageX,P.pageY);else{let he=Je(P),re=.5*(P.pageX+he.x),be=.5*(P.pageY+he.y);d.set(re,be)}f.subVectors(d,u).multiplyScalar(n.rotateSpeed);let $=n.domElement;O(2*Math.PI*f.x/$.clientHeight),W(2*Math.PI*f.y/$.clientHeight),u.copy(d)}function Ce(P){if(R.length===1)_.set(P.pageX,P.pageY);else{let $=Je(P),he=.5*(P.pageX+$.x),re=.5*(P.pageY+$.y);_.set(he,re)}m.subVectors(_,g).multiplyScalar(n.panSpeed),U(m.x,m.y),g.copy(_)}function Ne(P){let $=Je(P),he=P.pageX-$.x,re=P.pageY-$.y,be=Math.sqrt(he*he+re*re);y.set(0,be),x.set(0,Math.pow(y.y/p.y,n.zoomSpeed)),V(x.y),p.copy(y);let qe=(P.pageX+$.x)*.5,Qe=(P.pageY+$.y)*.5;Y(qe,Qe)}function xe(P){n.enableZoom&&Ne(P),n.enablePan&&Ce(P)}function pt(P){n.enableZoom&&Ne(P),n.enableRotate&&Ot(P)}function Be(P){n.enabled!==!1&&(R.length===0&&(n.domElement.setPointerCapture(P.pointerId),n.domElement.addEventListener("pointermove",S),n.domElement.addEventListener("pointerup",v)),Ie(P),P.pointerType==="touch"?ye(P):B(P))}function S(P){n.enabled!==!1&&(P.pointerType==="touch"?de(P):ie(P))}function v(P){He(P),R.length===0&&(n.domElement.releasePointerCapture(P.pointerId),n.domElement.removeEventListener("pointermove",S),n.domElement.removeEventListener("pointerup",v)),n.dispatchEvent(af),r=s.NONE}function B(P){let $;switch(P.button){case 0:$=n.mouseButtons.LEFT;break;case 1:$=n.mouseButtons.MIDDLE;break;case 2:$=n.mouseButtons.RIGHT;break;default:$=-1}switch($){case hn.DOLLY:if(n.enableZoom===!1)return;se(P),r=s.DOLLY;break;case hn.ROTATE:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enablePan===!1)return;me(P),r=s.PAN}else{if(n.enableRotate===!1)return;ee(P),r=s.ROTATE}break;case hn.PAN:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enableRotate===!1)return;ee(P),r=s.ROTATE}else{if(n.enablePan===!1)return;me(P),r=s.PAN}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(nh)}function ie(P){switch(r){case s.ROTATE:if(n.enableRotate===!1)return;G(P);break;case s.DOLLY:if(n.enableZoom===!1)return;Z(P);break;case s.PAN:if(n.enablePan===!1)return;fe(P);break}}function Q(P){n.enabled===!1||n.enableZoom===!1||r!==s.NONE||(P.preventDefault(),n.dispatchEvent(nh),we(P),n.dispatchEvent(af))}function te(P){n.enabled===!1||n.enablePan===!1||ve(P)}function ye(P){switch(J(P),R.length){case 1:switch(n.touches.ONE){case Tn.ROTATE:if(n.enableRotate===!1)return;Oe(P),r=s.TOUCH_ROTATE;break;case Tn.PAN:if(n.enablePan===!1)return;Fe(P),r=s.TOUCH_PAN;break;default:r=s.NONE}break;case 2:switch(n.touches.TWO){case Tn.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Ze(P),r=s.TOUCH_DOLLY_PAN;break;case Tn.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;F(P),r=s.TOUCH_DOLLY_ROTATE;break;default:r=s.NONE}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(nh)}function de(P){switch(J(P),r){case s.TOUCH_ROTATE:if(n.enableRotate===!1)return;Ot(P),n.update();break;case s.TOUCH_PAN:if(n.enablePan===!1)return;Ce(P),n.update();break;case s.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;xe(P),n.update();break;case s.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;pt(P),n.update();break;default:r=s.NONE}}function _e(P){n.enabled!==!1&&P.preventDefault()}function Ie(P){R.push(P.pointerId)}function He(P){delete N[P.pointerId];for(let $=0;$<R.length;$++)if(R[$]==P.pointerId){R.splice($,1);return}}function J(P){let $=N[P.pointerId];$===void 0&&($=new Re,N[P.pointerId]=$),$.set(P.pageX,P.pageY)}function Je(P){let $=P.pointerId===R[0]?R[1]:R[0];return N[$]}n.domElement.addEventListener("contextmenu",_e),n.domElement.addEventListener("pointerdown",Be),n.domElement.addEventListener("pointercancel",v),n.domElement.addEventListener("wheel",Q,{passive:!1}),this.update()}};var po=class extends zs{constructor(e=null){super();let t=new Xt;t.deleteAttribute("uv");let n=new et({side:zt}),s=new et,r=5;e!==null&&e._useLegacyLights===!1&&(r=900);let o=new Ni(16777215,r,28,2);o.position.set(.418,16.199,.3),this.add(o);let a=new je(t,n);a.position.set(-.757,13.219,.717),a.scale.set(31.713,28.305,28.591),this.add(a);let l=new je(t,s);l.position.set(-10.906,2.009,1.846),l.rotation.set(0,-.195,0),l.scale.set(2.328,7.905,4.651),this.add(l);let c=new je(t,s);c.position.set(-5.607,-.754,-.758),c.rotation.set(0,.994,0),c.scale.set(1.97,1.534,3.955),this.add(c);let h=new je(t,s);h.position.set(6.167,.857,7.803),h.rotation.set(0,.561,0),h.scale.set(3.927,6.285,3.687),this.add(h);let u=new je(t,s);u.position.set(-2.017,.018,6.124),u.rotation.set(0,.333,0),u.scale.set(2.002,4.566,2.064),this.add(u);let d=new je(t,s);d.position.set(2.291,-.756,-2.621),d.rotation.set(0,-.286,0),d.scale.set(1.546,1.552,1.496),this.add(d);let f=new je(t,s);f.position.set(-2.193,-.369,-5.547),f.rotation.set(0,.516,0),f.scale.set(3.875,3.487,2.986),this.add(f);let g=new je(t,Ks(50));g.position.set(-16.116,14.37,8.208),g.scale.set(.1,2.428,2.739),this.add(g);let _=new je(t,Ks(50));_.position.set(-16.109,18.021,-8.207),_.scale.set(.1,2.425,2.751),this.add(_);let m=new je(t,Ks(17));m.position.set(14.904,12.198,-1.832),m.scale.set(.15,4.265,6.331),this.add(m);let p=new je(t,Ks(43));p.position.set(-.462,8.89,14.52),p.scale.set(4.38,5.441,.088),this.add(p);let y=new je(t,Ks(20));y.position.set(3.235,11.486,-12.541),y.scale.set(2.5,2,.1),this.add(y);let x=new je(t,Ks(100));x.position.set(0,20,0),x.scale.set(1,.1,1),this.add(x)}dispose(){let e=new Set;this.traverse(t=>{t.isMesh&&(e.add(t.geometry),e.add(t.material))});for(let t of e)t.dispose()}};function Ks(i){let e=new Wt;return e.color.setScalar(i),e}var zr={oldcity:{dir:"",mr:"\u0936\u0928\u093F\u0935\u093E\u0930 \u0935\u093E\u0921\u093E",en:"Shaniwar Wada and old Pune",coord:"18.5195\xB0 N, 73.8553\xB0 E",blurb:"Shaniwar Wada, Lal Mahal, Kasba and Dagdusheth Ganpati, Tulshibaug, Laxmi Road, the Mandai, the wadas, Omkareshwar"},deccan:{dir:"deccan/",mr:"\u0921\u0947\u0915\u094D\u0915\u0928, \u092B\u0930\u094D\u0917\u094D\u092F\u0941\u0938\u0928 \u0935 \u091C\u0902\u0917\u0932\u0940 \u092E\u0939\u093E\u0930\u093E\u091C \u0930\u0938\u094D\u0924\u093E",en:"Deccan, FC Road and JM Road",coord:"18.5200\xB0 N, 73.8463\xB0 E",blurb:"Fergusson College\u2019s Main Building and gate, the shops of FC Road and JM Road, Pataleshwar cave temple, Balgandharva Rangmandir, Sambhaji Udyan metro, the river and Lakdi Pul",start:"pataleshwar",parts:[{file:"wada_ground.glb.txt",mb:1.6},{file:"wada_city.glb.txt",mb:2},{file:"wada_grounds.glb.txt",mb:.3},{file:"wada_life.glb.txt",mb:1.4},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.8,metro:!0},{file:"wada_market.glb.txt",mb:.2},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:2.2}],views:[{id:"pataleshwar",cam:"Cam_Pataleshwar",label:"Pataleshwar caves"},{id:"pataleshwar-above",cam:"Cam_PataleshwarAbove",label:"Pataleshwar from above"},{id:"fergusson",cam:"Cam_Fergusson",label:"Fergusson College"},{id:"fcroad",cam:"Cam_FCRoad",label:"FC Road"},{id:"jmroad",cam:"Cam_JMRoad",label:"JM Road"},{id:"balgandharva",cam:"Cam_Balgandharva",label:"Balgandharva Rangmandir"},{id:"metro",cam:"Cam_Metro",label:"Sambhaji Udyan metro"},{id:"lakdipul",cam:"Cam_LakdiPul",label:"Lakdi Pul"},{id:"omkareshwar",cam:"Cam_Omkareshwar",label:"Omkareshwar Mandir"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Pataleshwar caves",mr:"\u092A\u093E\u0924\u093E\u0933\u0947\u0936\u094D\u0935\u0930 \u0932\u0947\u0923\u0940",en:"Pataleshwar cave temple",bearing:200,r:55,h:30,note:"An 8th-century cave temple to Shiva, cut out of the basalt rock, with a round Nandi pavilion in its sunken courtyard."},{land:"Fergusson College",mr:"\u092B\u0930\u094D\u0917\u094D\u092F\u0941\u0938\u0928 \u092E\u0939\u093E\u0935\u093F\u0926\u094D\u092F\u093E\u0932\u092F",en:"Fergusson College",bearing:20,r:75,h:34,note:"Founded in 1885 by the Deccan Education Society of Tilak and Agarkar: its Main Building of grey basalt has timber galleries, a gabled front with a rose window and a corner tower."},{land:"FC Road",mr:"\u092B\u0930\u094D\u0917\u094D\u092F\u0941\u0938\u0928 \u0930\u0938\u094D\u0924\u093E",en:"Fergusson College Road",bearing:100,r:70,h:35,note:"FC Road, the college road: street shopping, caf\xE9s and students from the Deccan Gymkhana corner up past the college gate."},{land:"JM Road",mr:"\u091C\u0902\u0917\u0932\u0940 \u092E\u0939\u093E\u0930\u093E\u091C \u0930\u0938\u094D\u0924\u093E",en:"Jangli Maharaj Road",bearing:120,r:70,h:35,note:"The shopping street of Deccan, named after the saint whose temple stands beside the caves."},{land:"Balgandharva Rangmandir",mr:"\u092C\u093E\u0932\u0917\u0902\u0927\u0930\u094D\u0935 \u0930\u0902\u0917\u092E\u0902\u0926\u093F\u0930",en:"Balgandharva Rangmandir",bearing:330,r:70,h:32,note:"The city\u2019s best-known theatre, named after the singer-actor Bal Gandharva."},{land:"Omkareshwar Mandir",mr:"\u0913\u0902\u0915\u093E\u0930\u0947\u0936\u094D\u0935\u0930 \u092E\u0902\u0926\u093F\u0930",en:"Omkareshwar Mandir",bearing:120,r:75,h:38,note:"The Peshwa-era Shiva temple on the far bank of the Mutha, with its painted shikhara and ghats."}],landView:{"Pataleshwar caves":"pataleshwar","JM Road":"jmroad","Balgandharva Rangmandir":"balgandharva","Fergusson College":"fergusson","FC Road":"fcroad","Omkareshwar Mandir":"omkareshwar","Chhatrapati Sambhaji Udyan metro":"metro"}},south:{dir:"south/",mr:"\u092A\u0930\u094D\u0935\u0924\u0940, \u0938\u093E\u0930\u0938\u092C\u093E\u0917 \u0935 \u0938\u094D\u0935\u093E\u0930\u0917\u0947\u091F",en:"Parvati, Sarasbaug and Swargate",coord:"18.4992\xB0 N, 73.8520\xB0 E",blurb:"Parvati Hill with its stairway and temples, Sarasbaug\u2019s temple on its island, Swargate\u2019s bus stands and metro hub",start:"parvati-hill",parts:[{file:"wada_ground.glb.txt",mb:1.5},{file:"wada_city.glb.txt",mb:.4},{file:"wada_grounds.glb.txt",mb:.2},{file:"wada_life.glb.txt",mb:1.2},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.1,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.6}],views:[{id:"parvati-hill",cam:"Cam_ParvatiHill",label:"Parvati Hill"},{id:"parvati-stairs",cam:"Cam_ParvatiStairs",label:"Parvati stairway"},{id:"parvati",cam:"Cam_Parvati",label:"Parvati temples"},{id:"sarasbaug",cam:"Cam_Sarasbaug",label:"Sarasbaug temple"},{id:"sarasbaug-gate",cam:"Cam_SarasbaugGate",label:"Sarasbaug island"},{id:"swargate",cam:"Cam_Swargate",label:"Swargate hub"},{id:"ststand",cam:"Cam_STStand",label:"ST stand"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Parvati",mr:"\u092A\u0930\u094D\u0935\u0924\u0940",en:"Parvati Hill",bearing:60,r:140,h:95,note:"The Peshwas\u2019 hilltop temples above the city, reached by a long stone stairway. The Devdeveshwar temple dates from 1749."},{land:"Sarasbaug",mr:"\u0938\u093E\u0930\u0938\u092C\u093E\u0917",en:"Sarasbaug",bearing:30,r:60,h:30,note:"A garden laid out by the Peshwas round a lake; the temple of Shri Siddhivinayak stands on its island."},{land:"Swargate",mr:"\u0938\u094D\u0935\u093E\u0930\u0917\u0947\u091F",en:"Swargate",bearing:200,r:90,h:45,note:"Pune\u2019s great bus hub: State Transport buses to the whole state, city buses, and the metro\u2019s new terminus."}],landView:{Parvati:"parvati",Sarasbaug:"sarasbaug",Swargate:"swargate"}},coep:{dir:"coep/",mr:"\u0936\u093F\u0935\u093E\u091C\u0940\u0928\u0917\u0930, \u0938\u0940\u0913\u0908\u092A\u0940 \u0935 \u0938\u0902\u0917\u092E",en:"COEP, Sangam and Shivajinagar",coord:"18.5300\xB0 N, 73.8555\xB0 E",blurb:"COEP\u2019s Gothic main building and boat club, the old Sangam bridge at the confluence, the creeper-clad District Court, Shivajinagar station with its suburban trains",start:"coep",parts:[{file:"wada_ground.glb.txt",mb:1.3},{file:"wada_city.glb.txt",mb:.9},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:1.7},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1.5,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.9},{file:"wada_railway.glb.txt",mb:1.5}],views:[{id:"coep",cam:"Cam_COEP",label:"COEP main building"},{id:"court",cam:"Cam_DistrictCourt",label:"District Court"},{id:"sangam",cam:"Cam_SangamBridge",label:"Sangam Bridge"},{id:"railbridge",cam:"Cam_RailBridge",label:"Railway bridge"},{id:"boatclub",cam:"Cam_BoatClub",label:"COEP Boat Club"},{id:"station",cam:"Cam_RailPlatform",label:"Shivajinagar station"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"COEP main building",mr:"\u0938\u0940\u0913\u0908\u092A\u0940 \u092E\u0941\u0916\u094D\u092F \u0907\u092E\u093E\u0930\u0924",en:"COEP main building",bearing:60,r:75,h:38,note:"The College of Engineering, Pune, founded in 1854. Its Victorian Gothic main building is of grey basalt, with a tower in the corner between its wings."},{land:"Sangam Bridge",mr:"\u0938\u0902\u0917\u092E \u092A\u0942\u0932",en:"Sangam Bridge",bearing:200,r:115,h:32,note:"The old stone bridge near the confluence (sangam) of the Mula and the Mutha. The railway\u2019s girder bridge runs beside it."},{land:"District Court",mr:"\u091C\u093F\u0932\u094D\u0939\u093E \u0935 \u0938\u0924\u094D\u0930 \u0928\u094D\u092F\u093E\u092F\u093E\u0932\u092F",en:"District and Sessions Court",bearing:340,r:95,h:42,note:"Pune\u2019s District and Sessions Court at Shivajinagar, its stone walls famously grown over with creeper."},{land:"COEP Boat Club",mr:"\u0938\u0940\u0913\u0908\u092A\u0940 \u092C\u094B\u091F \u0915\u094D\u0932\u092C",en:"COEP Boat Club",bearing:45,r:75,h:28,note:"The college\u2019s rowing club on the river, home of its annual regatta."},{land:"Shivajinagar station",mr:"\u0936\u093F\u0935\u093E\u091C\u0940\u0928\u0917\u0930 \u0930\u0947\u0932\u094D\u0935\u0947 \u0938\u094D\u0925\u093E\u0928\u0915",en:"Shivajinagar station",bearing:250,r:120,h:45,note:"A station on the Mumbai\u2013Pune main line, where the suburban trains between Pune and Lonavala stop."}],landView:{"COEP main building":"coep","District Court":"court","Sangam Bridge":"sangam","COEP Boat Club":"boatclub","Shivajinagar station":"station"}},east:{dir:"east/",mr:"\u092A\u0941\u0923\u0947 \u0938\u094D\u091F\u0947\u0936\u0928, \u0938\u0938\u0942\u0928 \u0935 \u0932\u093E\u0932 \u0926\u0947\u090A\u0933",en:"Pune Station, Sassoon and Lal Deool",coord:"18.5240\xB0 N, 73.8740\xB0 E",blurb:"Pune Junction with its yards and suburban trains, Sassoon Hospital\u2019s Gothic stone building and clock tower, the red-brick Ohel David Synagogue (Lal Deool), the Aqua Line metro",start:"station",parts:[{file:"wada_ground.glb.txt",mb:1.7},{file:"wada_city.glb.txt",mb:1.6},{file:"wada_grounds.glb.txt",mb:.2},{file:"wada_life.glb.txt",mb:2.2},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.6,metro:!0},{file:"wada_market.glb.txt",mb:.2},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:3.1},{file:"wada_railway.glb.txt",mb:2.7}],views:[{id:"station",cam:"Cam_PuneStation",label:"Pune Junction"},{id:"platform",cam:"Cam_RailPlatform",label:"Platforms"},{id:"sassoon",cam:"Cam_Sassoon",label:"Sassoon Hospital"},{id:"sassoon-tower",cam:"Cam_SassoonTower",label:"Sassoon clock tower"},{id:"laldeool",cam:"Cam_LalDeool",label:"Lal Deool"},{id:"councilhall",cam:"Cam_CouncilHall",label:"Council Hall"},{id:"councilgate",cam:"Cam_CouncilGate",label:"Council Hall gate"},{id:"metro",cam:"Cam_Metro",label:"Pune Railway Station metro"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Pune Junction",mr:"\u092A\u0941\u0923\u0947 \u091C\u0902\u0915\u094D\u0936\u0928",en:"Pune Junction",bearing:180,r:120,h:45,note:"Pune\u2019s main railway station and junction: long white-and-red buildings beside the platforms, suburban trains to Lonavala and express trains across India."},{land:"Sassoon Hospital",mr:"\u0938\u0938\u0942\u0928 \u0930\u0941\u0917\u094D\u0923\u093E\u0932\u092F",en:"Sassoon Hospital",bearing:70,r:90,h:40,note:"The city\u2019s great public hospital, begun in the 1860s with a gift from David Sassoon: grey stone, long arcaded verandahs and a clock tower."},{land:"Ohel David Synagogue",mr:"\u0932\u093E\u0932 \u0926\u0947\u090A\u0933",en:"Ohel David Synagogue (Lal Deool)",bearing:200,r:70,h:32,note:"Called Lal Deool, the Red Temple, for its red brick: the synagogue built by David Sassoon in the 1860s, with its tall tower."},{land:"Council Hall",mr:"\u0915\u094C\u0928\u094D\u0938\u093F\u0932 \u0939\u0949\u0932",en:"Council Hall",bearing:200,r:90,h:38,note:"Built in the 1870s for the Bombay Legislative Council, which met in Poona during the monsoon; today the office of the Divisional Commissioner."},{land:"Pune Railway Station metro",mr:"\u092A\u0941\u0923\u0947 \u0930\u0947\u0932\u094D\u0935\u0947 \u0938\u094D\u091F\u0947\u0936\u0928 \u092E\u0947\u091F\u094D\u0930\u094B",en:"Pune Railway Station metro",bearing:330,r:110,h:45,note:"The Aqua Line\u2019s elevated station beside the railway yards."}],landView:{"Pune Junction":"station","Sassoon Hospital":"sassoon","Ohel David Synagogue":"laldeool","Pune Railway Station metro":"metro","Council Hall":"councilhall"}},camp:{dir:"camp/",mr:"\u0915\u0945\u092E\u094D\u092A: \u0938\u0947\u0902\u091F \u092E\u0947\u0930\u0940 \u091A\u0930\u094D\u091A \u0935 \u092E\u0939\u093E\u0924\u094D\u092E\u093E \u0917\u093E\u0902\u0927\u0940 \u0930\u0938\u094D\u0924\u093E",en:"Camp: St. Mary\u2019s Church and MG Road",coord:"18.5155\xB0 N, 73.8853\xB0 E",blurb:"The Cantonment: St. Mary\u2019s Church, the shops of MG Road and East Street, and the National War Memorial of the Southern Command",start:"stmarys",parts:[{file:"wada_ground.glb.txt",mb:1.4},{file:"wada_city.glb.txt",mb:4.5},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.7},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.4}],views:[{id:"stmarys",cam:"Cam_StMarys",label:"St. Mary\u2019s Church"},{id:"mgroad",cam:"Cam_MGRoad",label:"MG Road"},{id:"warmemorial",cam:"Cam_WarMemorial",label:"War Memorial"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"St. Mary's Church",mr:"\u0938\u0947\u0902\u091F \u092E\u0947\u0930\u0940 \u091A\u0930\u094D\u091A",en:"St. Mary\u2019s Church",bearing:200,r:70,h:32,note:"Founded in 1825 for the garrison, the oldest church of the Deccan, its \u201Cmother church\u201D, modelled on St Martin-in-the-Fields in London."},{land:"MG Road",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u0917\u093E\u0902\u0927\u0940 \u0930\u0938\u094D\u0924\u093E",en:"MG Road (Main Street)",bearing:120,r:70,h:35,note:"Camp\u2019s Main Street: old shopfronts, bakeries, caf\xE9s and the evening crowds of the Cantonment."},{land:"National War Memorial",mr:"\u0930\u093E\u0937\u094D\u091F\u094D\u0930\u0940\u092F \u092F\u0941\u0926\u094D\u0927 \u0938\u094D\u092E\u093E\u0930\u0915",en:"National War Memorial, Southern Command",bearing:160,r:70,h:30,note:"Dedicated to the soldiers who fell after Independence, and paid for by the contributions of Pune\u2019s citizens."}],landView:{"St. Mary's Church":"stmarys","MG Road":"mgroad","National War Memorial":"warmemorial"}},bund:{dir:"bund/",mr:"\u092C\u0902\u0921 \u0917\u093E\u0930\u094D\u0921\u0928 \u0935 \u092B\u093F\u091F\u094D\u091D\u0917\u0947\u0930\u093E\u0932\u094D\u0921 \u092A\u0942\u0932",en:"Bund Garden and Fitzgerald Bridge",coord:"18.5418\xB0 N, 73.8860\xB0 E",blurb:"The Mula-Mutha at Bund Garden: the old stone Fitzgerald Bridge of 1867, the riverside garden, the Aqua Line\u2019s Bund Garden metro and Koregaon Park",start:"fitzgerald",parts:[{file:"wada_ground.glb.txt",mb:1.1},{file:"wada_city.glb.txt",mb:2.5},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:6.5},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1.1,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.2}],views:[{id:"fitzgerald",cam:"Cam_Fitzgerald",label:"Fitzgerald Bridge"},{id:"fitzgerald-deck",cam:"Cam_FitzgeraldDeck",label:"On the old bridge"},{id:"bundgarden",cam:"Cam_BundGarden",label:"Bund Garden"},{id:"metro",cam:"Cam_Metro",label:"Bund Garden metro"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Fitzgerald Bridge",mr:"\u092B\u093F\u091F\u094D\u091D\u0917\u0947\u0930\u093E\u0932\u094D\u0921 \u092A\u0942\u0932",en:"Fitzgerald Bridge",bearing:250,r:110,h:35,note:"Built of basalt in 1867, its arches carried the road across the Mula-Mutha for a century and a half; today it is a bridge for walkers beside the new road bridges."},{land:"Bund Garden",mr:"\u092C\u0902\u0921 \u0917\u093E\u0930\u094D\u0921\u0928",en:"Bund Garden (Mahatma Gandhi Udyan)",bearing:160,r:80,h:32,note:"The riverside garden named after the bund, the weir across the river, where Pune\u2019s families come out in the evening."}],landView:{"Fitzgerald Bridge":"fitzgerald","Bund Garden":"bundgarden"}},agakhan:{dir:"agakhan/",mr:"\u0906\u0917\u093E \u0916\u093E\u0928 \u092A\u0945\u0932\u0947\u0938",en:"Aga Khan Palace",coord:"18.5523\xB0 N, 73.9015\xB0 E",blurb:"The palace of Sultan Muhammed Shah Aga Khan III, where Mahatma Gandhi, Kasturba Gandhi and Mahadev Desai were interned, with its lawns and the samadhis",start:"agakhan",parts:[{file:"wada_ground.glb.txt",mb:1.1},{file:"wada_city.glb.txt",mb:2.2},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.4},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.5,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.8}],views:[{id:"agakhan",cam:"Cam_AgaKhan",label:"Aga Khan Palace"},{id:"agakhan-side",cam:"Cam_AgaKhanSide",label:"The arcades"},{id:"samadhi",cam:"Cam_Samadhi",label:"The samadhis"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Aga Khan Palace",mr:"\u0906\u0917\u093E \u0916\u093E\u0928 \u092A\u0945\u0932\u0947\u0938",en:"Aga Khan Palace",bearing:70,r:95,h:40,note:"Built in 1892 by Sultan Muhammed Shah Aga Khan III; Mahatma Gandhi, Kasturba Gandhi and Mahadev Desai were interned here in 1942\u201344, and it is now a memorial to Gandhi."},{land:"Kasturba Gandhi Samadhi",mr:"\u0915\u0938\u094D\u0924\u0941\u0930\u092C\u093E \u0917\u093E\u0902\u0927\u0940 \u0938\u092E\u093E\u0927\u0940",en:"The samadhis of Kasturba Gandhi and Mahadev Desai",bearing:120,r:35,h:16,note:"Kasturba Gandhi and Mahadev Desai died here during the internment; their samadhis stand in the garden, beside a memorial holding some of Mahatma Gandhi\u2019s ashes."}],landView:{"Aga Khan Palace":"agakhan","Kasturba Gandhi Samadhi":"samadhi"}},wanowrie:{dir:"wanowrie/",mr:"\u0936\u093F\u0902\u0926\u0947 \u091B\u0924\u094D\u0930\u0940, \u0935\u093E\u0928\u0935\u0921\u0940",en:"Shinde Chhatri, Wanowrie",coord:"18.4916\xB0 N, 73.8972\xB0 E",blurb:"The memorial of Mahadji Shinde: the carved sandstone hall with its coloured glass and the Shiva temple with its spire of gilt finials, in the lanes of Wanowrie",start:"shinde",parts:[{file:"wada_ground.glb.txt",mb:.9},{file:"wada_city.glb.txt",mb:2.4},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.3},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.7}],views:[{id:"shinde",cam:"Cam_ShindeChhatri",label:"Shinde Chhatri"},{id:"shikhara",cam:"Cam_ShindeShikhara",label:"The temple\u2019s spire"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Shinde Chhatri",mr:"\u0936\u093F\u0902\u0926\u0947 \u091B\u0924\u094D\u0930\u0940",en:"Shinde Chhatri",bearing:30,r:70,h:32,note:"The memorial of Mahadji Shinde, the great Maratha general, who was cremated here in 1794: the Shiva temple he built, and the hall of carved sandstone added by his descendants."}],landView:{"Shinde Chhatri":"shinde"}},empress:{dir:"empress/",mr:"\u090F\u092E\u094D\u092A\u094D\u0930\u0947\u0938 \u0917\u093E\u0930\u094D\u0921\u0928 \u0935 \u0930\u0947\u0938\u0915\u094B\u0930\u094D\u0938",en:"Empress Garden and the Race Course",coord:"18.5125\xB0 N, 73.8963\xB0 E",blurb:"The Empress Botanical Garden\u2019s old trees and avenues, and the Pune Race Course of the Royal Western India Turf Club with its colonial grandstand",start:"empress",parts:[{file:"wada_ground.glb.txt",mb:.8},{file:"wada_city.glb.txt",mb:2.2},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.3},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:2.7},{file:"wada_railway.glb.txt",mb:.2}],views:[{id:"empress",cam:"Cam_Empress",label:"Empress Garden"},{id:"racecourse",cam:"Cam_RaceCourse",label:"The home straight"},{id:"grandstand",cam:"Cam_Grandstand",label:"The grandstand"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Empress Garden",mr:"\u090F\u092E\u094D\u092A\u094D\u0930\u0947\u0938 \u0917\u093E\u0930\u094D\u0921\u0928",en:"Empress Botanical Garden",bearing:200,r:260,h:120,note:"A botanical garden laid out in the 1830s and named after Queen Victoria, Empress of India: avenues under huge old trees, bamboo groves and lawns."},{land:"Pune Race Course",mr:"\u092A\u0941\u0923\u0947 \u0930\u0947\u0938\u0915\u094B\u0930\u094D\u0938",en:"Pune Race Course",bearing:220,r:420,h:180,note:"The race course of the Royal Western India Turf Club, where the monsoon racing season has been held since the 1830s; its colonial grandstand looks over the members\u2019 lawn."}],landView:{"Empress Garden":"empress","Pune Race Course":"racecourse"}},university:{dir:"university/",mr:"\u091A\u0924\u0941\u0903\u0936\u0943\u0902\u0917\u0940 \u0935 \u092A\u0941\u0923\u0947 \u0935\u093F\u0926\u094D\u092F\u093E\u092A\u0940\u0920",en:"Chaturshringi and Pune University",coord:"18.5465\xB0 N, 73.8273\xB0 E",blurb:"Chaturshringi temple on its hill above Senapati Bapat Road \u2014 the red gate, the long stairway and the painted spire \u2014 and Savitribai Phule Pune University\u2019s Main Building, the old Government House with its tall tower",start:"chaturshringi",parts:[{file:"wada_ground.glb.txt",mb:1.9},{file:"wada_city.glb.txt",mb:2.4},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.6},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1.2,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:4.3}],views:[{id:"chaturshringi",cam:"Cam_Chaturshringi",label:"Chaturshringi gate"},{id:"ct-stairs",cam:"Cam_ChaturshringiStairs",label:"The temple stairs"},{id:"ct-temple",cam:"Cam_ChaturshringiTemple",label:"Chaturshringi Mandir"},{id:"university",cam:"Cam_University",label:"University Main Building"},{id:"uni-tower",cam:"Cam_UniversityTower",label:"The tower"},{id:"uni-porch",cam:"Cam_UniversityPorch",label:"The east porch"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Chaturshringi Temple",mr:"\u091A\u0924\u0941\u0903\u0936\u0943\u0902\u0917\u0940 \u092E\u0902\u0926\u093F\u0930",en:"Chaturshringi Temple",bearing:80,r:260,h:150,note:"The temple of the goddess Chaturshringi on the slope of a hill of four peaks: from the red gate on Senapati Bapat Road more than two hundred steps climb to her shrine. The story goes that the merchant Durlabhsheth Pitambardas Mahajan built it after the goddess appeared to him in a dream; its Navratri fair fills the road every autumn."},{land:"Pune University",mr:"\u0938\u093E\u0935\u093F\u0924\u094D\u0930\u0940\u092C\u093E\u0908 \u092B\u0941\u0932\u0947 \u092A\u0941\u0923\u0947 \u0935\u093F\u0926\u094D\u092F\u093E\u092A\u0940\u0920",en:"Savitribai Phule Pune University",bearing:280,r:230,h:110,note:"The Main Building was built between 1864 and 1871 as Government House, the monsoon residence of the Governor of Bombay: an Italianate palace of dark basalt with a tall tower. Since 1949 it has housed the University of Pune, renamed after Savitribai Phule in 2014."}],landView:{"Chaturshringi Temple":"chaturshringi","Pune University":"university"}},kalyani:{dir:"kalyani/",mr:"\u0915\u0932\u094D\u092F\u093E\u0923\u0940 \u0928\u0917\u0930",en:"Kalyani Nagar: Cerebrum IT Park, DMart and Cybage",coord:"18.5470\xB0 N, 73.9080\xB0 E",blurb:"Kalyani Nagar\u2019s glass office blocks of Cerebrum IT Park, the DMart store and its busy forecourt, the Cybage towers with their fountain, and every shop, caf\xE9 and clinic signed with its real name",start:"dmart",parts:[{file:"wada_ground.glb.txt",mb:2.3},{file:"wada_city.glb.txt",mb:1.9},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.3},{file:"wada_movers.glb.txt",mb:1.6,movers:!0},{file:"wada_metro.glb.txt",mb:1.2,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:8}],views:[{id:"dmart",cam:"Cam_DMart",label:"DMart"},{id:"cerebrum",cam:"Cam_Cerebrum",label:"Cerebrum IT Park"},{id:"b2",cam:"Cam_CerebrumB2",label:"Cerebrum B2"},{id:"b2-top",cam:"Cam_CerebrumB2Top",label:"B2 from above"},{id:"cybage",cam:"Cam_Cybage",label:"Cybage Towers"},{id:"cy-plaza",cam:"Cam_CybagePlaza",label:"Cybage fountain"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"DMart",mr:"\u0921\u0940-\u092E\u093E\u0930\u094D\u091F",en:"DMart, Kalyani Nagar",bearing:20,r:160,h:80,note:"The supermarket on the lower floors of Cerebrum IT Park\u2019s eastern block on Central Avenue, with shoppers\u2019 cars and scooters packed in front."},{land:"Cerebrum IT Park",mr:"\u0938\u0947\u0930\u0947\u092C\u094D\u0930\u092E \u0906\u092F\u091F\u0940 \u092A\u093E\u0930\u094D\u0915",en:"Cerebrum IT Park",bearing:10,r:230,h:110,note:"An IT park of glass office blocks on Central Avenue in Kalyani Nagar, among the offices that have made this side of Pune a hub of software firms."},{land:"Cybage",mr:"\u0938\u093E\u092F\u092C\u0947\u091C",en:"Cybage Towers",bearing:200,r:220,h:120,note:"Cybage Software\u2019s campus in Kalyani Nagar: two blue glass towers round a fountain, with a multi-level car park behind."}],landView:{DMart:"dmart","Cerebrum IT Park":"cerebrum",Cybage:"cybage"}},ftii:{dir:"ftii/",mr:"\u090F\u092B\u091F\u0940\u0906\u092F\u0906\u092F \u0935 \u0935\u0947\u0924\u093E\u0933 \u091F\u0947\u0915\u0921\u0940",en:"FTII and Vetal Hill",coord:"18.5195\xB0 N, 73.8210\xB0 E",blurb:"The Film and Television Institute of India in the old Prabhat Film Company studios on Law College Road \u2014 Studio 1 with its tutari emblem, the Main Theatre and the Wisdom Tree \u2014 and the scrub forest of Vetal Tekdi with its shrine and flooded quarry",start:"ftii",parts:[{file:"wada_ground.glb.txt",mb:4.6},{file:"wada_city.glb.txt",mb:7},{file:"wada_grounds.glb.txt",mb:.6},{file:"wada_life.glb.txt",mb:.1},{file:"wada_movers.glb.txt",mb:1.5,movers:!0},{file:"wada_metro.glb.txt",mb:1,metro:!0},{file:"wada_market.glb.txt",mb:.2},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.3}],views:[{id:"ftii",cam:"Cam_FTII",label:"FTII gate"},{id:"prabhat",cam:"Cam_PrabhatStudio",label:"Prabhat Studio 1"},{id:"vetal",cam:"Cam_VetalHill",label:"Vetal Hill"},{id:"quarry",cam:"Cam_VetalQuarry",label:"The quarry"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"FTII",mr:"\u090F\u092B\u091F\u0940\u0906\u092F\u0906\u092F",en:"Film and Television Institute of India",bearing:160,r:220,h:110,note:"India\u2019s national film school, set up in 1960 in the studios of the Prabhat Film Company, which V. Shantaram and his partners had moved to Pune in 1933. Students still shoot on Prabhat\u2019s old stage and gather under the Wisdom Tree."},{land:"Vetal Hill",mr:"\u0935\u0947\u0924\u093E\u0933 \u091F\u0947\u0915\u0921\u0940",en:"Vetal Tekdi",bearing:120,r:420,h:220,note:"The highest hill within the city, a green island of scrub forest where Pune walks at dawn. On the top stands the little shrine of Vetal Baba; on its flank, a flooded quarry under walls of basalt."}],landView:{FTII:"ftii","Vetal Hill":"vetal"}},pashan:{dir:"pashan/",mr:"\u092A\u093E\u0937\u093E\u0923 \u0924\u0932\u093E\u0935",en:"Pashan Lake",coord:"18.5340\xB0 N, 73.7850\xB0 E",blurb:"The reservoir on the Ram Nadi with its two wooded islands, rowing boats drawn up at the lakeside park, and the egrets, herons and ducks that make it a favourite place for watching birds",start:"pashan",parts:[{file:"wada_ground.glb.txt",mb:1.6},{file:"wada_city.glb.txt",mb:3.3},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:1},{file:"wada_movers.glb.txt",mb:1.5,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.4}],views:[{id:"pashan",cam:"Cam_PashanLake",label:"Pashan Lake"},{id:"birds",cam:"Cam_PashanBirds",label:"The birding point"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Pashan Lake",mr:"\u092A\u093E\u0937\u093E\u0923 \u0924\u0932\u093E\u0935",en:"Pashan Lake",bearing:200,r:380,h:170,note:"A reservoir made by damming the Ram Nadi in British times. Its islands and reedy shallows draw egrets, herons and ducks all year, and migrant birds in winter."}],landView:{"Pashan Lake":"pashan"}},phule:{dir:"phule/",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u092B\u0941\u0932\u0947 \u0935\u093E\u0921\u093E, \u0917\u0902\u091C \u092A\u0947\u0920",en:"Phule Wada, Ganj Peth",coord:"18.5065\xB0 N, 73.8633\xB0 E",blurb:"The house of Jyotirao and Savitribai Phule with its walled garden, well and Jyotiba Phule\u2019s samadhi, in the lanes of Ganj Peth",start:"phulewada",parts:[{file:"wada_ground.glb.txt",mb:1.2},{file:"wada_city.glb.txt",mb:3.3},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.5},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.2}],views:[{id:"phulewada",cam:"Cam_PhuleWada",label:"Mahatma Phule Wada"},{id:"samadhi",cam:"Cam_PhuleSamadhi",label:"Phule samadhi"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Mahatma Phule Wada",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u092B\u0941\u0932\u0947 \u0935\u093E\u0921\u093E",en:"Mahatma Phule Wada",bearing:120,r:45,h:24,note:"The house where Jyotirao and Savitribai Phule lived and worked, pioneers of schools for girls and of social reform; now a national memorial, with Jyotiba Phule\u2019s samadhi in its garden."}],landView:{"Mahatma Phule Wada":"phulewada"}}},zn=(()=>{let i=null;try{i=new URLSearchParams(location.search).get("place")}catch{}let e=/(?:^|[#&])place=([\w-]+)/.exec(location.hash);return e&&e[1]||i||"oldcity"})(),Cn=zr[zn]||zr.oldcity,ts=Cn.dir,To=Cn.parts||[{file:"wada_ground.glb.txt",mb:2.3},{file:"wada_city.glb.txt",mb:3},{file:"wada_grounds.glb.txt",mb:3.9},{file:"wada_life.glb.txt",mb:1.5},{file:"wada_statues.glb.txt",mb:1.2},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1,metro:!0},{file:"wada_market.glb.txt",mb:.8},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:5.4}],Hr=Cn.views||[{id:"gate",cam:"Cam_Gate",label:"Dilli Darwaza"},{id:"street",cam:"Cam_Street",label:"Market street"},{id:"lane",cam:"Cam_Lane",label:"Old-city lane"},{id:"fort",cam:"Cam_Fort",label:"Fort"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"},{id:"river",cam:"Cam_River",label:"Mutha river"},{id:"lalmahal",cam:"Cam_LalMahal",label:"Lal Mahal"},{id:"lalmahal-street",cam:"Cam_StreetView_LalMahal",label:"Lal Mahal corner"},{id:"dagdusheth",cam:"Cam_Dagdusheth",label:"Dagdusheth Ganpati"},{id:"streetview",cam:"Cam_StreetView",label:"Junction (Street View)"},{id:"metro",cam:"Cam_Metro",label:"PMC Bhavan metro"},{id:"kasba",cam:"Cam_KasbaPeth",label:"Kasba Peth metro"},{id:"tulshibaug",cam:"Cam_Tulshibaug",label:"Tulshibaug Ram Mandir"},{id:"market",cam:"Cam_Market",label:"Tulshibaug market"},{id:"vishrambaug",cam:"Cam_Vishrambaug",label:"Vishrambaug Wada"},{id:"nana",cam:"Cam_NanaWada",label:"Nana Wada"},{id:"bhide",cam:"Cam_BhideWada",label:"Bhide Wada"},{id:"omkareshwar",cam:"Cam_Omkareshwar",label:"Omkareshwar Mandir"},{id:"laxmi",cam:"Cam_LaxmiRoad",label:"Laxmi Road"},{id:"kasbaganpati",cam:"Cam_KasbaGanpati",label:"Kasba Ganpati"},{id:"mandai",cam:"Cam_Mandai",label:"Mahatma Phule Mandai"},{id:"balgandharva",cam:"Cam_Balgandharva",label:"Balgandharva Rangmandir"},{id:"kesari",cam:"Cam_KesariWada",label:"Kesari Wada"},{id:"kesari-street",cam:"Cam_KesariWadaStreet",label:"Kesari Wada gate"},{id:"kelkar",cam:"Cam_KelkarMuseum",label:"Kelkar Museum"}],tr={day:{top:5211849,bg:11124694,sun:16773858,sunI:3,el:55,az:215,sky:12900334,ground:9075298,hemiI:1.3,night:0,lamp:0,pool:0,exp:1,fog:[700,2800],flood:0,lit:1},evening:{top:3886982,bg:13998702,sun:16749904,sunI:2.2,el:8,az:290,sky:15116934,ground:4864560,hemiI:.6,night:.4,lamp:2.5,pool:90,exp:1.1,fog:[500,2200],flood:.35,lit:.6},night:{top:66056,bg:197899,sun:9349375,sunI:.16,el:45,az:150,sky:1120812,ground:328966,hemiI:.2,night:1,lamp:8,pool:210,exp:1.25,fog:[45,380],flood:1,lit:.85}},Pn=matchMedia("(prefers-reduced-motion: reduce)").matches,kn=matchMedia("(pointer: coarse)").matches,pe=i=>document.getElementById(i),Ut=pe("scene"),ln;try{ln=new Mr({canvas:Ut,antialias:!0,powerPreference:"high-performance"})}catch(i){throw pe("status").textContent="This browser cannot show 3D graphics (WebGL is off or unsupported). Try a recent Chrome, Edge, Firefox or Safari.",i}ln.setPixelRatio(Math.min(window.devicePixelRatio||1,kn?1.5:2));ln.outputColorSpace=ut;ln.toneMapping=gc;ln.shadowMap.enabled=!0;ln.shadowMap.type=mc;ln.shadowMap.autoUpdate=!1;var Uf=1,dh=0,gt=new zs;gt.fog=new Wa(11124694,700,2800);var Me=new Ct(55,1,.1,6e3);Me.position.set(300,250,300);var nt=new fo(Me,Ut);nt.enableDamping=!0;nt.dampingFactor=.06;nt.maxPolarAngle=Math.PI*.66;nt.minDistance=2;nt.maxDistance=2600;nt.zoomSpeed=2.4;nt.zoomToCursor=!0;Ut.addEventListener("wheel",i=>{if(tt!=="orbit"||i.deltaY>=0||Me.position.distanceTo(nt.target)>12)return;let t=new C;Me.getWorldDirection(t);let n=Math.min(25,3+Math.abs(i.deltaY)*.04);nt.target.addScaledVector(t,n),Me.position.addScaledVector(t,n*.6)},{passive:!0});var wo=new eo(12900334,7035461,1.1);gt.add(wo);var un=new Xs(16777215,3);un.castShadow=!0;un.shadow.mapSize.set(kn?1024:2048,kn?1024:2048);un.shadow.camera.near=1;un.shadow.camera.far=1600;un.shadow.bias=-5e-4;gt.add(un,un.target);var js={top:{value:new Te(5211849)},horizon:{value:new Te(11124694)},sunDir:{value:new C(0,1,0)},sunCol:{value:new Te(16773858)},moonDir:{value:new C(-.4,.55,-.73).normalize()},night:{value:0}},Ho=new je(new qn(5e3,48,24),new Fn({uniforms:js,side:zt,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vDir; void main() { vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",fragmentShader:`
    uniform vec3 top, horizon, sunDir, sunCol, moonDir; uniform float night; varying vec3 vDir;
    float hash(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
    void main() {
      vec3 d = normalize(vDir);
      float h = d.y;
      vec3 col = mix(horizon, top, smoothstep(0.0, 0.55, h));
      float sd = max(dot(d, normalize(sunDir)), 0.0);
      col += sunCol * (pow(sd, 900.0) * 6.0 + pow(sd, 12.0) * 0.18) * (1.0 - night) * step(-0.02, h);
      if (night > 0.5) {
        vec3 q = floor(d * 420.0);
        float st = step(0.9975, hash(q)) * smoothstep(0.04, 0.3, h);
        col += vec3(0.85, 0.9, 1.0) * st * (0.6 + 0.4 * hash(q + 7.0));
        float md = dot(d, moonDir);
        col = mix(col, vec3(0.92, 0.92, 0.86), smoothstep(0.99955, 0.99975, md));
        col += vec3(0.25, 0.3, 0.42) * pow(max(md, 0.0), 60.0) * 0.6;
      }
      gl_FragColor = vec4(col, 1.0);
      #include <colorspace_fragment>
    }`}));Ho.renderOrder=-1;Ho.frustumCulled=!1;gt.add(Ho);var Of=8,fh=[];for(let i=0;i<Of;i++){let e=new Ni(16762510,0,32,2);gt.add(e),fh.push(e)}var en={uNight:{value:0},uFlood:{value:0},uLitCut:{value:1},uTime:{value:0}},Ff=`
#ifdef USE_INSTANCING
vec3 wp0 = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz;
#else
vec3 wp0 = (modelMatrix * vec4(transformed, 1.0)).xyz;
#endif
float ph = wp0.x * 0.37 + wp0.z * 0.29;
float gust = 0.35 + 0.65 * pow(0.5 + 0.5 * sin(uTime * 0.23 + wp0.x * 0.004 + wp0.z * 0.003), 3.0);`,wh=`
totalEmissiveRadiance += diffuseColor.rgb * vec3(1.0, 0.74, 0.46) * uFlood * 0.8 * clamp(1.2 - vWPos.y / 18.0, 0.25, 1.0)
  * (0.72 + 0.28 * sin(vWPos.x * 0.45) * sin(vWPos.z * 0.45));   // separate beams from the ground`,Sh=`
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }`;function ev(){let i=new et({vertexColors:!0,roughness:.88,flatShading:!0});return i.defines={USE_UV:""},i.customProgramCacheKey=()=>"facade",i.onBeforeCompile=e=>{e.uniforms.uNight=en.uNight,e.uniforms.uLitCut=en.uLitCut,e.fragmentShader=e.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;
uniform float uLitCut;
const float GF = 3.8;   // ground-floor height (m)
const float FH = 3.2;   // upper floor height (m)
${Sh}`).replace("#include <color_fragment>",`#include <color_fragment>
float shopFlag = vColor.a;
diffuseColor.a = 1.0;
float hgt = 1.0 - vUv.y;             // metres above the street (glTF flips V)
float along = vUv.x;                 // metres along the wall
float upper = step(GF, hgt);
float fz = fract((hgt - GF) / FH);
float fu = fract(along / 3.0);
float aa = clamp(1.6 - max(fwidth(along / 3.0), fwidth(hgt / FH)) * 4.0, 0.0, 1.0);   // fade tiny patterns
float winRaw = upper * step(0.28, fz) * step(fz, 0.80) * step(0.30, fu) * step(fu, 0.70);
float win = winRaw * aa;
float band = upper * step(fz, 0.07) * aa;
float gu = fract(along / 3.6);
float shut = shopFlag * step(0.15, hgt) * step(hgt, GF - 0.9) * step(0.06, gu) * step(gu, 0.94);
float ribs = fract(hgt * 9.0) * 0.25;
vec3 wallCol = diffuseColor.rgb * mix(1.0, 0.75, band);
wallCol *= mix(1.0, 0.82, (1.0 - clamp(hgt / 7.0, 0.0, 1.0)) * 0.7);
wallCol = mix(wallCol, mix(vec3(0.30, 0.31, 0.32), vec3(0.42, 0.43, 0.44), ribs), shut);
wallCol = mix(wallCol, vec3(0.035, 0.045, 0.055), win);
wallCol *= mix(1.0, 0.78, upper * (1.0 - aa));      // far away: windows blend into a darker wall
diffuseColor.rgb = wallCol;
float lit = winRaw * step(uLitCut, hash12(vec2(floor(along / 3.0), floor((hgt - GF) / FH)) + vColor.rg * 97.0));
float shopLit = shut * step(0.5, hash12(vec2(floor(along / 3.6), 7.0) + vColor.gb * 53.0));`).replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
roughnessFactor = mix(roughnessFactor, 0.25, win);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += (vec3(1.0, 0.72, 0.42) * lit * 1.5 + vec3(0.9, 0.55, 0.25) * shopLit * 0.6) * pow(uNight, 1.6);`)},i}function tv(){let i=new et({vertexColors:!0,roughness:.85,flatShading:!0});return i.customProgramCacheKey=()=>"wash",i.onBeforeCompile=e=>{e.uniforms.uFlood=en.uFlood,e.vertexShader=e.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),e.fragmentShader=e.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;`).replace("#include <color_fragment>",`#include <color_fragment>
float code = vColor.a;
diffuseColor.a = 1.0;
vec3 tint = code > 0.965 ? vec3(1.0, 0.74, 0.46) : (code > 0.895 ? vec3(0.80, 0.90, 1.0)
          : clamp(abs(mod(code / 0.9 * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0) * 1.3);
if (code < 0.895) diffuseColor.rgb *= mix(vec3(1.0), tint / max(max(tint.r, tint.g), max(tint.b, 0.001)), uFlood * 0.8);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
vec3 lit = code > 0.895 ? 0.06 + 0.38 * diffuseColor.rgb : diffuseColor.rgb * 0.85;   // white light: pale walls must not burn out
totalEmissiveRadiance += lit * tint * uFlood * clamp(1.25 - vWPos.y / 20.0, 0.3, 1.0)
  * (0.75 + 0.25 * sin(vWPos.x * 0.45) * sin(vWPos.z * 0.45));`)},i}function Fr(i,e,t=1,n=!0){let s=new et({vertexColors:!0,roughness:.9,flatShading:!0}),r=(Math.min(i,e)*.045/i).toFixed(4),o=(Math.min(i,e)*.045/e).toFixed(4);return s.customProgramCacheKey=()=>`masonry-${i}-${e}-${t}-${n}`,s.onBeforeCompile=a=>{a.uniforms.uFlood=en.uFlood,a.vertexShader=a.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),a.fragmentShader=a.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;${Sh}`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>${n?wh:""}`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;
vec3 fn = normalize(cross(dFdx(vWPos), dFdy(vWPos)));
float s = abs(fn.x) > abs(fn.z) ? vWPos.z : vWPos.x;
float t = abs(fn.y) > 0.8 ? vWPos.z : vWPos.y;
float row = floor(t / ${e.toFixed(3)});
float bx = s / ${i.toFixed(3)} + mod(row, 2.0) * 0.5;
float fx = fract(bx), fy = fract(t / ${e.toFixed(3)});
float aa = clamp(1.5 - max(fwidth(bx), fwidth(t / ${e.toFixed(3)})) * 3.0, 0.0, 1.0);
float joint = (1.0 - step(${r}, fx) * step(fx, 1.0 - ${r}) * step(${o}, fy) * step(fy, 1.0 - ${o})) * aa;
vec3 base = diffuseColor.rgb * ${t.toFixed(2)} * mix(0.7, 1.0, smoothstep(0.0, 2.8, vWPos.y));   // darker at the foot
float vert = 1.0 - step(0.8, abs(fn.y));                         // walls (1) or paving (0)
vec3 block = base * mix(1.0, mix(0.78, 1.22, hash12(vec2(floor(bx), row))), aa * mix(0.35, 1.0, vert));
diffuseColor.rgb = mix(block, base * 1.12, joint * mix(0.4, 1.0, vert));
float lane = hash12(vec2(floor(s * 1.4), 11.0));                 // rain streaks running down from the top
float streak = step(0.7, lane) * (0.55 + 0.45 * sin(t * 0.35 + lane * 40.0)) * vert;
float blotch = hash12(floor(vec2(s, t) * 0.35));
diffuseColor.rgb *= (1.0 - 0.16 * streak) * mix(0.9, 1.06, blotch);`)},s}function lf(i,e,t){let n=new et({vertexColors:!0,roughness:e,metalness:t,flatShading:!0});return t>.5&&(n.envMap=Qs,n.envMapIntensity=.5),n.customProgramCacheKey=()=>"surface-"+i,n.onBeforeCompile=s=>{s.uniforms.uFlood=en.uFlood,s.vertexShader=s.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`);let r=i==="wood"?`
vec3 fn = normalize(cross(dFdx(vWPos), dFdy(vWPos)));
float s = abs(fn.x) > abs(fn.z) ? vWPos.z : vWPos.x;
float t = vWPos.y;
float plank = floor(s / 0.28);
float g = fract(s / 0.28);
float joint = 1.0 - smoothstep(0.0, 0.04, g) * smoothstep(1.0, 0.96, g);
float grain = 0.5 + 0.5 * sin(s * 150.0 + sin(t * 2.7 + plank * 1.7) * 3.0 + plank * 9.0);
diffuseColor.rgb *= mix(0.86, 1.12, grain) * mix(0.9, 1.08, hash12(vec2(plank, 3.0))) * (1.0 - 0.55 * joint);`:`
float rust = smoothstep(0.45, 0.9, hash12(floor(vWPos.xz * 7.0 + vWPos.y * 5.0)));
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.28, 0.11, 0.05), rust * 0.75);
roughnessFactor = mix(roughnessFactor, 0.95, rust);`;s.fragmentShader=s.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;${Sh}`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>${r}`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>${wh}`)},n}var Vo=new et({color:16769720,emissive:16762510,emissiveIntensity:0,side:_t}),qr=new et({vertexColors:!0,roughness:.5,emissive:16764826,emissiveIntensity:0,flatShading:!0});qr.side=_t;qr.customProgramCacheKey=()=>"glow";qr.onBeforeCompile=i=>{i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
vec2 pp = vec2(vWPos.x + vWPos.z, vWPos.y) * 3.2;
float perf = smoothstep(0.34, 0.26, length(fract(pp) - 0.5)) * clamp(1.4 - fwidth(pp.x) * 2.5, 0.0, 1.0);
totalEmissiveRadiance *= mix(vec3(1.0), diffuseColor.rgb * 1.5, 0.55) * (0.45 + 0.75 * perf);`)};var Go=new et({color:5900293,emissive:16718344,emissiveIntensity:.4,side:_t}),Qs=new ks(ln).fromScene(new po,.04).texture;function Eh(i,e,t){let n=new et({vertexColors:!0,metalness:i,roughness:e,envMap:Qs,envMapIntensity:t});return n.customProgramCacheKey=()=>"shiny",n.onBeforeCompile=s=>{s.uniforms.uFlood=en.uFlood,s.fragmentShader=s.fragmentShader.replace("#include <common>",`#include <common>
uniform float uFlood;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += diffuseColor.rgb * uFlood * 0.55;`)},n}var nv=Eh(.85,.38,.9),iv=Eh(1,.22,1.2),sv=Eh(1,.04,1.4),Th=new et({vertexColors:!0,roughness:.85,side:_t,flatShading:!0});Th.customProgramCacheKey=()=>"cloth";Th.onBeforeCompile=i=>{i.uniforms.uTime=en.uTime,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <project_vertex>",`#include <project_vertex>
#ifdef USE_COLOR_ALPHA
float wgt = 1.0 - color.a;
#else
float wgt = 0.0;
#endif
${Ff}
vec3 off = vec3(sin(uTime * 2.3 + ph) * 0.17, 0.0, sin(uTime * 1.9 + ph * 1.4) * 0.12) * wgt * (0.4 + gust);
off.y = abs(off.x) * 0.3;
mvPosition.xyz += (viewMatrix * vec4(off, 0.0)).xyz;
gl_Position = projectionMatrix * mvPosition;`),i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};var Wo=new et({vertexColors:!0,roughness:.9,flatShading:!0});Wo.customProgramCacheKey=()=>"tree";Wo.onBeforeCompile=i=>{i.uniforms.uTime=en.uTime,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <project_vertex>",`#include <project_vertex>
${Ff}
float wgt = pow(clamp((wp0.y - 1.5) / 9.0, 0.0, 1.0), 1.5);
float sway = (sin(uTime * 1.1 + ph) * 0.13 + sin(uTime * 2.9 + ph * 2.3) * 0.05) * (0.3 + gust * 1.2) + gust * 0.12;
vec3 off = vec3(0.8, 0.0, 0.45) * sway * wgt;
mvPosition.xyz += (viewMatrix * vec4(off, 0.0)).xyz;
gl_Position = projectionMatrix * mvPosition;`),i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};var Ah=new et({vertexColors:!0,roughness:.8,flatShading:!0,side:_t});Ah.customProgramCacheKey=()=>"lit";Ah.onBeforeCompile=i=>{i.uniforms.uNight=en.uNight,i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += diffuseColor.rgb * vec3(1.2, 0.95, 0.65) * pow(uNight, 1.4) * 0.32;`)};var Rh=new et({vertexColors:!0,roughness:.6,flatShading:!0});Rh.customProgramCacheKey=()=>"nightlight";Rh.onBeforeCompile=i=>{i.uniforms.uNight=en.uNight,i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;
vec3 lightCol = diffuseColor.rgb;
diffuseColor.rgb *= mix(0.25, 1.0, uNight);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += lightCol * 0.85 * pow(uNight, 1.2);`)};var Ch=new et({vertexColors:!0,metalness:.9,roughness:.22,envMap:Qs,envMapIntensity:1.2,flatShading:!0});Ch.customProgramCacheKey=()=>"steel";Ch.onBeforeCompile=i=>{i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};var Ph=new et({vertexColors:!0,metalness:.45,roughness:.3,envMap:Qs,envMapIntensity:.8,flatShading:!0});Ph.customProgramCacheKey=()=>"train";Ph.onBeforeCompile=i=>{i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};function rv(i,e){let t=new et({vertexColors:!0,roughness:.7,flatShading:!0});return t.customProgramCacheKey=()=>"walker",t.onBeforeCompile=n=>{n.uniforms.uHip={value:i},n.uniforms.uShoulder={value:e},n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
attribute float aStep;
uniform float uHip;
uniform float uShoulder;
vec3 swingAbout(vec3 p, float pivot, float a) {
  float c = cos(a), s = sin(a), ry = p.y - pivot;
  return vec3(p.x * c - ry * s, p.x * s + ry * c + pivot, p.z);
}`).replace("#include <begin_vertex>",`#include <begin_vertex>
#ifdef USE_COLOR_ALPHA
float limb = floor(color.a * 5.0 + 0.5);
#else
float limb = 5.0;
#endif
float sw = sin(aStep);
if (limb > 3.5 && limb < 4.5) transformed = swingAbout(transformed, uHip, sw * 0.42);
else if (limb > 2.5 && limb < 3.5) transformed = swingAbout(transformed, uHip, -sw * 0.42);
else if (limb > 1.5 && limb < 2.5) transformed = swingAbout(transformed, uShoulder, -sw * 0.30);
else if (limb > 0.5 && limb < 1.5) transformed = swingAbout(transformed, uShoulder, sw * 0.30);
transformed.y += abs(cos(aStep)) * 0.025;`),n.fragmentShader=n.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)},t}var av=/^(Landmark_Paint|Gate_(CarvedWood|Plaster|Roof|Wood|Iron)|Grounds_Statue)$/,ih={},sh=new Map,rh=new Map;function ov(i,e){let t=i.uuid+":"+e;if(!rh.has(t)){let n=i.clone();n.onBeforeCompile=i.onBeforeCompile,i.customProgramCacheKey&&(n.customProgramCacheKey=i.customProgramCacheKey),n.polygonOffset=!0,n.polygonOffsetFactor=-e,n.polygonOffsetUnits=-2*e,rh.set(t,n)}return rh.get(t)}function Bf(i,e){if(e.attributes.normal||i.flatShading)return i;if(!sh.has(i)){let t=i.clone();t.flatShading=!0,t.onBeforeCompile=i.onBeforeCompile;let n=i.customProgramCacheKey?i.customProgramCacheKey():"std";t.customProgramCacheKey=()=>n+"-flat",sh.set(i,t)}return sh.get(i)}function lv(){let i=new et({vertexColors:!0,roughness:.95,flatShading:!0,side:_t});return i.customProgramCacheKey=()=>"sleepers",i.onBeforeCompile=e=>{e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      {
        float k = vColor.a * 25.0;
        float w = max(fwidth(k), 1e-4);
        float f = fract(k);
        float on = clamp((0.1785 - abs(f - 0.1785)) / w + 0.5, 0.0, 1.0);
        on = mix(on, 0.357, smoothstep(0.2, 0.7, w));          // far off: the average, no shimmer
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.55, 0.535, 0.50), on);
      }
      diffuseColor.a = 1.0;`)},i}function cv(){let i=new et({vertexColors:!0,roughness:.8,flatShading:!0});return i.customProgramCacheKey=()=>"creeper",i.onBeforeCompile=e=>{e.vertexShader=e.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),e.fragmentShader=e.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
float h3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
float vn(vec3 p) {
  vec3 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(h3(i), h3(i + vec3(1.0, 0.0, 0.0)), f.x), mix(h3(i + vec3(0.0, 1.0, 0.0)), h3(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
             mix(mix(h3(i + vec3(0.0, 0.0, 1.0)), h3(i + vec3(1.0, 0.0, 1.0)), f.x), mix(h3(i + vec3(0.0, 1.0, 1.0)), h3(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}`).replace("#include <color_fragment>",`#include <color_fragment>
{
  vec3 q = vWPos * 6.5;
  float a = vn(q), b = vn(q * 2.7 + 7.3), c = vn(q * 0.45 - 3.1);
  float leaf = smoothstep(0.32, 0.78, a * 0.55 + b * 0.45);
  vec3 pat = mix(diffuseColor.rgb * 0.32, diffuseColor.rgb * vec3(1.35, 1.5, 1.05), leaf) * (0.75 + 0.5 * c);
  float far = clamp(length(fwidth(q)) * 0.9, 0.0, 1.0);          // far off: the average tone, no shimmer
  diffuseColor.rgb = mix(pat, diffuseColor.rgb * (0.82 + 0.25 * c), far);
}
diffuseColor.a = 1.0;`)},i}function Ao(i){if(ih[i])return ih[i];let e;if(i==="Statue_Bronze")e=nv;else if(i==="Statue_Gold")e=iv;else if(i==="Grounds_Mirror")e=sv;else if(i==="City_Facade")e=ev();else if(i==="Wada_Brick")e=Fr(.3,.1,1.3);else if(i==="Wada_Basalt")e=Fr(.9,.45,1.9);else if(i==="Wada_PaleStone")e=Fr(.75,.4,1.5);else if(i==="City_RoofTile")e=Fr(.3,.16,1,!1);else if(i==="Gate_Roof")e=Fr(.28,.15,1,!0);else if(i==="Gate_Wood"||i==="Gate_CarvedWood")e=lf("wood",.85,0);else if(i==="Gate_Iron")e=lf("iron",.45,.85);else if(i==="City_Lamp")e=Vo;else if(i==="City_TailLamp")e=Go;else if(i==="Metro_Glow")e=qr;else if(i==="Metro_Train")e=Ph;else if(i==="Market_Cloth")e=Th;else if(i==="Market_Shiny")e=Ch;else if(i==="Market_Lit")e=Ah;else if(i==="Market_GlowLight")e=Rh;else if(i==="Old_Wash")e=tv();else if(i==="Railway_Sleepers")e=lv();else if(i==="Old_Creeper")e=cv();else{let t={City_Water:.3,Grounds_Water:.25,Gate_Iron:.45,City_Metal:.5,Grounds_Metal:.45,Life_Paint:.55,City_Sign:.5,Metro_Metal:.4,Metro_Concrete:.8,Old_Glass:.12,Railway_Metal:.38,Railway_Glass:.1,Railway_Train:.42}[i]??.9,n={Gate_Iron:.9,City_Metal:.7,Grounds_Metal:.6,City_Water:.1,Metro_Metal:.65,Old_Glass:.6,Railway_Metal:.6,Railway_Glass:.6,Railway_Train:.2}[i]??0;e=new et({vertexColors:!0,roughness:t,metalness:n,flatShading:!0}),/^(Metro|Railway)_/.test(i)&&(e.side=_t),n>=.5&&(e.envMap=Qs,e.envMapIntensity=.6),/Water/.test(i)&&(e.color.setRGB(.4,.47,.38),e.roughness=.3,e.metalness=0,e.envMap=Qs,e.envMapIntensity=.14,e.side=_t);let s=av.test(i);e.customProgramCacheKey=()=>s?"plain-floodlit":"plain",e.onBeforeCompile=r=>{r.fragmentShader=r.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`),s&&(r.uniforms.uFlood=en.uFlood,r.vertexShader=r.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),r.fragmentShader=r.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>${wh}`))}}return ih[i]=e,e}var kf=new co,Ro=To.map(()=>0),cf=To.reduce((i,e)=>i+e.mb,0);function Co(){let i=Ro.reduce((e,t)=>e+t,0);pe("bar").style.width=`${Math.min(100,i/cf*100).toFixed(1)}%`,pe("status").textContent=`Loading the city\u2026 ${i.toFixed(1)} of ${cf.toFixed(1)} MB`}var zf={},So=null,Eo=null,Po={},Lh=[],ph=0,mh=[],Hf=[],hf=/^(Ground|City_Roads|City_Plinths|Gate_Steps|Gate_Block|Grounds_(Amphitheatre|Street|LalMahal|Dagdusheth|Fountains|Palace)|Market_RamMandir|Metro_Entrances|Railway_(Platforms|Station))/;async function hv(i,e){let t=await fetch(ts+i.file);if(!t.ok)throw new Error(i.file);let n=Number(t.headers.get("content-length"))||i.mb*1e6;if(!t.body||!t.body.getReader){let c=await t.text();return Ro[e]=i.mb,Co(),c}let s=t.body.getReader(),r=[],o=0;for(;;){let{done:c,value:h}=await s.read();if(c)break;r.push(h),o+=h.length,Ro[e]=Math.min(i.mb,o/n*i.mb),Co()}let a=new Uint8Array(o),l=0;for(let c of r)a.set(c,l),l+=c.length;return new TextDecoder().decode(a)}function Vf(i){let e=atob(i.trim()),t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return t.buffer}async function uf(i,e){let t;try{let s=Vf(await hv(i,e));t=await kf.parseAsync(s,"")}catch{throw new Error(i.file.replace(".glb.txt",""))}if(Ro[e]=i.mb,Co(),i.movers)return So=t.scene,t;if(i.props)return Eo=t.scene,t;let n=[];t.scene.traverse(s=>{if(s.isCamera&&(zf[s.name]=s),s.isMesh){let r=s.material?.name||"",o=s.geometry;o.attributes.color_1&&Ih(o.attributes.color)&&o.setAttribute("color",o.attributes.color_1),s.material=Bf(Ao(r),s.geometry),/^Grounds_Trees/.test(s.name+" "+(s.parent?.name||""))&&r==="Grounds_Paint"&&(s.material=Wo,Dv(s));let a=/City_(Roads|Water|Green)|^Ground/.test(s.name)&&!/^Ground_Hills/.test(s.name)||/City_(Asphalt|Paving|Water|Grass|Ground)/.test(r);s.castShadow=!a&&!/Cable/.test(r),s.receiveShadow=!0,/^City_(Roads|Water|Green)/.test(s.name)&&(s.material=ov(s.material,/^City_Roads/.test(s.name)?2:1)),r==="City_Lamp"&&!/^Life_/.test(s.name+(s.parent?.name||""))&&uv(s),(hf.test(s.name)||hf.test(s.parent?.name||""))&&Hf.push(s),/^Life_/.test(s.name+(s.parent?.name||""))||Xf.push(s)}/^(Metro|Railway)_Car_(Front|Middle|Motor)$/.test(s.name)&&n.push(s)});for(let s of n)s.parent.remove(s),Po[s.name]=s;return gt.add(t.scene),t}function Ih(i){if(!i)return!0;let e=Math.min(i.count,200);for(let t=0;t<e;t++)if(i.getX(t)<.99||i.getY(t)<.99||i.getZ(t)<.99)return!1;return!0}function uv(i){i.updateWorldMatrix(!0,!1);let e=i.geometry.attributes.position,t=new Set,n=new C;for(let s=0;s<e.count;s++){n.fromBufferAttribute(e,s).applyMatrix4(i.matrixWorld);let r=`${Math.round(n.x/3)},${Math.round(n.z/3)}`;t.has(r)||(t.add(r),mh.push(new C(n.x,n.y-.4,n.z)))}}var nr="day",Lo=new C;function Gf(i){nr=i;let e=tr[i];gt.background=new Te(e.bg),js.top.value.set(e.top),js.horizon.value.set(e.bg),js.sunCol.value.set(e.sun),js.night.value=e.night,gt.fog.color.set(e.bg),gt.fog.near=e.fog[0],gt.fog.far=e.fog[1],en.uFlood.value=e.flood,en.uLitCut.value=e.lit,un.color.set(e.sun),un.intensity=e.sunI,wo.color.set(e.sky),wo.groundColor.set(e.ground),wo.intensity=e.hemiI,en.uNight.value=e.night,Vo.emissiveIntensity=Math.max(e.lamp,.6),Go.emissiveIntensity=e.night>.5?4:e.night>0?1.8:.5,qr.emissiveIntensity=e.night>.5?1.1:e.night>0?.45:0,ph=e.night>.5?.85:e.night>0?.45:0;for(let s of Lh)s.material.emissiveIntensity=ph;ln.toneMappingExposure=e.exp;let t=Dt.degToRad(e.el),n=Dt.degToRad(e.az);Lo.set(Math.sin(n)*Math.cos(t),Math.sin(t),-Math.cos(n)*Math.cos(t)),js.sunDir.value.copy(Lo);for(let s of document.querySelectorAll("#tod button"))s.setAttribute("aria-pressed",String(s.dataset.tod===i));gh=0}var gh=0;function dv(i,e){if(i-gh<400)return;gh=i;let t=tr[nr].pool;if(!t||!mh.length){fh.forEach(s=>s.intensity=0);return}let n=mh.map(s=>[s.distanceToSquared(e),s]).sort((s,r)=>s[0]-r[0]).slice(0,Of);fh.forEach((s,r)=>{n[r]?(s.position.copy(n[r][1]),s.intensity=t):s.intensity=0})}var tt="orbit",Xo=!1,X={yaw:0,pitch:0,tyaw:0,tpitch:0,pos:new C,keys:new Set,floor:0,lastProbe:0,runLock:!1},fv=1.4,pv=4.5,Vr=1.7,bt=null;function mv(i){let e=zf[i.cam];if(!e)return null;e.updateWorldMatrix(!0,!1);let t=new C,n=new xt;e.getWorldPosition(t),e.getWorldQuaternion(n);let s=new C(0,0,-1).applyQuaternion(n),r=t.y>50?Math.max(200,t.y*1.3):30;return{pos:t,dir:s,target:t.clone().addScaledVector(s,r)}}function qo(i,e=!1){let t=Hr.find(r=>r.id===i)||Hr[3],n=mv(t);if(!n)return;np(n,t);for(let r of document.querySelectorAll("#views button"))r.setAttribute("aria-pressed",String(r.dataset.view===t.id));let s="#"+t.id+(zn!=="oldcity"||/place=/.test(location.hash)?"&place="+zn:"");try{location.hash!==s&&history.replaceState(null,"",s)}catch{}if(tt==="walk"&&n.pos.y<5){X.pos.copy(n.pos),X.pos.y=Kt(X.pos.x,X.pos.z)+Vr,X.yaw=X.tyaw=Math.atan2(-n.dir.x,-n.dir.z),X.pitch=X.tpitch=0;return}tt==="walk"&&ss("orbit",!1),e||Pn?(Me.position.copy(n.pos),nt.target.copy(n.target),nt.update(),bt=null):Yr(n.pos,n.target)}function Yr(i,e,t={}){let n=Me.position.clone(),s=nt.target.clone(),r=n.distanceTo(i)+.5*s.distanceTo(e),o=t.arc??Math.min(220,r*.32);bt={t:0,dur:t.dur??Dt.clamp(1.3+r/380,1.3,5),arc:o,fromPos:n,fromTarget:s,toPos:i.clone(),toTarget:e.clone(),done:t.done}}function ss(i,e=!0){tt=i;for(let t of document.querySelectorAll("#mode button"))t.setAttribute("aria-pressed",String(t.dataset.mode===i));if(pe("pad").hidden=!(i==="walk"&&kn),i==="walk"){bt=null,nt.enabled=!1;let t=new C;Me.getWorldDirection(t),e&&(Me.position.y>4+Kt(Me.position.x,Me.position.z)?X.pos.copy(nt.target):X.pos.copy(Me.position),X.pos.y=Kt(X.pos.x,X.pos.z)+Vr),X.yaw=X.tyaw=Math.atan2(-t.x,-t.z),X.pitch=X.tpitch=0}else{$n()&&document.exitPointerLock(),X.glide=null;let t=new C(-Math.sin(X.yaw),0,-Math.cos(X.yaw));e&&nt.target.copy(Me.position).addScaledVector(t,20).setY(1.5),nt.enabled=!0}Yo()}function Yo(){let i=pe("hint");tt==="walk"?i.innerHTML=kn?"<strong>Walking</strong> at 1.4 m/s. Hold the arrows to walk, drag to look around, double-tap a spot to go there.":$n()?"<strong>Mouse-look</strong>: move the mouse to look, hold the left button (or W) to walk, right button to step back, double-click to go where the circle points. <strong>Esc</strong> to free the mouse.":"<strong>Walking</strong>: the view follows your mouse. W A S D to walk, Shift to run. <strong>Click</strong> for full mouse-look, double-click a spot to go there.":i.innerHTML=Xo?kn?"<strong>Pan</strong>: drag to move across the city, pinch to zoom.":"<strong>Pan</strong>: drag to move across the city, scroll to zoom, right-drag to turn.":kn?"Drag to look around, pinch to zoom, two fingers to move. Double-tap a spot to go there.":"Drag to look around (at street level the view turns where you stand), scroll to zoom, right-drag to move. Double-click a spot to go there."}var Io=.0024,xn=null,Kn=null,$s=null,$n=()=>document.pointerLockElement===Ut;function ah(i,e){X.tyaw-=i*Io,X.tpitch=Dt.clamp(X.tpitch-e*Io,-1.25,1.25)}function gv(i,e){let t=nt.target.clone().sub(Me.position),n=Math.max(4,t.length()),s=Math.atan2(t.x,t.z),r=Math.asin(Dt.clamp(t.y/n,-1,1));s-=i*Io,r=Dt.clamp(r-e*Io,-1.2,1.2),t.set(Math.sin(s)*Math.cos(r),Math.sin(r),Math.cos(s)*Math.cos(r)).multiplyScalar(n),nt.target.copy(Me.position).add(t)}Ut.addEventListener("pointerdown",i=>{if(tt==="walk"){if(X.glide=null,$n()){i.button===0&&X.keys.add("mf"),i.button===2&&X.keys.add("mb");return}xn={x:i.clientX,y:i.clientY,x0:i.clientX,y0:i.clientY,id:i.pointerId,type:i.pointerType},Ut.setPointerCapture(i.pointerId);return}!Xo&&i.button===0&&Me.position.y<9&&i.isPrimary&&(Kn={x:i.clientX,y:i.clientY,id:i.pointerId},nt.enableRotate=!1,bt=null)},!0);Ut.addEventListener("pointermove",i=>{if(tt==="walk"){if($n()){ah(i.movementX||0,i.movementY||0);return}if(xn&&i.pointerId===xn.id){ah(i.clientX-xn.x,i.clientY-xn.y),xn.x=i.clientX,xn.y=i.clientY;return}i.pointerType==="mouse"&&i.buttons===0&&($s&&ah((i.clientX-$s.x)*.9,(i.clientY-$s.y)*.9),$s={x:i.clientX,y:i.clientY});return}Kn&&i.pointerId===Kn.id&&(gv(i.clientX-Kn.x,i.clientY-Kn.y),Kn.x=i.clientX,Kn.y=i.clientY)});Ut.addEventListener("pointerleave",()=>{$s=null});var Wf=i=>{if(xn&&i.pointerId===xn.id){if(Math.hypot(i.clientX-xn.x0,i.clientY-xn.y0)<5&&xn.type==="mouse"&&i.type==="pointerup"&&tt==="walk"&&!$n()&&Ut.requestPointerLock)try{let t=Ut.requestPointerLock();t&&t.catch&&t.catch(()=>{})}catch{}xn=null}Kn&&i.pointerId===Kn.id&&(Kn=null,nt.enableRotate=!0),i.button===0&&X.keys.delete("mf"),i.button===2&&X.keys.delete("mb")};Ut.addEventListener("pointerup",Wf);Ut.addEventListener("pointercancel",Wf);Ut.addEventListener("contextmenu",i=>{tt==="walk"&&$n()&&i.preventDefault()});document.addEventListener("pointerlockchange",()=>{pe("crosshair").hidden=!$n(),$n()||(X.keys.delete("mf"),X.keys.delete("mb")),$s=null,Yo()});var df=new Ir,Xf=[];Ut.addEventListener("dblclick",i=>{let e=Ut.getBoundingClientRect(),t=$n()?new Re(0,0):new Re((i.clientX-e.left)/e.width*2-1,-((i.clientY-e.top)/e.height)*2+1);X.keys.delete("mf"),df.setFromCamera(t,Me);let n=df.intersectObjects(Xf,!1)[0];if(!n)return;let s=n.point.clone();if(tt==="walk"){let l=n.face?n.face.normal.clone().transformDirection(n.object.matrixWorld):new C(0,1,0);Math.abs(l.y)<.5&&s.addScaledVector(new C(l.x,0,l.z).normalize(),1.2);let c=new C(s.x,X.pos.y,s.z),h=c.distanceTo(X.pos);h>.5&&(X.glide={from:X.pos.clone(),to:c,t:0,dur:Math.min(8,.6+h/4)});return}st.on&&$r();let r=Me.position.clone().sub(s),o=Dt.clamp(r.length()*.45,6,90),a=s.clone().add(r.normalize().multiplyScalar(o));a.y=Math.max(a.y,s.y+1.6),Yr(a,s,{arc:0})});var Do={KeyW:"f",ArrowUp:"f",KeyS:"b",ArrowDown:"b",KeyA:"l",ArrowLeft:"l",KeyD:"r",ArrowRight:"r"};window.addEventListener("keydown",i=>{i.target.closest&&i.target.closest("button")||(Do[i.code]&&tt==="walk"&&(X.keys.add(Do[i.code]),i.preventDefault()),i.key==="Shift"&&X.keys.add("run"))});window.addEventListener("keyup",i=>{Do[i.code]&&X.keys.delete(Do[i.code]),i.key==="Shift"&&X.keys.delete("run")});window.addEventListener("blur",()=>X.keys.clear());for(let i of document.querySelectorAll("#pad button[data-move]")){let e=n=>{n.preventDefault(),X.keys.add(i.dataset.move),i.classList.add("on")},t=()=>{X.keys.delete(i.dataset.move),i.classList.remove("on")};i.addEventListener("pointerdown",e),i.addEventListener("pointerup",t),i.addEventListener("pointerleave",t),i.addEventListener("pointercancel",t)}pe("tod").addEventListener("click",i=>{let e=i.target.closest("button");e&&Gf(e.dataset.tod)});pe("mode").addEventListener("click",i=>{let e=i.target.closest("button");e&&e.dataset.mode!==tt&&ss(e.dataset.mode)});var Dh=pe("views");for(let i of Hr){let e=document.createElement("button");e.type="button",e.dataset.view=i.id,e.textContent=i.label,e.setAttribute("aria-pressed","false"),e.addEventListener("click",()=>qo(i.id)),Dh.appendChild(e)}if(zn!=="oldcity"){let i=document.querySelector(".brand");i.querySelector(".mr").textContent=Cn.mr,i.querySelector(".en").textContent=Cn.en,i.querySelector(".coord").textContent=Cn.coord,document.title=Cn.en+" 3D"}function _v(i){if(i===zn){Kr(!1);return}location.hash="place="+i,setTimeout(()=>location.reload(),400)}function Kr(i){pe("placesPanel").hidden=!i,pe("placesBtn").setAttribute("aria-expanded",String(i)),i&&pe("placesList").querySelector('[aria-current="true"]')?.focus()}for(let[i,e]of Object.entries(zr)){let t=document.createElement("button");t.type="button",t.className="placeItem",t.setAttribute("aria-current",String(i===zn)),t.innerHTML='<span class="pm" lang="mr"></span><span class="pe"></span><span class="pb"></span>',t.querySelector(".pm").textContent=e.mr,t.querySelector(".pe").textContent=e.en,t.querySelector(".pb").textContent=e.blurb,t.addEventListener("click",()=>_v(i)),pe("placesList").append(t)}pe("placesBtn").addEventListener("click",()=>Kr(pe("placesPanel").hidden));Object.keys(zr).length<2&&(pe("placesBtn").hidden=!0);pe("placesClose").addEventListener("click",()=>Kr(!1));window.addEventListener("keydown",i=>{i.key==="Escape"&&!pe("placesPanel").hidden&&Kr(!1)});window.addEventListener("hashchange",()=>{let i=(/(?:^|[#&])place=([\w-]+)/.exec(location.hash)||[])[1]||"oldcity";if(i!==zn&&zr[i]){location.reload();return}let e=location.hash.slice(1).split("&")[0];Hr.some(t=>t.id===e)&&qo(e)});function qf(){let i=window.innerWidth,e=window.innerHeight;try{Uo()}catch{}ln.setSize(i,e,!1),Me.aspect=i/Math.max(1,e),Me.fov=Me.aspect<1?72:55,Me.updateProjectionMatrix(),jr()}function jr(){document.documentElement.style.setProperty("--hud-h",`${pe("hudBottom").offsetHeight+34}px`)}window.addEventListener("resize",qf);qf();var gi=pe("radarCanvas"),xv=gi.getContext("2d"),ct=null,mi=!1,_h=0,Yf=null;function Kt(i,e){let t=Yf;if(!t)return 0;let n=(i-t.x0)/t.cell,s=(e-t.z0)/t.cell;if(n<0||s<0||n>=t.nx-1||s>=t.nz-1)return 0;let r=Math.floor(n),o=Math.floor(s),a=n-r,l=s-o,c=t.h,h=t.nx;return(c[o*h+r]*(1-a)+c[o*h+r+1]*a)*(1-l)+(c[(o+1)*h+r]*(1-a)+c[(o+1)*h+r+1]*a)*l}fetch(ts+"wada_map.json").then(i=>i.ok?i.json():null).then(i=>{if(i){i.bc=i.buildings.map(e=>{let t=0,n=0;for(let s=0;s<e.length;s+=2)t+=e[s],n+=e[s+1];return[t/(e.length/2),n/(e.length/2)]}),ct=i,Yf=i&&i.terrain?i.terrain:null;for(let e of i.landmarks)/Ganpati|Mandir|Temple/i.test(e.name)&&Js.temples.push({x:e.x,z:e.z}),/Ganpati|Mandir|Darwaza|Lal Mahal|Mandai|Laxmi Road/i.test(e.name)&&Js.markets.push({x:e.x,z:e.z});for(let e of i.water)for(let t=0;t<e.length;t+=8)Js.river.push({x:e[t],z:e[t+1]})}}).catch(()=>{});pe("radar").addEventListener("click",i=>{let e=gi.getBoundingClientRect(),t=gi.width/Math.max(1,e.width),n=(i.clientX-e.left)*t-gi.width/2,s=(i.clientY-e.top)*t-gi.height/2,r=null,o=16*t;for(let a of yh){let l=Math.hypot(a.X-n,a.Y-s);l<o&&(o=l,r=a)}if(r&&i.detail!==0&&!j.on){let a=eb[r.name];st.on&&$r(),a?qo(a):Yr(new C(r.x+60,50,r.z+60),new C(r.x,8,r.z));return}mi=!mi,_h=0});function yv(i,e,t){if(i-_h<66)return;_h=i;let n=gi.clientWidth;if(!n)return;let s=Math.min(window.devicePixelRatio||1,2),r=Math.round(n*s);gi.width!==r&&(gi.width=gi.height=r);let o=r/2,a=xv,l=Me.position.y>60,c=mi?600:l?Math.min(600,150+Me.position.y*.5):150,h=(o-4*s)/c,u=mi?0:e.x,d=mi?0:e.z,f=mi?0:t;pe("radarTag").textContent=mi?"Tap a place to fly there":`Radar \xB7 ${Math.round(c)} m`,a.save(),a.clearRect(0,0,r,r),a.beginPath(),a.arc(o,o,o-s,0,Math.PI*2),a.clip(),a.fillStyle="rgba(2, 14, 12, 0.88)",a.fillRect(0,0,r,r),a.translate(o,o),a.rotate(f);let g=(A,T,R)=>Math.abs(A-u)<c+R&&Math.abs(T-d)<c+R,_=A=>{a.beginPath();for(let T=0;T<A.length;T+=2){let R=(A[T]-u)*h,N=(A[T+1]-d)*h;T===0?a.moveTo(R,N):a.lineTo(R,N)}a.closePath()};if(ct){a.fillStyle="rgba(0, 150, 190, 0.38)";for(let A of ct.water)_(A),a.fill();a.fillStyle="rgba(0, 170, 90, 0.20)";for(let A of ct.green)_(A),a.fill();a.strokeStyle="rgba(0, 255, 190, 0.32)",a.fillStyle="rgba(0, 255, 190, 0.05)",a.lineWidth=s*.8,ct.buildings.forEach((A,T)=>{let R=ct.bc[T];g(R[0],R[1],40)&&(_(A),a.fill(),a.stroke())}),a.lineCap="round";for(let[A,T,R,N,b,E]of ct.roads)!g(A,T,60)&&!g(R,N,60)||(a.strokeStyle=E===0?"rgba(0, 229, 255, 0.9)":"rgba(0, 229, 255, 0.35)",a.lineWidth=Math.max(s,Math.min(b*h*.7,7*s)),a.beginPath(),a.moveTo((A-u)*h,(T-d)*h),a.lineTo((R-u)*h,(N-d)*h),a.stroke());ct.fort.length&&(a.shadowColor="#ffb347",a.shadowBlur=8*s,a.strokeStyle="#ffc06a",a.lineWidth=2.4*s,_(ct.fort),a.stroke(),a.shadowBlur=0)}a.restore(),a.save(),a.translate(o,o),a.strokeStyle="rgba(0, 255, 170, 0.16)",a.lineWidth=s;for(let A of[.33,.66])a.beginPath(),a.arc(0,0,(o-4*s)*A,0,Math.PI*2),a.stroke();if(!Pn){let A=i/1e3*1.3;a.fillStyle="rgba(0, 255, 170, 0.10)",a.beginPath(),a.moveTo(0,0),a.arc(0,0,o,A-.55,A),a.closePath(),a.fill(),a.strokeStyle="rgba(120, 255, 210, 0.55)",a.lineWidth=1.2*s,a.beginPath(),a.moveTo(0,0),a.lineTo(Math.cos(A)*o,Math.sin(A)*o),a.stroke()}let m=(A,T)=>{let R=(A-u)*h,N=(T-d)*h;return[R*Math.cos(f)-N*Math.sin(f),R*Math.sin(f)+N*Math.cos(f)]};if(ct){let A=.5+.5*Math.sin(i/300);a.font=`${10*s}px Inter, system-ui, sans-serif`,a.textAlign="center",yh=[];for(let T of ct.landmarks){let[R,N]=m(T.x,T.z);Math.hypot(R,N)>o-6*s||(yh.push({X:R,Y:N,name:T.name,x:T.x,z:T.z}),a.fillStyle=`rgba(255, 190, 90, ${.35+.4*A})`,a.beginPath(),a.arc(R,N,(4+3*A)*s,0,Math.PI*2),a.fill(),a.fillStyle="#ffd08a",a.beginPath(),a.arc(R,N,2.4*s,0,Math.PI*2),a.fill(),a.fillStyle="rgba(255, 225, 170, 0.95)",a.fillText(T.name,R,N-7*s))}}if(j.on&&j.spot){let[A,T]=m(j.spot.x,j.spot.z),R=Math.hypot(A,T),N=o-11*s,b=.5+.5*Math.sin(i/220);if(a.save(),a.shadowColor="#ffc35a",a.shadowBlur=12*s,a.fillStyle="#ffd36b",R>N)A*=N/R,T*=N/R,a.translate(A,T),a.rotate(Math.atan2(T,A)),a.beginPath(),a.moveTo(8*s,0),a.lineTo(-5*s,6*s),a.lineTo(-5*s,-6*s),a.closePath(),a.fill();else{a.strokeStyle=`rgba(255, 211, 107, ${.4+.5*b})`,a.lineWidth=2*s,a.beginPath(),a.arc(A,T,(8+5*b)*s,0,Math.PI*2),a.stroke(),a.translate(A,T),a.beginPath();for(let E=0;E<10;E++){let O=-Math.PI/2+E*Math.PI/5,W=(E%2?2.6:6.5)*s;E?a.lineTo(Math.cos(O)*W,Math.sin(O)*W):a.moveTo(Math.cos(O)*W,Math.sin(O)*W)}a.closePath(),a.fill()}a.restore()}let[p,y]=mi?m(e.x,e.z):[0,0],x=mi?-t:0;a.save(),a.translate(p,y),a.rotate(x),a.fillStyle="rgba(125, 255, 208, 0.12)",a.beginPath(),a.moveTo(0,0),a.arc(0,0,34*s,-Math.PI/2-.5,-Math.PI/2+.5),a.closePath(),a.fill(),a.shadowColor="#7dffd0",a.shadowBlur=8*s,a.fillStyle="#eafff7",a.beginPath(),a.moveTo(0,-8*s),a.lineTo(5.5*s,6*s),a.lineTo(0,3*s),a.lineTo(-5.5*s,6*s),a.closePath(),a.fill(),a.restore();let M=-Math.PI/2+f;a.fillStyle="#7dffd0",a.font=`600 ${10*s}px Inter, system-ui, sans-serif`,a.textAlign="center",a.textBaseline="middle",a.fillText("N",Math.cos(M)*(o-10*s),Math.sin(M)*(o-10*s)),a.restore(),a.beginPath(),a.arc(o,o,o-s,0,Math.PI*2),a.strokeStyle="rgba(125, 255, 208, 0.75)",a.lineWidth=1.5*s,a.stroke()}var ff={scooter:{v:7.5,minW:3},motorbike:{v:8.5,minW:3},delivery:{v:8,minW:3},auto:{v:6.5,minW:4},hatch:{v:7.2,minW:5},sedan:{v:7.6,minW:5},cab:{v:7.4,minW:5},suv:{v:7.6,minW:5.5},bus:{v:5.5,minW:9},shuttle:{v:6.5,minW:7}},xh=kn?260:450,vv=2*Math.PI/1.4,xi=null,Yt=[];function Kf(i){let e=i.geometry,t=e.attributes.position,n=new Float32Array(t.count*3),s=new C;for(let a=0;a<t.count;a++)s.fromBufferAttribute(t,a).applyMatrix4(i.matrixWorld),n[a*3]=s.x,n[a*3+1]=s.y,n[a*3+2]=s.z;let r=new Tt;r.setAttribute("position",new wt(n,3));let o=e.attributes.color;return e.attributes.color_1&&Ih(o)&&(o=e.attributes.color_1),o&&r.setAttribute("color",o),e.index&&r.setIndex(e.index),r}function bv(i){if(!So||!i||!i.nodes||!i.nodes.length)return;So.updateMatrixWorld(!0);let e=i.nodes,t=e.length/3,n=i.edges.length/5,s={nodes:e,ea:new Int32Array(n),eb:new Int32Array(n),ew:new Float32Array(n),ek:new Uint8Array(n),efp:new Uint8Array(n),elen:new Float32Array(n),adj:Array.from({length:t},()=>[]),centre:i.centre||[0,0],leash:i.leash||260,gates:[],homes:i.homes||[[...i.centre||[0,0],i.leash||260]]};for(let f=0;f<n;f++){let g=i.edges[f*5],_=i.edges[f*5+1];s.ea[f]=g,s.eb[f]=_,s.ew[f]=i.edges[f*5+2],s.ek[f]=i.edges[f*5+3],s.efp[f]=i.edges[f*5+4],s.elen[f]=Math.max(.05,Math.hypot(e[_*3]-e[g*3],e[_*3+2]-e[g*3+2])),s.adj[g].push(f),s.adj[_].push(f)}let r=1/0,o=-1/0,a=1/0,l=-1/0;for(let f=0;f<t;f++)r=Math.min(r,e[f*3]),o=Math.max(o,e[f*3]),a=Math.min(a,e[f*3+2]),l=Math.max(l,e[f*3+2]);for(let f=0;f<t;f++){if(s.adj[f].length!==1||s.ek[s.adj[f][0]]!==0||s.ew[s.adj[f][0]]<5)continue;let g=e[f*3],_=e[f*3+2];(g-r<3||o-g<3||_-a<3||l-_<3)&&s.gates.push(f)}let c=i.protos.map(f=>{let g=So.getObjectByName(f.name),_=[];return g&&g.traverse(m=>{m.isMesh&&_.push({geo:Kf(m),mat:m.material?.name||""})}),{p:f,parts:_,members:[],meshes:[],step:null}}),h=[],u=f=>{c[f.pid]&&c[f.pid].parts.length&&(c[f.pid].members.push(f),h.push(f))};for(let f=0;f<i.vehicles.length;f+=6){let[g,_,m,p,y,x]=i.vehicles.slice(f,f+6),M=i.protos[g];if(!M||_>=n)continue;let A=ff[M.kind]||ff.hatch;u({pid:g,car:!0,e:_,dir:p,s:m*s.elen[_],near:x|0,lane:Dt.clamp(y/Math.max(1,s.ew[_]/2),.25,.9),vmax:A.v*(.85+Math.random()*.3),minW:A.minW,v:A.v*.6,hl:M.half[0],hw:M.half[1],stuck:0,ignore:0,x:0,y:0,z:0,dx:1,dz:0,rx:0,ry:0,rz:0,hx:1,hz:0,snap:!0})}let d=i.people||[];for(let f=0;f<d.length;f+=5){let[g,_,m,p,y]=d.slice(f,f+5);i.protos[g]&&(i.protos[g].type==="v"&&Yt.push(_,-m,(i.protos[g].half?.[0]||1.5)+.7),u({pid:g,still:!0,car:!1,x:_,y:p,z:-m,rx:_,ry:p,rz:-m,hx:Math.cos(y),hz:-Math.sin(y),step:0,phase:Math.random()*6.28,v:0}))}for(let f=0;f<i.walkers.length;f+=7){let[g,_,m,p,y,x,M]=i.walkers.slice(f,f+7),A=i.protos[g];!A||_>=n||u({pid:g,car:!1,e:_,dir:p,s:m*s.elen[_],near:M|0,side:y,jit:x,v:(A.kind==="child"?1:1.05)+Math.random()*.45,step:Math.random()*6.28,x:0,y:0,z:0,dx:1,dz:0,rx:0,ry:0,rz:0,hx:1,hz:0,snap:!0})}for(let f of c){let g=f.members.length;if(!g)continue;let _=null;for(let m of f.parts){let p;m.mat==="City_Lamp"?p=Vo:m.mat==="City_TailLamp"?p=Go:f.p.type==="p"?p=f.walkMat||(f.walkMat=rv(f.p.hip,f.p.shoulder)):(f.p.type==="s"||f.p.type,p=Ao("Life_Paint")),f.p.type==="p"&&(f.step=f.step||new ci(new Float32Array(g),1),m.geo.setAttribute("aStep",f.step));let y=new Xn(m.geo,p,g);_?y.instanceMatrix=_:_=y.instanceMatrix,y.instanceMatrix.setUsage(Ur),y.frustumCulled=!1,y.castShadow=m.mat!=="City_Lamp"&&m.mat!=="City_TailLamp",y.receiveShadow=!0,y.count=0,gt.add(y),f.meshes.push(y)}f.matrix=_}xi={G:s,groups:c,movers:h,cars:h.filter(f=>f.car),grid:new Map},window.__wada=()=>({movers:h.length,cars:xi.cars.length,drawn:c.reduce((f,g)=>f+(g.meshes[0]?.count||0),0),moving:xi.cars.filter(f=>f.v>1).length,trains:Gr.map(f=>`${f.state} s=${f.s.toFixed(0)}/${f.L.toFixed(0)} v=${f.v.toFixed(1)} vis=${f.cars.filter(g=>g.visible).length}`),boards:Lh.length,coaches:Object.keys(Po)}),window.__wadaCam=()=>({mode:tt,x:+Me.position.x.toFixed(2),y:+Me.position.y.toFixed(2),z:+Me.position.z.toFixed(2),yaw:+X.yaw.toFixed(3),tyaw:+X.tyaw.toFixed(3),tx:+nt.target.x.toFixed(2),tz:+nt.target.z.toFixed(2),wx:+X.pos.x.toFixed(2),wz:+X.pos.z.toFixed(2),glide:!!X.glide,flight:!!bt}),window.__wadaLook=(f,g,_,m,p,y)=>{tt==="walk"&&ss("orbit",!1),Me.position.set(f,g,_),nt.target.set(m,p,y),nt.update()},window.__wadaTrainNow=(f=0,g=0)=>{let _=Gr[f];_&&(_.state="run",_.s=g,_.v=12,_.stopFront=_.stopBase,_.dwell=0)};for(let f of h)f.still||Zf(s,f)}var Mv=(()=>{let i=document.createElement("canvas");i.width=64,i.height=128;let e=i.getContext("2d"),t=e.createRadialGradient(32,112,4,32,70,70);t.addColorStop(0,"rgba(255,236,200,0.95)"),t.addColorStop(.45,"rgba(255,214,160,0.35)"),t.addColorStop(1,"rgba(255,200,140,0)"),e.fillStyle=t,e.fillRect(0,0,64,128);let n=new Rr(i);return n.colorSpace=ut,n})(),wv=new Qi(2.6,7.5).rotateX(-Math.PI/2).rotateY(-Math.PI/2).translate(3.75,.07,0),jf=new Wt({map:Mv,transparent:!0,depthWrite:!1,blending:gr,opacity:0,fog:!0}),$f=220,_i=new Xn(wv,jf,$f);_i.frustumCulled=!1;_i.count=0;_i.renderOrder=2;_i.instanceMatrix.setUsage(Ur);gt.add(_i);function Sv(i){let e=tr[nr].night;if(jf.opacity=e*.55,!xi||e<=0){_i.count=0;return}let t=_i.instanceMatrix.array,n=0;for(let s of xi.cars){if(n>=$f)break;let r=s.rx-i.x,o=s.rz-i.z;if(r*r+o*o>200*200)continue;let a=n*16,l=s.hx,c=s.hz,h=s.rx+l*s.hl,u=s.rz+c*s.hl;t[a]=l,t[a+1]=0,t[a+2]=c,t[a+3]=0,t[a+4]=0,t[a+5]=1,t[a+6]=0,t[a+7]=0,t[a+8]=-c,t[a+9]=0,t[a+10]=l,t[a+11]=0,t[a+12]=h,t[a+13]=s.ry,t[a+14]=u,t[a+15]=1,n++}_i.count=n,_i.instanceMatrix.needsUpdate=!0}function Ev(i,e){let t=i.ew[e.e],n=t>=7?t/2-2:t/2-1;return Math.max(.3,Math.min(e.lane*t/2,Math.max(.6,n)))}function Tv(i,e){let t=e.e,n=i.ew[t];return i.ek[t]!==0?e.jit*n*.25*e.side:i.efp[t]?(n/2+1.2+e.jit*.6)*e.side:Math.max(.3,n/2-.7+e.jit*.3)*e.side}function Zf(i,e){let t=e.e,n=i.nodes,s=e.dir>0?i.ea[t]:i.eb[t],r=e.dir>0?i.eb[t]:i.ea[t],o=i.elen[t],a=(n[r*3]-n[s*3])/o,l=(n[r*3+2]-n[s*3+2])/o,c=e.car?Ev(i,e):Tv(i,e),h=Math.min(e.s,o);e.dx=a,e.dz=l,e.x=n[s*3]+a*h+l*c,e.z=n[s*3+2]+l*h-a*c;let u=n[s*3+1]+(n[r*3+1]-n[s*3+1])*(h/o);e.car||(u=i.efp[t]&&h>3.5&&h<o-3.5?u+.14:Math.max(.03,u)),e.y=u,e.snap&&(e.rx=e.x,e.ry=e.y,e.rz=e.z,e.hx=a,e.hz=l,e.snap=!1)}function Av(i,e){let t=e.e,n=i.nodes,s=i.elen[t],r=e.dir>0?i.eb[t]:i.ea[t],o=e.dir>0?i.ea[t]:i.eb[t],a=(n[r*3]-n[o*3])/s,l=(n[r*3+2]-n[o*3+2])/s,c=[],h=0,u=Math.hypot(n[r*3]-i.centre[0],n[r*3+2]-i.centre[1]);for(let g of i.adj[r]){if(g===t||e.car&&(i.ek[g]!==0||i.ew[g]<e.minW))continue;let _=i.ea[g]===r?i.eb[g]:i.ea[g],m=i.elen[g],p=(n[_*3]-n[r*3])/m,y=(n[_*3+2]-n[r*3+2])/m,x=(e.car?Math.min(i.ew[g],14):1)*Math.max(.05,1.15+p*a+y*l);if(e.near){let M=i.homes[(e.near|0)-1]||i.homes[0],A=Math.hypot(n[_*3]-M[0],n[_*3+2]-M[1]),T=Math.hypot(n[r*3]-M[0],n[r*3+2]-M[1]);A>M[2]&&A>T&&(x*=.05)}c.push(g),c.push(x),h+=x}if(e.s-=s,!c.length){if(e.car&&i.gates.length&&i.gates.includes(r)){let g=i.gates[Math.floor(Math.random()*i.gates.length)];e.e=i.adj[g][0],e.dir=i.ea[e.e]===g?1:-1,e.s=0,e.snap=!0;return}e.dir=-e.dir,e.s=0;return}let d=Math.random()*h,f=c[0];for(let g=0;g<c.length&&(f=c[g],d-=c[g+1],!(d<=0));g+=2);e.dir=i.ea[f]===r?1:-1,e.e=f,e.s=Math.max(0,e.s)}function Rv(i,e,t){if(!xi)return;Pn&&(i=0);let{G:n,groups:s,movers:r,cars:o,grid:a}=xi;a.clear();let l=12;for(let d=0;d<o.length;d++){let f=o[d],g=(Math.floor(f.x/l)+500)*2e3+Math.floor(f.z/l)+500,_=a.get(g);_||a.set(g,_=[]),_.push(d)}let c=tt==="walk"?X.pos:null;for(let d=0;d<o.length;d++){let f=o[d],g=99;if(f.ignore<=0){let p=Math.floor(f.x/l)+500,y=Math.floor(f.z/l)+500;for(let x=-1;x<=1;x++)for(let M=-1;M<=1;M++){let A=a.get((p+x)*2e3+y+M);if(A)for(let T of A){if(T===d)continue;let R=o[T],N=R.x-f.x,b=R.z-f.z,E=N*f.dx+b*f.dz;E<=0||E>22||Math.abs(N*f.dz-b*f.dx)>f.hw+R.hw+.25||(g=Math.min(g,E-f.hl-R.hl))}}if(c){let x=c.x-f.x,M=c.z-f.z,A=x*f.dx+M*f.dz;A>0&&A<22&&Math.abs(x*f.dz-M*f.dx)<f.hw+.6&&(g=Math.min(g,A-f.hl-.4))}}let _=f.vmax*(n.ew[f.e]<6?.65:1),m=Math.min(_,Math.max(0,(g-1.2)*1.3));f.v+=Dt.clamp(m-f.v,-7*i,2.2*i),f.v<.25?f.stuck+=i:f.stuck=0,f.stuck>4&&!(c&&g<3)&&(f.ignore=2.5,f.stuck=0),f.ignore-=i}let h=t/1e3;for(let d of r){if(d.still){d.step=.22*Math.sin(h*.7+d.phase);continue}d.s+=d.v*i;for(let y=0;y<4&&d.s>n.elen[d.e];y++)Av(n,d);Zf(n,d),d.car||(d.step+=d.v*i*vv);let f=Math.min(1,i*(d.car?5:6));d.rx+=(d.x-d.rx)*f,d.ry+=(d.y-d.ry)*f,d.rz+=(d.z-d.rz)*f;let g=d.dx,_=d.dz;d.hx*g+d.hz*_<-.9&&(g-=d.hz*.6,_+=d.hx*.6);let m=Math.min(1,i*(d.car?4:6));d.hx+=(g-d.hx)*m,d.hz+=(_-d.hz)*m;let p=Math.hypot(d.hx,d.hz)||1;d.hx/=p,d.hz/=p}let u=xh*xh;for(let d of s){if(!d.matrix)continue;let f=d.matrix.array,g=d.step?d.step.array:null,_=0;for(let m of d.members){let p=m.rx-e.x,y=m.rz-e.z;if(p*p+y*y>u)continue;let x=_*16;f[x]=m.hx,f[x+1]=0,f[x+2]=m.hz,f[x+3]=0,f[x+4]=0,f[x+5]=1,f[x+6]=0,f[x+7]=0,f[x+8]=-m.hz,f[x+9]=0,f[x+10]=m.hx,f[x+11]=0,f[x+12]=m.rx,f[x+13]=m.ry,f[x+14]=m.rz,f[x+15]=1,g&&(g[_]=m.step),_++}d.matrix.needsUpdate=!0,d.step&&(d.step.needsUpdate=!0);for(let m of d.meshes)m.count=_}}function Cv(i){if(!Eo||!i)return;Eo.updateMatrixWorld(!0);let e=new ze,t=new xt,n=new C,s=new C,r=new C(0,1,0);for(let[o,a]of Object.entries(i)){let l=Eo.getObjectByName(o);if(!l||!a.length)continue;let c=/^Prop_Tree_/.test(o);if(l.traverse(h=>{if(!h.isMesh)return;let u=h.material?.name||"",d=Kf(h),f=new Xn(d,c&&u==="Grounds_Paint"?Wo:Bf(Ao(u),d),a.length);a.forEach(([g,_,m,p,y,x,M],A)=>{n.set(g,m,-_),t.setFromAxisAngle(r,p),s.set(y,M,x),f.setMatrixAt(A,e.compose(n,t,s))}),f.castShadow=u!=="City_Lamp",f.receiveShadow=!0,f.computeBoundingSphere(),gt.add(f)}),c)for(let h of a)kr.push(new C(h[0]+(Math.random()-.5)*4,5+Math.random()*3.5,-h[1]+(Math.random()-.5)*4))}}var Nh=42,Uh=new Tt;Uh.setAttribute("position",new ot([0,0,-.16,-.32,.02,.02,0,0,.06,0,0,-.16,0,0,.06,.32,.02,.02,0,-.03,-.18,0,.03,.14,0,-.03,.16],3));Uh.computeVertexNormals();var Oh=new et({color:4869461,roughness:.8,side:_t});Oh.customProgramCacheKey=()=>"bird";Oh.onBeforeCompile=i=>{i.uniforms.uTime=en.uTime,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <begin_vertex>",`#include <begin_vertex>
float bph = float(gl_InstanceID) * 1.37;
float glide = step(0.35, sin(uTime * 0.6 + bph * 0.5));
float beat = sin(uTime * 14.0 + bph) * (1.0 - glide) + 0.15 * glide;
transformed.y += beat * abs(position.x) * 0.9;`)};var ns=new Xn(Uh,Oh,Nh);ns.frustumCulled=!1;ns.instanceMatrix.setUsage(Ur);gt.add(ns);var Pv=Array.from({length:Nh},(i,e)=>({r:30+Math.random()*45,h:18+Math.random()*26,w:(.16+Math.random()*.08)*(e%7===0?-1:1),a:Math.random()*6.28,bob:Math.random()*6.28,s:1.6+Math.random()*.6})),Lv=new ze,pf=new xt,mf=new C,gf=new C;function Iv(i,e){if(ns.visible=tr[nr].night<.5,!ns.visible)return;let t=5,n=10;for(let s=0;s<Nh;s++){let r=Pv[s];r.a+=r.w*i;let o=Math.sin(e*.13+r.bob)*12;mf.set(t+Math.cos(r.a)*(r.r+o),r.h+Math.sin(e*.7+r.bob)*3,n+Math.sin(r.a)*(r.r+o));let a=-Math.sin(r.a)*Math.sign(r.w),l=Math.cos(r.a)*Math.sign(r.w);pf.setFromAxisAngle(new C(0,1,0),Math.atan2(a,l)),gf.setScalar(r.s),ns.setMatrixAt(s,Lv.compose(mf,pf,gf))}ns.instanceMatrix.needsUpdate=!0}var kr=[];function Dv(i){i.updateWorldMatrix(!0,!1);let e=i.geometry.attributes.position,t=new C;for(let n=0;n<e.count;n+=97)t.fromBufferAttribute(e,n).applyMatrix4(i.matrixWorld),t.y>4&&kr.push(t.clone())}var Fh=36,Nv=new Qi(.09,.06),Uv=new et({color:7309868,roughness:.8,side:_t}),Rn=new Xn(Nv,Uv,Fh);Rn.instanceMatrix.setUsage(Ur);Rn.frustumCulled=!1;Rn.count=0;gt.add(Rn);var Ov=Array.from({length:Fh},()=>({p:new C,wait:Math.random()*20,spin:0,ph:Math.random()*6})),mo=[7309868,9083445,11901498,10251050,6257962],_f=new ze,xf=new xt,yf=new Os,Fv=new C(1,1,1);function Bv(i,e,t){if(!kr.length)return;let n=0;for(let s=0;s<Fh;s++){let r=Ov[s];if(r.wait>0){if(r.wait-=i,r.wait<=0){let o=null;for(let a=0;a<12;a++){let l=kr[Math.floor(Math.random()*kr.length)];if(Math.abs(l.x-e.x)<70&&Math.abs(l.z-e.z)<70){o=l;break}}if(!o){r.wait=2+Math.random()*4;continue}r.p.copy(o),r.spin=Math.random()*6,r.ph=Math.random()*6,Rn.setColorAt(s,new Te(mo[s%mo.length])),Rn.instanceColor&&(Rn.instanceColor.needsUpdate=!0)}continue}if(r.p.y-=i*(.55+.25*Math.sin(t*1.7+r.ph)),r.p.x+=i*(.35+.5*Math.sin(t*.9+r.ph)),r.p.z+=i*.25*Math.cos(t*1.3+r.ph),r.spin+=i*2.4,r.p.y<.05){r.wait=6+Math.random()*18;continue}yf.set(Math.sin(r.spin)*1.2,r.spin*.7,Math.cos(r.spin*.8)),xf.setFromEuler(yf),_f.compose(r.p,xf,Fv),Rn.setMatrixAt(n,_f),n!==s&&Rn.instanceColor&&Rn.setColorAt(n,new Te(mo[s%mo.length])),n++}Rn.count=n,Rn.instanceMatrix.needsUpdate=!0}var Gr=[],Jf=16.7,kv=1,zv=20,Hv=95;function vf(i,e="metro"){if(!i||!i.tracks)return;let t=i.sequence||["Metro_Car_Front","Metro_Car_Middle","Metro_Car_Front"];if(!t.every(r=>Po[r]))return;let n=i.car_length||21.6,s=t.length;i.tracks.forEach((r,o)=>{let a=r.pts.map(([d,f,g])=>new C(d,f,g)),l=[0];for(let d=1;d<a.length;d++)l.push(l[d-1]+a[d].distanceTo(a[d-1]));let c=[];for(let d=0;d<s;d++){let f=new Jt,g=Po[t[d]].clone();if(d===s-1&&s>1&&/Front/.test(t[d])){let _=new Jt;_.rotation.y=Math.PI,_.add(g),f.add(_)}else f.add(g);f.visible=!1,gt.add(f),c.push(f)}let h=l[l.length-1],u=r.stop!=null?r.stop+n*s/2+.3*(s-1):null;Gr.push({pts:a,dist:l,L:h,CAR:n,cars:c,n:s,kind:e,stopFront:u,stopBase:u,state:"wait",clock:(e==="metro"?6:14)+o*(e==="metro"?55:70),s:0,v:0,dwell:0,cruise:i.cruise||Jf,accel:i.accel||kv,dwellTime:i.dwell||zv,gap:i.gap||Hv})})}function bf(i,e,t){let{pts:n,dist:s}=i;if(e<=0)return t.copy(n[0]);if(e>=i.L)return t.copy(n[n.length-1]);let r=0,o=s.length-1;for(;o-r>1;){let a=r+o>>1;s[a]<e?r=a:o=a}return t.lerpVectors(n[r],n[o],(e-s[r])/Math.max(1e-6,s[o]-s[r]))}var go=new C,_o=new C;function Vv(i){for(let e of Gr){if(e.state==="wait"&&(e.clock-=i,e.clock<=0&&(e.state="run",e.s=0,e.dwell=0,e.stopFront=e.stopBase,e.v=e.stopFront!=null?Math.min(e.cruise,Math.sqrt(2*e.accel*Math.max(1,e.stopFront))):e.cruise)),e.state==="run"){if(e.dwell>0)e.dwell-=i,e.dwell<=0&&(e.stopFront=null);else if(e.stopFront!=null){let t=e.stopFront-e.s;e.v=Math.min(e.cruise,e.v+e.accel*i,Math.sqrt(2*e.accel*Math.max(0,t))),t<=.05&&(e.v=0,e.s=e.stopFront,e.dwell=e.dwellTime)}else e.v=Math.min(e.cruise,e.v+e.accel*i);e.s+=e.v*i,e.s-e.n*(e.CAR+.3)>e.L&&(e.state="wait",e.clock=e.gap+Math.random()*30)}e.cars.forEach((t,n)=>{let s=e.s-n*(e.CAR+.3),r=s-e.CAR/2;t.visible=e.state==="run"&&r>0&&r<e.L,t.visible&&(bf(e,s-3.2,go),bf(e,s-e.CAR+3.2,_o),t.position.addVectors(go,_o).multiplyScalar(.5),t.rotation.set(0,Math.atan2(-(go.z-_o.z),go.x-_o.x),0))})}}var Mf={"metro-aqua":{bg:"#0a7f99",fg:"#ffffff",band:"#ffffff"},"metro-purple":{bg:"#5b2a86",fg:"#ffffff",band:"#ffffff"},street:{bg:"#1d4f9c",fg:"#ffffff",band:"#ffffff"},temple:{bg:"#8a1c12",fg:"#ffd27a",band:"#ffd27a"},shop:{bg:"#f2c230",fg:"#5a1208",band:"#5a1208"},heritage:{bg:"#3b2414",fg:"#f3e2b5",band:"#c9a45c"},jeweller:{bg:"#5e0b10",fg:"#f6cf6a",band:"#f6cf6a"},banner:{bg:"#f7f3e8",fg:"#7a1414",band:"#1d4f9c"},board:{bg:"#151311",fg:"#f4f1ea",band:"#f4f1ea"},gate:{bg:"#ecd3cb",fg:"#7a3b1c",band:"#c86a2c"},balg:{bg:"#6b6527",fg:"#ffffff",band:"#6b6527"},kelkar:{bg:"#ffffff",fg:"#7a1414",band:"#a01818"},welcome:{bg:"#f3d21c",fg:"#c8102e",band:"#1d3f9c"},station:{bg:"#f6c90e",fg:"#111111",band:"#111111"},college:{bg:"#f4f2ec",fg:"#1c2a5a",band:"#1c2a5a"},plaque:{bg:"#f1efe8",fg:"#161616",band:"#161616"},phule:{bg:"#7d6d5c",fg:"#fbfaf5",band:"#7d6d5c"},empress:{bg:"#fbfbf7",fg:"#1d6b2a",band:"#1d6b2a"},dmart:{bg:"#00703c",fg:"#ffffff",band:"#f7c600"},cybage:{bg:"#ffffff",fg:"#1d4f9c",band:"#ffffff"},cerebrum:{bg:"#2b2f36",fg:"#ffffff",band:"#2b2f36"},cerebrumstone:{bg:"#d4bb94",fg:"#3b3430",band:"#d4bb94"},stanchart:{bg:"#0473ea",fg:"#ffffff",band:"#38d200"},dmartwall:{bg:"#e2d9ba",fg:"#22704a",band:"#e2d9ba"}},wf=[["#f2c230","#5a1208"],["#b3161b","#fff3d6"],["#0f5e3c","#fff7e0"],["#173d7a","#ffffff"],["#ffffff","#b3161b"],["#e86a12","#ffffff"],["#5b1f63","#ffe9a8"]];async function Gv(i){if(!i||!i.length)return;try{await document.fonts.load('64px "Tiro Devanagari Marathi"')}catch{}let e=2048,t=[],n=null,s=0,r=0,o=0,a=()=>{let l=document.createElement("canvas");l.width=l.height=e,n={cv:l,g:l.getContext("2d"),quads:[]},t.push(n),s=0,r=0,o=0};a();for(let l of i){let c=Mf[l.style]||Mf.street;if(l.style==="shop"){let m=wf[(l.tone||0)%wf.length];c={bg:m[0],fg:m[1],band:m[1]}}let h=/^metro|temple|heritage|banner|board|gate|balg|kelkar|welcome|dmart|cybage|cerebrum|stanchart/.test(l.style)?128:72,u=Math.min(e,Math.max(h,Math.round(h*l.w/l.h)));s+u>e&&(s=0,r+=o+2,o=0),r+h>e&&a();let d=n.g;d.save(),d.translate(s,r),d.fillStyle=c.bg,d.fillRect(0,0,u,h);let f=Math.max(2,h*.05);d.strokeStyle=c.band,d.lineWidth=f,d.strokeRect(f,f,u-2*f,h-2*f),d.fillStyle=c.fg,d.textAlign="center",d.textBaseline="middle";let g=l.text&&l.text_mr,_=(m,p,y,x)=>{let M=y;for(d.font=p.replace("$",M);M>8&&d.measureText(m).width>u*.88;)M-=1,d.font=p.replace("$",M);d.fillText(m,u/2,x)};l.text_mr&&_(l.text_mr,'600 $px "Tiro Devanagari Marathi", "Noto Sans Devanagari", "Mangal", serif',Math.round(h*(g?.42:.6)),h*(g?.37:.53)),l.text&&_(l.text,"600 $px Inter, system-ui, sans-serif",Math.round(h*(g?.27:.5)),h*(g?.77:.52)),d.restore(),n.quads.push({lb:l,u0:s/e,v0:1-(r+h)/e,u1:(s+u)/e,v1:1-r/e}),s+=u+2,o=Math.max(o,h)}for(let l of t){let c=[],h=[],u=[],d=[],f=(y,x,M,A,T,R,N,b,E)=>{let O=T,W=-A,ne=E?-1:1,I=c.length/3,U=[[-1,-1],[1,-1],[1,1],[-1,1]];for(let[V,K]of U)c.push(y+O*V*ne*R/2,x+K*N/2,M+W*V*ne*R/2),u.push(A*ne,0,T*ne),h.push(V<0?b.u0:b.u1,K<0?b.v0:b.v1);d.push(I,I+1,I+2,I,I+2,I+3)};for(let y of l.quads){let x=y.lb,M=x.nx,A=-x.ny;f(x.x,x.z,-x.y,M,A,x.w,x.h,y,!1),x.back&&f(x.x-M*.04,x.z,-x.y-A*.04,-M,-A,x.w,x.h,y,!0)}let g=new Tt;g.setAttribute("position",new ot(c,3)),g.setAttribute("normal",new ot(u,3)),g.setAttribute("uv",new ot(h,2)),g.setIndex(d);let _=new Rr(l.cv);_.colorSpace=ut,_.anisotropy=4;let m=new et({map:_,emissiveMap:_,emissive:16777215,emissiveIntensity:ph,roughness:.55}),p=new je(g,m);p.receiveShadow=!0,gt.add(p),Lh.push(p)}}var Ae={ctx:null,on:!1,nodes:{},next:{},last:0};function Sf(i,e,t){let n=i.createBuffer(1,i.sampleRate*e,i.sampleRate),s=n.getChannelData(0),r=0;for(let o=0;o<s.length;o++){let a=Math.random()*2-1;t?(r=(r+.02*a)/1.02,s[o]=r*3.5):s[o]=a}return n}function oh(i,e,t,n,s){let r=i.createBufferSource();r.buffer=e,r.loop=!0;let o=i.createBiquadFilter();o.type=t,o.frequency.value=n,o.Q.value=s;let a=i.createGain();return a.gain.value=0,r.connect(o).connect(a).connect(Ae.master),r.start(),a}function Wv(){if(!Ae.ctx){let i=window.AudioContext||window.webkitAudioContext;if(!i)return!1;let e=Ae.ctx=new i;Ae.master=e.createGain(),Ae.master.gain.value=.9;let t=e.createDynamicsCompressor();Ae.master.connect(t).connect(e.destination);let n=Sf(e,4,!0),s=Sf(e,4,!1);Ae.nodes.traffic=oh(e,n,"lowpass",520,.4),Ae.nodes.crowd=oh(e,s,"bandpass",900,.6),Ae.nodes.river=oh(e,s,"lowpass",1400,.3);let r=e.createOscillator();r.type="sawtooth",r.frequency.value=95;let o=e.createBiquadFilter();o.type="lowpass",o.frequency.value=300,Ae.nodes.metro=e.createGain(),Ae.nodes.metro.gain.value=0,r.connect(o).connect(Ae.nodes.metro).connect(Ae.master),r.start(),Ae.nodes.metroOsc=r}return Ae.ctx.resume(),!0}function No(i,e,t){let n=Ae.ctx;for(let[s,r,o]of[[1,1,3.2],[2,.55,2.2],[2.76,.45,1.7],[5.4,.25,.9],[8.93,.12,.5]]){let a=n.createOscillator();a.type="sine",a.frequency.value=t*s*(1+(Math.random()-.5)*.004);let l=n.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(e*r,i+.006),l.gain.exponentialRampToValueAtTime(1e-4,i+o),a.connect(l).connect(Ae.master),a.start(i),a.stop(i+o+.05)}}function Xv(i,e){let t=Ae.ctx,n=330+Math.random()*160,s=.18+Math.random()*.35;for(let r of[1,1.26]){let o=t.createOscillator();o.type="square",o.frequency.value=n*r;let a=t.createBiquadFilter();a.type="lowpass",a.frequency.value=1800;let l=t.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(e,i+.02),l.gain.setValueAtTime(e,i+s),l.gain.exponentialRampToValueAtTime(1e-4,i+s+.06),o.connect(a).connect(l).connect(Ae.master),o.start(i),o.stop(i+s+.1)}}function qv(i,e){let t=Ae.ctx,n=t.createOscillator(),s=t.createGain();n.type="sine",n.frequency.setValueAtTime(110,i),n.frequency.exponentialRampToValueAtTime(55,i+.18),s.gain.setValueAtTime(1e-4,i),s.gain.exponentialRampToValueAtTime(e,i+.01),s.gain.exponentialRampToValueAtTime(1e-4,i+.35),n.connect(s).connect(Ae.master),n.start(i),n.stop(i+.4)}function Yv(i,e,t){let n=Ae.ctx,s=n.createOscillator(),r=n.createGain();if(s.type="sine",t){s.frequency.value=4300+Math.random()*300;for(let o=0;o<4;o++)r.gain.setValueAtTime(1e-4,i+o*.06),r.gain.exponentialRampToValueAtTime(e,i+o*.06+.01),r.gain.exponentialRampToValueAtTime(1e-4,i+o*.06+.045);s.start(i),s.stop(i+.3)}else{let o=2400+Math.random()*1800;s.frequency.setValueAtTime(o,i),s.frequency.exponentialRampToValueAtTime(o*(1.3+Math.random()*.5),i+.08),s.frequency.exponentialRampToValueAtTime(o*.9,i+.16),r.gain.setValueAtTime(1e-4,i),r.gain.exponentialRampToValueAtTime(e,i+.02),r.gain.exponentialRampToValueAtTime(1e-4,i+.17),s.start(i),s.stop(i+.2)}s.connect(r).connect(Ae.master)}var Js={temples:[],markets:[],river:[]};function Kv(i,e){if(!ct)return 200;let t=1e9;for(let[n,s,r,o,a,l]of ct.roads){if(l!==0||a<5||Math.abs(n-i)>120&&Math.abs(r-i)>120||Math.abs(s-e)>120&&Math.abs(o-e)>120)continue;let c=r-n,h=o-s,u=c*c+h*h||1,d=Math.max(0,Math.min(1,((i-n)*c+(e-s)*h)/u));t=Math.min(t,Math.hypot(n+c*d-i,s+h*d-e)-a/2)}return Math.max(0,t)}function lh(i,e,t){let n=1e9;for(let s of i)n=Math.min(n,Math.hypot(s.x-e,s.z-t));return n}function jv(i,e){if(!Ae.on||!Ae.ctx||i-Ae.last<250)return;Ae.last=i;let t=Ae.ctx,n=t.currentTime,r=1/(1+Math.max(0,e.y-2)/40),o=tr[nr].night,a=Kv(e.x,e.z),l=(.55-o*.3)*r/(1+a/18);Ae.nodes.traffic.gain.setTargetAtTime(.1*l+.012,n,.6);let c=lh(Js.temples,e.x,e.z),h=lh(Js.markets,e.x,e.z);Ae.nodes.crowd.gain.setTargetAtTime(.035*r*(1-o*.5)/(1+Math.min(h,c)/35),n,.8),Ae.nodes.river.gain.setTargetAtTime(.03*r/(1+lh(Js.river,e.x,e.z)/25),n,.8);let u=0;for(let g of Gr){if(g.state!=="run"||g.v<.5)continue;let _=g.cars[1].visible?g.cars[1].position:null;_&&(u=Math.max(u,g.v/Jf/(1+_.distanceTo(e)/40)))}Ae.nodes.metro.gain.setTargetAtTime(.05*u*r,n,.3),Ae.nodes.metroOsc.frequency.setTargetAtTime(70+u*90,n,.3);let d=(g,_,m)=>(Ae.next[g]||(Ae.next[g]=n+_+Math.random()*(m-_)),n>=Ae.next[g]),f=(g,_,m)=>{Ae.next[g]=n+_+Math.random()*(m-_)};if(c<160&&d("bell",2.5,7)){let g=.22*r/(1+c/25),_=620+Math.random()*260;No(n+.02,g,_),Math.random()<.5&&No(n+.45+Math.random()*.3,g*.8,_),f("bell",3,9)}if(o>.3&&c<140&&d("aarti",6,14)){let g=.2*r/(1+c/30);for(let _=0;_<8;_++)qv(n+.05+_*.42+_%2*.06,g*(_%2?.6:1));f("aarti",18,35)}if(d("horn",5,14)&&(l>.05&&Math.random()<.7&&Xv(n+.01,.03*l/.55),f("horn",5,16+o*20)),d("bird",1.5,5)){let g=(o>.5?.012:.02)*r;for(let _=0;_<(o>.5?2:1+Math.floor(Math.random()*3));_++)Yv(n+_*.22,g,o>.5);f("bird",o>.5?.8:2,o>.5?2.5:7)}}pe("sound").addEventListener("click",()=>{if(Ae.on)Ae.on=!1,Ae.master&&(Ae.master.gain.value=0);else{if(!Wv()){pe("soundLabel").textContent="No sound here";return}Ae.on=!0,Ae.master.gain.value=.9}pe("sound").setAttribute("aria-pressed",String(Ae.on)),pe("sound").setAttribute("aria-label",Ae.on?"Sound on. Tap to turn it off.":"Sound off. Tap for temple bells, traffic and birds.")});document.addEventListener("visibilitychange",()=>{Ae.ctx&&(document.hidden?Ae.ctx.suspend():Ae.on&&Ae.ctx.resume())});var Bn=Cn.stops||[{land:"Shaniwar Wada",mr:"\u0936\u0928\u093F\u0935\u093E\u0930 \u0935\u093E\u0921\u093E",en:"Shaniwar Wada",bearing:200,r:150,h:95,note:"Seat of the Peshwas, completed in 1732 for Bajirao I. The palace inside burned in 1828; the walls and gates still stand."},{land:"Dilli Darwaza",mr:"\u0926\u093F\u0932\u094D\u0932\u0940 \u0926\u0930\u0935\u093E\u091C\u093E",en:"Dilli Darwaza",bearing:340,r:55,h:22,note:"The main gate faces north, towards Delhi. Its doors carry rows of iron spikes against war elephants."},{land:"Bajirao I statue",mr:"\u0925\u094B\u0930\u0932\u0947 \u092C\u093E\u091C\u0940\u0930\u093E\u0935 \u092A\u0947\u0936\u0935\u0947",en:"Bajirao I on horseback",bearing:20,r:30,h:12,note:"The equestrian statue of Bajirao I stands in the garden before the main gate."},{land:"Lal Mahal",mr:"\u0932\u093E\u0932 \u092E\u0939\u093E\u0932",en:"Lal Mahal",bearing:120,r:60,h:30,note:"Rebuilt on the site of the house where Shivaji Maharaj grew up with Jijabai."},{land:"Kasba Ganpati",mr:"\u0917\u094D\u0930\u093E\u092E\u0926\u0948\u0935\u0924 \u0936\u094D\u0930\u0940 \u0915\u0938\u092C\u093E \u0917\u0923\u092A\u0924\u0940",en:"Kasba Ganpati",bearing:250,r:40,h:20,note:"Pune\u2019s guardian deity, the first of the city\u2019s honoured Ganpatis, whose temple Jijabai is said to have built. The timber front has three storeys of carved galleries."},{land:"Nana Wada",mr:"\u0928\u093E\u0928\u093E \u0935\u093E\u0921\u093E",en:"Nana Wada",bearing:75,r:55,h:26,note:"Built in 1780 by Nana Phadnavis, the Peshwas\u2019 chief minister; it later housed a school. Its whitewashed front with cusped niches faces Shivaji Road."},{land:"Dagdusheth Ganpati",mr:"\u0936\u094D\u0930\u0940\u092E\u0902\u0924 \u0926\u0917\u0921\u0942\u0936\u0947\u0920 \u0939\u0932\u0935\u093E\u0908 \u0917\u0923\u092A\u0924\u0940",en:"Dagdusheth Halwai Ganpati",bearing:60,r:55,h:26,note:"Pune\u2019s best-known Ganesh temple, founded by the sweet-maker Dagdusheth Gadve."},{land:"Bhide Wada",mr:"\u092D\u093F\u0921\u0947 \u0935\u093E\u0921\u093E",en:"Bhide Wada",bearing:250,r:45,h:24,note:"Here, in 1848, Savitribai and Jyotirao Phule opened their first school for girls. A national memorial is being built on the site."},{land:"Kesari Wada",mr:"\u0915\u0947\u0938\u0930\u0940 \u0935\u093E\u0921\u093E",en:"Kesari Wada",bearing:30,r:50,h:28,note:"Lokmanya Tilak\u2019s home, where he edited his papers Kesari and Maratha. His house in the courtyard is now a museum."},{land:"Laxmi Road",mr:"\u0932\u0915\u094D\u0937\u094D\u092E\u0940 \u0930\u0938\u094D\u0924\u093E",en:"Laxmi Road",bearing:160,r:60,h:28,note:"Pune\u2019s busiest shopping street: jewellers, sari and cloth shops, hawkers and rows of scooters."},{land:"Vishrambaug Wada",mr:"\u0935\u093F\u0936\u094D\u0930\u093E\u092E\u092C\u093E\u0917 \u0935\u093E\u0921\u093E",en:"Vishrambaug Wada",bearing:80,r:60,h:30,note:"Built in 1807 for Peshwa Bajirao II, famed for its carved teak balcony. It houses a post office and a museum."},{land:"Tulshibaug Ram Mandir",mr:"\u0924\u0941\u0933\u0936\u0940\u092C\u093E\u0917 \u0930\u093E\u092E \u092E\u0902\u0926\u093F\u0930",en:"Tulshibaug Ram Mandir",bearing:110,r:70,h:45,note:"An 18th-century Ram temple with a tall spire, at the heart of the Tulshibaug market lanes."},{land:"Mahatma Phule Mandai",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u092B\u0941\u0932\u0947 \u092E\u0902\u0921\u0908",en:"Mahatma Phule Mandai",bearing:30,r:75,h:40,note:"Pune\u2019s great vegetable market hall, opened in 1886, with its tall octagonal central tower."},{land:"Omkareshwar Mandir",mr:"\u0913\u0902\u0915\u093E\u0930\u0947\u0936\u094D\u0935\u0930 \u092E\u0902\u0926\u093F\u0930",en:"Omkareshwar Mandir",bearing:120,r:75,h:38,note:"An 18th-century Shiva temple of the Peshwa era on the Mutha, with a tall painted shikhara and ghats down to the river."},{land:"Balgandharva Rangmandir",mr:"\u092C\u093E\u0932\u0917\u0902\u0927\u0930\u094D\u0935 \u0930\u0902\u0917\u092E\u0902\u0926\u093F\u0930",en:"Balgandharva Rangmandir",bearing:330,r:70,h:32,note:"The city\u2019s best-known theatre, named after the singer-actor Bal Gandharva, at the head of JM Road across the river from the old city."},{land:"PMC Bhavan metro",mr:"\u092A\u0941\u0923\u0947 \u092E\u0928\u092A\u093E \u092E\u0947\u091F\u094D\u0930\u094B \u0938\u094D\u0925\u093E\u0928\u0915",en:"PMC Bhavan metro station",bearing:150,r:90,h:40,note:"Aqua Line station by the Mutha river. Its facade borrows the cusped arches of Pune\u2019s old wadas."}],st={on:!1,i:0,playing:!0,phase:"fly",t:0,DWELL:7,angle:0};function $v(i){let e=ct?.landmarks.find(r=>r.name===i.land);if(!e)return null;let t=Dt.degToRad(i.bearing),n=new C(e.x,i.h>60?6:8,e.z);return{pos:n.clone().add(new C(Math.sin(t)*i.r,i.h,-Math.cos(t)*i.r)),target:n}}function Zv(i){let e=Bn[i];pe("tourMr").textContent=e.mr,pe("tourEn").textContent=e.en,pe("tourNote").textContent=e.note,pe("tourCount").textContent=`${i+1} / ${Bn.length}`}function er(i){st.i=(i+Bn.length)%Bn.length;let e=$v(Bn[st.i]);Zv(st.i),e&&(tt==="walk"&&ss("orbit",!1),st.phase="fly",st.t=0,st.angle=0,Yr(e.pos,e.target,{arc:Math.min(90,Me.position.distanceTo(e.pos)*.16),dur:Pn?.01:void 0,done:()=>{st.phase="dwell",st.t=0}}))}function Jv(){ct&&(st.on=!0,st.playing=!0,pe("tour").hidden=!1,document.body.classList.add("touring"),jr(),pe("tourPlay").innerHTML="&#10073;&#10073;",pe("tourPlay").setAttribute("aria-label","Pause the tour"),er(0))}function $r(){st.on=!1,pe("tour").hidden=!0,document.body.classList.remove("touring"),jr()}function Qv(i){if(!(!st.on||st.phase!=="dwell"||bt)){if(!Pn){let e=i*Dt.degToRad(5),t=Me.position.clone().sub(nt.target);t.applyAxisAngle(new C(0,1,0),e),Me.position.copy(nt.target).add(t)}st.playing&&(st.t+=i,st.t>st.DWELL&&er(st.i+1))}}pe("tourNext").addEventListener("click",()=>er(st.i+1));pe("tourPrev").addEventListener("click",()=>er(st.i-1));pe("tourEnd").addEventListener("click",$r);pe("tourPlay").addEventListener("click",()=>{st.playing=!st.playing,pe("tourPlay").innerHTML=st.playing?"&#10073;&#10073;":"&#9654;",pe("tourPlay").setAttribute("aria-label",st.playing?"Pause the tour":"Continue the tour")});Ut.addEventListener("pointerdown",()=>{st.on&&st.playing&&pe("tourPlay").click()});window.addEventListener("keydown",i=>{st.on&&(i.key==="Escape"&&$r(),i.key==="ArrowRight"&&tt!=="walk"&&er(st.i+1),i.key==="ArrowLeft"&&tt!=="walk"&&er(st.i-1))});{let i=document.createElement("button");i.type="button",i.className="tourBtn",i.textContent="\u2708 Aerial tour",i.setAttribute("aria-label","Aerial tour of all the places, one stop at a time"),i.addEventListener("click",Jv),Dh.prepend(i)}var eb=Cn.landView||{"Shaniwar Wada":"fort","Dilli Darwaza":"gate","Bajirao I statue":"streetview","Lal Mahal":"lalmahal","Dagdusheth Ganpati":"dagdusheth","Tulshibaug Ram Mandir":"tulshibaug","PMC Bhavan metro":"metro","Vishrambaug Wada":"vishrambaug","Nana Wada":"nana","Bhide Wada":"bhide","Omkareshwar Mandir":"omkareshwar","Laxmi Road":"laxmi","Kasba Ganpati":"kasbaganpati","Mahatma Phule Mandai":"mandai","Balgandharva Rangmandir":"balgandharva","Kesari Wada":"kesari","Kelkar Museum":"kelkar"},yh=[];function tb(i){Xo=i,pe("hand").setAttribute("aria-pressed",String(i)),nt.mouseButtons=i?{LEFT:hn.PAN,MIDDLE:hn.DOLLY,RIGHT:hn.ROTATE}:{LEFT:hn.ROTATE,MIDDLE:hn.DOLLY,RIGHT:hn.PAN},nt.touches=i?{ONE:Tn.PAN,TWO:Tn.DOLLY_ROTATE}:{ONE:Tn.ROTATE,TWO:Tn.DOLLY_PAN},i&&tt==="walk"&&ss("orbit"),Yo()}nt.screenSpacePanning=!1;pe("hand").addEventListener("click",()=>tb(!Xo));var Qt={level:kn?1:0,frames:0,time:0,calm:0},nb=[26e5,17e5,11e5,75e4];function Uo(){let i=Qt.level;xh=[450,300,220,180][i];let e=Math.max(1,Ut.clientWidth*Ut.clientHeight),t=Math.min(window.devicePixelRatio||1,[2,1.5,1.25,1][i],Math.sqrt(nb[i]/e));if(ln.setPixelRatio(Math.max(.6,t)),Uf=[1,1,2,3][i],xi)for(let n of xi.groups)for(let s of n.meshes)s.castShadow=i===0&&s.material!==Vo&&s.material!==Go}function ib(i){if(Qt.frames++,Qt.time+=i,Qt.time<2)return;let e=Qt.frames/Qt.time;Qt.frames=0,Qt.time=0,!document.hidden&&(e<40&&Qt.level<3?(Qt.level++,Qt.calm=0,Uo()):e>57&&Qt.level>(kn?1:0)?++Qt.calm>=3&&(Qt.level--,Qt.calm=0,Uo()):Qt.calm=0)}var sb=new io,Ef=new Ir(new C,new C(0,-1,0),0,8),fi=new C,ae={guide:null,extras:[],pairs:[],pending:null,spot:null,t:0,ready:!1,view:null,greeted:new Set,said:-99,bubble:null,bubbleUntil:0},Tf=["point_up","thumbs_up","victory","think","present","stop","temple","surprised","wave","talk","talk","laugh","clap","look_around","phone"],rb=new Set(["wave","namaste","present","talk","point_up","thumbs_up","victory","stop","clap","laugh"]),Qf={look_around:0,laugh:.15,namaste:.25,phone:.35,walk_phone:0,think:.6,temple:.6},ep={namaste:[["\u0928\u092E\u0938\u094D\u0915\u093E\u0930!","Welcome to {place}."]],wave:[["\u0928\u092E\u0938\u094D\u0915\u093E\u0930!","Hello! Come, let me show you round."],["\u091A\u0932\u093E!","Come along!"]],point_up:[["\u0935\u0930 \u092A\u093E\u0939\u093E!","Look up there!"]],present:[["\u0939\u0947 \u092A\u093E\u0939\u093E!","Here it is: {view}."]],thumbs_up:[["\u091B\u093E\u0928!","Lovely, isn\u2019t it?"]],victory:[["\u092E\u0938\u094D\u0924!","A perfect spot for a photo!"]],think:[["\u0939\u092E\u094D\u092E\u2026","Let me remember the story\u2026"]],surprised:[["\u0905\u0930\u0947 \u0935\u093E!","Wow, look at that!"]],stop:[["\u0925\u093E\u0902\u092C\u093E!","Wait here a moment."]],temple:[["\u0932\u0915\u094D\u0937\u093E\u0924 \u0920\u0947\u0935\u093E!","Remember this one!"]],talk:[["\u0910\u0915\u093E\u2026","{fact}"]],laugh:[["\u0939\u093E \u0939\u093E!","Ha ha!"]],clap:[["\u0935\u093E!","Bravo!"]],look_around:[["\u0915\u093F\u0924\u0940 \u0938\u0941\u0902\u0926\u0930!","How beautiful it is here!"]],phone:[["\u0939\u0945\u0932\u094B?","Hello? Yes, I\u2019m at {place}. Come over!"]]},ab={E1:"office",E2:"western",E3:"saree",E4:"elder",E5:"student"},qt=new C,xo=new C,Af=new C,yo=new C,vo=new xt,bo=new xt,Rf=new C(1,0,0),Cf=new C(0,1,0);function Oo(i,e,t){let n=!1;for(let s=0,r=t.length-2;s<t.length;r=s,s+=2){let o=t[s],a=t[s+1],l=t[r],c=t[r+1];a>e!=c>e&&i<(l-o)*(e-a)/(c-a)+o&&(n=!n)}return n}function yi(i,e,t=!1){if(!ct)return!0;for(let n=0;n<ct.buildings.length;n++){let s=ct.bc[n];if(!(Math.abs(s[0]-i)>40||Math.abs(s[1]-e)>40)&&Oo(i,e,ct.buildings[n]))return!1}for(let n of ct.water||[])if(Oo(i,e,n))return!1;for(let n=0;n<Yt.length;n+=3)if(Math.abs(Yt[n]-i)<Yt[n+2]&&Math.abs(Yt[n+1]-e)<Yt[n+2])return!1;if(t)for(let n of ct.roads||[]){let[s,r,o,a,l]=n;if(Math.min(s,o)-l>i||Math.max(s,o)+l<i||Math.min(r,a)-l>e||Math.max(r,a)+l<e)continue;let c=o-s,h=a-r,u=c*c+h*h||1,d=Math.max(0,Math.min(1,((i-s)*c+(e-r)*h)/u));if(Math.hypot(s+c*d-i,r+h*d-e)<l/2+.5)return!1}return!0}function Ht(i,e,t=!1,n=.35){let s=i.clips[e];if(!s)return 0;let r=i.mixer.clipAction(s);return r.reset(),r.timeScale=1,r.setLoop(t?vc:yc,1/0),r.clampWhenFinished=!t,r.enabled=!0,r.setEffectiveWeight(1),i.cur&&i.cur!==r&&r.crossFadeFrom(i.cur,n,!1),r.play(),i.cur=r,i.act=e,s.duration}function ch(i,e){let t=null;return i.traverse(n=>{!t&&n.isBone&&n.name.replace(/[.\s]/g,"")===e&&(t=n)}),t}async function ob(){try{let i=await fetch("wada_characters.glb.txt");if(!i.ok)return;let e=await kf.parseAsync(Vf(await i.text()),""),t=new et({vertexColors:!0,roughness:.72,metalness:0}),n=new et({vertexColors:!0,roughness:.12,metalness:.5}),s=new Xt(.068,.142,.009),r=new Qi(.06,.128),o=new et({color:1447964,roughness:.35,metalness:.3}),a=new Wt({color:10273791}),l=[];e.scene.traverse(h=>{if(/^Char_(G|E\d)$/.test(h.name)&&l.push(h),h.isMesh){let u=h.geometry;u.attributes.color_1&&Ih(u.attributes.color)&&u.setAttribute("color",u.attributes.color_1),h.material=/Glass/.test(h.material?.name||"")?n:t,h.castShadow=!0,h.receiveShadow=!0,h.frustumCulled=!1}});for(let h of l){let u=h.name.slice(5),d=u+"_",f={};for(let m of e.animations)m.name.startsWith(d)&&(f[m.name.slice(d.length)]=m);h.removeFromParent(),h.position.set(0,0,0),h.visible=!1,gt.add(h);let g={root:h,clips:f,id:u,kind:ab[u]||"guide",mixer:new so(h),cur:null,act:"",mode:"idle",until:0,yaw:0,ang:Math.random()*6.28,dirSign:Math.random()<.5?-1:1,r:5,centre:new C,target:new C,lastWave:-99,lastGreet:-99,n:0,head:ch(h,d+"head"),neck:ch(h,d+"neck"),lookW:0,lookYaw:0,lookPitch:0,glance:!1,glanceUntil:0,turning:!1,faceCam:!1,phone:null,pair:null,walkClip:u==="E5"?"walk_phone":"walk",pace:u==="E4"?.82:1,speed:u==="E4"?1:1.25},_=ch(h,d+"handR");if(_){let m=new Jt,p=new je(r,a);p.position.z=-.0047,p.rotation.y=Math.PI,m.add(new je(s,o),p),m.position.set(0,.07,-.021),m.visible=!1,_.add(m),g.phone=m}d==="G_"?ae.guide=g:ae.extras.push(g)}let c=Object.fromEntries(ae.extras.map(h=>[h.id,h]));for(let[h,u]of[["E1","E2"],["E3","E4"]]){if(!c[h]||!c[u])continue;let d={members:[c[h],c[u]],state:"apart",next:0,end:0,talker:null,turnEnd:0,phase:"talk",giveUp:0};c[h].pair=c[u].pair=d,ae.pairs.push(d)}ae.bubble=document.getElementById("bubble"),ae.ready=!!ae.guide,window.__wadaCast=()=>({guide:ae.guide&&{mode:ae.guide.mode,act:ae.guide.act,vis:ae.guide.root.visible,x:+ae.guide.root.position.x.toFixed(2),z:+ae.guide.root.position.z.toFixed(2),look:[+ae.guide.lookYaw.toFixed(2),+ae.guide.lookPitch.toFixed(2)],phone:!!ae.guide.phone?.visible},extras:ae.extras.map(h=>`${h.id}:${h.mode}/${h.act}${h.root.visible?"":" (hidden)"}${h.phone?.visible?" +phone":""}`),pairs:ae.pairs.map(h=>h.state),bubble:ae.bubble.hidden?"":ae.bubble.textContent}),window.__wadaAct=h=>Wr(ae.guide,h),window.__wadaCastDbg=()=>({t:+ae.t.toFixed(2),spot:!!ae.spot,ex:ae.extras.map(h=>[h.id,h.mode,+h.until.toFixed(1),h.root.visible,+h.root.position.distanceTo(Me.position).toFixed(1)]),pairs:ae.pairs.map(h=>[h.state,+h.next.toFixed(1)])}),window.__wadaNearGuide=(h=3,u=0)=>{let d=ae.guide,f=d.root.position,g=Math.sin(d.yaw),_=Math.cos(d.yaw);window.__wadaLook(f.x+g*h+_*u,f.y+1.55,f.z+_*h-g*u,f.x,f.y+1.25,f.z)},window.__wadaMeet=()=>ae.pairs.map(h=>{h.next=0;for(let u of h.members)u.until=0;return h.state}),ae.pending&&np(...ae.pending)}catch{}}function Bi(i,e,t=1){let n=e-i.yaw;n=Math.atan2(Math.sin(n),Math.cos(n)),i.yaw+=n*t,i.root.rotation.y=i.yaw}function tp(i,e,t){if(!i.head||!i.neck||(i.lookW+=(t-i.lookW)*Math.min(1,e*3),i.lookW<.01&&Math.abs(i.lookYaw)<.01))return;i.root.updateMatrixWorld(),qt.copy(Me.position),i.root.worldToLocal(qt);let n=qt.x,s=qt.y-1.6,r=qt.z,o=Math.atan2(n,r),a=-Math.atan2(s,Math.hypot(n,r));Math.abs(o)>2&&(o=0,a=0),o=Dt.clamp(o,-1.15,1.15)*i.lookW,a=Dt.clamp(a,-.5,.35)*i.lookW;let l=Math.min(1,e*5);i.lookYaw+=(o-i.lookYaw)*l,i.lookPitch+=(a-i.lookPitch)*l,vo.setFromAxisAngle(Cf,i.lookYaw*.4),bo.setFromAxisAngle(Rf,i.lookPitch*.4),i.neck.quaternion.multiply(vo).multiply(bo),vo.setFromAxisAngle(Cf,i.lookYaw*.6),bo.setFromAxisAngle(Rf,i.lookPitch*.6),i.head.quaternion.multiply(vo).multiply(bo)}function lb(){if(!Bn.length)return"This is one of Pune\u2019s best-loved places.";let i=ae.view?.id,e=(ae.view?.label||"").toLowerCase(),n=(Bn.find(s=>Cn.landView?.[s.land]===i)||Bn.find(s=>e&&(e.includes(s.en.toLowerCase())||s.en.toLowerCase().includes(e)))||Bn[Math.floor(Math.random()*Bn.length)]).note.split(/(?<=[.!?])\s/)[0];return n.length>150&&(n=n.slice(0,n.lastIndexOf(" ",146))+"\u2026"),n}function cb(i){let e=ep[i],t=ae.bubble;if(!e||!t)return;let[n,s]=e[Math.floor(Math.random()*e.length)],r=(Cn.en||"").split(/[:,]/)[0].trim(),o=ae.view?.label||r;t.querySelector(".mr").textContent=n,t.querySelector(".en").textContent=s.replace("{place}",r).replace("{view}",o).replace("{fact}",()=>lb()),t.hidden=!1,ae.bubbleUntil=ae.t+(i==="talk"?6:3.6),ae.said=ae.t}function Pf(){let i=ae.bubble,e=ae.guide;if(!i||i.hidden)return;if(ae.t>ae.bubbleUntil||!e.root.visible){i.classList.remove("on"),(ae.t>ae.bubbleUntil+.4||!e.root.visible)&&(i.hidden=!0);return}qt.copy(e.root.position),qt.y+=2;let t=qt.distanceTo(Me.position);if(qt.project(Me),qt.z>1||Math.abs(qt.x)>1.02||qt.y>1.02||qt.y<-1||t>90){i.classList.remove("on");return}let n=(i.offsetWidth||200)/2+8,s=Math.min(innerWidth-n,Math.max(n,(qt.x*.5+.5)*innerWidth)),r=(-qt.y*.5+.5)*innerHeight;i.style.transform=`translate(${s.toFixed(1)}px, ${r.toFixed(1)}px) translate(-50%, -100%)`,i.classList.add("on")}function Wr(i,e){i.mode="gesture",i.until=ae.t+Ht(i,e)-.25,rb.has(e)&&(i.turning=!0),ep[e]&&ae.t-ae.said>6&&(e==="namaste"||e==="talk"||e==="phone"||Math.random()<.65)&&cb(e)}function np(i,e){if(!ae.ready){ae.pending=[i,e];return}ae.view=e||null,ae.bubble&&(ae.bubble.hidden=!0,ae.bubble.classList.remove("on")),ae.bubbleUntil=0;let t=[ae.guide,...ae.extras],n=i.pos,s=i.dir.clone();if(s.y=0,n.y-Kt(n.x,n.z)>30||s.lengthSq()<1e-6){for(let _ of t)_.root.visible=!1;ae.spot=null;return}s.normalize();let o=new C(-s.z,0,s.x),a=document.getElementById("views"),l=a?a.getBoundingClientRect().top:innerHeight*.75,c=1-2*Math.max(.3,Math.min(.92,(l-12)/innerHeight)),h=(_,m)=>{let p=Me.clone();p.position.copy(n),p.lookAt(_),p.updateMatrixWorld(!0),p.updateProjectionMatrix();for(let y of[.32,-.32,.18])for(let x=5;x<=45;x*=1.15){let M=n.clone().addScaledVector(s,x).addScaledVector(o,y*x);M.y=Kt(M.x,M.z);let A=M.clone().project(p),T=M.clone().add(new C(0,1.8,0)).project(p);if(A.y>c&&T.y<.95&&Math.abs(A.x)<.8&&A.z<1&&yi(M.x,M.z,m))return M}return null},u=h(i.target,!0)||h(i.target,!1);if(!u){let _=i.target.clone().sub(n),m=_.length(),p=Math.atan2(_.y,Math.hypot(_.x,_.z)),y=Math.max(.07,p-.12);if(y<p){let x=n.clone().addScaledVector(s,Math.cos(y)*m).add(new C(0,Math.sin(y)*m,0));u=h(x,!0)||h(x,!1),u&&i.target.copy(x)}}if(!u){for(let _ of t)_.root.visible=!1;ae.spot=null;return}u.y=Kt(u.x,u.z),ae.spot=u;let d=ae.guide;d.root.position.copy(u),d.root.visible=!0,Bi(d,Math.atan2(n.x-u.x,n.z-u.z));let f=!ae.greeted.has(zn);ae.greeted.add(zn),ae.said=-99,Wr(d,f?"namaste":Math.random()<.6?"present":"wave"),d.lastWave=ae.t;let g=0;for(let _ of ae.pairs)_.state="apart",_.next=ae.t+5+Math.random()*8+6*ae.pairs.indexOf(_);for(let _ of ae.extras){let m=!1,p=_.pair&&_.pair.members[1]===_&&_.pair.members[0].root.visible?_.pair.members[0]:null;for(let M=0;M<48&&!m;M++){let A=M>=24,T=Math.random()*6.28,R=p&&M<16?4+Math.random()*5:A?6+Math.random()*30:9+Math.random()*14,N=(p&&M<16?p.centre:u).clone().add(new C(Math.cos(T)*R,0,Math.sin(T)*R));if(N.clone().sub(n).dot(s)<(A?-4:2))continue;let b=A?2.5+Math.random()*2.5:3+Math.random()*4;m=!0;for(let E=0;E<12&&m;E++){let O=E/12*6.28;yi(N.x+Math.cos(O)*b,N.z+Math.sin(O)*b)||(m=!1)}m&&(_.centre.copy(N),_.r=b)}if(_.root.visible=m,!m)continue;let y=_.centre.x+Math.cos(_.ang)*_.r,x=_.centre.z+Math.sin(_.ang)*_.r;_.root.position.set(y,Kt(y,x),x),_.mode="walk",_.faceCam=!1,_.until=ae.t+6+Math.random()*10+g*2,Ht(_,_.walkClip,!0,.2),_.cur.time=Math.random()*.9,_.cur.timeScale=_.pace,g++}}function ip(i,e){xo.set(-Math.sin(X.yaw),0,-Math.cos(X.yaw)),Af.set(-xo.z,0,xo.x);let t=null;for(let[o,a]of[[1.3,1.7],[-1.3,1.7],[1.5,.5],[-1.5,.5]])if(yo.copy(X.pos).addScaledVector(Af,o).addScaledVector(xo,a),yi(yo.x,yo.z)){t=yo;break}if(!t)return!1;t.y=Kt(t.x,t.z);let n=qt.copy(t).sub(i.root.position);n.y=0;let s=n.length();if(!i.root.visible||s>30)return i.root.position.copy(t),i.root.visible=!0,ae.spot||(ae.spot=t.clone()),i.mode="idle",i.until=ae.t+1.5,Ht(i,"idle",!0),!0;let r=X.keys.size>0||!!X.glide;if(i.mode==="follow"?s>.12:s>(r?.6:1.8)){i.mode!=="follow"&&(i.mode="follow",Ht(i,"walk",!0,.25));let o=Math.min(j.on?8.5:5.2,Math.max(.9,s*1.8));return n.multiplyScalar(Math.min(s,o*e)/s),i.root.position.add(n),i.root.position.y=Kt(i.root.position.x,i.root.position.z),Bi(i,Math.atan2(n.x,n.z),Math.min(1,e*8)),i.cur&&(i.cur.timeScale=Dt.clamp(o/1.2,.7,2.6)),!0}return i.mode==="follow"&&(i.mode="idle",i.until=ae.t+1.5+Math.random()*2,Ht(i,"idle",!0)),!1}function hb(i,e,t,n){if(tt==="walk"&&ip(i,e))return;if(i.mode==="walk"){let a=i.target.clone().sub(i.root.position);a.y=0;let l=a.length();l<.08?(i.mode="idle",i.until=t+.8,Ht(i,"idle",!0)):(a.multiplyScalar(Math.min(l,1.2*e)/l),i.root.position.add(a),i.root.position.y=Kt(i.root.position.x,i.root.position.z),Bi(i,Math.atan2(a.x,a.z),Math.min(1,e*8)));return}let s=Math.atan2(n.x-i.root.position.x,n.z-i.root.position.z),r=Math.atan2(Math.sin(s-i.yaw),Math.cos(s-i.yaw));Math.abs(r)>.75&&(i.turning=!0),i.turning&&(Bi(i,s,Math.min(1,e*3)),Math.abs(r)<.1&&(i.turning=!1));let o=i.root.position.distanceTo(n)<9;if(tt!=="walk"&&o&&i.mode==="idle"&&t-i.lastWave>25)Wr(i,Math.random()<.5?"wave":"namaste"),i.lastWave=t;else if(t>i.until){if(i.mode==="gesture")i.mode="idle",i.until=t+(Pn?1e9:1.6+Math.random()*2.6),Ht(i,"idle",!0);else if(!Pn){if(i.n++,tt!=="walk"&&i.n%5===0){let l=new C(-(n.z-i.root.position.z),0,n.x-i.root.position.x).normalize(),c=ae.spot.clone().addScaledVector(l,(Math.random()<.5?-1:1)*(1.5+Math.random()*2.5));if(yi(c.x,c.z)){i.target.copy(c),i.mode="walk",Ht(i,"walk",!0);return}}let a=Tf[Math.floor(Math.random()*Tf.length)];a===i.act&&(a="talk"),Wr(i,a)}}}function Lf(i,e,t,n){let s=qt.copy(e).sub(i.root.position);s.y=0;let r=s.length();return r<.06?!0:(s.multiplyScalar(Math.min(r,t*n)/r),i.root.position.add(s),i.root.position.y=Kt(i.root.position.x,i.root.position.z),Bi(i,Math.atan2(s.x,s.z),Math.min(1,n*8)),!1)}function vh(i,e){i.mode="walk",i.faceCam=!1,Ht(i,i.walkClip,!0),i.cur.timeScale=i.pace,i.until=e+10+Math.random()*14}function ub(i,e){for(let t=0;t<8;t++){let n=Math.random()*6.28,s=i.root.position.clone().add(new C(-Math.cos(n)*i.r,0,-Math.sin(n)*i.r)),r=!0;for(let o=0;o<12&&r;o++){let a=o/12*6.28;yi(s.x+Math.cos(a)*i.r,s.z+Math.sin(a)*i.r)||(r=!1)}if(r){i.centre.copy(s),i.ang=n,vh(i,e);return}}i.ang=Math.atan2(i.root.position.z-i.centre.z,i.root.position.x-i.centre.x),i.target.set(i.centre.x+Math.cos(i.ang)*i.r,0,i.centre.z+Math.sin(i.ang)*i.r),vh(i,e),i.mode="return"}function db(i,e){let[t,n]=i.members,s=t.root.position.distanceTo(n.root.position),r=n.root.position.clone().sub(t.root.position).setY(0).normalize(),o=l=>yi(l.x,l.z)&&yi(l.x+r.x*.7,l.z+r.z*.7)&&yi(l.x-r.x*.7,l.z-r.z*.7),a=[t.root.position.clone().add(n.root.position).multiplyScalar(.5),t.root.position.clone(),n.root.position.clone()].find(o);return s>40||!a?!1:(t.target.copy(a).addScaledVector(r,-.55),n.target.copy(a).addScaledVector(r,.55),t.mode=n.mode="goto",i.state="meeting",i.giveUp=e+30,!0)}function If(i,e){i.state="apart",i.next=e+25+Math.random()*25;for(let t of i.members)ub(t,e)}function fb(i,e){let[t,n]=i.members;if(i.state==="meeting")t.mode==="wait"&&n.mode==="wait"?(i.state="chat",i.end=e+15+Math.random()*12,i.talker=Math.random()<.5?t:n,i.phase="talk",i.turnEnd=e+3+Math.random()*3,t.mode=n.mode="chat",Ht(i.talker,"talk",!0),Ht(i.talker===t?n:t,"idle",!0)):e>i.giveUp&&If(i,e);else if(i.state==="chat"){if(e>i.end){If(i,e);return}if(e<i.turnEnd)return;let s=i.talker===t?n:t;if(i.phase==="talk"&&Math.random()<.4)i.phase="laugh",Ht(s,"laugh"),Ht(i.talker,Math.random()<.5?"laugh":"idle",!1),i.turnEnd=e+2.7;else{i.phase="talk",i.talker=s,Ht(s,"talk",!0);let r=s===t?n:t,o=Math.random();Ht(r,o<.15?"thumbs_up":o<.3?"think":"idle",o>=.3),i.turnEnd=e+3+Math.random()*3.5}}}function pb(i,e,t,n){let s=i.root.position.distanceTo(n),r=n.y-Kt(n.x,n.z)<5;switch(i.mode){case"walk":{i.ang+=i.dirSign*(i.speed/i.r)*e;let a=i.centre.x+Math.cos(i.ang)*i.r,l=i.centre.z+Math.sin(i.ang)*i.r;if(i.root.position.set(a,Kt(a,l),l),Bi(i,Math.atan2(-Math.sin(i.ang)*i.dirSign,Math.cos(i.ang)*i.dirSign)),Pn)break;if(r&&s<6.5&&t-i.lastGreet>45&&(i.lastGreet=t,Math.random()<.6)){i.mode="act",i.faceCam=!0,i.until=t+Ht(i,i.kind==="elder"||i.kind==="saree"?"namaste":"wave")-.2;break}if(t>i.until){let c=i.pair;if(c&&c.state==="apart"&&t>c.next&&c.members.every(h=>h.root.visible&&h.mode==="walk")){if(db(c,t))break;c.next=t+8}i.kind==="student"||Math.random()<.6?(i.mode="act",i.until=t+Ht(i,i.kind==="student"?"phone":"look_around")-.2):i.until=t+8+Math.random()*10}break}case"goto":Lf(i,i.target,i.speed,e)&&(i.mode="wait",Ht(i,"idle",!0));break;case"return":Lf(i,i.target,i.speed,e)&&(i.mode="walk");break;case"wait":case"chat":{let a=i.pair.members[0]===i?i.pair.members[1]:i.pair.members[0];Bi(i,Math.atan2(a.root.position.x-i.root.position.x,a.root.position.z-i.root.position.z),Math.min(1,e*4)),i.pair.members[0]===i&&fb(i.pair,t);break}case"act":i.faceCam&&Bi(i,Math.atan2(n.x-i.root.position.x,n.z-i.root.position.z),Math.min(1,e*4)),t>i.until&&vh(i,t);break}t>i.glanceUntil&&(i.glance=Math.random()<.35,i.glanceUntil=t+2+Math.random()*3);let o=s<8&&i.mode!=="chat"&&i.mode!=="wait"&&(i.mode==="act"||i.glance);tp(i,e,o?Qf[i.act]??.75:0)}function Df(i){i.phone&&(i.phone.visible=i.act==="walk_phone"||i.act==="phone"&&!!i.cur&&i.cur.time>.4&&i.cur.time<5.6)}function mb(i){if(!ae.ready)return;let e=ae.guide;if(tt==="walk"&&!ae.spot&&ip(e,i),!ae.spot){Pf();return}ae.t+=i;let t=ae.t,n=Me.position;e.root.visible&&e.root.position.distanceTo(n)<160&&(e.mixer.update(i),hb(e,i,t,n),tp(e,i,e.mode==="follow"?.55:Qf[e.act]??1),Df(e));for(let s of ae.extras)if(s.root.visible){if(s.root.position.distanceTo(n)>160&&s.mode==="walk"){s.ang+=s.dirSign*(s.speed/s.r)*i;continue}s.mixer.update(i),pb(s,i,t,n),Df(s)}Pf()}var bh={oldcity:{mr:"\u091C\u0941\u0928\u094D\u092F\u093E \u092A\u0941\u0923\u094D\u092F\u093E\u091A\u093E \u0916\u091C\u093F\u0928\u093E",en:"Treasures of Old Pune",intro:"Ten treasures lie hidden at the landmarks of old Pune, from the Peshwas\u2019 great gate to the market hall. Follow each clue to a glowing beam of light, pick up the treasure and answer a question about the place.",start:{x:1.7,z:-140},items:[{land:"Dilli Darwaza",obj:"spike",mr:"\u0926\u0930\u0935\u093E\u091C\u093E\u091A\u093E \u0916\u093F\u0933\u093E",name:"An iron gate spike",clue:"Start at the great north gate of the Peshwas\u2019 fort, straight ahead of you.",fact:"Dilli Darwaza faces north, towards Delhi. Its doors carry rows of iron spikes against war elephants.",q:"Why do the doors of Dilli Darwaza carry rows of iron spikes?",a:["To stop war elephants ramming them","To hang lamps at festivals","To keep birds off the doors"]},{land:"Kasba Ganpati",obj:"flower",mr:"\u091C\u093E\u0938\u094D\u0935\u0902\u0926\u0940\u091A\u0947 \u092B\u0942\u0932",name:"A red hibiscus",clue:"Go east to the temple of the city\u2019s guardian Ganpati, the one honoured first of all.",fact:"Kasba Ganpati is Pune\u2019s gramadaivat, its guardian deity, the first of its honoured Ganpatis. Jijabai is said to have built the temple.",q:"What is Kasba Ganpati to the people of Pune?",a:["The city\u2019s guardian deity, honoured first","The newest temple in the city","A god of the river Mutha"]},{land:"Lal Mahal",obj:"plough",mr:"\u0938\u094B\u0928\u094D\u092F\u093E\u091A\u093E \u0928\u093E\u0902\u0917\u0930",name:"The golden plough",clue:"Close by stands the red palace where a great king spent his boyhood.",fact:"Lal Mahal is rebuilt on the site of the house where Shivaji Maharaj grew up with his mother Jijabai. The story goes that she had the ruined town\u2019s land ploughed with a golden plough to bring it back to life.",q:"Who grew up at Lal Mahal?",a:["Shivaji Maharaj, with his mother Jijabai","Bajirao I","Lokmanya Tilak"]},{land:"Nana Wada",obj:"quill",mr:"\u0928\u093E\u0928\u093E\u0902\u091A\u0940 \u0932\u0947\u0916\u0923\u0940",name:"The minister\u2019s quill",clue:"Find the mansion of the Peshwas\u2019 shrewd chief minister, its white front set with cusped niches.",fact:"Nana Wada was built in 1780 by Nana Phadnavis, the Peshwas\u2019 chief minister. It later housed a school.",q:"Who built Nana Wada in 1780?",a:["Nana Phadnavis, the Peshwas\u2019 chief minister","Dagdusheth Gadve, a sweet-maker","Jyotirao Phule"]},{land:"Dagdusheth Ganpati",obj:"pedha",mr:"\u092A\u0947\u0922\u094D\u092F\u093E\u0902\u091A\u0947 \u0924\u093E\u091F",name:"A plate of pedhas",clue:"Head south to Pune\u2019s best-known Ganesh temple, founded by a man who made sweets.",fact:"Shrimant Dagdusheth Halwai Ganpati was founded by Dagdusheth Gadve, a halwai: a maker of sweets.",q:"What was Dagdusheth Gadve\u2019s trade?",a:["He made sweets (a halwai)","He was a goldsmith","He was a soldier of the Peshwas"]},{land:"Bhide Wada",obj:"slate",mr:"\u092A\u093E\u091F\u0940 \u0906\u0923\u093F \u0916\u0921\u0942",name:"A slate and chalk",clue:"A few steps on, find the wada where girls first went to school in Pune.",fact:"At Bhide Wada, in 1848, Savitribai and Jyotirao Phule opened their first school for girls.",q:"What did Savitribai and Jyotirao Phule open at Bhide Wada in 1848?",a:["Their first school for girls","Pune\u2019s first post office","A printing press"]},{land:"Laxmi Road",obj:"anklet",mr:"\u091A\u093E\u0902\u0926\u0940\u091A\u0947 \u092A\u0948\u0902\u091C\u0923",name:"A silver anklet",clue:"Make for the city\u2019s busiest shopping street, lined with jewellers and sari shops.",fact:"Laxmi Road is Pune\u2019s busiest shopping street: jewellers, sari and cloth shops, hawkers and rows of scooters.",q:"What is Laxmi Road best known for?",a:["Shopping: jewellers, saris and cloth","Its railway station","Temples along the river"]},{land:"Tulshibaug Ram Mandir",obj:"tulsi",mr:"\u0924\u0941\u0933\u0936\u0940\u091A\u0940 \u0921\u0939\u093E\u0933\u0940",name:"A sprig of tulsi",clue:"Follow the market lanes to an 18th-century temple with a tall spire, named after a garden of tulsi.",fact:"Tulshibaug Ram Mandir is an 18th-century temple of Shri Ram with a tall spire, at the heart of the Tulshibaug market lanes.",q:"To whom is the temple at Tulshibaug dedicated?",a:["Shri Ram","Shri Ganesh","Lord Shiva"]},{land:"Vishrambaug Wada",obj:"rosette",mr:"\u0938\u093E\u0917\u0935\u093E\u0928\u0940 \u0928\u0915\u094D\u0937\u0940",name:"A carved teak flower",clue:"Go west to the last Peshwa\u2019s mansion, famed for its carved wooden balcony.",fact:"Vishrambaug Wada was built in 1807 for Peshwa Bajirao II and is famed for its carved teak balcony. It houses a post office and a museum.",q:"Vishrambaug Wada was built in 1807 for whom?",a:["Peshwa Bajirao II","Shivaji Maharaj","The British Collector of Pune"]},{land:"Mahatma Phule Mandai",obj:"weight",mr:"\u092E\u0902\u0921\u0908\u091A\u0947 \u0935\u091C\u0928",name:"The market\u2019s brass weight",clue:"Last of all: the great market hall with an eight-sided tower.",fact:"Mahatma Phule Mandai, Pune\u2019s great vegetable market hall, opened in 1886 with its tall octagonal central tower.",q:"What is sold in the Mandai\u2019s great hall, opened in 1886?",a:["Vegetables, fruit and flowers","Cars and scooters","Only books"]}]}},Nt=bh[zn]||null,j={on:!1,i:0,score:0,secs:0,right:0,hints:0,hinted:!1,spot:null,beacon:null,card:!1,picked:null,lastHud:0,answered:!1},sp="wada-hunt-"+zn,gb=/(?:^|[#&])play(?:&|$)/.test(location.hash),Fo=null,pi=.35;function rp(){if(!ct)return null;let i=32,e=new Map,t=n=>{let s=1/0,r=1/0,o=-1/0,a=-1/0;for(let c=0;c<n.length;c+=2)s=Math.min(s,n[c]),o=Math.max(o,n[c]),r=Math.min(r,n[c+1]),a=Math.max(a,n[c+1]);let l={p:n,x0:s,z0:r,x1:o,z1:a,water:!1};for(let c=Math.floor(s/i);c<=Math.floor(o/i);c++)for(let h=Math.floor(r/i);h<=Math.floor(a/i);h++){let u=c+","+h;e.has(u)||e.set(u,[]),e.get(u).push(l)}return l};for(let n of ct.buildings)t(n);for(let n of ct.water||[])t(n).water=!0;return{cell:i,grid:e}}var Zs={x:0,z:0};function _b(i,e,t){let n=1/0;for(let s=0,r=t.length-2;s<t.length;r=s,s+=2){let o=t[r],a=t[r+1],l=t[s]-o,c=t[s+1]-a,h=Math.max(0,Math.min(1,((i-o)*l+(e-a)*c)/(l*l+c*c||1e-9))),u=o+l*h,d=a+c*h,f=(i-u)*(i-u)+(e-d)*(e-d);f<n&&(n=f,Zs.x=u,Zs.z=d)}return n}function ap(i,e){for(let[t,n,s,r,o]of ct.roads){if(Math.min(t,s)-o>i||Math.max(t,s)+o<i||Math.min(n,r)-o>e||Math.max(n,r)+o<e)continue;let a=s-t,l=r-n,c=Math.max(0,Math.min(1,((i-t)*a+(e-n)*l)/(a*a+l*l||1)));if(Math.hypot(t+a*c-i,n+l*c-e)<o/2+.5)return!0}return!1}function op(i){let e=Fo||(Fo=rp());if(!e)return!1;let t=!1;for(let n=0;n<3;n++){let s=!1,r=Math.floor(i.x/e.cell),o=Math.floor(i.z/e.cell),a=new Set;for(let l=r-1;l<=r+1;l++)for(let c=o-1;c<=o+1;c++)for(let h of e.grid.get(l+","+c)||[]){if(a.has(h)||(a.add(h),i.x<h.x0-pi||i.x>h.x1+pi||i.z<h.z0-pi||i.z>h.z1+pi))continue;let u=Oo(i.x,i.z,h.p),d=_b(i.x,i.z,h.p);if(!u&&d>=pi*pi||h.water&&ap(i.x,i.z))continue;let f=Math.sqrt(d),g=1,_=0;f>1e-5&&(g=(i.x-Zs.x)/f,_=(i.z-Zs.z)/f,u&&(g=-g,_=-_)),i.x=Zs.x+g*pi,i.z=Zs.z+_*pi,s=t=!0}for(let l=0;l<Yt.length;l+=3){let c=Math.max(.5,(Yt[l+2]-.7)*.75)+pi,h=i.x-Yt[l],u=i.z-Yt[l+1],d=Math.hypot(h,u);d>=c||d<1e-5||(i.x=Yt[l]+h/d*c,i.z=Yt[l+1]+u/d*c,s=t=!0)}if(!s)break}return t}function Bo(i,e){let t=Fo||(Fo=rp());if(!t)return!0;for(let n of t.grid.get(Math.floor(i/t.cell)+","+Math.floor(e/t.cell))||[])if(!(i<n.x0||i>n.x1||e<n.z0||e>n.z1)&&Oo(i,e,n.p)&&!(n.water&&ap(i,e)))return!1;for(let n=0;n<Yt.length;n+=3)if(Math.abs(Yt[n]-i)<Yt[n+2]&&Math.abs(Yt[n+1]-e)<Yt[n+2])return!1;return!0}function lp(i){let e=ct.landmarks.find(a=>a.name===i);if(!e)return null;let t=null;for(let[a,l,c,h]of ct.roads){let u=c-a,d=h-l,f=Math.max(0,Math.min(1,((e.x-a)*u+(e.z-l)*d)/(u*u+d*d||1e-9))),g=a+u*f,_=l+d*f,m=Math.hypot(e.x-g,e.z-_);t&&m>=t.d||Bo(g,_)&&(t={d:m,x:g,z:_})}if(!t)return{x:e.x,z:e.z};let n=Math.hypot(e.x-t.x,e.z-t.z);if(n<1)return{x:t.x,z:t.z};let s=(e.x-t.x)/n,r=(e.z-t.z)/n,o=0;for(;o<n-1&&Bo(t.x+s*(o+1.5),t.z+r*(o+1.5));)o+=.5;return{x:t.x+s*Math.max(0,o-1),z:t.z+r*Math.max(0,o-1)}}function At(i,e=.3,t=.5,n=.4){return new et({color:i,emissive:i,emissiveIntensity:e,metalness:t,roughness:n})}function xb(i){let e=new Jt,t=(s,r,o=0,a=0,l=0,c=0,h=0,u=0)=>{let d=new je(s,r);return d.position.set(o,a,l),d.rotation.set(c,h,u),e.add(d),d},n=15250757;switch(i){case"spike":{t(new Vs(.11,.62,14),At(7041400,.2,.85,.35),0,.33,0),t(new cn(.22,.26,.09,20),At(n),0,0,0);break}case"flower":{let s=At(14165547,.35,0,.6);for(let r=0;r<5;r++){let o=r*Math.PI*2/5;t(new qn(.15,12,8),s,Math.cos(o)*.17,0,Math.sin(o)*.17,0,-o,0).scale.set(1.35,.32,.9)}t(new cn(.016,.016,.34,6),At(16765498,.5,0,.5),0,.15,.04,.35,0,0),e.rotation.x=.55;break}case"plough":{let s=At(n,.35,.8,.3);t(new Xt(.95,.06,.06),s,0,.12,0,0,0,.3),t(new Xt(.06,.5,.06),s,-.3,.12,0,0,0,-.35),t(new Vs(.08,.32,8),s,.3,-.12,0,0,0,-2.1),t(new Xt(.05,.3,.05),s,.22,-.02,0,0,0,.1);break}case"quill":{t(new Vs(.035,.22,8),At(n,.35,.8,.3),0,-.38,0,Math.PI,0,0),t(new cn(.012,.012,.75,6),At(14274744,.25,0,.6),0,-.02,0),t(new qn(.12,14,10),At(16183782,.3,0,.6),0,.1,0).scale.set(.65,2.6,.12),e.rotation.z=.45;break}case"pedha":{t(new cn(.34,.3,.04,28),At(n,.3,.8,.3),0,-.04,0);let s=At(15323030,.22,0,.8);for(let[r,o]of[[0,0],[.15,.08],[-.15,.08],[0,-.16],[.15,-.09],[-.15,-.09],[0,.17]])t(new qn(.075,12,8),s,r,.02,o).scale.set(1,.55,1);e.rotation.x=.55;break}case"slate":{t(new Xt(.58,.44,.04),At(9067051,.2,0,.7),0,0,0),t(new Xt(.48,.34,.046),At(2503224,.1,0,.9),0,0,0);let s=At(16777215,.6,0,.9);t(new Xt(.26,.025,.05),s,-.05,.08,.002),t(new Xt(.18,.025,.05),s,-.09,0,.002),t(new Xt(.22,.025,.05),s,-.07,-.08,.002),t(new cn(.02,.02,.16,8),s,.17,-.12,.04,0,0,1.3);break}case"anklet":{let s=At(14672872,.3,.9,.25);t(new Cr(.26,.03,10,40),s,0,0,0);for(let r=0;r<12;r++){let o=r/12*Math.PI*2;t(new qn(.04,8,6),s,Math.cos(o)*.26,Math.sin(o)*.26-.05,0)}break}case"tulsi":{t(new cn(.16,.12,.22,18),At(n,.3,.8,.3),0,-.22,0),t(new cn(.012,.012,.5,6),At(5982762,.15,0,.8),0,.1,0);let s=At(4164142,.3,0,.7);for(let r=0;r<14;r++){let o=r*2.4,a=-.05+r*.03;t(new qn(.05,8,6),s,Math.cos(o)*.07,a,Math.sin(o)*.07,0,-o,0).scale.set(1.4,.4,.8)}break}case"rosette":{t(new cn(.1,.1,.08,16),At(11565626,.3,.1,.6),0,0,0,Math.PI/2,0,0);let s=At(9065763,.28,.1,.6);for(let r=0;r<8;r++){let o=r*Math.PI/4;t(new qn(.11,10,8),s,Math.cos(o)*.19,Math.sin(o)*.19,0,0,0,o).scale.set(1.5,.7,.35)}break}default:{let s=At(13212220,.3,.8,.35);t(new cn(.16,.22,.26,22),s,0,-.08,0),t(new Cr(.08,.02,8,22),s,0,.12,0)}}return e}function yb(i,e){let t=new Jt;t.position.set(i.x,Kt(i.x,i.z),i.z);let n=xb(e);n.scale.setScalar(1.5),n.position.y=1.3,t.add(n);let s=90,r=new cn(.45,.85,s,20,8,!0);r.translate(0,s/2,0);let o=r.attributes.position,a=new Float32Array(o.count*4);for(let h=0;h<o.count;h++)a.set([1,.72,.3,Math.pow(1-o.getY(h)/s,1.7)],h*4);r.setAttribute("color",new wt(a,4));let l=new je(r,new Wt({vertexColors:!0,transparent:!0,opacity:.55,blending:gr,depthWrite:!1,side:_t,fog:!1}));t.add(l);let c=new je(new $a(.95,1.2,48),new Wt({color:16761690,transparent:!0,opacity:.85,side:_t,depthWrite:!1,fog:!1}));return c.rotation.x=-Math.PI/2,c.position.y=.07,t.add(c),t.userData={item:n,beam:l,ring:c},gt.add(t),t}function Mh(i){i&&(gt.remove(i),i.traverse(e=>{e.isMesh&&(e.geometry.dispose(),e.material.dispose())}))}function Bh(){Mh(j.beacon),j.beacon=null,j.picked&&(Mh(j.picked.b),j.picked=null)}function ko(i){if(!Ae.on||!Ae.ctx)return;let e=Ae.ctx,t=e.currentTime+.02,n=(s,r,o,a,l)=>{let c=e.createOscillator();c.type=a,c.frequency.value=s;let h=e.createGain();h.gain.setValueAtTime(1e-4,r),h.gain.exponentialRampToValueAtTime(l,r+.012),h.gain.exponentialRampToValueAtTime(1e-4,r+o),c.connect(h).connect(Ae.master),c.start(r),c.stop(r+o+.05)};i==="found"&&([523.3,659.3,784,1046.5].forEach((s,r)=>n(s,t+r*.08,.45,"triangle",.15)),No(t+.36,.1,880)),i==="right"&&(n(659.3,t,.25,"sine",.2),n(987.8,t+.12,.5,"sine",.2)),i==="wrong"&&(n(233,t,.3,"triangle",.12),n(196,t+.16,.45,"triangle",.12)),i==="win"&&([523.3,659.3,784,1046.5,784,1046.5].forEach((s,r)=>n(s,t+r*.12,.6,"triangle",.15)),No(t+.8,.18,440))}function rs(i,e,t){if(!ae.ready||!ae.guide)return;let n=ae.guide;i&&n.root.visible&&Wr(n,i);let s=ae.bubble;s&&(s.querySelector(".mr").textContent=e,s.querySelector(".en").textContent=t,s.hidden=!1,ae.bubbleUntil=ae.t+4.5,ae.said=ae.t)}var jn=pe("huntCard");function cp(i){return(Bn.find(e=>e.land===i)||{}).mr||""}function zo(i){return i=Math.round(i),`${Math.floor(i/60)}:${String(i%60).padStart(2,"0")}`}function hp(){try{return JSON.parse(localStorage.getItem(sp)||"null")}catch{return null}}function Xr(i,e="button"){$n()&&document.exitPointerLock(),X.keys.clear(),jn.innerHTML=i,jn.hidden=!1,j.card=!0,pe("hunt").hidden=!0,pe("toast").hidden=!0,jn.querySelector(e)?.focus()}function is(){jn.hidden=!0,jn.innerHTML="",j.card=!1,j.on&&(pe("hunt").hidden=!1),Ut.focus()}function on(i){return String(i).replace(/[&<>"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[e])}function up(){if(!Nt){Xr(`<div class="hc-kicker">Heritage hunt</div>
      <h2><span class="mr" lang="mr">${on(bh.oldcity.mr)}</span> ${on(bh.oldcity.en)}</h2>
      <p>The hunt is set in the old city round Shaniwar Wada. Go there to play?</p>
      <div class="hc-btns"><button type="button" class="primary" data-act="go">Go to the old city</button>
      <button type="button" data-act="close">Not now</button></div>`);return}let i=hp(),e=kn?"Hold the arrows to walk, tap \u26A1 to run, drag to look round, double-tap a spot to go there.":"W A S D or the arrow keys to walk, Shift to run, move the mouse to look round, double-click a spot to go there.";Xr(`<div class="hc-kicker">Heritage hunt \xB7 ${Nt.items.length} treasures</div>
    <h2><span class="mr" lang="mr">${on(Nt.mr)}</span> ${on(Nt.en)}</h2>
    <p>${on(Nt.intro)}</p>
    <p class="hc-small">${on(e)} The radar points to each treasure; a hint names the place for 20 points.
    ${Ae.on?"":"Turn on <strong>Sound</strong> for chimes and bells."}</p>
    ${i?`<p class="hc-small">Your best: <strong>${i.score}</strong> points in ${zo(i.secs)}.</p>`:""}
    <div class="hc-btns"><button type="button" class="primary" data-act="start">Start the hunt</button>
    <button type="button" data-act="close">Not now</button></div>`)}function vb(){if(!Nt||!ct)return;is(),st.on&&$r(),pe("placesPanel").hidden||Kr(!1),Bh(),Object.assign(j,{on:!0,i:0,score:0,secs:0,right:0,hints:0,hinted:!1,picked:null,answered:!1,lastT:0}),document.body.classList.add("hunting"),pe("hunt").hidden=!1,jr();let i=Nt.start,e=lp(Nt.items[0].land)||{x:i.x,z:i.z+30},t=new C(i.x,Kt(i.x,i.z)+Vr,i.z),n=new C(e.x,t.y,e.z);dp(0);let s=()=>{X.pos.copy(t),ss("walk",!1),rs("namaste","\u091A\u0932\u093E!","Let\u2019s find the treasures of old Pune. Your first clue is on the card.")};tt==="walk"&&ss("orbit",!1),Yr(t,n,{dur:Pn?.01:void 0,done:s})}function dp(i){j.i=i,j.hinted=!1,j.answered=!1,Bh();let e=Nt.items[i];j.spot=lp(e.land),j.spot&&(j.beacon=yb(j.spot,e.obj)),pe("huntItem").innerHTML=`<span class="mr" lang="mr">${on(e.mr)}</span> ${on(e.name)}`,pe("huntClue").textContent=e.clue,pe("huntWhere").textContent="",Zr(!0)}function Zr(i){let e=performance.now();if(!i&&e-j.lastHud<120||(j.lastHud=e,pe("huntStep").textContent=`${j.i+1} / ${Nt.items.length}`,pe("huntScore").textContent=`\u2605 ${j.score}`,pe("huntTime").textContent=zo(j.secs),!j.spot))return;let t=tt==="walk"?X.pos:Me.position,n=j.spot.x-t.x,s=j.spot.z-t.z,r=Math.hypot(n,s),o=new C;Me.getWorldDirection(o);let a=Math.atan2(o.x*s-o.z*n,o.x*n+o.z*s);pe("huntArrow").style.transform=`rotate(${a.toFixed(3)}rad)`,pe("huntDist").textContent=r<10?"Here!":`${r<100?Math.round(r):Math.round(r/10)*10} m`,pe("huntWhere").textContent=tt!=="walk"?"Tap Walk to go on":j.hinted?`It is ${Nt.items[j.i].land} (${cp(Nt.items[j.i].land)})`:""}function bb(){let i=Nt.items[j.i];j.score+=50,j.picked={t:0,b:j.beacon},j.beacon=null,ko("found"),rs(Math.random()<.5?"clap":"surprised","\u0938\u093E\u092A\u0921\u0932\u093E!",`You found it: ${i.name.toLowerCase()}!`);let e=i.a.map((t,n)=>({a:t,k:n})).sort(()=>Math.random()-.5);setTimeout(()=>{Xr(`<div class="hc-kicker">Treasure ${j.i+1} of ${Nt.items.length} found \xB7 +50</div>
      <h2><span class="mr" lang="mr">${on(i.mr)}</span> ${on(i.name)}</h2>
      <p class="hc-small">at ${on(i.land)} <span lang="mr">${on(cp(i.land))}</span></p>
      <p class="hc-q">${on(i.q)}</p>
      <div class="hc-opts">${e.map((t,n)=>`<button type="button" data-k="${t.k}"><span class="n">${n+1}</span>${on(t.a)}</button>`).join("")}</div>
      <div class="hc-after" hidden></div>`,".hc-opts button")},Pn?50:700)}function Mb(i){if(j.answered)return;j.answered=!0;let e=Nt.items[j.i],t=i===0;t?(j.score+=100,j.right++,ko("right"),rs("thumbs_up","\u092C\u0930\u094B\u092C\u0930!","Right answer!")):(ko("wrong"),rs("think","\u0939\u092E\u094D\u092E\u2026","Not quite. Now you know!"));for(let r of jn.querySelectorAll(".hc-opts button"))r.disabled=!0,+r.dataset.k==0?r.classList.add("right"):+r.dataset.k===i&&r.classList.add("wrong");let n=j.i===Nt.items.length-1,s=jn.querySelector(".hc-after");s.innerHTML=`<p class="hc-res">${t?"<strong>Right!</strong> +100":"<strong>Not this time.</strong>"}</p>
    <p>${on(e.fact)}</p>
    <div class="hc-btns"><button type="button" class="primary" data-act="${n?"finish":"next"}">${n?"See your score":"Next clue"}</button></div>`,s.hidden=!1,s.querySelector("button").focus(),Zr(!0)}function wb(){let i=Math.max(0,Math.round((1200-j.secs)/4));j.score+=i;let e=Nt.items.length,t=j.score>=1400?3:j.score>=1e3?2:1,n=hp(),s=!n||j.score>n.score;if(s)try{localStorage.setItem(sp,JSON.stringify({score:j.score,secs:Math.round(j.secs),right:j.right}))}catch{}ko("win"),rs("victory","\u0936\u093E\u092C\u094D\u092C\u093E\u0938!","You found every treasure of old Pune!"),fp(!1),Xr(`<div class="hc-kicker">Heritage hunt complete</div>
    <h2><span class="mr" lang="mr">\u0936\u093E\u092C\u094D\u092C\u093E\u0938!</span> All ${e} treasures found</h2>
    <div class="hc-stars" aria-label="${t} of 3 stars">${"\u2605".repeat(t)}<span>${"\u2605".repeat(3-t)}</span></div>
    <p class="hc-score"><strong>${j.score}</strong> points</p>
    <p class="hc-small">${j.right} of ${e} answers right \xB7 time ${zo(j.secs)} (time bonus +${i})${j.hints?` \xB7 ${j.hints} hint${j.hints>1?"s":""}`:""}</p>
    <p class="hc-small">${s?"A new best score!":`Your best: ${n.score} points in ${zo(n.secs)}.`}</p>
    <div class="hc-btns"><button type="button" class="primary" data-act="start">Play again</button>
    <button type="button" data-act="close">Explore freely</button></div>`)}function fp(i=!0){j.on=!1,j.spot=null,Bh(),pe("hunt").hidden=!0,document.body.classList.remove("hunting"),jr(),i&&is()}function Sb(i){if(!j.on)return;let e=j.picked;if(e){let{item:r,beam:o,ring:a}=e.b.userData;e.t+=i,r.position.y=1.3+e.t*3,r.rotation.y+=i*12,r.scale.setScalar(1.5*Math.max(.01,1-e.t/.8)),o.material.opacity=Math.max(0,.55*(1-e.t/.6)),a.material.opacity=Math.max(0,.85*(1-e.t/.5)),e.t>.9&&(Mh(e.b),j.picked=null)}let t=j.beacon;if(t&&!Pn){let{item:r,beam:o,ring:a}=t.userData,l=performance.now()/1e3;r.rotation.y+=i*1.4,r.position.y=1.3+Math.sin(l*2.2)*.12,a.scale.setScalar(1+.12*Math.sin(l*3)),o.material.opacity=.45+.12*Math.sin(l*1.7)}let n=performance.now()/1e3,s=j.lastT?Math.min(1,n-j.lastT):0;j.lastT=n,!j.card&&(j.secs+=s,Zr(!1),j.beacon&&tt==="walk"&&j.spot&&Math.hypot(X.pos.x-j.spot.x,X.pos.z-j.spot.z)<3.2&&bb())}jn.addEventListener("click",i=>{let e=i.target.closest("button");if(!e)return;if(e.dataset.k!==void 0){Mb(+e.dataset.k);return}let t=e.dataset.act;t==="start"?vb():t==="close"?is():t==="go"?(location.hash="play&place=oldcity",setTimeout(()=>location.reload(),300)):t==="next"?(is(),dp(j.i+1),rs("point_up","\u092A\u0941\u0922\u091A\u093E!","On to the next clue!")):t==="finish"?(is(),wb()):t==="quit"?fp(!0):t==="keep"&&is()});window.addEventListener("keydown",i=>{if(!jn.hidden)if(/^[1-3]$/.test(i.key)){let e=jn.querySelectorAll(".hc-opts button")[+i.key-1];e&&!e.disabled&&(e.click(),i.preventDefault())}else i.key==="Escape"&&!j.on&&is()},!0);pe("playBtn").addEventListener("click",()=>{if(j.on){Zr(!0);return}up()});pe("huntHint").addEventListener("click",()=>{if(!j.on||j.hinted)return;j.hinted=!0,j.hints++,j.score=Math.max(0,j.score-20);let i=Nt.items[j.i];rs("point_up","\u0924\u093F\u0925\u0947!",`Over there: ${i.land}.`),Zr(!0)});pe("huntQuit").addEventListener("click",()=>{j.on&&Xr(`<h2>Stop the hunt?</h2><p>You have found ${j.i} of ${Nt.items.length} treasures; your progress will be lost.</p>
    <div class="hc-btns"><button type="button" class="primary" data-act="keep">Keep playing</button>
    <button type="button" data-act="quit">Stop</button></div>`)});window.__wadaHunt=(i,e,t,n)=>{if(i==="near"&&j.spot&&X.pos.set(j.spot.x+7,X.pos.y,j.spot.z+7),i==="at"&&j.spot&&X.pos.set(j.spot.x,X.pos.y,j.spot.z),i==="to"&&X.pos.set(e,X.pos.y,t),i==="sim"){let[s,r]=n,o=new C(e,0,t);for(let a=0;a<600;a++){let l=s-o.x,c=r-o.z,h=Math.hypot(l,c);if(h<.3)break;o.x+=l/h*.25,o.z+=c/h*.25,op(o)}return{end:[+o.x.toFixed(2),+o.z.toFixed(2)],free:Bo(o.x,o.z),left:+Math.hypot(s-o.x,r-o.z).toFixed(1)}}return{on:j.on,i:j.i,score:j.score,secs:Math.round(j.secs),card:j.card,mode:tt,spot:j.spot&&[+j.spot.x.toFixed(1),+j.spot.z.toFixed(1)],pos:[+X.pos.x.toFixed(2),+X.pos.z.toFixed(2)],open:yi(X.pos.x,X.pos.z),free:Bo(X.pos.x,X.pos.z),fl:bt&&+bt.t.toFixed(2),frame:dh}};{let i=pe("padRun");i.addEventListener("click",()=>{X.runLock=!X.runLock,i.setAttribute("aria-pressed",String(X.runLock)),i.classList.toggle("on",X.runLock)})}var hh=0,Eb=new C(0,1,0),Mo=new C,uh=new C,Br=new C,Nf=i=>i*i*i*(i*(i*6-15)+10);function pp(i){let e=sb.getDelta(),t=Math.min(.05,e),n=Math.min(.1,e);if(ib(e),dh++,bt){bt.t=Math.min(1,bt.t+n/(bt.dur||1.4));let c=bt.t,h=Nf(c),u=Nf(Math.min(1,c*1.08));if(Me.position.lerpVectors(bt.fromPos,bt.toPos,h),Me.position.y+=(bt.arc||0)*Math.sin(Math.PI*h),nt.target.lerpVectors(bt.fromTarget,bt.toTarget,u),c>=1){let d=bt.done;bt=null,d&&d()}}if(tt==="walk"){let c=X.keys.has("run")||X.runLock,h=(c?pv:fv)*(j.on?c?1.6:2:1),u=Math.min(1,t*14);X.yaw+=(X.tyaw-X.yaw)*u,X.pitch+=(X.tpitch-X.pitch)*u;let d=new C(-Math.sin(X.yaw),0,-Math.cos(X.yaw)),f=new C(-d.z,0,d.x),g=new C;if((X.keys.has("f")||X.keys.has("mf"))&&g.add(d),(X.keys.has("b")||X.keys.has("mb"))&&g.sub(d),X.keys.has("r")&&g.add(f),X.keys.has("l")&&g.sub(f),j.card)X.glide=null;else if(g.lengthSq())X.glide=null,X.pos.addScaledVector(g.normalize(),h*t);else if(X.glide){let _=X.glide;_.t=Math.min(1,_.t+t/_.dur);let m=_.t<.5?2*_.t*_.t:1-(-2*_.t+2)**2/2;X.pos.x=_.from.x+(_.to.x-_.from.x)*m,X.pos.z=_.from.z+(_.to.z-_.from.z)*m,_.t>=1&&(X.glide=null)}if(j.on&&op(X.pos)&&X.glide&&(X.glide=null),i-X.lastProbe>100){X.lastProbe=i,Ef.ray.origin.set(X.pos.x,X.pos.y-Vr+.75,X.pos.z);let _=Ef.intersectObjects(Hf,!1)[0];X.floor=_?_.point.y:Kt(X.pos.x,X.pos.z)}X.pos.y+=(X.floor+Vr-X.pos.y)*Math.min(1,t*8),Me.position.copy(X.pos),Me.rotation.set(X.pitch,X.yaw,0,"YXZ"),fi.copy(X.pos)}else{nt.dampingFactor=1-Math.pow(1-.06,n*60),nt.update();let c=Kt(Me.position.x,Me.position.z)+1.2;Me.position.y<c&&(Me.position.y=c),fi.copy(nt.target)}let s=bt?bt.toTarget:fi,r=Me.position.distanceTo(fi),a=(bt?!0:hh===650?r>300:r>380)?650:170;if(a!==hh){let c=un.shadow.camera;c.left=c.bottom=-a,c.right=c.top=a,c.updateProjectionMatrix(),hh=a}{let c=2*a/un.shadow.mapSize.x;Br.copy(Lo).normalize(),Mo.crossVectors(Eb,Br).normalize(),uh.crossVectors(Br,Mo);let h=Math.round(s.dot(Mo)/c)*c,u=Math.round(s.dot(uh)/c)*c;un.target.position.copy(Mo).multiplyScalar(h).addScaledVector(uh,u).addScaledVector(Br,s.dot(Br)),un.position.copy(un.target.position).addScaledVector(Lo,700)}dh%Uf===0&&(ln.shadowMap.needsUpdate=!0),dv(i,fi),jv(i,Me.position),Qv(t),Sb(t),Rv(t,tt==="walk"?X.pos:fi,i),Sv(tt==="walk"?X.pos:fi),Pn||(Vv(t),en.uTime.value=i/1e3,Bv(t,tt==="walk"?X.pos:fi,i/1e3),Iv(t,i/1e3)),mb(t);let l=new C;Me.getWorldDirection(l),yv(i,tt==="walk"?X.pos:Me.position.y>60?fi:Me.position,Math.atan2(-l.x,-l.z)),Ho.position.copy(Me.position);{let c=tr[nr].fog,h=Math.max(0,Me.position.y-20);gt.fog.near=c[0]+h*.9,gt.fog.far=c[1]+h*3.2}ln.render(gt,Me),requestAnimationFrame(pp)}Gf("day");Yo();Co();Promise.all(To.map((i,e)=>i.movers||i.metro?uf(i,e).catch(()=>null):uf(i,e))).then(async()=>{try{let t=await fetch(ts+"wada_traffic.json");t.ok&&bv(await t.json())}catch{}try{let t=await fetch(ts+"wada_metro.json");t.ok&&vf(await t.json())}catch{}if(To.some(t=>/railway/.test(t.file)))try{let t=await fetch(ts+"wada_railway.json");t.ok&&vf(await t.json(),"rail")}catch{}try{let t=await fetch(ts+"wada_props.json");t.ok&&Cv(await t.json())}catch{}Uo();{let t=[];gt.traverse(n=>{n.visible||(t.push(n),n.visible=!0)});try{ln.compile(gt,Me)}catch{}for(let n of t)n.visible=!1;ln.shadowMap.needsUpdate=!0}fetch(ts+"wada_labels.json").then(t=>t.ok?t.json():null).then(Gv).catch(()=>{});let i=location.hash.slice(1).split("&")[0];qo(Hr.some(t=>t.id===i)?i:Cn.start||"fort",!0),pe("loader").classList.add("done"),ob(),gb&&up();let e=!1;try{e=localStorage.getItem("wada-tip")==="1",localStorage.setItem("wada-tip","1")}catch{}if(!e){pe("toast").hidden=!1;let t=()=>{pe("toast").hidden=!0};pe("toastClose").addEventListener("click",t),setTimeout(t,12e3),pe("tod").addEventListener("click",t,{once:!0}),Dh.addEventListener("click",t,{once:!0})}requestAnimationFrame(pp)}).catch(i=>{pe("status").textContent=`Part of the city (${i.message}) did not load. Reload the page to try again.`});
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
