var Oc="160",un={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Cn={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},$p=0,gu=1,Zp=2;var nf=1,Fc=2,oi=3,Yn=0,Yt=1,yt=2;var Ri=0,Is=1,wr=2,_u=3,xu=4,Jp=5,Yi=100,Qp=101,em=102,yu=103,vu=104,tm=200,nm=201,im=202,sm=203,Xl=204,ql=205,rm=206,am=207,om=208,lm=209,cm=210,hm=211,um=212,dm=213,fm=214,pm=0,mm=1,gm=2,ka=3,_m=4,xm=5,ym=6,vm=7,sf=0,bm=1,Mm=2,Ci=0,wm=1,Sm=2,Em=3,Bc=4,Tm=5,Am=6,bu="attached",Rm="detached",rf=300,Us=301,Os=302,Yl=303,Kl=304,vo=306,Ji=1e3,_n=1001,Sr=1002,Ut=1003,za=1004;var gr=1005;var cn=1006,kc=1007;var Li=1008;var Pi=1009,Cm=1010,Pm=1011,zc=1012,af=1013,Ti=1014,li=1015,Er=1016,of=1017,lf=1018,ji=1020,Lm=1021,wn=1023,Im=1024,Dm=1025,$i=1026,Fs=1027,Nm=1028,cf=1029,Um=1030,hf=1031,uf=1033,cl=33776,hl=33777,ul=33778,dl=33779,Mu=35840,wu=35841,Su=35842,Eu=35843,df=36196,Tu=37492,Au=37496,Ru=37808,Cu=37809,Pu=37810,Lu=37811,Iu=37812,Du=37813,Nu=37814,Uu=37815,Ou=37816,Fu=37817,Bu=37818,ku=37819,zu=37820,Hu=37821,fl=36492,Vu=36494,Gu=36495,Om=36283,Wu=36284,Xu=36285,qu=36286,Hc=2200,Vc=2201,Fm=2202,Bs=2300,Qi=2301,pl=2302,As=2400,Rs=2401,Ha=2402,Gc=2500,Bm=2501,ff=0,bo=1,Gr=2,pf=3e3,Zi=3001,km=3200,zm=3201,mf=0,Hm=1,Sn="",ut="srgb",Ft="srgb-linear",Wc="display-p3",Mo="display-p3-linear",Va="linear",_t="srgb",Ga="rec709",Wa="p3";var hs=7680;var Yu=519,Vm=512,Gm=513,Wm=514,gf=515,Xm=516,qm=517,Ym=518,Km=519,jl=35044,Wr=35048;var Ku="300 es",$l=1035,ci=2e3,Xa=2001,Bn=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let s=this._listeners[e];if(s!==void 0){let r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let n=this._listeners[e.type];if(n!==void 0){e.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}},Qt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],ju=1234567,_r=Math.PI/180,ks=180/Math.PI;function Fn(){let i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Qt[i&255]+Qt[i>>8&255]+Qt[i>>16&255]+Qt[i>>24&255]+"-"+Qt[e&255]+Qt[e>>8&255]+"-"+Qt[e>>16&15|64]+Qt[e>>24&255]+"-"+Qt[t&63|128]+Qt[t>>8&255]+"-"+Qt[t>>16&255]+Qt[t>>24&255]+Qt[n&255]+Qt[n>>8&255]+Qt[n>>16&255]+Qt[n>>24&255]).toLowerCase()}function Ct(i,e,t){return Math.max(e,Math.min(t,i))}function Xc(i,e){return(i%e+e)%e}function jm(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function $m(i,e,t){return i!==e?(t-i)/(e-i):0}function xr(i,e,t){return(1-t)*i+t*e}function Zm(i,e,t,n){return xr(i,e,1-Math.exp(-t*n))}function Jm(i,e=1){return e-Math.abs(Xc(i,e*2)-e)}function Qm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function eg(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function tg(i,e){return i+Math.floor(Math.random()*(e-i+1))}function ng(i,e){return i+Math.random()*(e-i)}function ig(i){return i*(.5-Math.random())}function sg(i){i!==void 0&&(ju=i);let e=ju+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function rg(i){return i*_r}function ag(i){return i*ks}function Zl(i){return(i&i-1)===0&&i!==0}function og(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function qa(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function lg(i,e,t,n,s){let r=Math.cos,o=Math.sin,a=r(t/2),l=o(t/2),c=r((e+n)/2),h=o((e+n)/2),u=r((e-n)/2),d=o((e-n)/2),p=r((n-e)/2),g=o((n-e)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*g,l*p,a*c);break;case"YXY":i.set(l*p,a*h,l*g,a*c);break;case"ZYZ":i.set(l*g,l*p,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function qn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function lt(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var It={DEG2RAD:_r,RAD2DEG:ks,generateUUID:Fn,clamp:Ct,euclideanModulo:Xc,mapLinear:jm,inverseLerp:$m,lerp:xr,damp:Zm,pingpong:Jm,smoothstep:Qm,smootherstep:eg,randInt:tg,randFloat:ng,randFloatSpread:ig,seededRandom:sg,degToRad:rg,radToDeg:ag,isPowerOfTwo:Zl,ceilPowerOfTwo:og,floorPowerOfTwo:qa,setQuaternionFromProperEuler:lg,normalize:lt,denormalize:qn},he=class i{constructor(e=0,t=0){i.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Ct(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},je=class i{constructor(e,t,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c)}set(e,t,n,s,r,o,a,l,c){let h=this.elements;return h[0]=e,h[1]=s,h[2]=a,h[3]=t,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],p=n[5],g=n[8],f=s[0],_=s[3],m=s[6],y=s[1],x=s[4],b=s[7],E=s[2],w=s[5],T=s[8];return r[0]=o*f+a*y+l*E,r[3]=o*_+a*x+l*w,r[6]=o*m+a*b+l*T,r[1]=c*f+h*y+u*E,r[4]=c*_+h*x+u*w,r[7]=c*m+h*b+u*T,r[2]=d*f+p*y+g*E,r[5]=d*_+p*x+g*w,r[8]=d*m+p*b+g*T,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*r,p=c*r-o*l,g=t*u+n*d+s*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let f=1/g;return e[0]=u*f,e[1]=(s*c-h*n)*f,e[2]=(a*n-s*o)*f,e[3]=d*f,e[4]=(h*t-s*l)*f,e[5]=(s*r-a*t)*f,e[6]=p*f,e[7]=(n*l-c*t)*f,e[8]=(o*t-n*r)*f,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-s*c,s*l,-s*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(ml.makeScale(e,t)),this}rotate(e){return this.premultiply(ml.makeRotation(-e)),this}translate(e,t){return this.premultiply(ml.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},ml=new je;function _f(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Tr(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function cg(){let i=Tr("canvas");return i.style.display="block",i}var $u={};function yr(i){i in $u||($u[i]=!0,console.warn(i))}var Zu=new je().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Ju=new je().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),ha={[Ft]:{transfer:Va,primaries:Ga,toReference:i=>i,fromReference:i=>i},[ut]:{transfer:_t,primaries:Ga,toReference:i=>i.convertSRGBToLinear(),fromReference:i=>i.convertLinearToSRGB()},[Mo]:{transfer:Va,primaries:Wa,toReference:i=>i.applyMatrix3(Ju),fromReference:i=>i.applyMatrix3(Zu)},[Wc]:{transfer:_t,primaries:Wa,toReference:i=>i.convertSRGBToLinear().applyMatrix3(Ju),fromReference:i=>i.applyMatrix3(Zu).convertLinearToSRGB()}},hg=new Set([Ft,Mo]),ot={enabled:!0,_workingColorSpace:Ft,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(i){if(!hg.has(i))throw new Error(`Unsupported working color space, "${i}".`);this._workingColorSpace=i},convert:function(i,e,t){if(this.enabled===!1||e===t||!e||!t)return i;let n=ha[e].toReference,s=ha[t].fromReference;return s(n(i))},fromWorkingColorSpace:function(i,e){return this.convert(i,this._workingColorSpace,e)},toWorkingColorSpace:function(i,e){return this.convert(i,e,this._workingColorSpace)},getPrimaries:function(i){return ha[i].primaries},getTransfer:function(i){return i===Sn?Va:ha[i].transfer}};function Ds(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function gl(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var us,Ya=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{us===void 0&&(us=Tr("canvas")),us.width=e.width,us.height=e.height;let n=us.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=us}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=Tr("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Ds(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Ds(t[n]/255)*255):t[n]=Ds(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},ug=0,Ka=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:ug++}),this.uuid=Fn(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(_l(s[o].image)):r.push(_l(s[o]))}else r=_l(s);n.url=r}return t||(e.images[this.uuid]=n),n}};function _l(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Ya.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var dg=0,jt=class i extends Bn{constructor(e=i.DEFAULT_IMAGE,t=i.DEFAULT_MAPPING,n=_n,s=_n,r=cn,o=Li,a=wn,l=Pi,c=i.DEFAULT_ANISOTROPY,h=Sn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:dg++}),this.uuid=Fn(),this.name="",this.source=new Ka(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new he(0,0),this.repeat=new he(1,1),this.center=new he(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new je,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(yr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===Zi?ut:Sn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==rf)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Ji:e.x=e.x-Math.floor(e.x);break;case _n:e.x=e.x<0?0:1;break;case Sr:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Ji:e.y=e.y-Math.floor(e.y);break;case _n:e.y=e.y<0?0:1;break;case Sr:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return yr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===ut?Zi:pf}set encoding(e){yr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===Zi?ut:Sn}};jt.DEFAULT_IMAGE=null;jt.DEFAULT_MAPPING=rf;jt.DEFAULT_ANISOTROPY=1;var dt=class i{constructor(e=0,t=0,n=0,s=1){i.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r,l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],p=l[5],g=l[9],f=l[2],_=l[6],m=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-f)<.01&&Math.abs(g-_)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+f)<.1&&Math.abs(g+_)<.1&&Math.abs(c+p+m-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let x=(c+1)/2,b=(p+1)/2,E=(m+1)/2,w=(h+d)/4,T=(u+f)/4,D=(g+_)/4;return x>b&&x>E?x<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(x),s=w/n,r=T/n):b>E?b<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(b),n=w/s,r=D/s):E<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(E),n=T/r,s=D/r),this.set(n,s,r,t),this}let y=Math.sqrt((_-g)*(_-g)+(u-f)*(u-f)+(d-h)*(d-h));return Math.abs(y)<.001&&(y=1),this.x=(_-g)/y,this.y=(u-f)/y,this.z=(d-h)/y,this.w=Math.acos((c+p+m-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Jl=class extends Bn{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new dt(0,0,e,t),this.scissorTest=!1,this.viewport=new dt(0,0,e,t);let s={width:e,height:t,depth:1};n.encoding!==void 0&&(yr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===Zi?ut:Sn),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:cn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new jt(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(e,t,n=1){(this.width!==e||this.height!==t||this.depth!==n)&&(this.width=e,this.height=t,this.depth=n,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new Ka(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},hi=class extends Jl{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},ja=class extends jt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=Ut,this.minFilter=Ut,this.wrapR=_n,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Ql=class extends jt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=Ut,this.minFilter=Ut,this.wrapR=_n,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var ct=class{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[o+0],p=r[o+1],g=r[o+2],f=r[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(a===1){e[t+0]=d,e[t+1]=p,e[t+2]=g,e[t+3]=f;return}if(u!==f||l!==d||c!==p||h!==g){let _=1-a,m=l*d+c*p+h*g+u*f,y=m>=0?1:-1,x=1-m*m;if(x>Number.EPSILON){let E=Math.sqrt(x),w=Math.atan2(E,m*y);_=Math.sin(_*w)/E,a=Math.sin(a*w)/E}let b=a*y;if(l=l*_+d*b,c=c*_+p*b,h=h*_+g*b,u=u*_+f*b,_===1-a){let E=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=E,c*=E,h*=E,u*=E}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],p=r[o+2],g=r[o+3];return e[t]=a*g+h*u+l*p-c*d,e[t+1]=l*g+h*d+c*u-a*p,e[t+2]=c*g+h*p+a*d-l*u,e[t+3]=h*g-a*u-l*d-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),p=l(s/2),g=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u-d*p*g;break;case"YXZ":this._x=d*h*u+c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u+d*p*g;break;case"ZXY":this._x=d*h*u-c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u-d*p*g;break;case"ZYX":this._x=d*h*u-c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u+d*p*g;break;case"YZX":this._x=d*h*u+c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u-d*p*g;break;case"XZY":this._x=d*h*u-c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u+d*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){let p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(h-l)*p,this._y=(r-c)*p,this._z=(o-s)*p}else if(n>a&&n>u){let p=2*Math.sqrt(1+n-a-u);this._w=(h-l)/p,this._x=.25*p,this._y=(s+o)/p,this._z=(r+c)/p}else if(a>u){let p=2*Math.sqrt(1+a-n-u);this._w=(r-c)/p,this._x=(s+o)/p,this._y=.25*p,this._z=(l+h)/p}else{let p=2*Math.sqrt(1+u-n-a);this._w=(o-s)/p,this._x=(r+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ct(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,s=e._y,r=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*e._w+n*e._x+s*e._y+r*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let p=1-t;return this._w=p*o+t*this._w,this._x=p*n+t*this._x,this._y=p*s+t*this._y,this._z=p*r+t*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=Math.random(),t=Math.sqrt(1-e),n=Math.sqrt(e),s=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(t*Math.cos(s),n*Math.sin(r),n*Math.cos(r),t*Math.sin(s))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},R=class i{constructor(e=0,t=0,n=0){i.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Qu.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Qu.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){let t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*s-a*n),h=2*(a*t-r*s),u=2*(r*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,s=e.y,r=e.z,o=t.x,a=t.y,l=t.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return xl.copy(this).projectOnVector(e),this.sub(xl)}reflect(e){return this.sub(xl.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Ct(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,n=Math.sqrt(1-e**2);return this.x=n*Math.cos(t),this.y=n*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},xl=new R,Qu=new ct,En=class{constructor(e=new R(1/0,1/0,1/0),t=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Dn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Dn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Dn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Dn):Dn.fromBufferAttribute(r,o),Dn.applyMatrix4(e.matrixWorld),this.expandByPoint(Dn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),ua.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ua.copy(n.boundingBox)),ua.applyMatrix4(e.matrixWorld),this.union(ua)}let s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,Dn),Dn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(cr),da.subVectors(this.max,cr),ds.subVectors(e.a,cr),fs.subVectors(e.b,cr),ps.subVectors(e.c,cr),bi.subVectors(fs,ds),Mi.subVectors(ps,fs),Vi.subVectors(ds,ps);let t=[0,-bi.z,bi.y,0,-Mi.z,Mi.y,0,-Vi.z,Vi.y,bi.z,0,-bi.x,Mi.z,0,-Mi.x,Vi.z,0,-Vi.x,-bi.y,bi.x,0,-Mi.y,Mi.x,0,-Vi.y,Vi.x,0];return!yl(t,ds,fs,ps,da)||(t=[1,0,0,0,1,0,0,0,1],!yl(t,ds,fs,ps,da))?!1:(fa.crossVectors(bi,Mi),t=[fa.x,fa.y,fa.z],yl(t,ds,fs,ps,da))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Dn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Dn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ti[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ti[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ti[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ti[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ti[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ti[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ti[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ti[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ti),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},ti=[new R,new R,new R,new R,new R,new R,new R,new R],Dn=new R,ua=new En,ds=new R,fs=new R,ps=new R,bi=new R,Mi=new R,Vi=new R,cr=new R,da=new R,fa=new R,Gi=new R;function yl(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Gi.fromArray(i,r);let a=s.x*Math.abs(Gi.x)+s.y*Math.abs(Gi.y)+s.z*Math.abs(Gi.z),l=e.dot(Gi),c=t.dot(Gi),h=n.dot(Gi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var fg=new En,hr=new R,vl=new R,xn=class{constructor(e=new R,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t!==void 0?n.copy(t):fg.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;hr.subVectors(e,this.center);let t=hr.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(hr,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(vl.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(hr.copy(e.center).add(vl)),this.expandByPoint(hr.copy(e.center).sub(vl))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},ni=new R,bl=new R,pa=new R,wi=new R,Ml=new R,ma=new R,wl=new R,ui=class{constructor(e=new R,t=new R(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,ni)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=ni.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(ni.copy(this.origin).addScaledVector(this.direction,t),ni.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){bl.copy(e).add(t).multiplyScalar(.5),pa.copy(t).sub(e).normalize(),wi.copy(this.origin).sub(bl);let r=e.distanceTo(t)*.5,o=-this.direction.dot(pa),a=wi.dot(this.direction),l=-wi.dot(pa),c=wi.lengthSq(),h=Math.abs(1-o*o),u,d,p,g;if(h>0)if(u=o*l-a,d=o*a-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let f=1/h;u*=f,d*=f,p=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),p=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),p=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),p=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),p=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),p=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),p=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(bl).addScaledVector(pa,d),p}intersectSphere(e,t){ni.subVectors(e.center,this.origin);let n=ni.dot(this.direction),s=ni.dot(ni)-n*n,r=e.radius*e.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,s=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,s=(e.min.x-d.x)*c),h>=0?(r=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(r=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,ni)!==null}intersectTriangle(e,t,n,s,r){Ml.subVectors(t,e),ma.subVectors(n,e),wl.crossVectors(Ml,ma);let o=this.direction.dot(wl),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;wi.subVectors(this.origin,e);let l=a*this.direction.dot(ma.crossVectors(wi,ma));if(l<0)return null;let c=a*this.direction.dot(Ml.cross(wi));if(c<0||l+c>o)return null;let h=-a*wi.dot(wl);return h<0?null:this.at(h/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ke=class i{constructor(e,t,n,s,r,o,a,l,c,h,u,d,p,g,f,_){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c,h,u,d,p,g,f,_)}set(e,t,n,s,r,o,a,l,c,h,u,d,p,g,f,_){let m=this.elements;return m[0]=e,m[4]=t,m[8]=n,m[12]=s,m[1]=r,m[5]=o,m[9]=a,m[13]=l,m[2]=c,m[6]=h,m[10]=u,m[14]=d,m[3]=p,m[7]=g,m[11]=f,m[15]=_,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,s=1/ms.setFromMatrixColumn(e,0).length(),r=1/ms.setFromMatrixColumn(e,1).length(),o=1/ms.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(e.order==="XYZ"){let d=o*h,p=o*u,g=a*h,f=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=p+g*c,t[5]=d-f*c,t[9]=-a*l,t[2]=f-d*c,t[6]=g+p*c,t[10]=o*l}else if(e.order==="YXZ"){let d=l*h,p=l*u,g=c*h,f=c*u;t[0]=d+f*a,t[4]=g*a-p,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=p*a-g,t[6]=f+d*a,t[10]=o*l}else if(e.order==="ZXY"){let d=l*h,p=l*u,g=c*h,f=c*u;t[0]=d-f*a,t[4]=-o*u,t[8]=g+p*a,t[1]=p+g*a,t[5]=o*h,t[9]=f-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){let d=o*h,p=o*u,g=a*h,f=a*u;t[0]=l*h,t[4]=g*c-p,t[8]=d*c+f,t[1]=l*u,t[5]=f*c+d,t[9]=p*c-g,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){let d=o*l,p=o*c,g=a*l,f=a*c;t[0]=l*h,t[4]=f-d*u,t[8]=g*u+p,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=p*u+g,t[10]=d-f*u}else if(e.order==="XZY"){let d=o*l,p=o*c,g=a*l,f=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+f,t[5]=o*h,t[9]=p*u-g,t[2]=g*u-p,t[6]=a*h,t[10]=f*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(pg,e,mg)}lookAt(e,t,n){let s=this.elements;return mn.subVectors(e,t),mn.lengthSq()===0&&(mn.z=1),mn.normalize(),Si.crossVectors(n,mn),Si.lengthSq()===0&&(Math.abs(n.z)===1?mn.x+=1e-4:mn.z+=1e-4,mn.normalize(),Si.crossVectors(n,mn)),Si.normalize(),ga.crossVectors(mn,Si),s[0]=Si.x,s[4]=ga.x,s[8]=mn.x,s[1]=Si.y,s[5]=ga.y,s[9]=mn.y,s[2]=Si.z,s[6]=ga.z,s[10]=mn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],p=n[13],g=n[2],f=n[6],_=n[10],m=n[14],y=n[3],x=n[7],b=n[11],E=n[15],w=s[0],T=s[4],D=s[8],v=s[12],S=s[1],N=s[5],O=s[9],j=s[13],L=s[2],U=s[6],V=s[10],K=s[14],Y=s[3],q=s[7],$=s[11],ie=s[15];return r[0]=o*w+a*S+l*L+c*Y,r[4]=o*T+a*N+l*U+c*q,r[8]=o*D+a*O+l*V+c*$,r[12]=o*v+a*j+l*K+c*ie,r[1]=h*w+u*S+d*L+p*Y,r[5]=h*T+u*N+d*U+p*q,r[9]=h*D+u*O+d*V+p*$,r[13]=h*v+u*j+d*K+p*ie,r[2]=g*w+f*S+_*L+m*Y,r[6]=g*T+f*N+_*U+m*q,r[10]=g*D+f*O+_*V+m*$,r[14]=g*v+f*j+_*K+m*ie,r[3]=y*w+x*S+b*L+E*Y,r[7]=y*T+x*N+b*U+E*q,r[11]=y*D+x*O+b*V+E*$,r[15]=y*v+x*j+b*K+E*ie,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],p=e[14],g=e[3],f=e[7],_=e[11],m=e[15];return g*(+r*l*u-s*c*u-r*a*d+n*c*d+s*a*p-n*l*p)+f*(+t*l*p-t*c*d+r*o*d-s*o*p+s*c*h-r*l*h)+_*(+t*c*u-t*a*p-r*o*u+n*o*p+r*a*h-n*c*h)+m*(-s*a*h-t*l*u+t*a*d+s*o*u-n*o*d+n*l*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],p=e[11],g=e[12],f=e[13],_=e[14],m=e[15],y=u*_*c-f*d*c+f*l*p-a*_*p-u*l*m+a*d*m,x=g*d*c-h*_*c-g*l*p+o*_*p+h*l*m-o*d*m,b=h*f*c-g*u*c+g*a*p-o*f*p-h*a*m+o*u*m,E=g*u*l-h*f*l-g*a*d+o*f*d+h*a*_-o*u*_,w=t*y+n*x+s*b+r*E;if(w===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let T=1/w;return e[0]=y*T,e[1]=(f*d*r-u*_*r-f*s*p+n*_*p+u*s*m-n*d*m)*T,e[2]=(a*_*r-f*l*r+f*s*c-n*_*c-a*s*m+n*l*m)*T,e[3]=(u*l*r-a*d*r-u*s*c+n*d*c+a*s*p-n*l*p)*T,e[4]=x*T,e[5]=(h*_*r-g*d*r+g*s*p-t*_*p-h*s*m+t*d*m)*T,e[6]=(g*l*r-o*_*r-g*s*c+t*_*c+o*s*m-t*l*m)*T,e[7]=(o*d*r-h*l*r+h*s*c-t*d*c-o*s*p+t*l*p)*T,e[8]=b*T,e[9]=(g*u*r-h*f*r-g*n*p+t*f*p+h*n*m-t*u*m)*T,e[10]=(o*f*r-g*a*r+g*n*c-t*f*c-o*n*m+t*a*m)*T,e[11]=(h*a*r-o*u*r-h*n*c+t*u*c+o*n*p-t*a*p)*T,e[12]=E*T,e[13]=(h*f*s-g*u*s+g*n*d-t*f*d-h*n*_+t*u*_)*T,e[14]=(g*a*s-o*f*s-g*n*l+t*f*l+o*n*_-t*a*_)*T,e[15]=(o*u*s-h*a*s+h*n*l-t*u*l-o*n*d+t*a*d)*T,this}scale(e){let t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,a=e.y,l=e.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){let s=this.elements,r=t._x,o=t._y,a=t._z,l=t._w,c=r+r,h=o+o,u=a+a,d=r*c,p=r*h,g=r*u,f=o*h,_=o*u,m=a*u,y=l*c,x=l*h,b=l*u,E=n.x,w=n.y,T=n.z;return s[0]=(1-(f+m))*E,s[1]=(p+b)*E,s[2]=(g-x)*E,s[3]=0,s[4]=(p-b)*w,s[5]=(1-(d+m))*w,s[6]=(_+y)*w,s[7]=0,s[8]=(g+x)*T,s[9]=(_-y)*T,s[10]=(1-(d+f))*T,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){let s=this.elements,r=ms.set(s[0],s[1],s[2]).length(),o=ms.set(s[4],s[5],s[6]).length(),a=ms.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],Nn.copy(this);let c=1/r,h=1/o,u=1/a;return Nn.elements[0]*=c,Nn.elements[1]*=c,Nn.elements[2]*=c,Nn.elements[4]*=h,Nn.elements[5]*=h,Nn.elements[6]*=h,Nn.elements[8]*=u,Nn.elements[9]*=u,Nn.elements[10]*=u,t.setFromRotationMatrix(Nn),n.x=r,n.y=o,n.z=a,this}makePerspective(e,t,n,s,r,o,a=ci){let l=this.elements,c=2*r/(t-e),h=2*r/(n-s),u=(t+e)/(t-e),d=(n+s)/(n-s),p,g;if(a===ci)p=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===Xa)p=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=p,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,r,o,a=ci){let l=this.elements,c=1/(t-e),h=1/(n-s),u=1/(o-r),d=(t+e)*c,p=(n+s)*h,g,f;if(a===ci)g=(o+r)*u,f=-2*u;else if(a===Xa)g=r*u,f=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-p,l[2]=0,l[6]=0,l[10]=f,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},ms=new R,Nn=new ke,pg=new R(0,0,0),mg=new R(1,1,1),Si=new R,ga=new R,mn=new R,ed=new ke,td=new ct,zs=class i{constructor(e=0,t=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let s=e.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],p=s[10];switch(t){case"XYZ":this._y=Math.asin(Ct(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ct(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ct(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Ct(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Ct(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,p));break;case"XZY":this._z=Math.asin(-Ct(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return ed.makeRotationFromQuaternion(e),this.setFromRotationMatrix(ed,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return td.setFromEuler(this),this.setFromQuaternion(td,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};zs.DEFAULT_ORDER="XYZ";var Ar=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},gg=0,nd=new R,gs=new ct,ii=new ke,_a=new R,ur=new R,_g=new R,xg=new ct,id=new R(1,0,0),sd=new R(0,1,0),rd=new R(0,0,1),yg={type:"added"},vg={type:"removed"},bt=class i extends Bn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:gg++}),this.uuid=Fn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let e=new R,t=new zs,n=new ct,s=new R(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ke},normalMatrix:{value:new je}}),this.matrix=new ke,this.matrixWorld=new ke,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ar,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return gs.setFromAxisAngle(e,t),this.quaternion.multiply(gs),this}rotateOnWorldAxis(e,t){return gs.setFromAxisAngle(e,t),this.quaternion.premultiply(gs),this}rotateX(e){return this.rotateOnAxis(id,e)}rotateY(e){return this.rotateOnAxis(sd,e)}rotateZ(e){return this.rotateOnAxis(rd,e)}translateOnAxis(e,t){return nd.copy(e).applyQuaternion(this.quaternion),this.position.add(nd.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(id,e)}translateY(e){return this.translateOnAxis(sd,e)}translateZ(e){return this.translateOnAxis(rd,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ii.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?_a.copy(e):_a.set(e,t,n);let s=this.parent;this.updateWorldMatrix(!0,!1),ur.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ii.lookAt(ur,_a,this.up):ii.lookAt(_a,ur,this.up),this.quaternion.setFromRotationMatrix(ii),s&&(ii.extractRotation(s.matrixWorld),gs.setFromRotationMatrix(ii),this.quaternion.premultiply(gs.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(yg)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(vg)),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ii.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ii.multiply(e.parent.matrixWorld)),e.applyMatrix4(ii),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ur,e,_g),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ur,xg,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,s=t.length;n<s;n++){let r=t[n];(r.matrixWorldAutoUpdate===!0||e===!0)&&r.updateMatrixWorld(e)}}updateWorldMatrix(e,t){let n=this.parent;if(e===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++){let a=s[r];a.matrixWorldAutoUpdate===!0&&a.updateWorldMatrix(!1,!0)}}}toJSON(e){let t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxGeometryCount=this._maxGeometryCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(e.shapes,u)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(e.materials,this.material[l]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(e.animations,l))}}if(t){let a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),p=o(e.animations),g=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let s=e.children[n];this.add(s.clone())}return this}};bt.DEFAULT_UP=new R(0,1,0);bt.DEFAULT_MATRIX_AUTO_UPDATE=!0;bt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Un=new R,si=new R,Sl=new R,ri=new R,_s=new R,xs=new R,ad=new R,El=new R,Tl=new R,Al=new R,xa=!1,Cs=class i{constructor(e=new R,t=new R,n=new R){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),Un.subVectors(e,t),s.cross(Un);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){Un.subVectors(s,t),si.subVectors(n,t),Sl.subVectors(e,t);let o=Un.dot(Un),a=Un.dot(si),l=Un.dot(Sl),c=si.dot(si),h=si.dot(Sl),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let d=1/u,p=(c*l-a*h)*d,g=(o*h-a*l)*d;return r.set(1-p-g,g,p)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,ri)===null?!1:ri.x>=0&&ri.y>=0&&ri.x+ri.y<=1}static getUV(e,t,n,s,r,o,a,l){return xa===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),xa=!0),this.getInterpolation(e,t,n,s,r,o,a,l)}static getInterpolation(e,t,n,s,r,o,a,l){return this.getBarycoord(e,t,n,s,ri)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,ri.x),l.addScaledVector(o,ri.y),l.addScaledVector(a,ri.z),l)}static isFrontFacing(e,t,n,s){return Un.subVectors(n,t),si.subVectors(e,t),Un.cross(si).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Un.subVectors(this.c,this.b),si.subVectors(this.a,this.b),Un.cross(si).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return i.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return i.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,n,s,r){return xa===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),xa=!0),i.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}getInterpolation(e,t,n,s,r){return i.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return i.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return i.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,s=this.b,r=this.c,o,a;_s.subVectors(s,n),xs.subVectors(r,n),El.subVectors(e,n);let l=_s.dot(El),c=xs.dot(El);if(l<=0&&c<=0)return t.copy(n);Tl.subVectors(e,s);let h=_s.dot(Tl),u=xs.dot(Tl);if(h>=0&&u<=h)return t.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector(_s,o);Al.subVectors(e,r);let p=_s.dot(Al),g=xs.dot(Al);if(g>=0&&p<=g)return t.copy(r);let f=p*c-l*g;if(f<=0&&c>=0&&g<=0)return a=c/(c-g),t.copy(n).addScaledVector(xs,a);let _=h*g-p*u;if(_<=0&&u-h>=0&&p-g>=0)return ad.subVectors(r,s),a=(u-h)/(u-h+(p-g)),t.copy(s).addScaledVector(ad,a);let m=1/(_+f+d);return o=f*m,a=d*m,t.copy(n).addScaledVector(_s,o).addScaledVector(xs,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},xf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ei={h:0,s:0,l:0},ya={h:0,s:0,l:0};function Rl(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}var Re=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=ut){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,ot.toWorkingColorSpace(this,t),this}setRGB(e,t,n,s=ot.workingColorSpace){return this.r=e,this.g=t,this.b=n,ot.toWorkingColorSpace(this,s),this}setHSL(e,t,n,s=ot.workingColorSpace){if(e=Xc(e,1),t=Ct(t,0,1),n=Ct(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=Rl(o,r,e+1/3),this.g=Rl(o,r,e),this.b=Rl(o,r,e-1/3)}return ot.toWorkingColorSpace(this,s),this}setStyle(e,t=ut){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=ut){let n=xf[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ds(e.r),this.g=Ds(e.g),this.b=Ds(e.b),this}copyLinearToSRGB(e){return this.r=gl(e.r),this.g=gl(e.g),this.b=gl(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=ut){return ot.fromWorkingColorSpace(en.copy(this),e),Math.round(Ct(en.r*255,0,255))*65536+Math.round(Ct(en.g*255,0,255))*256+Math.round(Ct(en.b*255,0,255))}getHexString(e=ut){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=ot.workingColorSpace){ot.fromWorkingColorSpace(en.copy(this),t);let n=en.r,s=en.g,r=en.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=ot.workingColorSpace){return ot.fromWorkingColorSpace(en.copy(this),t),e.r=en.r,e.g=en.g,e.b=en.b,e}getStyle(e=ut){ot.fromWorkingColorSpace(en.copy(this),e);let t=en.r,n=en.g,s=en.b;return e!==ut?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(Ei),this.setHSL(Ei.h+e,Ei.s+t,Ei.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Ei),e.getHSL(ya);let n=xr(Ei.h,ya.h,t),s=xr(Ei.s,ya.s,t),r=xr(Ei.l,ya.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},en=new Re;Re.NAMES=xf;var bg=0,yn=class extends Bn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:bg++}),this.uuid=Fn(),this.name="",this.type="Material",this.blending=Is,this.side=Yn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Xl,this.blendDst=ql,this.blendEquation=Yi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Re(0,0,0),this.blendAlpha=0,this.depthFunc=ka,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Yu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=hs,this.stencilZFail=hs,this.stencilZPass=hs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Is&&(n.blending=this.blending),this.side!==Yn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Xl&&(n.blendSrc=this.blendSrc),this.blendDst!==ql&&(n.blendDst=this.blendDst),this.blendEquation!==Yi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ka&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Yu&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==hs&&(n.stencilFail=this.stencilFail),this.stencilZFail!==hs&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==hs&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(t){let r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Kt=class extends yn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Re(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=sf,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}};var Rt=new R,va=new he,Et=class{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=jl,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=li,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)va.fromBufferAttribute(this,t),va.applyMatrix3(e),this.setXY(t,va.x,va.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Rt.fromBufferAttribute(this,t),Rt.applyMatrix3(e),this.setXYZ(t,Rt.x,Rt.y,Rt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Rt.fromBufferAttribute(this,t),Rt.applyMatrix4(e),this.setXYZ(t,Rt.x,Rt.y,Rt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Rt.fromBufferAttribute(this,t),Rt.applyNormalMatrix(e),this.setXYZ(t,Rt.x,Rt.y,Rt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Rt.fromBufferAttribute(this,t),Rt.transformDirection(e),this.setXYZ(t,Rt.x,Rt.y,Rt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=qn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=lt(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=qn(t,this.array)),t}setX(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=qn(t,this.array)),t}setY(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=qn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=qn(t,this.array)),t}setW(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array),r=lt(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==jl&&(e.usage=this.usage),e}};var $a=class extends Et{constructor(e,t,n){super(new Uint16Array(e),t,n)}};var Za=class extends Et{constructor(e,t,n){super(new Uint32Array(e),t,n)}};var st=class extends Et{constructor(e,t,n){super(new Float32Array(e),t,n)}};var Mg=0,Mn=new ke,Cl=new bt,ys=new R,gn=new En,dr=new En,qt=new R,At=class i extends Bn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Mg++}),this.uuid=Fn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(_f(e)?Za:$a)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new je().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Mn.makeRotationFromQuaternion(e),this.applyMatrix4(Mn),this}rotateX(e){return Mn.makeRotationX(e),this.applyMatrix4(Mn),this}rotateY(e){return Mn.makeRotationY(e),this.applyMatrix4(Mn),this}rotateZ(e){return Mn.makeRotationZ(e),this.applyMatrix4(Mn),this}translate(e,t,n){return Mn.makeTranslation(e,t,n),this.applyMatrix4(Mn),this}scale(e,t,n){return Mn.makeScale(e,t,n),this.applyMatrix4(Mn),this}lookAt(e){return Cl.lookAt(e),Cl.updateMatrix(),this.applyMatrix4(Cl.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ys).negate(),this.translate(ys.x,ys.y,ys.z),this}setFromPoints(e){let t=[];for(let n=0,s=e.length;n<s;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new st(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new En);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){let r=t[n];gn.setFromBufferAttribute(r),this.morphTargetsRelative?(qt.addVectors(this.boundingBox.min,gn.min),this.boundingBox.expandByPoint(qt),qt.addVectors(this.boundingBox.max,gn.max),this.boundingBox.expandByPoint(qt)):(this.boundingBox.expandByPoint(gn.min),this.boundingBox.expandByPoint(gn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new xn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new R,1/0);return}if(e){let n=this.boundingSphere.center;if(gn.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){let a=t[r];dr.setFromBufferAttribute(a),this.morphTargetsRelative?(qt.addVectors(gn.min,dr.min),gn.expandByPoint(qt),qt.addVectors(gn.max,dr.max),gn.expandByPoint(qt)):(gn.expandByPoint(dr.min),gn.expandByPoint(dr.max))}gn.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)qt.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(qt));if(t)for(let r=0,o=t.length;r<o;r++){let a=t[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)qt.fromBufferAttribute(a,c),l&&(ys.fromBufferAttribute(e,c),qt.add(ys)),s=Math.max(s,n.distanceToSquared(qt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.array,s=t.position.array,r=t.normal.array,o=t.uv.array,a=s.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Et(new Float32Array(4*a),4));let l=this.getAttribute("tangent").array,c=[],h=[];for(let S=0;S<a;S++)c[S]=new R,h[S]=new R;let u=new R,d=new R,p=new R,g=new he,f=new he,_=new he,m=new R,y=new R;function x(S,N,O){u.fromArray(s,S*3),d.fromArray(s,N*3),p.fromArray(s,O*3),g.fromArray(o,S*2),f.fromArray(o,N*2),_.fromArray(o,O*2),d.sub(u),p.sub(u),f.sub(g),_.sub(g);let j=1/(f.x*_.y-_.x*f.y);isFinite(j)&&(m.copy(d).multiplyScalar(_.y).addScaledVector(p,-f.y).multiplyScalar(j),y.copy(p).multiplyScalar(f.x).addScaledVector(d,-_.x).multiplyScalar(j),c[S].add(m),c[N].add(m),c[O].add(m),h[S].add(y),h[N].add(y),h[O].add(y))}let b=this.groups;b.length===0&&(b=[{start:0,count:n.length}]);for(let S=0,N=b.length;S<N;++S){let O=b[S],j=O.start,L=O.count;for(let U=j,V=j+L;U<V;U+=3)x(n[U+0],n[U+1],n[U+2])}let E=new R,w=new R,T=new R,D=new R;function v(S){T.fromArray(r,S*3),D.copy(T);let N=c[S];E.copy(N),E.sub(T.multiplyScalar(T.dot(N))).normalize(),w.crossVectors(D,N);let j=w.dot(h[S])<0?-1:1;l[S*4]=E.x,l[S*4+1]=E.y,l[S*4+2]=E.z,l[S*4+3]=j}for(let S=0,N=b.length;S<N;++S){let O=b[S],j=O.start,L=O.count;for(let U=j,V=j+L;U<V;U+=3)v(n[U+0]),v(n[U+1]),v(n[U+2])}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Et(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,p=n.count;d<p;d++)n.setXYZ(d,0,0,0);let s=new R,r=new R,o=new R,a=new R,l=new R,c=new R,h=new R,u=new R;if(e)for(let d=0,p=e.count;d<p;d+=3){let g=e.getX(d+0),f=e.getX(d+1),_=e.getX(d+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,f),o.fromBufferAttribute(t,_),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,f),c.fromBufferAttribute(n,_),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(f,l.x,l.y,l.z),n.setXYZ(_,c.x,c.y,c.z)}else for(let d=0,p=t.count;d<p;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)qt.fromBufferAttribute(e,t),qt.normalize(),e.setXYZ(t,qt.x,qt.y,qt.z)}toNonIndexed(){function e(a,l){let c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h),p=0,g=0;for(let f=0,_=l.length;f<_;f++){a.isInterleavedBufferAttribute?p=l[f]*a.data.stride+a.offset:p=l[f]*h;for(let m=0;m<h;m++)d[g++]=c[p++]}return new Et(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=e(l,n);t.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let d=c[h],p=e(d,n);l.push(p)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let l in n){let c=n[l];e.data.attributes[l]=c.toJSON(e.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let p=c[u];h.push(p.toJSON(e.data))}h.length>0&&(s[l]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone(t));let s=e.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(t))}let r=e.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,p=u.length;d<p;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let o=e.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},od=new ke,Wi=new ui,ba=new xn,ld=new R,vs=new R,bs=new R,Ms=new R,Pl=new R,Ma=new R,wa=new he,Sa=new he,Ea=new he,cd=new R,hd=new R,ud=new R,Ta=new R,Aa=new R,Oe=class extends bt{constructor(e=new At,t=new Kt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,t){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);let a=this.morphTargetInfluences;if(r&&a){Ma.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&(Pl.fromBufferAttribute(u,e),o?Ma.addScaledVector(Pl,h):Ma.addScaledVector(Pl.sub(t),h))}t.add(Ma)}return t}raycast(e,t){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ba.copy(n.boundingSphere),ba.applyMatrix4(r),Wi.copy(e.ray).recast(e.near),!(ba.containsPoint(Wi.origin)===!1&&(Wi.intersectSphere(ba,ld)===null||Wi.origin.distanceToSquared(ld)>(e.far-e.near)**2))&&(od.copy(r).invert(),Wi.copy(e.ray).applyMatrix4(od),!(n.boundingBox!==null&&Wi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Wi)))}_computeIntersections(e,t,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,p=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,f=d.length;g<f;g++){let _=d[g],m=o[_.materialIndex],y=Math.max(_.start,p.start),x=Math.min(a.count,Math.min(_.start+_.count,p.start+p.count));for(let b=y,E=x;b<E;b+=3){let w=a.getX(b),T=a.getX(b+1),D=a.getX(b+2);s=Ra(this,m,e,n,c,h,u,w,T,D),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=_.materialIndex,t.push(s))}}else{let g=Math.max(0,p.start),f=Math.min(a.count,p.start+p.count);for(let _=g,m=f;_<m;_+=3){let y=a.getX(_),x=a.getX(_+1),b=a.getX(_+2);s=Ra(this,o,e,n,c,h,u,y,x,b),s&&(s.faceIndex=Math.floor(_/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,f=d.length;g<f;g++){let _=d[g],m=o[_.materialIndex],y=Math.max(_.start,p.start),x=Math.min(l.count,Math.min(_.start+_.count,p.start+p.count));for(let b=y,E=x;b<E;b+=3){let w=b,T=b+1,D=b+2;s=Ra(this,m,e,n,c,h,u,w,T,D),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=_.materialIndex,t.push(s))}}else{let g=Math.max(0,p.start),f=Math.min(l.count,p.start+p.count);for(let _=g,m=f;_<m;_+=3){let y=_,x=_+1,b=_+2;s=Ra(this,o,e,n,c,h,u,y,x,b),s&&(s.faceIndex=Math.floor(_/3),t.push(s))}}}};function wg(i,e,t,n,s,r,o,a){let l;if(e.side===Yt?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,e.side===Yn,a),l===null)return null;Aa.copy(a),Aa.applyMatrix4(i.matrixWorld);let c=t.ray.origin.distanceTo(Aa);return c<t.near||c>t.far?null:{distance:c,point:Aa.clone(),object:i}}function Ra(i,e,t,n,s,r,o,a,l,c){i.getVertexPosition(a,vs),i.getVertexPosition(l,bs),i.getVertexPosition(c,Ms);let h=wg(i,e,t,n,vs,bs,Ms,Ta);if(h){s&&(wa.fromBufferAttribute(s,a),Sa.fromBufferAttribute(s,l),Ea.fromBufferAttribute(s,c),h.uv=Cs.getInterpolation(Ta,vs,bs,Ms,wa,Sa,Ea,new he)),r&&(wa.fromBufferAttribute(r,a),Sa.fromBufferAttribute(r,l),Ea.fromBufferAttribute(r,c),h.uv1=Cs.getInterpolation(Ta,vs,bs,Ms,wa,Sa,Ea,new he),h.uv2=h.uv1),o&&(cd.fromBufferAttribute(o,a),hd.fromBufferAttribute(o,l),ud.fromBufferAttribute(o,c),h.normal=Cs.getInterpolation(Ta,vs,bs,Ms,cd,hd,ud,new R),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let u={a,b:l,c,normal:new R,materialIndex:0};Cs.getNormal(vs,bs,Ms,u.normal),h.face=u}return h}var Pt=class i extends At{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],d=0,p=0;g("z","y","x",-1,-1,n,t,e,o,r,0),g("z","y","x",1,-1,n,t,-e,o,r,1),g("x","z","y",1,1,e,n,t,s,o,2),g("x","z","y",1,-1,e,n,-t,s,o,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new st(c,3)),this.setAttribute("normal",new st(h,3)),this.setAttribute("uv",new st(u,2));function g(f,_,m,y,x,b,E,w,T,D,v){let S=b/T,N=E/D,O=b/2,j=E/2,L=w/2,U=T+1,V=D+1,K=0,Y=0,q=new R;for(let $=0;$<V;$++){let ie=$*N-j;for(let pe=0;pe<U;pe++){let X=pe*S-O;q[f]=X*y,q[_]=ie*x,q[m]=L,c.push(q.x,q.y,q.z),q[f]=0,q[_]=0,q[m]=w>0?1:-1,h.push(q.x,q.y,q.z),u.push(pe/T),u.push(1-$/D),K+=1}}for(let $=0;$<D;$++)for(let ie=0;ie<T;ie++){let pe=d+ie+U*$,X=d+ie+U*($+1),Q=d+(ie+1)+U*($+1),ge=d+(ie+1)+U*$;l.push(pe,X,ge),l.push(X,Q,ge),Y+=6}a.addGroup(p,Y,v),p+=Y,d+=K}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function Hs(i){let e={};for(let t in i){e[t]={};for(let n in i[t]){let s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function ln(i){let e={};for(let t=0;t<i.length;t++){let n=Hs(i[t]);for(let s in n)e[s]=n[s]}return e}function Sg(i){let e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function yf(i){return i.getRenderTarget()===null?i.outputColorSpace:ot.workingColorSpace}var Eg={clone:Hs,merge:ln},Tg=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Ag=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,kn=class extends yn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Tg,this.fragmentShader=Ag,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Hs(e.uniforms),this.uniformsGroups=Sg(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}},Ja=class extends bt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ke,this.projectionMatrix=new ke,this.projectionMatrixInverse=new ke,this.coordinateSystem=ci}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Ot=class extends Ja{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=ks*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(_r*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ks*2*Math.atan(Math.tan(_r*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(_r*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,t-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},ws=-90,Ss=1,ec=class extends bt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Ot(ws,Ss,e,t);s.layers=this.layers,this.add(s);let r=new Ot(ws,Ss,e,t);r.layers=this.layers,this.add(r);let o=new Ot(ws,Ss,e,t);o.layers=this.layers,this.add(o);let a=new Ot(ws,Ss,e,t);a.layers=this.layers,this.add(a);let l=new Ot(ws,Ss,e,t);l.layers=this.layers,this.add(l);let c=new Ot(ws,Ss,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,a,l]=t;for(let c of t)this.remove(c);if(e===ci)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Xa)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;let f=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,o),e.setRenderTarget(n,2,s),e.render(t,a),e.setRenderTarget(n,3,s),e.render(t,l),e.setRenderTarget(n,4,s),e.render(t,c),n.texture.generateMipmaps=f,e.setRenderTarget(n,5,s),e.render(t,h),e.setRenderTarget(u,d,p),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},Qa=class extends jt{constructor(e,t,n,s,r,o,a,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:Us,super(e,t,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},tc=class extends hi{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];t.encoding!==void 0&&(yr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===Zi?ut:Sn),this.texture=new Qa(s,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:cn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Pt(5,5,5),r=new kn({name:"CubemapFromEquirect",uniforms:Hs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Yt,blending:Ri});r.uniforms.tEquirect.value=t;let o=new Oe(s,r),a=t.minFilter;return t.minFilter===Li&&(t.minFilter=cn),new ec(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,s){let r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}},Ll=new R,Rg=new R,Cg=new je,On=class{constructor(e=new R(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let s=Ll.subVectors(n,t).cross(Rg.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let n=e.delta(Ll),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||Cg.getNormalMatrix(e),s=this.coplanarPoint(Ll).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},Xi=new xn,Ca=new R,Rr=class{constructor(e=new On,t=new On,n=new On,s=new On,r=new On,o=new On){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){let a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ci){let n=this.planes,s=e.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],p=s[8],g=s[9],f=s[10],_=s[11],m=s[12],y=s[13],x=s[14],b=s[15];if(n[0].setComponents(l-r,d-c,_-p,b-m).normalize(),n[1].setComponents(l+r,d+c,_+p,b+m).normalize(),n[2].setComponents(l+o,d+h,_+g,b+y).normalize(),n[3].setComponents(l-o,d-h,_-g,b-y).normalize(),n[4].setComponents(l-a,d-u,_-f,b-x).normalize(),t===ci)n[5].setComponents(l+a,d+u,_+f,b+x).normalize();else if(t===Xa)n[5].setComponents(a,u,f,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Xi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Xi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Xi)}intersectsSprite(e){return Xi.center.set(0,0,0),Xi.radius=.7071067811865476,Xi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Xi)}intersectsSphere(e){let t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let s=t[n];if(Ca.x=s.normal.x>0?e.max.x:e.min.x,Ca.y=s.normal.y>0?e.max.y:e.min.y,Ca.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Ca)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function vf(){let i=null,e=!1,t=null,n=null;function s(r,o){t(r,o),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function Pg(i,e){let t=e.isWebGL2,n=new WeakMap;function s(c,h){let u=c.array,d=c.usage,p=u.byteLength,g=i.createBuffer();i.bindBuffer(h,g),i.bufferData(h,u,d),c.onUploadCallback();let f;if(u instanceof Float32Array)f=i.FLOAT;else if(u instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(t)f=i.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else f=i.UNSIGNED_SHORT;else if(u instanceof Int16Array)f=i.SHORT;else if(u instanceof Uint32Array)f=i.UNSIGNED_INT;else if(u instanceof Int32Array)f=i.INT;else if(u instanceof Int8Array)f=i.BYTE;else if(u instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:g,type:f,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:p}}function r(c,h,u){let d=h.array,p=h._updateRange,g=h.updateRanges;if(i.bindBuffer(u,c),p.count===-1&&g.length===0&&i.bufferSubData(u,0,d),g.length!==0){for(let f=0,_=g.length;f<_;f++){let m=g[f];t?i.bufferSubData(u,m.start*d.BYTES_PER_ELEMENT,d,m.start,m.count):i.bufferSubData(u,m.start*d.BYTES_PER_ELEMENT,d.subarray(m.start,m.start+m.count))}h.clearUpdateRanges()}p.count!==-1&&(t?i.bufferSubData(u,p.offset*d.BYTES_PER_ELEMENT,d,p.offset,p.count):i.bufferSubData(u,p.offset*d.BYTES_PER_ELEMENT,d.subarray(p.offset,p.offset+p.count)),p.count=-1),h.onUploadCallback()}function o(c){return c.isInterleavedBufferAttribute&&(c=c.data),n.get(c)}function a(c){c.isInterleavedBufferAttribute&&(c=c.data);let h=n.get(c);h&&(i.deleteBuffer(h.buffer),n.delete(c))}function l(c,h){if(c.isGLBufferAttribute){let d=n.get(c);(!d||d.version<c.version)&&n.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);let u=n.get(c);if(u===void 0)n.set(c,s(c,h));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,c,h),u.version=c.version}}return{get:o,remove:a,update:l}}var es=class i extends At{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};let r=e/2,o=t/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=e/a,d=t/l,p=[],g=[],f=[],_=[];for(let m=0;m<h;m++){let y=m*d-o;for(let x=0;x<c;x++){let b=x*u-r;g.push(b,-y,0),f.push(0,0,1),_.push(x/a),_.push(1-m/l)}}for(let m=0;m<l;m++)for(let y=0;y<a;y++){let x=y+c*m,b=y+c*(m+1),E=y+1+c*(m+1),w=y+1+c*m;p.push(x,b,w),p.push(b,E,w)}this.setIndex(p),this.setAttribute("position",new st(g,3)),this.setAttribute("normal",new st(f,3)),this.setAttribute("uv",new st(_,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.widthSegments,e.heightSegments)}},Lg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Ig=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Dg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Ng=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ug=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Og=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Fg=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Bg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,kg=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,zg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Hg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Vg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Gg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Wg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Xg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,qg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Yg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Kg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,jg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,$g=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Zg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Jg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Qg=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,e0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,t0=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,n0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,i0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,s0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,r0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,a0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,o0="gl_FragColor = linearToOutputTexel( gl_FragColor );",l0=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,c0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,h0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,u0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,d0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,f0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,p0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,m0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,g0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,_0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,x0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,y0=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,v0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,b0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,M0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,w0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,S0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,E0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,T0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,A0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,R0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,C0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,P0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,L0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,I0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,D0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,N0=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,U0=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,O0=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,F0=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,B0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,k0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,z0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,H0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,V0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,G0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,W0=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,X0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,q0=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Y0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,K0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,j0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,$0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Z0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,J0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Q0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,e_=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,t_=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,n_=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,i_=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,s_=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,r_=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,a_=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,o_=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,l_=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,c_=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,h_=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,u_=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,d_=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,f_=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,p_=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,m_=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,g_=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,__=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,x_=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,y_=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,v_=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,b_=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,M_=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,w_=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,S_=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,E_=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,T_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,A_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,R_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,C_=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,P_=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,L_=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,I_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,D_=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,N_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,U_=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,O_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,F_=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,B_=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,k_=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,z_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,H_=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,V_=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,G_=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,W_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,X_=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,q_=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Y_=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,K_=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,j_=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Z_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,J_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Q_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ex=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,tx=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nx=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ix=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,rx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ax=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ox=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,lx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,cx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,We={alphahash_fragment:Lg,alphahash_pars_fragment:Ig,alphamap_fragment:Dg,alphamap_pars_fragment:Ng,alphatest_fragment:Ug,alphatest_pars_fragment:Og,aomap_fragment:Fg,aomap_pars_fragment:Bg,batching_pars_vertex:kg,batching_vertex:zg,begin_vertex:Hg,beginnormal_vertex:Vg,bsdfs:Gg,iridescence_fragment:Wg,bumpmap_pars_fragment:Xg,clipping_planes_fragment:qg,clipping_planes_pars_fragment:Yg,clipping_planes_pars_vertex:Kg,clipping_planes_vertex:jg,color_fragment:$g,color_pars_fragment:Zg,color_pars_vertex:Jg,color_vertex:Qg,common:e0,cube_uv_reflection_fragment:t0,defaultnormal_vertex:n0,displacementmap_pars_vertex:i0,displacementmap_vertex:s0,emissivemap_fragment:r0,emissivemap_pars_fragment:a0,colorspace_fragment:o0,colorspace_pars_fragment:l0,envmap_fragment:c0,envmap_common_pars_fragment:h0,envmap_pars_fragment:u0,envmap_pars_vertex:d0,envmap_physical_pars_fragment:S0,envmap_vertex:f0,fog_vertex:p0,fog_pars_vertex:m0,fog_fragment:g0,fog_pars_fragment:_0,gradientmap_pars_fragment:x0,lightmap_fragment:y0,lightmap_pars_fragment:v0,lights_lambert_fragment:b0,lights_lambert_pars_fragment:M0,lights_pars_begin:w0,lights_toon_fragment:E0,lights_toon_pars_fragment:T0,lights_phong_fragment:A0,lights_phong_pars_fragment:R0,lights_physical_fragment:C0,lights_physical_pars_fragment:P0,lights_fragment_begin:L0,lights_fragment_maps:I0,lights_fragment_end:D0,logdepthbuf_fragment:N0,logdepthbuf_pars_fragment:U0,logdepthbuf_pars_vertex:O0,logdepthbuf_vertex:F0,map_fragment:B0,map_pars_fragment:k0,map_particle_fragment:z0,map_particle_pars_fragment:H0,metalnessmap_fragment:V0,metalnessmap_pars_fragment:G0,morphcolor_vertex:W0,morphnormal_vertex:X0,morphtarget_pars_vertex:q0,morphtarget_vertex:Y0,normal_fragment_begin:K0,normal_fragment_maps:j0,normal_pars_fragment:$0,normal_pars_vertex:Z0,normal_vertex:J0,normalmap_pars_fragment:Q0,clearcoat_normal_fragment_begin:e_,clearcoat_normal_fragment_maps:t_,clearcoat_pars_fragment:n_,iridescence_pars_fragment:i_,opaque_fragment:s_,packing:r_,premultiplied_alpha_fragment:a_,project_vertex:o_,dithering_fragment:l_,dithering_pars_fragment:c_,roughnessmap_fragment:h_,roughnessmap_pars_fragment:u_,shadowmap_pars_fragment:d_,shadowmap_pars_vertex:f_,shadowmap_vertex:p_,shadowmask_pars_fragment:m_,skinbase_vertex:g_,skinning_pars_vertex:__,skinning_vertex:x_,skinnormal_vertex:y_,specularmap_fragment:v_,specularmap_pars_fragment:b_,tonemapping_fragment:M_,tonemapping_pars_fragment:w_,transmission_fragment:S_,transmission_pars_fragment:E_,uv_pars_fragment:T_,uv_pars_vertex:A_,uv_vertex:R_,worldpos_vertex:C_,background_vert:P_,background_frag:L_,backgroundCube_vert:I_,backgroundCube_frag:D_,cube_vert:N_,cube_frag:U_,depth_vert:O_,depth_frag:F_,distanceRGBA_vert:B_,distanceRGBA_frag:k_,equirect_vert:z_,equirect_frag:H_,linedashed_vert:V_,linedashed_frag:G_,meshbasic_vert:W_,meshbasic_frag:X_,meshlambert_vert:q_,meshlambert_frag:Y_,meshmatcap_vert:K_,meshmatcap_frag:j_,meshnormal_vert:$_,meshnormal_frag:Z_,meshphong_vert:J_,meshphong_frag:Q_,meshphysical_vert:ex,meshphysical_frag:tx,meshtoon_vert:nx,meshtoon_frag:ix,points_vert:sx,points_frag:rx,shadow_vert:ax,shadow_frag:ox,sprite_vert:lx,sprite_frag:cx},de={common:{diffuse:{value:new Re(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new je}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new je}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new je}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new je},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new je},normalScale:{value:new he(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new je},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new je}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new je}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new je}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Re(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Re(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0},uvTransform:{value:new je}},sprite:{diffuse:{value:new Re(16777215)},opacity:{value:1},center:{value:new he(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}}},Xn={basic:{uniforms:ln([de.common,de.specularmap,de.envmap,de.aomap,de.lightmap,de.fog]),vertexShader:We.meshbasic_vert,fragmentShader:We.meshbasic_frag},lambert:{uniforms:ln([de.common,de.specularmap,de.envmap,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.fog,de.lights,{emissive:{value:new Re(0)}}]),vertexShader:We.meshlambert_vert,fragmentShader:We.meshlambert_frag},phong:{uniforms:ln([de.common,de.specularmap,de.envmap,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.fog,de.lights,{emissive:{value:new Re(0)},specular:{value:new Re(1118481)},shininess:{value:30}}]),vertexShader:We.meshphong_vert,fragmentShader:We.meshphong_frag},standard:{uniforms:ln([de.common,de.envmap,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.roughnessmap,de.metalnessmap,de.fog,de.lights,{emissive:{value:new Re(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:We.meshphysical_vert,fragmentShader:We.meshphysical_frag},toon:{uniforms:ln([de.common,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.gradientmap,de.fog,de.lights,{emissive:{value:new Re(0)}}]),vertexShader:We.meshtoon_vert,fragmentShader:We.meshtoon_frag},matcap:{uniforms:ln([de.common,de.bumpmap,de.normalmap,de.displacementmap,de.fog,{matcap:{value:null}}]),vertexShader:We.meshmatcap_vert,fragmentShader:We.meshmatcap_frag},points:{uniforms:ln([de.points,de.fog]),vertexShader:We.points_vert,fragmentShader:We.points_frag},dashed:{uniforms:ln([de.common,de.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:We.linedashed_vert,fragmentShader:We.linedashed_frag},depth:{uniforms:ln([de.common,de.displacementmap]),vertexShader:We.depth_vert,fragmentShader:We.depth_frag},normal:{uniforms:ln([de.common,de.bumpmap,de.normalmap,de.displacementmap,{opacity:{value:1}}]),vertexShader:We.meshnormal_vert,fragmentShader:We.meshnormal_frag},sprite:{uniforms:ln([de.sprite,de.fog]),vertexShader:We.sprite_vert,fragmentShader:We.sprite_frag},background:{uniforms:{uvTransform:{value:new je},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:We.background_vert,fragmentShader:We.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:We.backgroundCube_vert,fragmentShader:We.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:We.cube_vert,fragmentShader:We.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:We.equirect_vert,fragmentShader:We.equirect_frag},distanceRGBA:{uniforms:ln([de.common,de.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:We.distanceRGBA_vert,fragmentShader:We.distanceRGBA_frag},shadow:{uniforms:ln([de.lights,de.fog,{color:{value:new Re(0)},opacity:{value:1}}]),vertexShader:We.shadow_vert,fragmentShader:We.shadow_frag}};Xn.physical={uniforms:ln([Xn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new je},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new je},clearcoatNormalScale:{value:new he(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new je},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new je},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new je},sheen:{value:0},sheenColor:{value:new Re(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new je},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new je},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new je},transmissionSamplerSize:{value:new he},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new je},attenuationDistance:{value:0},attenuationColor:{value:new Re(0)},specularColor:{value:new Re(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new je},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new je},anisotropyVector:{value:new he},anisotropyMap:{value:null},anisotropyMapTransform:{value:new je}}]),vertexShader:We.meshphysical_vert,fragmentShader:We.meshphysical_frag};var Pa={r:0,b:0,g:0};function hx(i,e,t,n,s,r,o){let a=new Re(0),l=r===!0?0:1,c,h,u=null,d=0,p=null;function g(_,m){let y=!1,x=m.isScene===!0?m.background:null;x&&x.isTexture&&(x=(m.backgroundBlurriness>0?t:e).get(x)),x===null?f(a,l):x&&x.isColor&&(f(x,1),y=!0);let b=i.xr.getEnvironmentBlendMode();b==="additive"?n.buffers.color.setClear(0,0,0,1,o):b==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||y)&&i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil),x&&(x.isCubeTexture||x.mapping===vo)?(h===void 0&&(h=new Oe(new Pt(1,1,1),new kn({name:"BackgroundCubeMaterial",uniforms:Hs(Xn.backgroundCube.uniforms),vertexShader:Xn.backgroundCube.vertexShader,fragmentShader:Xn.backgroundCube.fragmentShader,side:Yt,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(E,w,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=x,h.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=m.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,h.material.toneMapped=ot.getTransfer(x.colorSpace)!==_t,(u!==x||d!==x.version||p!==i.toneMapping)&&(h.material.needsUpdate=!0,u=x,d=x.version,p=i.toneMapping),h.layers.enableAll(),_.unshift(h,h.geometry,h.material,0,0,null)):x&&x.isTexture&&(c===void 0&&(c=new Oe(new es(2,2),new kn({name:"BackgroundMaterial",uniforms:Hs(Xn.background.uniforms),vertexShader:Xn.background.vertexShader,fragmentShader:Xn.background.fragmentShader,side:Yn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=x,c.material.uniforms.backgroundIntensity.value=m.backgroundIntensity,c.material.toneMapped=ot.getTransfer(x.colorSpace)!==_t,x.matrixAutoUpdate===!0&&x.updateMatrix(),c.material.uniforms.uvTransform.value.copy(x.matrix),(u!==x||d!==x.version||p!==i.toneMapping)&&(c.material.needsUpdate=!0,u=x,d=x.version,p=i.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null))}function f(_,m){_.getRGB(Pa,yf(i)),n.buffers.color.setClear(Pa.r,Pa.g,Pa.b,m,o)}return{getClearColor:function(){return a},setClearColor:function(_,m=1){a.set(_),l=m,f(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(_){l=_,f(a,l)},render:g}}function ux(i,e,t,n){let s=i.getParameter(i.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:e.get("OES_vertex_array_object"),o=n.isWebGL2||r!==null,a={},l=_(null),c=l,h=!1;function u(L,U,V,K,Y){let q=!1;if(o){let $=f(K,V,U);c!==$&&(c=$,p(c.object)),q=m(L,K,V,Y),q&&y(L,K,V,Y)}else{let $=U.wireframe===!0;(c.geometry!==K.id||c.program!==V.id||c.wireframe!==$)&&(c.geometry=K.id,c.program=V.id,c.wireframe=$,q=!0)}Y!==null&&t.update(Y,i.ELEMENT_ARRAY_BUFFER),(q||h)&&(h=!1,D(L,U,V,K),Y!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(Y).buffer))}function d(){return n.isWebGL2?i.createVertexArray():r.createVertexArrayOES()}function p(L){return n.isWebGL2?i.bindVertexArray(L):r.bindVertexArrayOES(L)}function g(L){return n.isWebGL2?i.deleteVertexArray(L):r.deleteVertexArrayOES(L)}function f(L,U,V){let K=V.wireframe===!0,Y=a[L.id];Y===void 0&&(Y={},a[L.id]=Y);let q=Y[U.id];q===void 0&&(q={},Y[U.id]=q);let $=q[K];return $===void 0&&($=_(d()),q[K]=$),$}function _(L){let U=[],V=[],K=[];for(let Y=0;Y<s;Y++)U[Y]=0,V[Y]=0,K[Y]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:U,enabledAttributes:V,attributeDivisors:K,object:L,attributes:{},index:null}}function m(L,U,V,K){let Y=c.attributes,q=U.attributes,$=0,ie=V.getAttributes();for(let pe in ie)if(ie[pe].location>=0){let Q=Y[pe],ge=q[pe];if(ge===void 0&&(pe==="instanceMatrix"&&L.instanceMatrix&&(ge=L.instanceMatrix),pe==="instanceColor"&&L.instanceColor&&(ge=L.instanceColor)),Q===void 0||Q.attribute!==ge||ge&&Q.data!==ge.data)return!0;$++}return c.attributesNum!==$||c.index!==K}function y(L,U,V,K){let Y={},q=U.attributes,$=0,ie=V.getAttributes();for(let pe in ie)if(ie[pe].location>=0){let Q=q[pe];Q===void 0&&(pe==="instanceMatrix"&&L.instanceMatrix&&(Q=L.instanceMatrix),pe==="instanceColor"&&L.instanceColor&&(Q=L.instanceColor));let ge={};ge.attribute=Q,Q&&Q.data&&(ge.data=Q.data),Y[pe]=ge,$++}c.attributes=Y,c.attributesNum=$,c.index=K}function x(){let L=c.newAttributes;for(let U=0,V=L.length;U<V;U++)L[U]=0}function b(L){E(L,0)}function E(L,U){let V=c.newAttributes,K=c.enabledAttributes,Y=c.attributeDivisors;V[L]=1,K[L]===0&&(i.enableVertexAttribArray(L),K[L]=1),Y[L]!==U&&((n.isWebGL2?i:e.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,U),Y[L]=U)}function w(){let L=c.newAttributes,U=c.enabledAttributes;for(let V=0,K=U.length;V<K;V++)U[V]!==L[V]&&(i.disableVertexAttribArray(V),U[V]=0)}function T(L,U,V,K,Y,q,$){$===!0?i.vertexAttribIPointer(L,U,V,Y,q):i.vertexAttribPointer(L,U,V,K,Y,q)}function D(L,U,V,K){if(n.isWebGL2===!1&&(L.isInstancedMesh||K.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;x();let Y=K.attributes,q=V.getAttributes(),$=U.defaultAttributeValues;for(let ie in q){let pe=q[ie];if(pe.location>=0){let X=Y[ie];if(X===void 0&&(ie==="instanceMatrix"&&L.instanceMatrix&&(X=L.instanceMatrix),ie==="instanceColor"&&L.instanceColor&&(X=L.instanceColor)),X!==void 0){let Q=X.normalized,ge=X.itemSize,Ee=t.get(X);if(Ee===void 0)continue;let we=Ee.buffer,Fe=Ee.type,Be=Ee.bytesPerElement,Le=n.isWebGL2===!0&&(Fe===i.INT||Fe===i.UNSIGNED_INT||X.gpuType===af);if(X.isInterleavedBufferAttribute){let Je=X.data,B=Je.stride,Gt=X.offset;if(Je.isInstancedInterleavedBuffer){for(let Ce=0;Ce<pe.locationSize;Ce++)E(pe.location+Ce,Je.meshPerAttribute);L.isInstancedMesh!==!0&&K._maxInstanceCount===void 0&&(K._maxInstanceCount=Je.meshPerAttribute*Je.count)}else for(let Ce=0;Ce<pe.locationSize;Ce++)b(pe.location+Ce);i.bindBuffer(i.ARRAY_BUFFER,we);for(let Ce=0;Ce<pe.locationSize;Ce++)T(pe.location+Ce,ge/pe.locationSize,Fe,Q,B*Be,(Gt+ge/pe.locationSize*Ce)*Be,Le)}else{if(X.isInstancedBufferAttribute){for(let Je=0;Je<pe.locationSize;Je++)E(pe.location+Je,X.meshPerAttribute);L.isInstancedMesh!==!0&&K._maxInstanceCount===void 0&&(K._maxInstanceCount=X.meshPerAttribute*X.count)}else for(let Je=0;Je<pe.locationSize;Je++)b(pe.location+Je);i.bindBuffer(i.ARRAY_BUFFER,we);for(let Je=0;Je<pe.locationSize;Je++)T(pe.location+Je,ge/pe.locationSize,Fe,Q,ge*Be,ge/pe.locationSize*Je*Be,Le)}}else if($!==void 0){let Q=$[ie];if(Q!==void 0)switch(Q.length){case 2:i.vertexAttrib2fv(pe.location,Q);break;case 3:i.vertexAttrib3fv(pe.location,Q);break;case 4:i.vertexAttrib4fv(pe.location,Q);break;default:i.vertexAttrib1fv(pe.location,Q)}}}}w()}function v(){O();for(let L in a){let U=a[L];for(let V in U){let K=U[V];for(let Y in K)g(K[Y].object),delete K[Y];delete U[V]}delete a[L]}}function S(L){if(a[L.id]===void 0)return;let U=a[L.id];for(let V in U){let K=U[V];for(let Y in K)g(K[Y].object),delete K[Y];delete U[V]}delete a[L.id]}function N(L){for(let U in a){let V=a[U];if(V[L.id]===void 0)continue;let K=V[L.id];for(let Y in K)g(K[Y].object),delete K[Y];delete V[L.id]}}function O(){j(),h=!0,c!==l&&(c=l,p(c.object))}function j(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:u,reset:O,resetDefaultState:j,dispose:v,releaseStatesOfGeometry:S,releaseStatesOfProgram:N,initAttributes:x,enableAttribute:b,disableUnusedAttributes:w}}function dx(i,e,t,n){let s=n.isWebGL2,r;function o(h){r=h}function a(h,u){i.drawArrays(r,h,u),t.update(u,r,1)}function l(h,u,d){if(d===0)return;let p,g;if(s)p=i,g="drawArraysInstanced";else if(p=e.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",p===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[g](r,h,u,d),t.update(u,r,d)}function c(h,u,d){if(d===0)return;let p=e.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<d;g++)this.render(h[g],u[g]);else{p.multiDrawArraysWEBGL(r,h,0,u,0,d);let g=0;for(let f=0;f<d;f++)g+=u[f];t.update(g,r,1)}}this.setMode=o,this.render=a,this.renderInstances=l,this.renderMultiDraw=c}function fx(i,e,t){let n;function s(){if(n!==void 0)return n;if(e.has("EXT_texture_filter_anisotropic")===!0){let T=e.get("EXT_texture_filter_anisotropic");n=i.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(T){if(T==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let o=typeof WebGL2RenderingContext<"u"&&i.constructor.name==="WebGL2RenderingContext",a=t.precision!==void 0?t.precision:"highp",l=r(a);l!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",l,"instead."),a=l);let c=o||e.has("WEBGL_draw_buffers"),h=t.logarithmicDepthBuffer===!0,u=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),d=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),p=i.getParameter(i.MAX_TEXTURE_SIZE),g=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),f=i.getParameter(i.MAX_VERTEX_ATTRIBS),_=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),m=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),x=d>0,b=o||e.has("OES_texture_float"),E=x&&b,w=o?i.getParameter(i.MAX_SAMPLES):0;return{isWebGL2:o,drawBuffers:c,getMaxAnisotropy:s,getMaxPrecision:r,precision:a,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:d,maxTextureSize:p,maxCubemapSize:g,maxAttributes:f,maxVertexUniforms:_,maxVaryings:m,maxFragmentUniforms:y,vertexTextures:x,floatFragmentTextures:b,floatVertexTextures:E,maxSamples:w}}function px(i){let e=this,t=null,n=0,s=!1,r=!1,o=new On,a=new je,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let p=u.length!==0||d||n!==0||s;return s=d,n=u.length,p},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,p){let g=u.clippingPlanes,f=u.clipIntersection,_=u.clipShadows,m=i.get(u);if(!s||g===null||g.length===0||r&&!_)r?h(null):c();else{let y=r?0:n,x=y*4,b=m.clippingState||null;l.value=b,b=h(g,d,x,p);for(let E=0;E!==x;++E)b[E]=t[E];m.clippingState=b,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=y}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,p,g){let f=u!==null?u.length:0,_=null;if(f!==0){if(_=l.value,g!==!0||_===null){let m=p+f*4,y=d.matrixWorldInverse;a.getNormalMatrix(y),(_===null||_.length<m)&&(_=new Float32Array(m));for(let x=0,b=p;x!==f;++x,b+=4)o.copy(u[x]).applyMatrix4(y,a),o.normal.toArray(_,b),_[b+3]=o.constant}l.value=_,l.needsUpdate=!0}return e.numPlanes=f,e.numIntersection=0,_}}function mx(i){let e=new WeakMap;function t(o,a){return a===Yl?o.mapping=Us:a===Kl&&(o.mapping=Os),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Yl||a===Kl)if(e.has(o)){let l=e.get(o).texture;return t(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new tc(l.height/2);return c.fromEquirectangularTexture(i,o),e.set(o,c),o.addEventListener("dispose",s),t(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}var Vs=class extends Ja{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-e,o=n+e,a=s+t,l=s-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Ps=4,dd=[.125,.215,.35,.446,.526,.582],Ki=20,Il=new Vs,fd=new Re,Dl=null,Nl=0,Ul=0,qi=(1+Math.sqrt(5))/2,Es=1/qi,pd=[new R(1,1,1),new R(-1,1,1),new R(1,1,-1),new R(-1,1,-1),new R(0,qi,Es),new R(0,qi,-Es),new R(Es,0,qi),new R(-Es,0,qi),new R(qi,Es,0),new R(-qi,Es,0)],Gs=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100){Dl=this._renderer.getRenderTarget(),Nl=this._renderer.getActiveCubeFace(),Ul=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,n,s,r),t>0&&this._blur(r,0,0,t),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=_d(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=gd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Dl,Nl,Ul),e.scissorTest=!1,La(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Us||e.mapping===Os?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Dl=this._renderer.getRenderTarget(),Nl=this._renderer.getActiveCubeFace(),Ul=this._renderer.getActiveMipmapLevel();let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:cn,minFilter:cn,generateMipmaps:!1,type:Er,format:wn,colorSpace:Ft,depthBuffer:!1},s=md(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=md(e,t,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=gx(r)),this._blurMaterial=_x(r,e,t)}return s}_compileMaterial(e){let t=new Oe(this._lodPlanes[0],e);this._renderer.compile(t,Il)}_sceneToCubeUV(e,t,n,s){let a=new Ot(90,1,t,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(fd),h.toneMapping=Ci,h.autoClear=!1;let p=new Kt({name:"PMREM.Background",side:Yt,depthWrite:!1,depthTest:!1}),g=new Oe(new Pt,p),f=!1,_=e.background;_?_.isColor&&(p.color.copy(_),e.background=null,f=!0):(p.color.copy(fd),f=!0);for(let m=0;m<6;m++){let y=m%3;y===0?(a.up.set(0,l[m],0),a.lookAt(c[m],0,0)):y===1?(a.up.set(0,0,l[m]),a.lookAt(0,c[m],0)):(a.up.set(0,l[m],0),a.lookAt(0,0,c[m]));let x=this._cubeSize;La(s,y*x,m>2?x:0,x,x),h.setRenderTarget(s),f&&h.render(g,a),h.render(e,a)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,e.background=_}_textureToCubeUV(e,t){let n=this._renderer,s=e.mapping===Us||e.mapping===Os;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=_d()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=gd());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new Oe(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=e;let l=this._cubeSize;La(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,Il)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;for(let s=1;s<this._lodPlanes.length;s++){let r=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=pd[(s-1)%pd.length];this._blur(e,s-1,s,r,o)}t.autoClear=n}_blur(e,t,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,s,"latitudinal",r),this._halfBlur(o,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new Oe(this._lodPlanes[s],c),d=c.uniforms,p=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*p):2*Math.PI/(2*Ki-1),f=r/g,_=isFinite(r)?1+Math.floor(h*f):Ki;_>Ki&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${_} samples when the maximum is set to ${Ki}`);let m=[],y=0;for(let T=0;T<Ki;++T){let D=T/f,v=Math.exp(-D*D/2);m.push(v),T===0?y+=v:T<_&&(y+=2*v)}for(let T=0;T<m.length;T++)m[T]=m[T]/y;d.envMap.value=e.texture,d.samples.value=_,d.weights.value=m,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);let{_lodMax:x}=this;d.dTheta.value=g,d.mipInt.value=x-n;let b=this._sizeLods[s],E=3*b*(s>x-Ps?s-x+Ps:0),w=4*(this._cubeSize-b);La(t,E,w,3*b,2*b),l.setRenderTarget(t),l.render(u,Il)}};function gx(i){let e=[],t=[],n=[],s=i,r=i-Ps+1+dd.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);t.push(a);let l=1/a;o>i-Ps?l=dd[o-i+Ps-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],p=6,g=6,f=3,_=2,m=1,y=new Float32Array(f*g*p),x=new Float32Array(_*g*p),b=new Float32Array(m*g*p);for(let w=0;w<p;w++){let T=w%3*2/3-1,D=w>2?0:-1,v=[T,D,0,T+2/3,D,0,T+2/3,D+1,0,T,D,0,T+2/3,D+1,0,T,D+1,0];y.set(v,f*g*w),x.set(d,_*g*w);let S=[w,w,w,w,w,w];b.set(S,m*g*w)}let E=new At;E.setAttribute("position",new Et(y,f)),E.setAttribute("uv",new Et(x,_)),E.setAttribute("faceIndex",new Et(b,m)),e.push(E),s>Ps&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function md(i,e,t){let n=new hi(i,e,t);return n.texture.mapping=vo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function La(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function _x(i,e,t){let n=new Float32Array(Ki),s=new R(0,1,0);return new kn({name:"SphericalGaussianBlur",defines:{n:Ki,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:qc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ri,depthTest:!1,depthWrite:!1})}function gd(){return new kn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:qc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ri,depthTest:!1,depthWrite:!1})}function _d(){return new kn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:qc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ri,depthTest:!1,depthWrite:!1})}function qc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function xx(i){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Yl||l===Kl,h=l===Us||l===Os;if(c||h)if(a.isRenderTargetTexture&&a.needsPMREMUpdate===!0){a.needsPMREMUpdate=!1;let u=e.get(a);return t===null&&(t=new Gs(i)),u=c?t.fromEquirectangular(a,u):t.fromCubemap(a,u),e.set(a,u),u.texture}else{if(e.has(a))return e.get(a).texture;{let u=a.image;if(c&&u&&u.height>0||h&&u&&s(u)){t===null&&(t=new Gs(i));let d=c?t.fromEquirectangular(a):t.fromCubemap(a);return e.set(a,d),a.addEventListener("dispose",r),d.texture}else return null}}}return a}function s(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function yx(i){let e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(n){n.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(n){let s=t(n);return s===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function vx(i,e,t,n){let s={},r=new WeakMap;function o(u){let d=u.target;d.index!==null&&e.remove(d.index);for(let g in d.attributes)e.remove(d.attributes[g]);for(let g in d.morphAttributes){let f=d.morphAttributes[g];for(let _=0,m=f.length;_<m;_++)e.remove(f[_])}d.removeEventListener("dispose",o),delete s[d.id];let p=r.get(d);p&&(e.remove(p),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,t.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)e.update(d[g],i.ARRAY_BUFFER);let p=u.morphAttributes;for(let g in p){let f=p[g];for(let _=0,m=f.length;_<m;_++)e.update(f[_],i.ARRAY_BUFFER)}}function c(u){let d=[],p=u.index,g=u.attributes.position,f=0;if(p!==null){let y=p.array;f=p.version;for(let x=0,b=y.length;x<b;x+=3){let E=y[x+0],w=y[x+1],T=y[x+2];d.push(E,w,w,T,T,E)}}else if(g!==void 0){let y=g.array;f=g.version;for(let x=0,b=y.length/3-1;x<b;x+=3){let E=x+0,w=x+1,T=x+2;d.push(E,w,w,T,T,E)}}else return;let _=new(_f(d)?Za:$a)(d,1);_.version=f;let m=r.get(u);m&&e.remove(m),r.set(u,_)}function h(u){let d=r.get(u);if(d){let p=u.index;p!==null&&d.version<p.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function bx(i,e,t,n){let s=n.isWebGL2,r;function o(p){r=p}let a,l;function c(p){a=p.type,l=p.bytesPerElement}function h(p,g){i.drawElements(r,g,a,p*l),t.update(g,r,1)}function u(p,g,f){if(f===0)return;let _,m;if(s)_=i,m="drawElementsInstanced";else if(_=e.get("ANGLE_instanced_arrays"),m="drawElementsInstancedANGLE",_===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}_[m](r,g,a,p*l,f),t.update(g,r,f)}function d(p,g,f){if(f===0)return;let _=e.get("WEBGL_multi_draw");if(_===null)for(let m=0;m<f;m++)this.render(p[m]/l,g[m]);else{_.multiDrawElementsWEBGL(r,g,0,a,p,0,f);let m=0;for(let y=0;y<f;y++)m+=g[y];t.update(m,r,1)}}this.setMode=o,this.setIndex=c,this.render=h,this.renderInstances=u,this.renderMultiDraw=d}function Mx(i){let e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(r/3);break;case i.LINES:t.lines+=a*(r/2);break;case i.LINE_STRIP:t.lines+=a*(r-1);break;case i.LINE_LOOP:t.lines+=a*r;break;case i.POINTS:t.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function wx(i,e){return i[0]-e[0]}function Sx(i,e){return Math.abs(e[1])-Math.abs(i[1])}function Ex(i,e,t){let n={},s=new Float32Array(8),r=new WeakMap,o=new dt,a=[];for(let c=0;c<8;c++)a[c]=[c,0];function l(c,h,u){let d=c.morphTargetInfluences;if(e.isWebGL2===!0){let p=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=p!==void 0?p.length:0,f=r.get(h);if(f===void 0||f.count!==g){let L=function(){O.dispose(),r.delete(h),h.removeEventListener("dispose",L)};f!==void 0&&f.texture.dispose();let y=h.morphAttributes.position!==void 0,x=h.morphAttributes.normal!==void 0,b=h.morphAttributes.color!==void 0,E=h.morphAttributes.position||[],w=h.morphAttributes.normal||[],T=h.morphAttributes.color||[],D=0;y===!0&&(D=1),x===!0&&(D=2),b===!0&&(D=3);let v=h.attributes.position.count*D,S=1;v>e.maxTextureSize&&(S=Math.ceil(v/e.maxTextureSize),v=e.maxTextureSize);let N=new Float32Array(v*S*4*g),O=new ja(N,v,S,g);O.type=li,O.needsUpdate=!0;let j=D*4;for(let U=0;U<g;U++){let V=E[U],K=w[U],Y=T[U],q=v*S*4*U;for(let $=0;$<V.count;$++){let ie=$*j;y===!0&&(o.fromBufferAttribute(V,$),N[q+ie+0]=o.x,N[q+ie+1]=o.y,N[q+ie+2]=o.z,N[q+ie+3]=0),x===!0&&(o.fromBufferAttribute(K,$),N[q+ie+4]=o.x,N[q+ie+5]=o.y,N[q+ie+6]=o.z,N[q+ie+7]=0),b===!0&&(o.fromBufferAttribute(Y,$),N[q+ie+8]=o.x,N[q+ie+9]=o.y,N[q+ie+10]=o.z,N[q+ie+11]=Y.itemSize===4?o.w:1)}}f={count:g,texture:O,size:new he(v,S)},r.set(h,f),h.addEventListener("dispose",L)}let _=0;for(let y=0;y<d.length;y++)_+=d[y];let m=h.morphTargetsRelative?1:1-_;u.getUniforms().setValue(i,"morphTargetBaseInfluence",m),u.getUniforms().setValue(i,"morphTargetInfluences",d),u.getUniforms().setValue(i,"morphTargetsTexture",f.texture,t),u.getUniforms().setValue(i,"morphTargetsTextureSize",f.size)}else{let p=d===void 0?0:d.length,g=n[h.id];if(g===void 0||g.length!==p){g=[];for(let x=0;x<p;x++)g[x]=[x,0];n[h.id]=g}for(let x=0;x<p;x++){let b=g[x];b[0]=x,b[1]=d[x]}g.sort(Sx);for(let x=0;x<8;x++)x<p&&g[x][1]?(a[x][0]=g[x][0],a[x][1]=g[x][1]):(a[x][0]=Number.MAX_SAFE_INTEGER,a[x][1]=0);a.sort(wx);let f=h.morphAttributes.position,_=h.morphAttributes.normal,m=0;for(let x=0;x<8;x++){let b=a[x],E=b[0],w=b[1];E!==Number.MAX_SAFE_INTEGER&&w?(f&&h.getAttribute("morphTarget"+x)!==f[E]&&h.setAttribute("morphTarget"+x,f[E]),_&&h.getAttribute("morphNormal"+x)!==_[E]&&h.setAttribute("morphNormal"+x,_[E]),s[x]=w,m+=w):(f&&h.hasAttribute("morphTarget"+x)===!0&&h.deleteAttribute("morphTarget"+x),_&&h.hasAttribute("morphNormal"+x)===!0&&h.deleteAttribute("morphNormal"+x),s[x]=0)}let y=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(i,"morphTargetBaseInfluence",y),u.getUniforms().setValue(i,"morphTargetInfluences",s)}}return{update:l}}function Tx(i,e,t,n){let s=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=e.get(l,h);if(s.get(u)!==c&&(e.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:r,dispose:o}}var eo=class extends jt{constructor(e,t,n,s,r,o,a,l,c,h){if(h=h!==void 0?h:$i,h!==$i&&h!==Fs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===$i&&(n=Ti),n===void 0&&h===Fs&&(n=ji),super(null,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:Ut,this.minFilter=l!==void 0?l:Ut,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},bf=new jt,Mf=new eo(1,1);Mf.compareFunction=gf;var wf=new ja,Sf=new Ql,Ef=new Qa,xd=[],yd=[],vd=new Float32Array(16),bd=new Float32Array(9),Md=new Float32Array(4);function js(i,e,t){let n=i[0];if(n<=0||n>0)return i;let s=e*t,r=xd[s];if(r===void 0&&(r=new Float32Array(s),xd[s]=r),e!==0){n.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(r,a)}return r}function Bt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function kt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function wo(i,e){let t=yd[e];t===void 0&&(t=new Int32Array(e),yd[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Ax(i,e){let t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Rx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2fv(this.addr,e),kt(t,e)}}function Cx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Bt(t,e))return;i.uniform3fv(this.addr,e),kt(t,e)}}function Px(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4fv(this.addr,e),kt(t,e)}}function Lx(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Md.set(n),i.uniformMatrix2fv(this.addr,!1,Md),kt(t,n)}}function Ix(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;bd.set(n),i.uniformMatrix3fv(this.addr,!1,bd),kt(t,n)}}function Dx(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;vd.set(n),i.uniformMatrix4fv(this.addr,!1,vd),kt(t,n)}}function Nx(i,e){let t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function Ux(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2iv(this.addr,e),kt(t,e)}}function Ox(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3iv(this.addr,e),kt(t,e)}}function Fx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4iv(this.addr,e),kt(t,e)}}function Bx(i,e){let t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function kx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2uiv(this.addr,e),kt(t,e)}}function zx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3uiv(this.addr,e),kt(t,e)}}function Hx(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4uiv(this.addr,e),kt(t,e)}}function Vx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r=this.type===i.SAMPLER_2D_SHADOW?Mf:bf;t.setTexture2D(e||r,s)}function Gx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||Sf,s)}function Wx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||Ef,s)}function Xx(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||wf,s)}function qx(i){switch(i){case 5126:return Ax;case 35664:return Rx;case 35665:return Cx;case 35666:return Px;case 35674:return Lx;case 35675:return Ix;case 35676:return Dx;case 5124:case 35670:return Nx;case 35667:case 35671:return Ux;case 35668:case 35672:return Ox;case 35669:case 35673:return Fx;case 5125:return Bx;case 36294:return kx;case 36295:return zx;case 36296:return Hx;case 35678:case 36198:case 36298:case 36306:case 35682:return Vx;case 35679:case 36299:case 36307:return Gx;case 35680:case 36300:case 36308:case 36293:return Wx;case 36289:case 36303:case 36311:case 36292:return Xx}}function Yx(i,e){i.uniform1fv(this.addr,e)}function Kx(i,e){let t=js(e,this.size,2);i.uniform2fv(this.addr,t)}function jx(i,e){let t=js(e,this.size,3);i.uniform3fv(this.addr,t)}function $x(i,e){let t=js(e,this.size,4);i.uniform4fv(this.addr,t)}function Zx(i,e){let t=js(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function Jx(i,e){let t=js(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function Qx(i,e){let t=js(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function ey(i,e){i.uniform1iv(this.addr,e)}function ty(i,e){i.uniform2iv(this.addr,e)}function ny(i,e){i.uniform3iv(this.addr,e)}function iy(i,e){i.uniform4iv(this.addr,e)}function sy(i,e){i.uniform1uiv(this.addr,e)}function ry(i,e){i.uniform2uiv(this.addr,e)}function ay(i,e){i.uniform3uiv(this.addr,e)}function oy(i,e){i.uniform4uiv(this.addr,e)}function ly(i,e,t){let n=this.cache,s=e.length,r=wo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||bf,r[o])}function cy(i,e,t){let n=this.cache,s=e.length,r=wo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||Sf,r[o])}function hy(i,e,t){let n=this.cache,s=e.length,r=wo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Ef,r[o])}function uy(i,e,t){let n=this.cache,s=e.length,r=wo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||wf,r[o])}function dy(i){switch(i){case 5126:return Yx;case 35664:return Kx;case 35665:return jx;case 35666:return $x;case 35674:return Zx;case 35675:return Jx;case 35676:return Qx;case 5124:case 35670:return ey;case 35667:case 35671:return ty;case 35668:case 35672:return ny;case 35669:case 35673:return iy;case 5125:return sy;case 36294:return ry;case 36295:return ay;case 36296:return oy;case 35678:case 36198:case 36298:case 36306:case 35682:return ly;case 35679:case 36299:case 36307:return cy;case 35680:case 36300:case 36308:case 36293:return hy;case 36289:case 36303:case 36311:case 36292:return uy}}var nc=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=qx(t.type)}},ic=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=dy(t.type)}},sc=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(e,t[a.id],n)}}},Ol=/(\w+)(\])?(\[|\.)?/g;function wd(i,e){i.seq.push(e),i.map[e.id]=e}function fy(i,e,t){let n=i.name,s=n.length;for(Ol.lastIndex=0;;){let r=Ol.exec(n),o=Ol.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){wd(t,c===void 0?new nc(a,i,e):new ic(a,i,e));break}else{let u=t.map[a];u===void 0&&(u=new sc(a),wd(t,u)),t=u}}}var Ns=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);fy(r,o,this)}}setValue(e,t,n,s){let r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){let s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){let a=t[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,s)}}static seqWithValue(e,t){let n=[];for(let s=0,r=e.length;s!==r;++s){let o=e[s];o.id in t&&n.push(o)}return n}};function Sd(i,e,t){let n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}var py=37297,my=0;function gy(i,e){let t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}function _y(i){let e=ot.getPrimaries(ot.workingColorSpace),t=ot.getPrimaries(i),n;switch(e===t?n="":e===Wa&&t===Ga?n="LinearDisplayP3ToLinearSRGB":e===Ga&&t===Wa&&(n="LinearSRGBToLinearDisplayP3"),i){case Ft:case Mo:return[n,"LinearTransferOETF"];case ut:case Wc:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[n,"LinearTransferOETF"]}}function Ed(i,e,t){let n=i.getShaderParameter(e,i.COMPILE_STATUS),s=i.getShaderInfoLog(e).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return t.toUpperCase()+`

`+s+`

`+gy(i.getShaderSource(e),o)}else return s}function xy(i,e){let t=_y(e);return`vec4 ${i}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function yy(i,e){let t;switch(e){case wm:t="Linear";break;case Sm:t="Reinhard";break;case Em:t="OptimizedCineon";break;case Bc:t="ACESFilmic";break;case Am:t="AgX";break;case Tm:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function vy(i){return[i.extensionDerivatives||i.envMapCubeUVHeight||i.bumpMap||i.normalMapTangentSpace||i.clearcoatNormalMap||i.flatShading||i.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(i.extensionFragDepth||i.logarithmicDepthBuffer)&&i.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",i.extensionDrawBuffers&&i.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(i.extensionShaderTextureLOD||i.envMap||i.transmission)&&i.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ls).join(`
`)}function by(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ls).join(`
`)}function My(i){let e=[];for(let t in i){let n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function wy(i,e){let t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(e,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function Ls(i){return i!==""}function Td(i,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Ad(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var Sy=/^[ \t]*#include +<([\w\d./]+)>/gm;function rc(i){return i.replace(Sy,Ty)}var Ey=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Ty(i,e){let t=We[e];if(t===void 0){let n=Ey.get(e);if(n!==void 0)t=We[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return rc(t)}var Ay=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Rd(i){return i.replace(Ay,Ry)}function Ry(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Cd(i){let e="precision "+i.precision+` float;
precision `+i.precision+" int;";return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Cy(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===nf?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===Fc?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===oi&&(e="SHADOWMAP_TYPE_VSM"),e}function Py(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Us:case Os:e="ENVMAP_TYPE_CUBE";break;case vo:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Ly(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Os:e="ENVMAP_MODE_REFRACTION";break}return e}function Iy(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case sf:e="ENVMAP_BLENDING_MULTIPLY";break;case bm:e="ENVMAP_BLENDING_MIX";break;case Mm:e="ENVMAP_BLENDING_ADD";break}return e}function Dy(i){let e=i.envMapCubeUVHeight;if(e===null)return null;let t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function Ny(i,e,t,n){let s=i.getContext(),r=t.defines,o=t.vertexShader,a=t.fragmentShader,l=Cy(t),c=Py(t),h=Ly(t),u=Iy(t),d=Dy(t),p=t.isWebGL2?"":vy(t),g=by(t),f=My(r),_=s.createProgram(),m,y,x=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f].filter(Ls).join(`
`),m.length>0&&(m+=`
`),y=[p,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f].filter(Ls).join(`
`),y.length>0&&(y+=`
`)):(m=[Cd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ls).join(`
`),y=[p,Cd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ci?"#define TONE_MAPPING":"",t.toneMapping!==Ci?We.tonemapping_pars_fragment:"",t.toneMapping!==Ci?yy("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",We.colorspace_pars_fragment,xy("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ls).join(`
`)),o=rc(o),o=Td(o,t),o=Ad(o,t),a=rc(a),a=Td(a,t),a=Ad(a,t),o=Rd(o),a=Rd(a),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,m=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,y=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===Ku?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Ku?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+y);let b=x+m+o,E=x+y+a,w=Sd(s,s.VERTEX_SHADER,b),T=Sd(s,s.FRAGMENT_SHADER,E);s.attachShader(_,w),s.attachShader(_,T),t.index0AttributeName!==void 0?s.bindAttribLocation(_,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function D(O){if(i.debug.checkShaderErrors){let j=s.getProgramInfoLog(_).trim(),L=s.getShaderInfoLog(w).trim(),U=s.getShaderInfoLog(T).trim(),V=!0,K=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(V=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,w,T);else{let Y=Ed(s,w,"vertex"),q=Ed(s,T,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Program Info Log: `+j+`
`+Y+`
`+q)}else j!==""?console.warn("THREE.WebGLProgram: Program Info Log:",j):(L===""||U==="")&&(K=!1);K&&(O.diagnostics={runnable:V,programLog:j,vertexShader:{log:L,prefix:m},fragmentShader:{log:U,prefix:y}})}s.deleteShader(w),s.deleteShader(T),v=new Ns(s,_),S=wy(s,_)}let v;this.getUniforms=function(){return v===void 0&&D(this),v};let S;this.getAttributes=function(){return S===void 0&&D(this),S};let N=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return N===!1&&(N=s.getProgramParameter(_,py)),N},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=my++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=w,this.fragmentShader=T,this}var Uy=0,ac=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new oc(e),t.set(e,n)),n}},oc=class{constructor(e){this.id=Uy++,this.code=e,this.usedTimes=0}};function Oy(i,e,t,n,s,r,o){let a=new Ar,l=new ac,c=[],h=s.isWebGL2,u=s.logarithmicDepthBuffer,d=s.vertexTextures,p=s.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(v){return v===0?"uv":`uv${v}`}function _(v,S,N,O,j){let L=O.fog,U=j.geometry,V=v.isMeshStandardMaterial?O.environment:null,K=(v.isMeshStandardMaterial?t:e).get(v.envMap||V),Y=K&&K.mapping===vo?K.image.height:null,q=g[v.type];v.precision!==null&&(p=s.getMaxPrecision(v.precision),p!==v.precision&&console.warn("THREE.WebGLProgram.getParameters:",v.precision,"not supported, using",p,"instead."));let $=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,ie=$!==void 0?$.length:0,pe=0;U.morphAttributes.position!==void 0&&(pe=1),U.morphAttributes.normal!==void 0&&(pe=2),U.morphAttributes.color!==void 0&&(pe=3);let X,Q,ge,Ee;if(q){let rn=Xn[q];X=rn.vertexShader,Q=rn.fragmentShader}else X=v.vertexShader,Q=v.fragmentShader,l.update(v),ge=l.getVertexShaderID(v),Ee=l.getFragmentShaderID(v);let we=i.getRenderTarget(),Fe=j.isInstancedMesh===!0,Be=j.isBatchedMesh===!0,Le=!!v.map,Je=!!v.matcap,B=!!K,Gt=!!v.aoMap,Ce=!!v.lightMap,Ne=!!v.bumpMap,be=!!v.normalMap,gt=!!v.displacementMap,ze=!!v.emissiveMap,C=!!v.metalnessMap,M=!!v.roughnessMap,k=v.anisotropy>0,se=v.clearcoat>0,te=v.iridescence>0,ne=v.sheen>0,Me=v.transmission>0,fe=k&&!!v.anisotropyMap,ye=se&&!!v.clearcoatMap,Ie=se&&!!v.clearcoatNormalMap,Ve=se&&!!v.clearcoatRoughnessMap,ee=te&&!!v.iridescenceMap,Qe=te&&!!v.iridescenceThicknessMap,P=ne&&!!v.sheenColorMap,J=ne&&!!v.sheenRoughnessMap,ue=!!v.specularMap,ae=!!v.specularColorMap,Se=!!v.specularIntensityMap,Ye=Me&&!!v.transmissionMap,et=Me&&!!v.thicknessMap,Xe=!!v.gradientMap,ce=!!v.alphaMap,I=v.alphaTest>0,oe=!!v.alphaHash,le=!!v.extensions,Pe=!!U.attributes.uv1,Te=!!U.attributes.uv2,it=!!U.attributes.uv3,at=Ci;return v.toneMapped&&(we===null||we.isXRRenderTarget===!0)&&(at=i.toneMapping),{isWebGL2:h,shaderID:q,shaderType:v.type,shaderName:v.name,vertexShader:X,fragmentShader:Q,defines:v.defines,customVertexShaderID:ge,customFragmentShaderID:Ee,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:p,batching:Be,instancing:Fe,instancingColor:Fe&&j.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:we===null?i.outputColorSpace:we.isXRRenderTarget===!0?we.texture.colorSpace:Ft,map:Le,matcap:Je,envMap:B,envMapMode:B&&K.mapping,envMapCubeUVHeight:Y,aoMap:Gt,lightMap:Ce,bumpMap:Ne,normalMap:be,displacementMap:d&&gt,emissiveMap:ze,normalMapObjectSpace:be&&v.normalMapType===Hm,normalMapTangentSpace:be&&v.normalMapType===mf,metalnessMap:C,roughnessMap:M,anisotropy:k,anisotropyMap:fe,clearcoat:se,clearcoatMap:ye,clearcoatNormalMap:Ie,clearcoatRoughnessMap:Ve,iridescence:te,iridescenceMap:ee,iridescenceThicknessMap:Qe,sheen:ne,sheenColorMap:P,sheenRoughnessMap:J,specularMap:ue,specularColorMap:ae,specularIntensityMap:Se,transmission:Me,transmissionMap:Ye,thicknessMap:et,gradientMap:Xe,opaque:v.transparent===!1&&v.blending===Is,alphaMap:ce,alphaTest:I,alphaHash:oe,combine:v.combine,mapUv:Le&&f(v.map.channel),aoMapUv:Gt&&f(v.aoMap.channel),lightMapUv:Ce&&f(v.lightMap.channel),bumpMapUv:Ne&&f(v.bumpMap.channel),normalMapUv:be&&f(v.normalMap.channel),displacementMapUv:gt&&f(v.displacementMap.channel),emissiveMapUv:ze&&f(v.emissiveMap.channel),metalnessMapUv:C&&f(v.metalnessMap.channel),roughnessMapUv:M&&f(v.roughnessMap.channel),anisotropyMapUv:fe&&f(v.anisotropyMap.channel),clearcoatMapUv:ye&&f(v.clearcoatMap.channel),clearcoatNormalMapUv:Ie&&f(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ve&&f(v.clearcoatRoughnessMap.channel),iridescenceMapUv:ee&&f(v.iridescenceMap.channel),iridescenceThicknessMapUv:Qe&&f(v.iridescenceThicknessMap.channel),sheenColorMapUv:P&&f(v.sheenColorMap.channel),sheenRoughnessMapUv:J&&f(v.sheenRoughnessMap.channel),specularMapUv:ue&&f(v.specularMap.channel),specularColorMapUv:ae&&f(v.specularColorMap.channel),specularIntensityMapUv:Se&&f(v.specularIntensityMap.channel),transmissionMapUv:Ye&&f(v.transmissionMap.channel),thicknessMapUv:et&&f(v.thicknessMap.channel),alphaMapUv:ce&&f(v.alphaMap.channel),vertexTangents:!!U.attributes.tangent&&(be||k),vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,vertexUv1s:Pe,vertexUv2s:Te,vertexUv3s:it,pointsUvs:j.isPoints===!0&&!!U.attributes.uv&&(Le||ce),fog:!!L,useFog:v.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:v.flatShading===!0,sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:j.isSkinnedMesh===!0,morphTargets:U.morphAttributes.position!==void 0,morphNormals:U.morphAttributes.normal!==void 0,morphColors:U.morphAttributes.color!==void 0,morphTargetsCount:ie,morphTextureStride:pe,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:v.dithering,shadowMapEnabled:i.shadowMap.enabled&&N.length>0,shadowMapType:i.shadowMap.type,toneMapping:at,useLegacyLights:i._useLegacyLights,decodeVideoTexture:Le&&v.map.isVideoTexture===!0&&ot.getTransfer(v.map.colorSpace)===_t,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===yt,flipSided:v.side===Yt,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionDerivatives:le&&v.extensions.derivatives===!0,extensionFragDepth:le&&v.extensions.fragDepth===!0,extensionDrawBuffers:le&&v.extensions.drawBuffers===!0,extensionShaderTextureLOD:le&&v.extensions.shaderTextureLOD===!0,extensionClipCullDistance:le&&v.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()}}function m(v){let S=[];if(v.shaderID?S.push(v.shaderID):(S.push(v.customVertexShaderID),S.push(v.customFragmentShaderID)),v.defines!==void 0)for(let N in v.defines)S.push(N),S.push(v.defines[N]);return v.isRawShaderMaterial===!1&&(y(S,v),x(S,v),S.push(i.outputColorSpace)),S.push(v.customProgramCacheKey),S.join()}function y(v,S){v.push(S.precision),v.push(S.outputColorSpace),v.push(S.envMapMode),v.push(S.envMapCubeUVHeight),v.push(S.mapUv),v.push(S.alphaMapUv),v.push(S.lightMapUv),v.push(S.aoMapUv),v.push(S.bumpMapUv),v.push(S.normalMapUv),v.push(S.displacementMapUv),v.push(S.emissiveMapUv),v.push(S.metalnessMapUv),v.push(S.roughnessMapUv),v.push(S.anisotropyMapUv),v.push(S.clearcoatMapUv),v.push(S.clearcoatNormalMapUv),v.push(S.clearcoatRoughnessMapUv),v.push(S.iridescenceMapUv),v.push(S.iridescenceThicknessMapUv),v.push(S.sheenColorMapUv),v.push(S.sheenRoughnessMapUv),v.push(S.specularMapUv),v.push(S.specularColorMapUv),v.push(S.specularIntensityMapUv),v.push(S.transmissionMapUv),v.push(S.thicknessMapUv),v.push(S.combine),v.push(S.fogExp2),v.push(S.sizeAttenuation),v.push(S.morphTargetsCount),v.push(S.morphAttributeCount),v.push(S.numDirLights),v.push(S.numPointLights),v.push(S.numSpotLights),v.push(S.numSpotLightMaps),v.push(S.numHemiLights),v.push(S.numRectAreaLights),v.push(S.numDirLightShadows),v.push(S.numPointLightShadows),v.push(S.numSpotLightShadows),v.push(S.numSpotLightShadowsWithMaps),v.push(S.numLightProbes),v.push(S.shadowMapType),v.push(S.toneMapping),v.push(S.numClippingPlanes),v.push(S.numClipIntersection),v.push(S.depthPacking)}function x(v,S){a.disableAll(),S.isWebGL2&&a.enable(0),S.supportsVertexTextures&&a.enable(1),S.instancing&&a.enable(2),S.instancingColor&&a.enable(3),S.matcap&&a.enable(4),S.envMap&&a.enable(5),S.normalMapObjectSpace&&a.enable(6),S.normalMapTangentSpace&&a.enable(7),S.clearcoat&&a.enable(8),S.iridescence&&a.enable(9),S.alphaTest&&a.enable(10),S.vertexColors&&a.enable(11),S.vertexAlphas&&a.enable(12),S.vertexUv1s&&a.enable(13),S.vertexUv2s&&a.enable(14),S.vertexUv3s&&a.enable(15),S.vertexTangents&&a.enable(16),S.anisotropy&&a.enable(17),S.alphaHash&&a.enable(18),S.batching&&a.enable(19),v.push(a.mask),a.disableAll(),S.fog&&a.enable(0),S.useFog&&a.enable(1),S.flatShading&&a.enable(2),S.logarithmicDepthBuffer&&a.enable(3),S.skinning&&a.enable(4),S.morphTargets&&a.enable(5),S.morphNormals&&a.enable(6),S.morphColors&&a.enable(7),S.premultipliedAlpha&&a.enable(8),S.shadowMapEnabled&&a.enable(9),S.useLegacyLights&&a.enable(10),S.doubleSided&&a.enable(11),S.flipSided&&a.enable(12),S.useDepthPacking&&a.enable(13),S.dithering&&a.enable(14),S.transmission&&a.enable(15),S.sheen&&a.enable(16),S.opaque&&a.enable(17),S.pointsUvs&&a.enable(18),S.decodeVideoTexture&&a.enable(19),v.push(a.mask)}function b(v){let S=g[v.type],N;if(S){let O=Xn[S];N=Eg.clone(O.uniforms)}else N=v.uniforms;return N}function E(v,S){let N;for(let O=0,j=c.length;O<j;O++){let L=c[O];if(L.cacheKey===S){N=L,++N.usedTimes;break}}return N===void 0&&(N=new Ny(i,S,v,r),c.push(N)),N}function w(v){if(--v.usedTimes===0){let S=c.indexOf(v);c[S]=c[c.length-1],c.pop(),v.destroy()}}function T(v){l.remove(v)}function D(){l.dispose()}return{getParameters:_,getProgramCacheKey:m,getUniforms:b,acquireProgram:E,releaseProgram:w,releaseShaderCache:T,programs:c,dispose:D}}function Fy(){let i=new WeakMap;function e(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function t(r){i.delete(r)}function n(r,o,a){i.get(r)[o]=a}function s(){i=new WeakMap}return{get:e,remove:t,update:n,dispose:s}}function By(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Pd(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Ld(){let i=[],e=0,t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(u,d,p,g,f,_){let m=i[e];return m===void 0?(m={id:u.id,object:u,geometry:d,material:p,groupOrder:g,renderOrder:u.renderOrder,z:f,group:_},i[e]=m):(m.id=u.id,m.object=u,m.geometry=d,m.material=p,m.groupOrder=g,m.renderOrder=u.renderOrder,m.z=f,m.group=_),e++,m}function a(u,d,p,g,f,_){let m=o(u,d,p,g,f,_);p.transmission>0?n.push(m):p.transparent===!0?s.push(m):t.push(m)}function l(u,d,p,g,f,_){let m=o(u,d,p,g,f,_);p.transmission>0?n.unshift(m):p.transparent===!0?s.unshift(m):t.unshift(m)}function c(u,d){t.length>1&&t.sort(u||By),n.length>1&&n.sort(d||Pd),s.length>1&&s.sort(d||Pd)}function h(){for(let u=e,d=i.length;u<d;u++){let p=i[u];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function ky(){let i=new WeakMap;function e(n,s){let r=i.get(n),o;return r===void 0?(o=new Ld,i.set(n,[o])):s>=r.length?(o=new Ld,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function zy(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new R,color:new Re};break;case"SpotLight":t={position:new R,direction:new R,color:new Re,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new R,color:new Re,distance:0,decay:0};break;case"HemisphereLight":t={direction:new R,skyColor:new Re,groundColor:new Re};break;case"RectAreaLight":t={color:new Re,position:new R,halfWidth:new R,halfHeight:new R};break}return i[e.id]=t,t}}}function Hy(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new he};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new he};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new he,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}var Vy=0;function Gy(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Wy(i,e){let t=new zy,n=Hy(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new R);let r=new R,o=new ke,a=new ke;function l(h,u){let d=0,p=0,g=0;for(let O=0;O<9;O++)s.probe[O].set(0,0,0);let f=0,_=0,m=0,y=0,x=0,b=0,E=0,w=0,T=0,D=0,v=0;h.sort(Gy);let S=u===!0?Math.PI:1;for(let O=0,j=h.length;O<j;O++){let L=h[O],U=L.color,V=L.intensity,K=L.distance,Y=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)d+=U.r*V*S,p+=U.g*V*S,g+=U.b*V*S;else if(L.isLightProbe){for(let q=0;q<9;q++)s.probe[q].addScaledVector(L.sh.coefficients[q],V);v++}else if(L.isDirectionalLight){let q=t.get(L);if(q.color.copy(L.color).multiplyScalar(L.intensity*S),L.castShadow){let $=L.shadow,ie=n.get(L);ie.shadowBias=$.bias,ie.shadowNormalBias=$.normalBias,ie.shadowRadius=$.radius,ie.shadowMapSize=$.mapSize,s.directionalShadow[f]=ie,s.directionalShadowMap[f]=Y,s.directionalShadowMatrix[f]=L.shadow.matrix,b++}s.directional[f]=q,f++}else if(L.isSpotLight){let q=t.get(L);q.position.setFromMatrixPosition(L.matrixWorld),q.color.copy(U).multiplyScalar(V*S),q.distance=K,q.coneCos=Math.cos(L.angle),q.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),q.decay=L.decay,s.spot[m]=q;let $=L.shadow;if(L.map&&(s.spotLightMap[T]=L.map,T++,$.updateMatrices(L),L.castShadow&&D++),s.spotLightMatrix[m]=$.matrix,L.castShadow){let ie=n.get(L);ie.shadowBias=$.bias,ie.shadowNormalBias=$.normalBias,ie.shadowRadius=$.radius,ie.shadowMapSize=$.mapSize,s.spotShadow[m]=ie,s.spotShadowMap[m]=Y,w++}m++}else if(L.isRectAreaLight){let q=t.get(L);q.color.copy(U).multiplyScalar(V),q.halfWidth.set(L.width*.5,0,0),q.halfHeight.set(0,L.height*.5,0),s.rectArea[y]=q,y++}else if(L.isPointLight){let q=t.get(L);if(q.color.copy(L.color).multiplyScalar(L.intensity*S),q.distance=L.distance,q.decay=L.decay,L.castShadow){let $=L.shadow,ie=n.get(L);ie.shadowBias=$.bias,ie.shadowNormalBias=$.normalBias,ie.shadowRadius=$.radius,ie.shadowMapSize=$.mapSize,ie.shadowCameraNear=$.camera.near,ie.shadowCameraFar=$.camera.far,s.pointShadow[_]=ie,s.pointShadowMap[_]=Y,s.pointShadowMatrix[_]=L.shadow.matrix,E++}s.point[_]=q,_++}else if(L.isHemisphereLight){let q=t.get(L);q.skyColor.copy(L.color).multiplyScalar(V*S),q.groundColor.copy(L.groundColor).multiplyScalar(V*S),s.hemi[x]=q,x++}}y>0&&(e.isWebGL2?i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=de.LTC_FLOAT_1,s.rectAreaLTC2=de.LTC_FLOAT_2):(s.rectAreaLTC1=de.LTC_HALF_1,s.rectAreaLTC2=de.LTC_HALF_2):i.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=de.LTC_FLOAT_1,s.rectAreaLTC2=de.LTC_FLOAT_2):i.has("OES_texture_half_float_linear")===!0?(s.rectAreaLTC1=de.LTC_HALF_1,s.rectAreaLTC2=de.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),s.ambient[0]=d,s.ambient[1]=p,s.ambient[2]=g;let N=s.hash;(N.directionalLength!==f||N.pointLength!==_||N.spotLength!==m||N.rectAreaLength!==y||N.hemiLength!==x||N.numDirectionalShadows!==b||N.numPointShadows!==E||N.numSpotShadows!==w||N.numSpotMaps!==T||N.numLightProbes!==v)&&(s.directional.length=f,s.spot.length=m,s.rectArea.length=y,s.point.length=_,s.hemi.length=x,s.directionalShadow.length=b,s.directionalShadowMap.length=b,s.pointShadow.length=E,s.pointShadowMap.length=E,s.spotShadow.length=w,s.spotShadowMap.length=w,s.directionalShadowMatrix.length=b,s.pointShadowMatrix.length=E,s.spotLightMatrix.length=w+T-D,s.spotLightMap.length=T,s.numSpotLightShadowsWithMaps=D,s.numLightProbes=v,N.directionalLength=f,N.pointLength=_,N.spotLength=m,N.rectAreaLength=y,N.hemiLength=x,N.numDirectionalShadows=b,N.numPointShadows=E,N.numSpotShadows=w,N.numSpotMaps=T,N.numLightProbes=v,s.version=Vy++)}function c(h,u){let d=0,p=0,g=0,f=0,_=0,m=u.matrixWorldInverse;for(let y=0,x=h.length;y<x;y++){let b=h[y];if(b.isDirectionalLight){let E=s.directional[d];E.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(r),E.direction.transformDirection(m),d++}else if(b.isSpotLight){let E=s.spot[g];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),E.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(r),E.direction.transformDirection(m),g++}else if(b.isRectAreaLight){let E=s.rectArea[f];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),a.identity(),o.copy(b.matrixWorld),o.premultiply(m),a.extractRotation(o),E.halfWidth.set(b.width*.5,0,0),E.halfHeight.set(0,b.height*.5,0),E.halfWidth.applyMatrix4(a),E.halfHeight.applyMatrix4(a),f++}else if(b.isPointLight){let E=s.point[p];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(m),p++}else if(b.isHemisphereLight){let E=s.hemi[_];E.direction.setFromMatrixPosition(b.matrixWorld),E.direction.transformDirection(m),_++}}}return{setup:l,setupView:c,state:s}}function Id(i,e){let t=new Wy(i,e),n=[],s=[];function r(){n.length=0,s.length=0}function o(u){n.push(u)}function a(u){s.push(u)}function l(u){t.setup(n,u)}function c(u){t.setupView(n,u)}return{init:r,state:{lightsArray:n,shadowsArray:s,lights:t},setupLights:l,setupLightsView:c,pushLight:o,pushShadow:a}}function Xy(i,e){let t=new WeakMap;function n(r,o=0){let a=t.get(r),l;return a===void 0?(l=new Id(i,e),t.set(r,[l])):o>=a.length?(l=new Id(i,e),a.push(l)):l=a[o],l}function s(){t=new WeakMap}return{get:n,dispose:s}}var lc=class extends yn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=km,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},cc=class extends yn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},qy=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Yy=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Ky(i,e,t){let n=new Rr,s=new he,r=new he,o=new dt,a=new lc({depthPacking:zm}),l=new cc,c={},h=t.maxTextureSize,u={[Yn]:Yt,[Yt]:Yn,[yt]:yt},d=new kn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new he},radius:{value:4}},vertexShader:qy,fragmentShader:Yy}),p=d.clone();p.defines.HORIZONTAL_PASS=1;let g=new At;g.setAttribute("position",new Et(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let f=new Oe(g,d),_=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=nf;let m=this.type;this.render=function(w,T,D){if(_.enabled===!1||_.autoUpdate===!1&&_.needsUpdate===!1||w.length===0)return;let v=i.getRenderTarget(),S=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),O=i.state;O.setBlending(Ri),O.buffers.color.setClear(1,1,1,1),O.buffers.depth.setTest(!0),O.setScissorTest(!1);let j=m!==oi&&this.type===oi,L=m===oi&&this.type!==oi;for(let U=0,V=w.length;U<V;U++){let K=w[U],Y=K.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",K,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;s.copy(Y.mapSize);let q=Y.getFrameExtents();if(s.multiply(q),r.copy(Y.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/q.x),s.x=r.x*q.x,Y.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/q.y),s.y=r.y*q.y,Y.mapSize.y=r.y)),Y.map===null||j===!0||L===!0){let ie=this.type!==oi?{minFilter:Ut,magFilter:Ut}:{};Y.map!==null&&Y.map.dispose(),Y.map=new hi(s.x,s.y,ie),Y.map.texture.name=K.name+".shadowMap",Y.camera.updateProjectionMatrix()}i.setRenderTarget(Y.map),i.clear();let $=Y.getViewportCount();for(let ie=0;ie<$;ie++){let pe=Y.getViewport(ie);o.set(r.x*pe.x,r.y*pe.y,r.x*pe.z,r.y*pe.w),O.viewport(o),Y.updateMatrices(K,ie),n=Y.getFrustum(),b(T,D,Y.camera,K,this.type)}Y.isPointLightShadow!==!0&&this.type===oi&&y(Y,D),Y.needsUpdate=!1}m=this.type,_.needsUpdate=!1,i.setRenderTarget(v,S,N)};function y(w,T){let D=e.update(f);d.defines.VSM_SAMPLES!==w.blurSamples&&(d.defines.VSM_SAMPLES=w.blurSamples,p.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),w.mapPass===null&&(w.mapPass=new hi(s.x,s.y)),d.uniforms.shadow_pass.value=w.map.texture,d.uniforms.resolution.value=w.mapSize,d.uniforms.radius.value=w.radius,i.setRenderTarget(w.mapPass),i.clear(),i.renderBufferDirect(T,null,D,d,f,null),p.uniforms.shadow_pass.value=w.mapPass.texture,p.uniforms.resolution.value=w.mapSize,p.uniforms.radius.value=w.radius,i.setRenderTarget(w.map),i.clear(),i.renderBufferDirect(T,null,D,p,f,null)}function x(w,T,D,v){let S=null,N=D.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(N!==void 0)S=N;else if(S=D.isPointLight===!0?l:a,i.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0){let O=S.uuid,j=T.uuid,L=c[O];L===void 0&&(L={},c[O]=L);let U=L[j];U===void 0&&(U=S.clone(),L[j]=U,T.addEventListener("dispose",E)),S=U}if(S.visible=T.visible,S.wireframe=T.wireframe,v===oi?S.side=T.shadowSide!==null?T.shadowSide:T.side:S.side=T.shadowSide!==null?T.shadowSide:u[T.side],S.alphaMap=T.alphaMap,S.alphaTest=T.alphaTest,S.map=T.map,S.clipShadows=T.clipShadows,S.clippingPlanes=T.clippingPlanes,S.clipIntersection=T.clipIntersection,S.displacementMap=T.displacementMap,S.displacementScale=T.displacementScale,S.displacementBias=T.displacementBias,S.wireframeLinewidth=T.wireframeLinewidth,S.linewidth=T.linewidth,D.isPointLight===!0&&S.isMeshDistanceMaterial===!0){let O=i.properties.get(S);O.light=D}return S}function b(w,T,D,v,S){if(w.visible===!1)return;if(w.layers.test(T.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&S===oi)&&(!w.frustumCulled||n.intersectsObject(w))){w.modelViewMatrix.multiplyMatrices(D.matrixWorldInverse,w.matrixWorld);let j=e.update(w),L=w.material;if(Array.isArray(L)){let U=j.groups;for(let V=0,K=U.length;V<K;V++){let Y=U[V],q=L[Y.materialIndex];if(q&&q.visible){let $=x(w,q,v,S);w.onBeforeShadow(i,w,T,D,j,$,Y),i.renderBufferDirect(D,null,j,$,w,Y),w.onAfterShadow(i,w,T,D,j,$,Y)}}}else if(L.visible){let U=x(w,L,v,S);w.onBeforeShadow(i,w,T,D,j,U,null),i.renderBufferDirect(D,null,j,U,w,null),w.onAfterShadow(i,w,T,D,j,U,null)}}let O=w.children;for(let j=0,L=O.length;j<L;j++)b(O[j],T,D,v,S)}function E(w){w.target.removeEventListener("dispose",E);for(let D in c){let v=c[D],S=w.target.uuid;S in v&&(v[S].dispose(),delete v[S])}}}function jy(i,e,t){let n=t.isWebGL2;function s(){let I=!1,oe=new dt,le=null,Pe=new dt(0,0,0,0);return{setMask:function(Te){le!==Te&&!I&&(i.colorMask(Te,Te,Te,Te),le=Te)},setLocked:function(Te){I=Te},setClear:function(Te,it,at,Wt,rn){rn===!0&&(Te*=Wt,it*=Wt,at*=Wt),oe.set(Te,it,at,Wt),Pe.equals(oe)===!1&&(i.clearColor(Te,it,at,Wt),Pe.copy(oe))},reset:function(){I=!1,le=null,Pe.set(-1,0,0,0)}}}function r(){let I=!1,oe=null,le=null,Pe=null;return{setTest:function(Te){Te?Be(i.DEPTH_TEST):Le(i.DEPTH_TEST)},setMask:function(Te){oe!==Te&&!I&&(i.depthMask(Te),oe=Te)},setFunc:function(Te){if(le!==Te){switch(Te){case pm:i.depthFunc(i.NEVER);break;case mm:i.depthFunc(i.ALWAYS);break;case gm:i.depthFunc(i.LESS);break;case ka:i.depthFunc(i.LEQUAL);break;case _m:i.depthFunc(i.EQUAL);break;case xm:i.depthFunc(i.GEQUAL);break;case ym:i.depthFunc(i.GREATER);break;case vm:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}le=Te}},setLocked:function(Te){I=Te},setClear:function(Te){Pe!==Te&&(i.clearDepth(Te),Pe=Te)},reset:function(){I=!1,oe=null,le=null,Pe=null}}}function o(){let I=!1,oe=null,le=null,Pe=null,Te=null,it=null,at=null,Wt=null,rn=null;return{setTest:function(pt){I||(pt?Be(i.STENCIL_TEST):Le(i.STENCIL_TEST))},setMask:function(pt){oe!==pt&&!I&&(i.stencilMask(pt),oe=pt)},setFunc:function(pt,an,Wn){(le!==pt||Pe!==an||Te!==Wn)&&(i.stencilFunc(pt,an,Wn),le=pt,Pe=an,Te=Wn)},setOp:function(pt,an,Wn){(it!==pt||at!==an||Wt!==Wn)&&(i.stencilOp(pt,an,Wn),it=pt,at=an,Wt=Wn)},setLocked:function(pt){I=pt},setClear:function(pt){rn!==pt&&(i.clearStencil(pt),rn=pt)},reset:function(){I=!1,oe=null,le=null,Pe=null,Te=null,it=null,at=null,Wt=null,rn=null}}}let a=new s,l=new r,c=new o,h=new WeakMap,u=new WeakMap,d={},p={},g=new WeakMap,f=[],_=null,m=!1,y=null,x=null,b=null,E=null,w=null,T=null,D=null,v=new Re(0,0,0),S=0,N=!1,O=null,j=null,L=null,U=null,V=null,K=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),Y=!1,q=0,$=i.getParameter(i.VERSION);$.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec($)[1]),Y=q>=1):$.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec($)[1]),Y=q>=2);let ie=null,pe={},X=i.getParameter(i.SCISSOR_BOX),Q=i.getParameter(i.VIEWPORT),ge=new dt().fromArray(X),Ee=new dt().fromArray(Q);function we(I,oe,le,Pe){let Te=new Uint8Array(4),it=i.createTexture();i.bindTexture(I,it),i.texParameteri(I,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(I,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let at=0;at<le;at++)n&&(I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY)?i.texImage3D(oe,0,i.RGBA,1,1,Pe,0,i.RGBA,i.UNSIGNED_BYTE,Te):i.texImage2D(oe+at,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Te);return it}let Fe={};Fe[i.TEXTURE_2D]=we(i.TEXTURE_2D,i.TEXTURE_2D,1),Fe[i.TEXTURE_CUBE_MAP]=we(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(Fe[i.TEXTURE_2D_ARRAY]=we(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Fe[i.TEXTURE_3D]=we(i.TEXTURE_3D,i.TEXTURE_3D,1,1)),a.setClear(0,0,0,1),l.setClear(1),c.setClear(0),Be(i.DEPTH_TEST),l.setFunc(ka),ze(!1),C(gu),Be(i.CULL_FACE),be(Ri);function Be(I){d[I]!==!0&&(i.enable(I),d[I]=!0)}function Le(I){d[I]!==!1&&(i.disable(I),d[I]=!1)}function Je(I,oe){return p[I]!==oe?(i.bindFramebuffer(I,oe),p[I]=oe,n&&(I===i.DRAW_FRAMEBUFFER&&(p[i.FRAMEBUFFER]=oe),I===i.FRAMEBUFFER&&(p[i.DRAW_FRAMEBUFFER]=oe)),!0):!1}function B(I,oe){let le=f,Pe=!1;if(I)if(le=g.get(oe),le===void 0&&(le=[],g.set(oe,le)),I.isWebGLMultipleRenderTargets){let Te=I.texture;if(le.length!==Te.length||le[0]!==i.COLOR_ATTACHMENT0){for(let it=0,at=Te.length;it<at;it++)le[it]=i.COLOR_ATTACHMENT0+it;le.length=Te.length,Pe=!0}}else le[0]!==i.COLOR_ATTACHMENT0&&(le[0]=i.COLOR_ATTACHMENT0,Pe=!0);else le[0]!==i.BACK&&(le[0]=i.BACK,Pe=!0);Pe&&(t.isWebGL2?i.drawBuffers(le):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(le))}function Gt(I){return _!==I?(i.useProgram(I),_=I,!0):!1}let Ce={[Yi]:i.FUNC_ADD,[Qp]:i.FUNC_SUBTRACT,[em]:i.FUNC_REVERSE_SUBTRACT};if(n)Ce[yu]=i.MIN,Ce[vu]=i.MAX;else{let I=e.get("EXT_blend_minmax");I!==null&&(Ce[yu]=I.MIN_EXT,Ce[vu]=I.MAX_EXT)}let Ne={[tm]:i.ZERO,[nm]:i.ONE,[im]:i.SRC_COLOR,[Xl]:i.SRC_ALPHA,[cm]:i.SRC_ALPHA_SATURATE,[om]:i.DST_COLOR,[rm]:i.DST_ALPHA,[sm]:i.ONE_MINUS_SRC_COLOR,[ql]:i.ONE_MINUS_SRC_ALPHA,[lm]:i.ONE_MINUS_DST_COLOR,[am]:i.ONE_MINUS_DST_ALPHA,[hm]:i.CONSTANT_COLOR,[um]:i.ONE_MINUS_CONSTANT_COLOR,[dm]:i.CONSTANT_ALPHA,[fm]:i.ONE_MINUS_CONSTANT_ALPHA};function be(I,oe,le,Pe,Te,it,at,Wt,rn,pt){if(I===Ri){m===!0&&(Le(i.BLEND),m=!1);return}if(m===!1&&(Be(i.BLEND),m=!0),I!==Jp){if(I!==y||pt!==N){if((x!==Yi||w!==Yi)&&(i.blendEquation(i.FUNC_ADD),x=Yi,w=Yi),pt)switch(I){case Is:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case wr:i.blendFunc(i.ONE,i.ONE);break;case _u:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case xu:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}else switch(I){case Is:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case wr:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case _u:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case xu:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}b=null,E=null,T=null,D=null,v.set(0,0,0),S=0,y=I,N=pt}return}Te=Te||oe,it=it||le,at=at||Pe,(oe!==x||Te!==w)&&(i.blendEquationSeparate(Ce[oe],Ce[Te]),x=oe,w=Te),(le!==b||Pe!==E||it!==T||at!==D)&&(i.blendFuncSeparate(Ne[le],Ne[Pe],Ne[it],Ne[at]),b=le,E=Pe,T=it,D=at),(Wt.equals(v)===!1||rn!==S)&&(i.blendColor(Wt.r,Wt.g,Wt.b,rn),v.copy(Wt),S=rn),y=I,N=!1}function gt(I,oe){I.side===yt?Le(i.CULL_FACE):Be(i.CULL_FACE);let le=I.side===Yt;oe&&(le=!le),ze(le),I.blending===Is&&I.transparent===!1?be(Ri):be(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),l.setFunc(I.depthFunc),l.setTest(I.depthTest),l.setMask(I.depthWrite),a.setMask(I.colorWrite);let Pe=I.stencilWrite;c.setTest(Pe),Pe&&(c.setMask(I.stencilWriteMask),c.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),c.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),k(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?Be(i.SAMPLE_ALPHA_TO_COVERAGE):Le(i.SAMPLE_ALPHA_TO_COVERAGE)}function ze(I){O!==I&&(I?i.frontFace(i.CW):i.frontFace(i.CCW),O=I)}function C(I){I!==$p?(Be(i.CULL_FACE),I!==j&&(I===gu?i.cullFace(i.BACK):I===Zp?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Le(i.CULL_FACE),j=I}function M(I){I!==L&&(Y&&i.lineWidth(I),L=I)}function k(I,oe,le){I?(Be(i.POLYGON_OFFSET_FILL),(U!==oe||V!==le)&&(i.polygonOffset(oe,le),U=oe,V=le)):Le(i.POLYGON_OFFSET_FILL)}function se(I){I?Be(i.SCISSOR_TEST):Le(i.SCISSOR_TEST)}function te(I){I===void 0&&(I=i.TEXTURE0+K-1),ie!==I&&(i.activeTexture(I),ie=I)}function ne(I,oe,le){le===void 0&&(ie===null?le=i.TEXTURE0+K-1:le=ie);let Pe=pe[le];Pe===void 0&&(Pe={type:void 0,texture:void 0},pe[le]=Pe),(Pe.type!==I||Pe.texture!==oe)&&(ie!==le&&(i.activeTexture(le),ie=le),i.bindTexture(I,oe||Fe[I]),Pe.type=I,Pe.texture=oe)}function Me(){let I=pe[ie];I!==void 0&&I.type!==void 0&&(i.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function fe(){try{i.compressedTexImage2D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ye(){try{i.compressedTexImage3D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ie(){try{i.texSubImage2D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ve(){try{i.texSubImage3D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ee(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Qe(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function P(){try{i.texStorage2D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function J(){try{i.texStorage3D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ue(){try{i.texImage2D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ae(){try{i.texImage3D.apply(i,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Se(I){ge.equals(I)===!1&&(i.scissor(I.x,I.y,I.z,I.w),ge.copy(I))}function Ye(I){Ee.equals(I)===!1&&(i.viewport(I.x,I.y,I.z,I.w),Ee.copy(I))}function et(I,oe){let le=u.get(oe);le===void 0&&(le=new WeakMap,u.set(oe,le));let Pe=le.get(I);Pe===void 0&&(Pe=i.getUniformBlockIndex(oe,I.name),le.set(I,Pe))}function Xe(I,oe){let Pe=u.get(oe).get(I);h.get(oe)!==Pe&&(i.uniformBlockBinding(oe,Pe,I.__bindingPointIndex),h.set(oe,Pe))}function ce(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),n===!0&&(i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null)),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),d={},ie=null,pe={},p={},g=new WeakMap,f=[],_=null,m=!1,y=null,x=null,b=null,E=null,w=null,T=null,D=null,v=new Re(0,0,0),S=0,N=!1,O=null,j=null,L=null,U=null,V=null,ge.set(0,0,i.canvas.width,i.canvas.height),Ee.set(0,0,i.canvas.width,i.canvas.height),a.reset(),l.reset(),c.reset()}return{buffers:{color:a,depth:l,stencil:c},enable:Be,disable:Le,bindFramebuffer:Je,drawBuffers:B,useProgram:Gt,setBlending:be,setMaterial:gt,setFlipSided:ze,setCullFace:C,setLineWidth:M,setPolygonOffset:k,setScissorTest:se,activeTexture:te,bindTexture:ne,unbindTexture:Me,compressedTexImage2D:fe,compressedTexImage3D:ye,texImage2D:ue,texImage3D:ae,updateUBOMapping:et,uniformBlockBinding:Xe,texStorage2D:P,texStorage3D:J,texSubImage2D:Ie,texSubImage3D:Ve,compressedTexSubImage2D:ee,compressedTexSubImage3D:Qe,scissor:Se,viewport:Ye,reset:ce}}function $y(i,e,t,n,s,r,o){let a=s.isWebGL2,l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,d=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(C,M){return p?new OffscreenCanvas(C,M):Tr("canvas")}function f(C,M,k,se){let te=1;if((C.width>se||C.height>se)&&(te=se/Math.max(C.width,C.height)),te<1||M===!0)if(typeof HTMLImageElement<"u"&&C instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&C instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&C instanceof ImageBitmap){let ne=M?qa:Math.floor,Me=ne(te*C.width),fe=ne(te*C.height);u===void 0&&(u=g(Me,fe));let ye=k?g(Me,fe):u;return ye.width=Me,ye.height=fe,ye.getContext("2d").drawImage(C,0,0,Me,fe),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+C.width+"x"+C.height+") to ("+Me+"x"+fe+")."),ye}else return"data"in C&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+C.width+"x"+C.height+")."),C;return C}function _(C){return Zl(C.width)&&Zl(C.height)}function m(C){return a?!1:C.wrapS!==_n||C.wrapT!==_n||C.minFilter!==Ut&&C.minFilter!==cn}function y(C,M){return C.generateMipmaps&&M&&C.minFilter!==Ut&&C.minFilter!==cn}function x(C){i.generateMipmap(C)}function b(C,M,k,se,te=!1){if(a===!1)return M;if(C!==null){if(i[C]!==void 0)return i[C];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+C+"'")}let ne=M;if(M===i.RED&&(k===i.FLOAT&&(ne=i.R32F),k===i.HALF_FLOAT&&(ne=i.R16F),k===i.UNSIGNED_BYTE&&(ne=i.R8)),M===i.RED_INTEGER&&(k===i.UNSIGNED_BYTE&&(ne=i.R8UI),k===i.UNSIGNED_SHORT&&(ne=i.R16UI),k===i.UNSIGNED_INT&&(ne=i.R32UI),k===i.BYTE&&(ne=i.R8I),k===i.SHORT&&(ne=i.R16I),k===i.INT&&(ne=i.R32I)),M===i.RG&&(k===i.FLOAT&&(ne=i.RG32F),k===i.HALF_FLOAT&&(ne=i.RG16F),k===i.UNSIGNED_BYTE&&(ne=i.RG8)),M===i.RGBA){let Me=te?Va:ot.getTransfer(se);k===i.FLOAT&&(ne=i.RGBA32F),k===i.HALF_FLOAT&&(ne=i.RGBA16F),k===i.UNSIGNED_BYTE&&(ne=Me===_t?i.SRGB8_ALPHA8:i.RGBA8),k===i.UNSIGNED_SHORT_4_4_4_4&&(ne=i.RGBA4),k===i.UNSIGNED_SHORT_5_5_5_1&&(ne=i.RGB5_A1)}return(ne===i.R16F||ne===i.R32F||ne===i.RG16F||ne===i.RG32F||ne===i.RGBA16F||ne===i.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function E(C,M,k){return y(C,k)===!0||C.isFramebufferTexture&&C.minFilter!==Ut&&C.minFilter!==cn?Math.log2(Math.max(M.width,M.height))+1:C.mipmaps!==void 0&&C.mipmaps.length>0?C.mipmaps.length:C.isCompressedTexture&&Array.isArray(C.image)?M.mipmaps.length:1}function w(C){return C===Ut||C===za||C===gr?i.NEAREST:i.LINEAR}function T(C){let M=C.target;M.removeEventListener("dispose",T),v(M),M.isVideoTexture&&h.delete(M)}function D(C){let M=C.target;M.removeEventListener("dispose",D),N(M)}function v(C){let M=n.get(C);if(M.__webglInit===void 0)return;let k=C.source,se=d.get(k);if(se){let te=se[M.__cacheKey];te.usedTimes--,te.usedTimes===0&&S(C),Object.keys(se).length===0&&d.delete(k)}n.remove(C)}function S(C){let M=n.get(C);i.deleteTexture(M.__webglTexture);let k=C.source,se=d.get(k);delete se[M.__cacheKey],o.memory.textures--}function N(C){let M=C.texture,k=n.get(C),se=n.get(M);if(se.__webglTexture!==void 0&&(i.deleteTexture(se.__webglTexture),o.memory.textures--),C.depthTexture&&C.depthTexture.dispose(),C.isWebGLCubeRenderTarget)for(let te=0;te<6;te++){if(Array.isArray(k.__webglFramebuffer[te]))for(let ne=0;ne<k.__webglFramebuffer[te].length;ne++)i.deleteFramebuffer(k.__webglFramebuffer[te][ne]);else i.deleteFramebuffer(k.__webglFramebuffer[te]);k.__webglDepthbuffer&&i.deleteRenderbuffer(k.__webglDepthbuffer[te])}else{if(Array.isArray(k.__webglFramebuffer))for(let te=0;te<k.__webglFramebuffer.length;te++)i.deleteFramebuffer(k.__webglFramebuffer[te]);else i.deleteFramebuffer(k.__webglFramebuffer);if(k.__webglDepthbuffer&&i.deleteRenderbuffer(k.__webglDepthbuffer),k.__webglMultisampledFramebuffer&&i.deleteFramebuffer(k.__webglMultisampledFramebuffer),k.__webglColorRenderbuffer)for(let te=0;te<k.__webglColorRenderbuffer.length;te++)k.__webglColorRenderbuffer[te]&&i.deleteRenderbuffer(k.__webglColorRenderbuffer[te]);k.__webglDepthRenderbuffer&&i.deleteRenderbuffer(k.__webglDepthRenderbuffer)}if(C.isWebGLMultipleRenderTargets)for(let te=0,ne=M.length;te<ne;te++){let Me=n.get(M[te]);Me.__webglTexture&&(i.deleteTexture(Me.__webglTexture),o.memory.textures--),n.remove(M[te])}n.remove(M),n.remove(C)}let O=0;function j(){O=0}function L(){let C=O;return C>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+C+" texture units while this GPU supports only "+s.maxTextures),O+=1,C}function U(C){let M=[];return M.push(C.wrapS),M.push(C.wrapT),M.push(C.wrapR||0),M.push(C.magFilter),M.push(C.minFilter),M.push(C.anisotropy),M.push(C.internalFormat),M.push(C.format),M.push(C.type),M.push(C.generateMipmaps),M.push(C.premultiplyAlpha),M.push(C.flipY),M.push(C.unpackAlignment),M.push(C.colorSpace),M.join()}function V(C,M){let k=n.get(C);if(C.isVideoTexture&&gt(C),C.isRenderTargetTexture===!1&&C.version>0&&k.__version!==C.version){let se=C.image;if(se===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(se.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ge(k,C,M);return}}t.bindTexture(i.TEXTURE_2D,k.__webglTexture,i.TEXTURE0+M)}function K(C,M){let k=n.get(C);if(C.version>0&&k.__version!==C.version){ge(k,C,M);return}t.bindTexture(i.TEXTURE_2D_ARRAY,k.__webglTexture,i.TEXTURE0+M)}function Y(C,M){let k=n.get(C);if(C.version>0&&k.__version!==C.version){ge(k,C,M);return}t.bindTexture(i.TEXTURE_3D,k.__webglTexture,i.TEXTURE0+M)}function q(C,M){let k=n.get(C);if(C.version>0&&k.__version!==C.version){Ee(k,C,M);return}t.bindTexture(i.TEXTURE_CUBE_MAP,k.__webglTexture,i.TEXTURE0+M)}let $={[Ji]:i.REPEAT,[_n]:i.CLAMP_TO_EDGE,[Sr]:i.MIRRORED_REPEAT},ie={[Ut]:i.NEAREST,[za]:i.NEAREST_MIPMAP_NEAREST,[gr]:i.NEAREST_MIPMAP_LINEAR,[cn]:i.LINEAR,[kc]:i.LINEAR_MIPMAP_NEAREST,[Li]:i.LINEAR_MIPMAP_LINEAR},pe={[Vm]:i.NEVER,[Km]:i.ALWAYS,[Gm]:i.LESS,[gf]:i.LEQUAL,[Wm]:i.EQUAL,[Ym]:i.GEQUAL,[Xm]:i.GREATER,[qm]:i.NOTEQUAL};function X(C,M,k){if(k?(i.texParameteri(C,i.TEXTURE_WRAP_S,$[M.wrapS]),i.texParameteri(C,i.TEXTURE_WRAP_T,$[M.wrapT]),(C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY)&&i.texParameteri(C,i.TEXTURE_WRAP_R,$[M.wrapR]),i.texParameteri(C,i.TEXTURE_MAG_FILTER,ie[M.magFilter]),i.texParameteri(C,i.TEXTURE_MIN_FILTER,ie[M.minFilter])):(i.texParameteri(C,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(C,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE),(C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY)&&i.texParameteri(C,i.TEXTURE_WRAP_R,i.CLAMP_TO_EDGE),(M.wrapS!==_n||M.wrapT!==_n)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),i.texParameteri(C,i.TEXTURE_MAG_FILTER,w(M.magFilter)),i.texParameteri(C,i.TEXTURE_MIN_FILTER,w(M.minFilter)),M.minFilter!==Ut&&M.minFilter!==cn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),M.compareFunction&&(i.texParameteri(C,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(C,i.TEXTURE_COMPARE_FUNC,pe[M.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){let se=e.get("EXT_texture_filter_anisotropic");if(M.magFilter===Ut||M.minFilter!==gr&&M.minFilter!==Li||M.type===li&&e.has("OES_texture_float_linear")===!1||a===!1&&M.type===Er&&e.has("OES_texture_half_float_linear")===!1)return;(M.anisotropy>1||n.get(M).__currentAnisotropy)&&(i.texParameterf(C,se.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,s.getMaxAnisotropy())),n.get(M).__currentAnisotropy=M.anisotropy)}}function Q(C,M){let k=!1;C.__webglInit===void 0&&(C.__webglInit=!0,M.addEventListener("dispose",T));let se=M.source,te=d.get(se);te===void 0&&(te={},d.set(se,te));let ne=U(M);if(ne!==C.__cacheKey){te[ne]===void 0&&(te[ne]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,k=!0),te[ne].usedTimes++;let Me=te[C.__cacheKey];Me!==void 0&&(te[C.__cacheKey].usedTimes--,Me.usedTimes===0&&S(M)),C.__cacheKey=ne,C.__webglTexture=te[ne].texture}return k}function ge(C,M,k){let se=i.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(se=i.TEXTURE_2D_ARRAY),M.isData3DTexture&&(se=i.TEXTURE_3D);let te=Q(C,M),ne=M.source;t.bindTexture(se,C.__webglTexture,i.TEXTURE0+k);let Me=n.get(ne);if(ne.version!==Me.__version||te===!0){t.activeTexture(i.TEXTURE0+k);let fe=ot.getPrimaries(ot.workingColorSpace),ye=M.colorSpace===Sn?null:ot.getPrimaries(M.colorSpace),Ie=M.colorSpace===Sn||fe===ye?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ie);let Ve=m(M)&&_(M.image)===!1,ee=f(M.image,Ve,!1,s.maxTextureSize);ee=ze(M,ee);let Qe=_(ee)||a,P=r.convert(M.format,M.colorSpace),J=r.convert(M.type),ue=b(M.internalFormat,P,J,M.colorSpace,M.isVideoTexture);X(se,M,Qe);let ae,Se=M.mipmaps,Ye=a&&M.isVideoTexture!==!0&&ue!==df,et=Me.__version===void 0||te===!0,Xe=E(M,ee,Qe);if(M.isDepthTexture)ue=i.DEPTH_COMPONENT,a?M.type===li?ue=i.DEPTH_COMPONENT32F:M.type===Ti?ue=i.DEPTH_COMPONENT24:M.type===ji?ue=i.DEPTH24_STENCIL8:ue=i.DEPTH_COMPONENT16:M.type===li&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),M.format===$i&&ue===i.DEPTH_COMPONENT&&M.type!==zc&&M.type!==Ti&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),M.type=Ti,J=r.convert(M.type)),M.format===Fs&&ue===i.DEPTH_COMPONENT&&(ue=i.DEPTH_STENCIL,M.type!==ji&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),M.type=ji,J=r.convert(M.type))),et&&(Ye?t.texStorage2D(i.TEXTURE_2D,1,ue,ee.width,ee.height):t.texImage2D(i.TEXTURE_2D,0,ue,ee.width,ee.height,0,P,J,null));else if(M.isDataTexture)if(Se.length>0&&Qe){Ye&&et&&t.texStorage2D(i.TEXTURE_2D,Xe,ue,Se[0].width,Se[0].height);for(let ce=0,I=Se.length;ce<I;ce++)ae=Se[ce],Ye?t.texSubImage2D(i.TEXTURE_2D,ce,0,0,ae.width,ae.height,P,J,ae.data):t.texImage2D(i.TEXTURE_2D,ce,ue,ae.width,ae.height,0,P,J,ae.data);M.generateMipmaps=!1}else Ye?(et&&t.texStorage2D(i.TEXTURE_2D,Xe,ue,ee.width,ee.height),t.texSubImage2D(i.TEXTURE_2D,0,0,0,ee.width,ee.height,P,J,ee.data)):t.texImage2D(i.TEXTURE_2D,0,ue,ee.width,ee.height,0,P,J,ee.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){Ye&&et&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Xe,ue,Se[0].width,Se[0].height,ee.depth);for(let ce=0,I=Se.length;ce<I;ce++)ae=Se[ce],M.format!==wn?P!==null?Ye?t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,ae.width,ae.height,ee.depth,P,ae.data,0,0):t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ce,ue,ae.width,ae.height,ee.depth,0,ae.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ye?t.texSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,ae.width,ae.height,ee.depth,P,J,ae.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ce,ue,ae.width,ae.height,ee.depth,0,P,J,ae.data)}else{Ye&&et&&t.texStorage2D(i.TEXTURE_2D,Xe,ue,Se[0].width,Se[0].height);for(let ce=0,I=Se.length;ce<I;ce++)ae=Se[ce],M.format!==wn?P!==null?Ye?t.compressedTexSubImage2D(i.TEXTURE_2D,ce,0,0,ae.width,ae.height,P,ae.data):t.compressedTexImage2D(i.TEXTURE_2D,ce,ue,ae.width,ae.height,0,ae.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ye?t.texSubImage2D(i.TEXTURE_2D,ce,0,0,ae.width,ae.height,P,J,ae.data):t.texImage2D(i.TEXTURE_2D,ce,ue,ae.width,ae.height,0,P,J,ae.data)}else if(M.isDataArrayTexture)Ye?(et&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Xe,ue,ee.width,ee.height,ee.depth),t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ee.width,ee.height,ee.depth,P,J,ee.data)):t.texImage3D(i.TEXTURE_2D_ARRAY,0,ue,ee.width,ee.height,ee.depth,0,P,J,ee.data);else if(M.isData3DTexture)Ye?(et&&t.texStorage3D(i.TEXTURE_3D,Xe,ue,ee.width,ee.height,ee.depth),t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ee.width,ee.height,ee.depth,P,J,ee.data)):t.texImage3D(i.TEXTURE_3D,0,ue,ee.width,ee.height,ee.depth,0,P,J,ee.data);else if(M.isFramebufferTexture){if(et)if(Ye)t.texStorage2D(i.TEXTURE_2D,Xe,ue,ee.width,ee.height);else{let ce=ee.width,I=ee.height;for(let oe=0;oe<Xe;oe++)t.texImage2D(i.TEXTURE_2D,oe,ue,ce,I,0,P,J,null),ce>>=1,I>>=1}}else if(Se.length>0&&Qe){Ye&&et&&t.texStorage2D(i.TEXTURE_2D,Xe,ue,Se[0].width,Se[0].height);for(let ce=0,I=Se.length;ce<I;ce++)ae=Se[ce],Ye?t.texSubImage2D(i.TEXTURE_2D,ce,0,0,P,J,ae):t.texImage2D(i.TEXTURE_2D,ce,ue,P,J,ae);M.generateMipmaps=!1}else Ye?(et&&t.texStorage2D(i.TEXTURE_2D,Xe,ue,ee.width,ee.height),t.texSubImage2D(i.TEXTURE_2D,0,0,0,P,J,ee)):t.texImage2D(i.TEXTURE_2D,0,ue,P,J,ee);y(M,Qe)&&x(se),Me.__version=ne.version,M.onUpdate&&M.onUpdate(M)}C.__version=M.version}function Ee(C,M,k){if(M.image.length!==6)return;let se=Q(C,M),te=M.source;t.bindTexture(i.TEXTURE_CUBE_MAP,C.__webglTexture,i.TEXTURE0+k);let ne=n.get(te);if(te.version!==ne.__version||se===!0){t.activeTexture(i.TEXTURE0+k);let Me=ot.getPrimaries(ot.workingColorSpace),fe=M.colorSpace===Sn?null:ot.getPrimaries(M.colorSpace),ye=M.colorSpace===Sn||Me===fe?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ye);let Ie=M.isCompressedTexture||M.image[0].isCompressedTexture,Ve=M.image[0]&&M.image[0].isDataTexture,ee=[];for(let ce=0;ce<6;ce++)!Ie&&!Ve?ee[ce]=f(M.image[ce],!1,!0,s.maxCubemapSize):ee[ce]=Ve?M.image[ce].image:M.image[ce],ee[ce]=ze(M,ee[ce]);let Qe=ee[0],P=_(Qe)||a,J=r.convert(M.format,M.colorSpace),ue=r.convert(M.type),ae=b(M.internalFormat,J,ue,M.colorSpace),Se=a&&M.isVideoTexture!==!0,Ye=ne.__version===void 0||se===!0,et=E(M,Qe,P);X(i.TEXTURE_CUBE_MAP,M,P);let Xe;if(Ie){Se&&Ye&&t.texStorage2D(i.TEXTURE_CUBE_MAP,et,ae,Qe.width,Qe.height);for(let ce=0;ce<6;ce++){Xe=ee[ce].mipmaps;for(let I=0;I<Xe.length;I++){let oe=Xe[I];M.format!==wn?J!==null?Se?t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I,0,0,oe.width,oe.height,J,oe.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I,ae,oe.width,oe.height,0,oe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Se?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I,0,0,oe.width,oe.height,J,ue,oe.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I,ae,oe.width,oe.height,0,J,ue,oe.data)}}}else{Xe=M.mipmaps,Se&&Ye&&(Xe.length>0&&et++,t.texStorage2D(i.TEXTURE_CUBE_MAP,et,ae,ee[0].width,ee[0].height));for(let ce=0;ce<6;ce++)if(Ve){Se?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,0,0,ee[ce].width,ee[ce].height,J,ue,ee[ce].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,ae,ee[ce].width,ee[ce].height,0,J,ue,ee[ce].data);for(let I=0;I<Xe.length;I++){let le=Xe[I].image[ce].image;Se?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I+1,0,0,le.width,le.height,J,ue,le.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I+1,ae,le.width,le.height,0,J,ue,le.data)}}else{Se?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,0,0,J,ue,ee[ce]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,ae,J,ue,ee[ce]);for(let I=0;I<Xe.length;I++){let oe=Xe[I];Se?t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I+1,0,0,J,ue,oe.image[ce]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ce,I+1,ae,J,ue,oe.image[ce])}}}y(M,P)&&x(i.TEXTURE_CUBE_MAP),ne.__version=te.version,M.onUpdate&&M.onUpdate(M)}C.__version=M.version}function we(C,M,k,se,te,ne){let Me=r.convert(k.format,k.colorSpace),fe=r.convert(k.type),ye=b(k.internalFormat,Me,fe,k.colorSpace);if(!n.get(M).__hasExternalTextures){let Ve=Math.max(1,M.width>>ne),ee=Math.max(1,M.height>>ne);te===i.TEXTURE_3D||te===i.TEXTURE_2D_ARRAY?t.texImage3D(te,ne,ye,Ve,ee,M.depth,0,Me,fe,null):t.texImage2D(te,ne,ye,Ve,ee,0,Me,fe,null)}t.bindFramebuffer(i.FRAMEBUFFER,C),be(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,se,te,n.get(k).__webglTexture,0,Ne(M)):(te===i.TEXTURE_2D||te>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&te<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,se,te,n.get(k).__webglTexture,ne),t.bindFramebuffer(i.FRAMEBUFFER,null)}function Fe(C,M,k){if(i.bindRenderbuffer(i.RENDERBUFFER,C),M.depthBuffer&&!M.stencilBuffer){let se=a===!0?i.DEPTH_COMPONENT24:i.DEPTH_COMPONENT16;if(k||be(M)){let te=M.depthTexture;te&&te.isDepthTexture&&(te.type===li?se=i.DEPTH_COMPONENT32F:te.type===Ti&&(se=i.DEPTH_COMPONENT24));let ne=Ne(M);be(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ne,se,M.width,M.height):i.renderbufferStorageMultisample(i.RENDERBUFFER,ne,se,M.width,M.height)}else i.renderbufferStorage(i.RENDERBUFFER,se,M.width,M.height);i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.RENDERBUFFER,C)}else if(M.depthBuffer&&M.stencilBuffer){let se=Ne(M);k&&be(M)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,se,i.DEPTH24_STENCIL8,M.width,M.height):be(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,se,i.DEPTH24_STENCIL8,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,i.DEPTH_STENCIL,M.width,M.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.RENDERBUFFER,C)}else{let se=M.isWebGLMultipleRenderTargets===!0?M.texture:[M.texture];for(let te=0;te<se.length;te++){let ne=se[te],Me=r.convert(ne.format,ne.colorSpace),fe=r.convert(ne.type),ye=b(ne.internalFormat,Me,fe,ne.colorSpace),Ie=Ne(M);k&&be(M)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ie,ye,M.width,M.height):be(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ie,ye,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,ye,M.width,M.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Be(C,M){if(M&&M.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,C),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(M.depthTexture).__webglTexture||M.depthTexture.image.width!==M.width||M.depthTexture.image.height!==M.height)&&(M.depthTexture.image.width=M.width,M.depthTexture.image.height=M.height,M.depthTexture.needsUpdate=!0),V(M.depthTexture,0);let se=n.get(M.depthTexture).__webglTexture,te=Ne(M);if(M.depthTexture.format===$i)be(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,se,0,te):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,se,0);else if(M.depthTexture.format===Fs)be(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,se,0,te):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,se,0);else throw new Error("Unknown depthTexture format")}function Le(C){let M=n.get(C),k=C.isWebGLCubeRenderTarget===!0;if(C.depthTexture&&!M.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");Be(M.__webglFramebuffer,C)}else if(k){M.__webglDepthbuffer=[];for(let se=0;se<6;se++)t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer[se]),M.__webglDepthbuffer[se]=i.createRenderbuffer(),Fe(M.__webglDepthbuffer[se],C,!1)}else t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer=i.createRenderbuffer(),Fe(M.__webglDepthbuffer,C,!1);t.bindFramebuffer(i.FRAMEBUFFER,null)}function Je(C,M,k){let se=n.get(C);M!==void 0&&we(se.__webglFramebuffer,C,C.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),k!==void 0&&Le(C)}function B(C){let M=C.texture,k=n.get(C),se=n.get(M);C.addEventListener("dispose",D),C.isWebGLMultipleRenderTargets!==!0&&(se.__webglTexture===void 0&&(se.__webglTexture=i.createTexture()),se.__version=M.version,o.memory.textures++);let te=C.isWebGLCubeRenderTarget===!0,ne=C.isWebGLMultipleRenderTargets===!0,Me=_(C)||a;if(te){k.__webglFramebuffer=[];for(let fe=0;fe<6;fe++)if(a&&M.mipmaps&&M.mipmaps.length>0){k.__webglFramebuffer[fe]=[];for(let ye=0;ye<M.mipmaps.length;ye++)k.__webglFramebuffer[fe][ye]=i.createFramebuffer()}else k.__webglFramebuffer[fe]=i.createFramebuffer()}else{if(a&&M.mipmaps&&M.mipmaps.length>0){k.__webglFramebuffer=[];for(let fe=0;fe<M.mipmaps.length;fe++)k.__webglFramebuffer[fe]=i.createFramebuffer()}else k.__webglFramebuffer=i.createFramebuffer();if(ne)if(s.drawBuffers){let fe=C.texture;for(let ye=0,Ie=fe.length;ye<Ie;ye++){let Ve=n.get(fe[ye]);Ve.__webglTexture===void 0&&(Ve.__webglTexture=i.createTexture(),o.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(a&&C.samples>0&&be(C)===!1){let fe=ne?M:[M];k.__webglMultisampledFramebuffer=i.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let ye=0;ye<fe.length;ye++){let Ie=fe[ye];k.__webglColorRenderbuffer[ye]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,k.__webglColorRenderbuffer[ye]);let Ve=r.convert(Ie.format,Ie.colorSpace),ee=r.convert(Ie.type),Qe=b(Ie.internalFormat,Ve,ee,Ie.colorSpace,C.isXRRenderTarget===!0),P=Ne(C);i.renderbufferStorageMultisample(i.RENDERBUFFER,P,Qe,C.width,C.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ye,i.RENDERBUFFER,k.__webglColorRenderbuffer[ye])}i.bindRenderbuffer(i.RENDERBUFFER,null),C.depthBuffer&&(k.__webglDepthRenderbuffer=i.createRenderbuffer(),Fe(k.__webglDepthRenderbuffer,C,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(te){t.bindTexture(i.TEXTURE_CUBE_MAP,se.__webglTexture),X(i.TEXTURE_CUBE_MAP,M,Me);for(let fe=0;fe<6;fe++)if(a&&M.mipmaps&&M.mipmaps.length>0)for(let ye=0;ye<M.mipmaps.length;ye++)we(k.__webglFramebuffer[fe][ye],C,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,ye);else we(k.__webglFramebuffer[fe],C,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0);y(M,Me)&&x(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ne){let fe=C.texture;for(let ye=0,Ie=fe.length;ye<Ie;ye++){let Ve=fe[ye],ee=n.get(Ve);t.bindTexture(i.TEXTURE_2D,ee.__webglTexture),X(i.TEXTURE_2D,Ve,Me),we(k.__webglFramebuffer,C,Ve,i.COLOR_ATTACHMENT0+ye,i.TEXTURE_2D,0),y(Ve,Me)&&x(i.TEXTURE_2D)}t.unbindTexture()}else{let fe=i.TEXTURE_2D;if((C.isWebGL3DRenderTarget||C.isWebGLArrayRenderTarget)&&(a?fe=C.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(fe,se.__webglTexture),X(fe,M,Me),a&&M.mipmaps&&M.mipmaps.length>0)for(let ye=0;ye<M.mipmaps.length;ye++)we(k.__webglFramebuffer[ye],C,M,i.COLOR_ATTACHMENT0,fe,ye);else we(k.__webglFramebuffer,C,M,i.COLOR_ATTACHMENT0,fe,0);y(M,Me)&&x(fe),t.unbindTexture()}C.depthBuffer&&Le(C)}function Gt(C){let M=_(C)||a,k=C.isWebGLMultipleRenderTargets===!0?C.texture:[C.texture];for(let se=0,te=k.length;se<te;se++){let ne=k[se];if(y(ne,M)){let Me=C.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:i.TEXTURE_2D,fe=n.get(ne).__webglTexture;t.bindTexture(Me,fe),x(Me),t.unbindTexture()}}}function Ce(C){if(a&&C.samples>0&&be(C)===!1){let M=C.isWebGLMultipleRenderTargets?C.texture:[C.texture],k=C.width,se=C.height,te=i.COLOR_BUFFER_BIT,ne=[],Me=C.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,fe=n.get(C),ye=C.isWebGLMultipleRenderTargets===!0;if(ye)for(let Ie=0;Ie<M.length;Ie++)t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,fe.__webglMultisampledFramebuffer),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,fe.__webglFramebuffer);for(let Ie=0;Ie<M.length;Ie++){ne.push(i.COLOR_ATTACHMENT0+Ie),C.depthBuffer&&ne.push(Me);let Ve=fe.__ignoreDepthValues!==void 0?fe.__ignoreDepthValues:!1;if(Ve===!1&&(C.depthBuffer&&(te|=i.DEPTH_BUFFER_BIT),C.stencilBuffer&&(te|=i.STENCIL_BUFFER_BIT)),ye&&i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,fe.__webglColorRenderbuffer[Ie]),Ve===!0&&(i.invalidateFramebuffer(i.READ_FRAMEBUFFER,[Me]),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[Me])),ye){let ee=n.get(M[Ie]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,ee,0)}i.blitFramebuffer(0,0,k,se,0,0,k,se,te,i.NEAREST),c&&i.invalidateFramebuffer(i.READ_FRAMEBUFFER,ne)}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ye)for(let Ie=0;Ie<M.length;Ie++){t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.RENDERBUFFER,fe.__webglColorRenderbuffer[Ie]);let Ve=n.get(M[Ie]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ie,i.TEXTURE_2D,Ve,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,fe.__webglMultisampledFramebuffer)}}function Ne(C){return Math.min(s.maxSamples,C.samples)}function be(C){let M=n.get(C);return a&&C.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function gt(C){let M=o.render.frame;h.get(C)!==M&&(h.set(C,M),C.update())}function ze(C,M){let k=C.colorSpace,se=C.format,te=C.type;return C.isCompressedTexture===!0||C.isVideoTexture===!0||C.format===$l||k!==Ft&&k!==Sn&&(ot.getTransfer(k)===_t?a===!1?e.has("EXT_sRGB")===!0&&se===wn?(C.format=$l,C.minFilter=cn,C.generateMipmaps=!1):M=Ya.sRGBToLinear(M):(se!==wn||te!==Pi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",k)),M}this.allocateTextureUnit=L,this.resetTextureUnits=j,this.setTexture2D=V,this.setTexture2DArray=K,this.setTexture3D=Y,this.setTextureCube=q,this.rebindTextures=Je,this.setupRenderTarget=B,this.updateRenderTargetMipmap=Gt,this.updateMultisampleRenderTarget=Ce,this.setupDepthRenderbuffer=Le,this.setupFrameBufferTexture=we,this.useMultisampledRTT=be}function Zy(i,e,t){let n=t.isWebGL2;function s(r,o=Sn){let a,l=ot.getTransfer(o);if(r===Pi)return i.UNSIGNED_BYTE;if(r===of)return i.UNSIGNED_SHORT_4_4_4_4;if(r===lf)return i.UNSIGNED_SHORT_5_5_5_1;if(r===Cm)return i.BYTE;if(r===Pm)return i.SHORT;if(r===zc)return i.UNSIGNED_SHORT;if(r===af)return i.INT;if(r===Ti)return i.UNSIGNED_INT;if(r===li)return i.FLOAT;if(r===Er)return n?i.HALF_FLOAT:(a=e.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(r===Lm)return i.ALPHA;if(r===wn)return i.RGBA;if(r===Im)return i.LUMINANCE;if(r===Dm)return i.LUMINANCE_ALPHA;if(r===$i)return i.DEPTH_COMPONENT;if(r===Fs)return i.DEPTH_STENCIL;if(r===$l)return a=e.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(r===Nm)return i.RED;if(r===cf)return i.RED_INTEGER;if(r===Um)return i.RG;if(r===hf)return i.RG_INTEGER;if(r===uf)return i.RGBA_INTEGER;if(r===cl||r===hl||r===ul||r===dl)if(l===_t)if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(r===cl)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===hl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===ul)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===dl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=e.get("WEBGL_compressed_texture_s3tc"),a!==null){if(r===cl)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===hl)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===ul)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===dl)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Mu||r===wu||r===Su||r===Eu)if(a=e.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(r===Mu)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===wu)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Su)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Eu)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===df)return a=e.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===Tu||r===Au)if(a=e.get("WEBGL_compressed_texture_etc"),a!==null){if(r===Tu)return l===_t?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(r===Au)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===Ru||r===Cu||r===Pu||r===Lu||r===Iu||r===Du||r===Nu||r===Uu||r===Ou||r===Fu||r===Bu||r===ku||r===zu||r===Hu)if(a=e.get("WEBGL_compressed_texture_astc"),a!==null){if(r===Ru)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Cu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Pu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Lu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Iu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Du)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Nu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Uu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Ou)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Fu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Bu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===ku)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===zu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===Hu)return l===_t?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===fl||r===Vu||r===Gu)if(a=e.get("EXT_texture_compression_bptc"),a!==null){if(r===fl)return l===_t?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Vu)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Gu)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===Om||r===Wu||r===Xu||r===qu)if(a=e.get("EXT_texture_compression_rgtc"),a!==null){if(r===fl)return a.COMPRESSED_RED_RGTC1_EXT;if(r===Wu)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Xu)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===qu)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===ji?n?i.UNSIGNED_INT_24_8:(a=e.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):i[r]!==void 0?i[r]:null}return{convert:s}}var hc=class extends Ot{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},St=class extends bt{constructor(){super(),this.isGroup=!0,this.type="Group"}},Jy={type:"move"},vr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new St,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new St,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new St,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(let f of e.hand.values()){let _=t.getJointPose(f,n),m=this._getHandJoint(c,f);_!==null&&(m.matrix.fromArray(_.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=_.radius),m.visible=_!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),p=.02,g=.005;c.inputState.pinching&&d>p+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=p-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Jy)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new St;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},uc=class extends Bn{constructor(e,t){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,p=null,g=null,f=t.getContextAttributes(),_=null,m=null,y=[],x=[],b=new he,E=null,w=new Ot;w.layers.enable(1),w.viewport=new dt;let T=new Ot;T.layers.enable(2),T.viewport=new dt;let D=[w,T],v=new hc;v.layers.enable(1),v.layers.enable(2);let S=null,N=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(X){let Q=y[X];return Q===void 0&&(Q=new vr,y[X]=Q),Q.getTargetRaySpace()},this.getControllerGrip=function(X){let Q=y[X];return Q===void 0&&(Q=new vr,y[X]=Q),Q.getGripSpace()},this.getHand=function(X){let Q=y[X];return Q===void 0&&(Q=new vr,y[X]=Q),Q.getHandSpace()};function O(X){let Q=x.indexOf(X.inputSource);if(Q===-1)return;let ge=y[Q];ge!==void 0&&(ge.update(X.inputSource,X.frame,c||o),ge.dispatchEvent({type:X.type,data:X.inputSource}))}function j(){s.removeEventListener("select",O),s.removeEventListener("selectstart",O),s.removeEventListener("selectend",O),s.removeEventListener("squeeze",O),s.removeEventListener("squeezestart",O),s.removeEventListener("squeezeend",O),s.removeEventListener("end",j),s.removeEventListener("inputsourceschange",L);for(let X=0;X<y.length;X++){let Q=x[X];Q!==null&&(x[X]=null,y[X].disconnect(Q))}S=null,N=null,e.setRenderTarget(_),p=null,d=null,u=null,s=null,m=null,pe.stop(),n.isPresenting=!1,e.setPixelRatio(E),e.setSize(b.width,b.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(X){r=X,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(X){a=X,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(X){c=X},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(X){if(s=X,s!==null){if(_=e.getRenderTarget(),s.addEventListener("select",O),s.addEventListener("selectstart",O),s.addEventListener("selectend",O),s.addEventListener("squeeze",O),s.addEventListener("squeezestart",O),s.addEventListener("squeezeend",O),s.addEventListener("end",j),s.addEventListener("inputsourceschange",L),f.xrCompatible!==!0&&await t.makeXRCompatible(),E=e.getPixelRatio(),e.getSize(b),s.renderState.layers===void 0||e.capabilities.isWebGL2===!1){let Q={antialias:s.renderState.layers===void 0?f.antialias:!0,alpha:!0,depth:f.depth,stencil:f.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(s,t,Q),s.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),m=new hi(p.framebufferWidth,p.framebufferHeight,{format:wn,type:Pi,colorSpace:e.outputColorSpace,stencilBuffer:f.stencil})}else{let Q=null,ge=null,Ee=null;f.depth&&(Ee=f.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Q=f.stencil?Fs:$i,ge=f.stencil?ji:Ti);let we={colorFormat:t.RGBA8,depthFormat:Ee,scaleFactor:r};u=new XRWebGLBinding(s,t),d=u.createProjectionLayer(we),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),m=new hi(d.textureWidth,d.textureHeight,{format:wn,type:Pi,depthTexture:new eo(d.textureWidth,d.textureHeight,ge,void 0,void 0,void 0,void 0,void 0,void 0,Q),stencilBuffer:f.stencil,colorSpace:e.outputColorSpace,samples:f.antialias?4:0});let Fe=e.properties.get(m);Fe.__ignoreDepthValues=d.ignoreDepthValues}m.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),pe.setContext(s),pe.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode};function L(X){for(let Q=0;Q<X.removed.length;Q++){let ge=X.removed[Q],Ee=x.indexOf(ge);Ee>=0&&(x[Ee]=null,y[Ee].disconnect(ge))}for(let Q=0;Q<X.added.length;Q++){let ge=X.added[Q],Ee=x.indexOf(ge);if(Ee===-1){for(let Fe=0;Fe<y.length;Fe++)if(Fe>=x.length){x.push(ge),Ee=Fe;break}else if(x[Fe]===null){x[Fe]=ge,Ee=Fe;break}if(Ee===-1)break}let we=y[Ee];we&&we.connect(ge)}}let U=new R,V=new R;function K(X,Q,ge){U.setFromMatrixPosition(Q.matrixWorld),V.setFromMatrixPosition(ge.matrixWorld);let Ee=U.distanceTo(V),we=Q.projectionMatrix.elements,Fe=ge.projectionMatrix.elements,Be=we[14]/(we[10]-1),Le=we[14]/(we[10]+1),Je=(we[9]+1)/we[5],B=(we[9]-1)/we[5],Gt=(we[8]-1)/we[0],Ce=(Fe[8]+1)/Fe[0],Ne=Be*Gt,be=Be*Ce,gt=Ee/(-Gt+Ce),ze=gt*-Gt;Q.matrixWorld.decompose(X.position,X.quaternion,X.scale),X.translateX(ze),X.translateZ(gt),X.matrixWorld.compose(X.position,X.quaternion,X.scale),X.matrixWorldInverse.copy(X.matrixWorld).invert();let C=Be+gt,M=Le+gt,k=Ne-ze,se=be+(Ee-ze),te=Je*Le/M*C,ne=B*Le/M*C;X.projectionMatrix.makePerspective(k,se,te,ne,C,M),X.projectionMatrixInverse.copy(X.projectionMatrix).invert()}function Y(X,Q){Q===null?X.matrixWorld.copy(X.matrix):X.matrixWorld.multiplyMatrices(Q.matrixWorld,X.matrix),X.matrixWorldInverse.copy(X.matrixWorld).invert()}this.updateCamera=function(X){if(s===null)return;v.near=T.near=w.near=X.near,v.far=T.far=w.far=X.far,(S!==v.near||N!==v.far)&&(s.updateRenderState({depthNear:v.near,depthFar:v.far}),S=v.near,N=v.far);let Q=X.parent,ge=v.cameras;Y(v,Q);for(let Ee=0;Ee<ge.length;Ee++)Y(ge[Ee],Q);ge.length===2?K(v,w,T):v.projectionMatrix.copy(w.projectionMatrix),q(X,v,Q)};function q(X,Q,ge){ge===null?X.matrix.copy(Q.matrixWorld):(X.matrix.copy(ge.matrixWorld),X.matrix.invert(),X.matrix.multiply(Q.matrixWorld)),X.matrix.decompose(X.position,X.quaternion,X.scale),X.updateMatrixWorld(!0),X.projectionMatrix.copy(Q.projectionMatrix),X.projectionMatrixInverse.copy(Q.projectionMatrixInverse),X.isPerspectiveCamera&&(X.fov=ks*2*Math.atan(1/X.projectionMatrix.elements[5]),X.zoom=1)}this.getCamera=function(){return v},this.getFoveation=function(){if(!(d===null&&p===null))return l},this.setFoveation=function(X){l=X,d!==null&&(d.fixedFoveation=X),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=X)};let $=null;function ie(X,Q){if(h=Q.getViewerPose(c||o),g=Q,h!==null){let ge=h.views;p!==null&&(e.setRenderTargetFramebuffer(m,p.framebuffer),e.setRenderTarget(m));let Ee=!1;ge.length!==v.cameras.length&&(v.cameras.length=0,Ee=!0);for(let we=0;we<ge.length;we++){let Fe=ge[we],Be=null;if(p!==null)Be=p.getViewport(Fe);else{let Je=u.getViewSubImage(d,Fe);Be=Je.viewport,we===0&&(e.setRenderTargetTextures(m,Je.colorTexture,d.ignoreDepthValues?void 0:Je.depthStencilTexture),e.setRenderTarget(m))}let Le=D[we];Le===void 0&&(Le=new Ot,Le.layers.enable(we),Le.viewport=new dt,D[we]=Le),Le.matrix.fromArray(Fe.transform.matrix),Le.matrix.decompose(Le.position,Le.quaternion,Le.scale),Le.projectionMatrix.fromArray(Fe.projectionMatrix),Le.projectionMatrixInverse.copy(Le.projectionMatrix).invert(),Le.viewport.set(Be.x,Be.y,Be.width,Be.height),we===0&&(v.matrix.copy(Le.matrix),v.matrix.decompose(v.position,v.quaternion,v.scale)),Ee===!0&&v.cameras.push(Le)}}for(let ge=0;ge<y.length;ge++){let Ee=x[ge],we=y[ge];Ee!==null&&we!==void 0&&we.update(Ee,Q,c||o)}$&&$(X,Q),Q.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Q}),g=null}let pe=new vf;pe.setAnimationLoop(ie),this.setAnimationLoop=function(X){$=X},this.dispose=function(){}}};function Qy(i,e){function t(_,m){_.matrixAutoUpdate===!0&&_.updateMatrix(),m.value.copy(_.matrix)}function n(_,m){m.color.getRGB(_.fogColor.value,yf(i)),m.isFog?(_.fogNear.value=m.near,_.fogFar.value=m.far):m.isFogExp2&&(_.fogDensity.value=m.density)}function s(_,m,y,x,b){m.isMeshBasicMaterial||m.isMeshLambertMaterial?r(_,m):m.isMeshToonMaterial?(r(_,m),u(_,m)):m.isMeshPhongMaterial?(r(_,m),h(_,m)):m.isMeshStandardMaterial?(r(_,m),d(_,m),m.isMeshPhysicalMaterial&&p(_,m,b)):m.isMeshMatcapMaterial?(r(_,m),g(_,m)):m.isMeshDepthMaterial?r(_,m):m.isMeshDistanceMaterial?(r(_,m),f(_,m)):m.isMeshNormalMaterial?r(_,m):m.isLineBasicMaterial?(o(_,m),m.isLineDashedMaterial&&a(_,m)):m.isPointsMaterial?l(_,m,y,x):m.isSpriteMaterial?c(_,m):m.isShadowMaterial?(_.color.value.copy(m.color),_.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(_,m){_.opacity.value=m.opacity,m.color&&_.diffuse.value.copy(m.color),m.emissive&&_.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(_.map.value=m.map,t(m.map,_.mapTransform)),m.alphaMap&&(_.alphaMap.value=m.alphaMap,t(m.alphaMap,_.alphaMapTransform)),m.bumpMap&&(_.bumpMap.value=m.bumpMap,t(m.bumpMap,_.bumpMapTransform),_.bumpScale.value=m.bumpScale,m.side===Yt&&(_.bumpScale.value*=-1)),m.normalMap&&(_.normalMap.value=m.normalMap,t(m.normalMap,_.normalMapTransform),_.normalScale.value.copy(m.normalScale),m.side===Yt&&_.normalScale.value.negate()),m.displacementMap&&(_.displacementMap.value=m.displacementMap,t(m.displacementMap,_.displacementMapTransform),_.displacementScale.value=m.displacementScale,_.displacementBias.value=m.displacementBias),m.emissiveMap&&(_.emissiveMap.value=m.emissiveMap,t(m.emissiveMap,_.emissiveMapTransform)),m.specularMap&&(_.specularMap.value=m.specularMap,t(m.specularMap,_.specularMapTransform)),m.alphaTest>0&&(_.alphaTest.value=m.alphaTest);let y=e.get(m).envMap;if(y&&(_.envMap.value=y,_.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,_.reflectivity.value=m.reflectivity,_.ior.value=m.ior,_.refractionRatio.value=m.refractionRatio),m.lightMap){_.lightMap.value=m.lightMap;let x=i._useLegacyLights===!0?Math.PI:1;_.lightMapIntensity.value=m.lightMapIntensity*x,t(m.lightMap,_.lightMapTransform)}m.aoMap&&(_.aoMap.value=m.aoMap,_.aoMapIntensity.value=m.aoMapIntensity,t(m.aoMap,_.aoMapTransform))}function o(_,m){_.diffuse.value.copy(m.color),_.opacity.value=m.opacity,m.map&&(_.map.value=m.map,t(m.map,_.mapTransform))}function a(_,m){_.dashSize.value=m.dashSize,_.totalSize.value=m.dashSize+m.gapSize,_.scale.value=m.scale}function l(_,m,y,x){_.diffuse.value.copy(m.color),_.opacity.value=m.opacity,_.size.value=m.size*y,_.scale.value=x*.5,m.map&&(_.map.value=m.map,t(m.map,_.uvTransform)),m.alphaMap&&(_.alphaMap.value=m.alphaMap,t(m.alphaMap,_.alphaMapTransform)),m.alphaTest>0&&(_.alphaTest.value=m.alphaTest)}function c(_,m){_.diffuse.value.copy(m.color),_.opacity.value=m.opacity,_.rotation.value=m.rotation,m.map&&(_.map.value=m.map,t(m.map,_.mapTransform)),m.alphaMap&&(_.alphaMap.value=m.alphaMap,t(m.alphaMap,_.alphaMapTransform)),m.alphaTest>0&&(_.alphaTest.value=m.alphaTest)}function h(_,m){_.specular.value.copy(m.specular),_.shininess.value=Math.max(m.shininess,1e-4)}function u(_,m){m.gradientMap&&(_.gradientMap.value=m.gradientMap)}function d(_,m){_.metalness.value=m.metalness,m.metalnessMap&&(_.metalnessMap.value=m.metalnessMap,t(m.metalnessMap,_.metalnessMapTransform)),_.roughness.value=m.roughness,m.roughnessMap&&(_.roughnessMap.value=m.roughnessMap,t(m.roughnessMap,_.roughnessMapTransform)),e.get(m).envMap&&(_.envMapIntensity.value=m.envMapIntensity)}function p(_,m,y){_.ior.value=m.ior,m.sheen>0&&(_.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),_.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(_.sheenColorMap.value=m.sheenColorMap,t(m.sheenColorMap,_.sheenColorMapTransform)),m.sheenRoughnessMap&&(_.sheenRoughnessMap.value=m.sheenRoughnessMap,t(m.sheenRoughnessMap,_.sheenRoughnessMapTransform))),m.clearcoat>0&&(_.clearcoat.value=m.clearcoat,_.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(_.clearcoatMap.value=m.clearcoatMap,t(m.clearcoatMap,_.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(_.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,t(m.clearcoatRoughnessMap,_.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(_.clearcoatNormalMap.value=m.clearcoatNormalMap,t(m.clearcoatNormalMap,_.clearcoatNormalMapTransform),_.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===Yt&&_.clearcoatNormalScale.value.negate())),m.iridescence>0&&(_.iridescence.value=m.iridescence,_.iridescenceIOR.value=m.iridescenceIOR,_.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],_.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(_.iridescenceMap.value=m.iridescenceMap,t(m.iridescenceMap,_.iridescenceMapTransform)),m.iridescenceThicknessMap&&(_.iridescenceThicknessMap.value=m.iridescenceThicknessMap,t(m.iridescenceThicknessMap,_.iridescenceThicknessMapTransform))),m.transmission>0&&(_.transmission.value=m.transmission,_.transmissionSamplerMap.value=y.texture,_.transmissionSamplerSize.value.set(y.width,y.height),m.transmissionMap&&(_.transmissionMap.value=m.transmissionMap,t(m.transmissionMap,_.transmissionMapTransform)),_.thickness.value=m.thickness,m.thicknessMap&&(_.thicknessMap.value=m.thicknessMap,t(m.thicknessMap,_.thicknessMapTransform)),_.attenuationDistance.value=m.attenuationDistance,_.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(_.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(_.anisotropyMap.value=m.anisotropyMap,t(m.anisotropyMap,_.anisotropyMapTransform))),_.specularIntensity.value=m.specularIntensity,_.specularColor.value.copy(m.specularColor),m.specularColorMap&&(_.specularColorMap.value=m.specularColorMap,t(m.specularColorMap,_.specularColorMapTransform)),m.specularIntensityMap&&(_.specularIntensityMap.value=m.specularIntensityMap,t(m.specularIntensityMap,_.specularIntensityMapTransform))}function g(_,m){m.matcap&&(_.matcap.value=m.matcap)}function f(_,m){let y=e.get(m).light;_.referencePosition.value.setFromMatrixPosition(y.matrixWorld),_.nearDistance.value=y.shadow.camera.near,_.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function ev(i,e,t,n){let s={},r={},o=[],a=t.isWebGL2?i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(y,x){let b=x.program;n.uniformBlockBinding(y,b)}function c(y,x){let b=s[y.id];b===void 0&&(g(y),b=h(y),s[y.id]=b,y.addEventListener("dispose",_));let E=x.program;n.updateUBOMapping(y,E);let w=e.render.frame;r[y.id]!==w&&(d(y),r[y.id]=w)}function h(y){let x=u();y.__bindingPointIndex=x;let b=i.createBuffer(),E=y.__size,w=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,b),i.bufferData(i.UNIFORM_BUFFER,E,w),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,x,b),b}function u(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(y){let x=s[y.id],b=y.uniforms,E=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,x);for(let w=0,T=b.length;w<T;w++){let D=Array.isArray(b[w])?b[w]:[b[w]];for(let v=0,S=D.length;v<S;v++){let N=D[v];if(p(N,w,v,E)===!0){let O=N.__offset,j=Array.isArray(N.value)?N.value:[N.value],L=0;for(let U=0;U<j.length;U++){let V=j[U],K=f(V);typeof V=="number"||typeof V=="boolean"?(N.__data[0]=V,i.bufferSubData(i.UNIFORM_BUFFER,O+L,N.__data)):V.isMatrix3?(N.__data[0]=V.elements[0],N.__data[1]=V.elements[1],N.__data[2]=V.elements[2],N.__data[3]=0,N.__data[4]=V.elements[3],N.__data[5]=V.elements[4],N.__data[6]=V.elements[5],N.__data[7]=0,N.__data[8]=V.elements[6],N.__data[9]=V.elements[7],N.__data[10]=V.elements[8],N.__data[11]=0):(V.toArray(N.__data,L),L+=K.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,O,N.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function p(y,x,b,E){let w=y.value,T=x+"_"+b;if(E[T]===void 0)return typeof w=="number"||typeof w=="boolean"?E[T]=w:E[T]=w.clone(),!0;{let D=E[T];if(typeof w=="number"||typeof w=="boolean"){if(D!==w)return E[T]=w,!0}else if(D.equals(w)===!1)return D.copy(w),!0}return!1}function g(y){let x=y.uniforms,b=0,E=16;for(let T=0,D=x.length;T<D;T++){let v=Array.isArray(x[T])?x[T]:[x[T]];for(let S=0,N=v.length;S<N;S++){let O=v[S],j=Array.isArray(O.value)?O.value:[O.value];for(let L=0,U=j.length;L<U;L++){let V=j[L],K=f(V),Y=b%E;Y!==0&&E-Y<K.boundary&&(b+=E-Y),O.__data=new Float32Array(K.storage/Float32Array.BYTES_PER_ELEMENT),O.__offset=b,b+=K.storage}}}let w=b%E;return w>0&&(b+=E-w),y.__size=b,y.__cache={},this}function f(y){let x={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(x.boundary=4,x.storage=4):y.isVector2?(x.boundary=8,x.storage=8):y.isVector3||y.isColor?(x.boundary=16,x.storage=12):y.isVector4?(x.boundary=16,x.storage=16):y.isMatrix3?(x.boundary=48,x.storage=48):y.isMatrix4?(x.boundary=64,x.storage=64):y.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",y),x}function _(y){let x=y.target;x.removeEventListener("dispose",_);let b=o.indexOf(x.__bindingPointIndex);o.splice(b,1),i.deleteBuffer(s[x.id]),delete s[x.id],delete r[x.id]}function m(){for(let y in s)i.deleteBuffer(s[y]);o=[],s={},r={}}return{bind:l,update:c,dispose:m}}var Cr=class{constructor(e={}){let{canvas:t=cg(),context:n=null,depth:s=!0,stencil:r=!0,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=e;this.isWebGLRenderer=!0;let d;n!==null?d=n.getContextAttributes().alpha:d=o;let p=new Uint32Array(4),g=new Int32Array(4),f=null,_=null,m=[],y=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=ut,this._useLegacyLights=!1,this.toneMapping=Ci,this.toneMappingExposure=1;let x=this,b=!1,E=0,w=0,T=null,D=-1,v=null,S=new dt,N=new dt,O=null,j=new Re(0),L=0,U=t.width,V=t.height,K=1,Y=null,q=null,$=new dt(0,0,U,V),ie=new dt(0,0,U,V),pe=!1,X=new Rr,Q=!1,ge=!1,Ee=null,we=new ke,Fe=new he,Be=new R,Le={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function Je(){return T===null?K:1}let B=n;function Gt(A,F){for(let H=0;H<A.length;H++){let G=A[H],z=t.getContext(G,F);if(z!==null)return z}return null}try{let A={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Oc}`),t.addEventListener("webglcontextlost",ce,!1),t.addEventListener("webglcontextrestored",I,!1),t.addEventListener("webglcontextcreationerror",oe,!1),B===null){let F=["webgl2","webgl","experimental-webgl"];if(x.isWebGL1Renderer===!0&&F.shift(),B=Gt(F,A),B===null)throw Gt(F)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&B instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),B.getShaderPrecisionFormat===void 0&&(B.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(A){throw console.error("THREE.WebGLRenderer: "+A.message),A}let Ce,Ne,be,gt,ze,C,M,k,se,te,ne,Me,fe,ye,Ie,Ve,ee,Qe,P,J,ue,ae,Se,Ye;function et(){Ce=new yx(B),Ne=new fx(B,Ce,e),Ce.init(Ne),ae=new Zy(B,Ce,Ne),be=new jy(B,Ce,Ne),gt=new Mx(B),ze=new Fy,C=new $y(B,Ce,be,ze,Ne,ae,gt),M=new mx(x),k=new xx(x),se=new Pg(B,Ne),Se=new ux(B,Ce,se,Ne),te=new vx(B,se,gt,Se),ne=new Tx(B,te,se,gt),P=new Ex(B,Ne,C),Ve=new px(ze),Me=new Oy(x,M,k,Ce,Ne,Se,Ve),fe=new Qy(x,ze),ye=new ky,Ie=new Xy(Ce,Ne),Qe=new hx(x,M,k,be,ne,d,l),ee=new Ky(x,ne,Ne),Ye=new ev(B,gt,Ne,be),J=new dx(B,Ce,gt,Ne),ue=new bx(B,Ce,gt,Ne),gt.programs=Me.programs,x.capabilities=Ne,x.extensions=Ce,x.properties=ze,x.renderLists=ye,x.shadowMap=ee,x.state=be,x.info=gt}et();let Xe=new uc(x,B);this.xr=Xe,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){let A=Ce.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){let A=Ce.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return K},this.setPixelRatio=function(A){A!==void 0&&(K=A,this.setSize(U,V,!1))},this.getSize=function(A){return A.set(U,V)},this.setSize=function(A,F,H=!0){if(Xe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}U=A,V=F,t.width=Math.floor(A*K),t.height=Math.floor(F*K),H===!0&&(t.style.width=A+"px",t.style.height=F+"px"),this.setViewport(0,0,A,F)},this.getDrawingBufferSize=function(A){return A.set(U*K,V*K).floor()},this.setDrawingBufferSize=function(A,F,H){U=A,V=F,K=H,t.width=Math.floor(A*H),t.height=Math.floor(F*H),this.setViewport(0,0,A,F)},this.getCurrentViewport=function(A){return A.copy(S)},this.getViewport=function(A){return A.copy($)},this.setViewport=function(A,F,H,G){A.isVector4?$.set(A.x,A.y,A.z,A.w):$.set(A,F,H,G),be.viewport(S.copy($).multiplyScalar(K).floor())},this.getScissor=function(A){return A.copy(ie)},this.setScissor=function(A,F,H,G){A.isVector4?ie.set(A.x,A.y,A.z,A.w):ie.set(A,F,H,G),be.scissor(N.copy(ie).multiplyScalar(K).floor())},this.getScissorTest=function(){return pe},this.setScissorTest=function(A){be.setScissorTest(pe=A)},this.setOpaqueSort=function(A){Y=A},this.setTransparentSort=function(A){q=A},this.getClearColor=function(A){return A.copy(Qe.getClearColor())},this.setClearColor=function(){Qe.setClearColor.apply(Qe,arguments)},this.getClearAlpha=function(){return Qe.getClearAlpha()},this.setClearAlpha=function(){Qe.setClearAlpha.apply(Qe,arguments)},this.clear=function(A=!0,F=!0,H=!0){let G=0;if(A){let z=!1;if(T!==null){let _e=T.texture.format;z=_e===uf||_e===hf||_e===cf}if(z){let _e=T.texture.type,Ae=_e===Pi||_e===Ti||_e===zc||_e===ji||_e===of||_e===lf,De=Qe.getClearColor(),Ue=Qe.getClearAlpha(),qe=De.r,He=De.g,Ge=De.b;Ae?(p[0]=qe,p[1]=He,p[2]=Ge,p[3]=Ue,B.clearBufferuiv(B.COLOR,0,p)):(g[0]=qe,g[1]=He,g[2]=Ge,g[3]=Ue,B.clearBufferiv(B.COLOR,0,g))}else G|=B.COLOR_BUFFER_BIT}F&&(G|=B.DEPTH_BUFFER_BIT),H&&(G|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),B.clear(G)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ce,!1),t.removeEventListener("webglcontextrestored",I,!1),t.removeEventListener("webglcontextcreationerror",oe,!1),ye.dispose(),Ie.dispose(),ze.dispose(),M.dispose(),k.dispose(),ne.dispose(),Se.dispose(),Ye.dispose(),Me.dispose(),Xe.dispose(),Xe.removeEventListener("sessionstart",rn),Xe.removeEventListener("sessionend",pt),Ee&&(Ee.dispose(),Ee=null),an.stop()};function ce(A){A.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),b=!0}function I(){console.log("THREE.WebGLRenderer: Context Restored."),b=!1;let A=gt.autoReset,F=ee.enabled,H=ee.autoUpdate,G=ee.needsUpdate,z=ee.type;et(),gt.autoReset=A,ee.enabled=F,ee.autoUpdate=H,ee.needsUpdate=G,ee.type=z}function oe(A){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function le(A){let F=A.target;F.removeEventListener("dispose",le),Pe(F)}function Pe(A){Te(A),ze.remove(A)}function Te(A){let F=ze.get(A).programs;F!==void 0&&(F.forEach(function(H){Me.releaseProgram(H)}),A.isShaderMaterial&&Me.releaseShaderCache(A))}this.renderBufferDirect=function(A,F,H,G,z,_e){F===null&&(F=Le);let Ae=z.isMesh&&z.matrixWorld.determinant()<0,De=qp(A,F,H,G,z);be.setMaterial(G,Ae);let Ue=H.index,qe=1;if(G.wireframe===!0){if(Ue=te.getWireframeAttribute(H),Ue===void 0)return;qe=2}let He=H.drawRange,Ge=H.attributes.position,Tt=He.start*qe,pn=(He.start+He.count)*qe;_e!==null&&(Tt=Math.max(Tt,_e.start*qe),pn=Math.min(pn,(_e.start+_e.count)*qe)),Ue!==null?(Tt=Math.max(Tt,0),pn=Math.min(pn,Ue.count)):Ge!=null&&(Tt=Math.max(Tt,0),pn=Math.min(pn,Ge.count));let Xt=pn-Tt;if(Xt<0||Xt===1/0)return;Se.setup(z,G,De,H,Ue);let ei,vt=J;if(Ue!==null&&(ei=se.get(Ue),vt=ue,vt.setIndex(ei)),z.isMesh)G.wireframe===!0?(be.setLineWidth(G.wireframeLinewidth*Je()),vt.setMode(B.LINES)):vt.setMode(B.TRIANGLES);else if(z.isLine){let Ke=G.linewidth;Ke===void 0&&(Ke=1),be.setLineWidth(Ke*Je()),z.isLineSegments?vt.setMode(B.LINES):z.isLineLoop?vt.setMode(B.LINE_LOOP):vt.setMode(B.LINE_STRIP)}else z.isPoints?vt.setMode(B.POINTS):z.isSprite&&vt.setMode(B.TRIANGLES);if(z.isBatchedMesh)vt.renderMultiDraw(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount);else if(z.isInstancedMesh)vt.renderInstances(Tt,Xt,z.count);else if(H.isInstancedBufferGeometry){let Ke=H._maxInstanceCount!==void 0?H._maxInstanceCount:1/0,rl=Math.min(H.instanceCount,Ke);vt.renderInstances(Tt,Xt,rl)}else vt.render(Tt,Xt)};function it(A,F,H){A.transparent===!0&&A.side===yt&&A.forceSinglePass===!1?(A.side=Yt,A.needsUpdate=!0,ca(A,F,H),A.side=Yn,A.needsUpdate=!0,ca(A,F,H),A.side=yt):ca(A,F,H)}this.compile=function(A,F,H=null){H===null&&(H=A),_=Ie.get(H),_.init(),y.push(_),H.traverseVisible(function(z){z.isLight&&z.layers.test(F.layers)&&(_.pushLight(z),z.castShadow&&_.pushShadow(z))}),A!==H&&A.traverseVisible(function(z){z.isLight&&z.layers.test(F.layers)&&(_.pushLight(z),z.castShadow&&_.pushShadow(z))}),_.setupLights(x._useLegacyLights);let G=new Set;return A.traverse(function(z){let _e=z.material;if(_e)if(Array.isArray(_e))for(let Ae=0;Ae<_e.length;Ae++){let De=_e[Ae];it(De,H,z),G.add(De)}else it(_e,H,z),G.add(_e)}),y.pop(),_=null,G},this.compileAsync=function(A,F,H=null){let G=this.compile(A,F,H);return new Promise(z=>{function _e(){if(G.forEach(function(Ae){ze.get(Ae).currentProgram.isReady()&&G.delete(Ae)}),G.size===0){z(A);return}setTimeout(_e,10)}Ce.get("KHR_parallel_shader_compile")!==null?_e():setTimeout(_e,10)})};let at=null;function Wt(A){at&&at(A)}function rn(){an.stop()}function pt(){an.start()}let an=new vf;an.setAnimationLoop(Wt),typeof self<"u"&&an.setContext(self),this.setAnimationLoop=function(A){at=A,Xe.setAnimationLoop(A),A===null?an.stop():an.start()},Xe.addEventListener("sessionstart",rn),Xe.addEventListener("sessionend",pt),this.render=function(A,F){if(F!==void 0&&F.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(b===!0)return;A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),F.parent===null&&F.matrixWorldAutoUpdate===!0&&F.updateMatrixWorld(),Xe.enabled===!0&&Xe.isPresenting===!0&&(Xe.cameraAutoUpdate===!0&&Xe.updateCamera(F),F=Xe.getCamera()),A.isScene===!0&&A.onBeforeRender(x,A,F,T),_=Ie.get(A,y.length),_.init(),y.push(_),we.multiplyMatrices(F.projectionMatrix,F.matrixWorldInverse),X.setFromProjectionMatrix(we),ge=this.localClippingEnabled,Q=Ve.init(this.clippingPlanes,ge),f=ye.get(A,m.length),f.init(),m.push(f),Wn(A,F,0,x.sortObjects),f.finish(),x.sortObjects===!0&&f.sort(Y,q),this.info.render.frame++,Q===!0&&Ve.beginShadows();let H=_.state.shadowsArray;if(ee.render(H,A,F),Q===!0&&Ve.endShadows(),this.info.autoReset===!0&&this.info.reset(),Qe.render(f,A),_.setupLights(x._useLegacyLights),F.isArrayCamera){let G=F.cameras;for(let z=0,_e=G.length;z<_e;z++){let Ae=G[z];hu(f,A,Ae,Ae.viewport)}}else hu(f,A,F);T!==null&&(C.updateMultisampleRenderTarget(T),C.updateRenderTargetMipmap(T)),A.isScene===!0&&A.onAfterRender(x,A,F),Se.resetDefaultState(),D=-1,v=null,y.pop(),y.length>0?_=y[y.length-1]:_=null,m.pop(),m.length>0?f=m[m.length-1]:f=null};function Wn(A,F,H,G){if(A.visible===!1)return;if(A.layers.test(F.layers)){if(A.isGroup)H=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(F);else if(A.isLight)_.pushLight(A),A.castShadow&&_.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||X.intersectsSprite(A)){G&&Be.setFromMatrixPosition(A.matrixWorld).applyMatrix4(we);let Ae=ne.update(A),De=A.material;De.visible&&f.push(A,Ae,De,H,Be.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||X.intersectsObject(A))){let Ae=ne.update(A),De=A.material;if(G&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),Be.copy(A.boundingSphere.center)):(Ae.boundingSphere===null&&Ae.computeBoundingSphere(),Be.copy(Ae.boundingSphere.center)),Be.applyMatrix4(A.matrixWorld).applyMatrix4(we)),Array.isArray(De)){let Ue=Ae.groups;for(let qe=0,He=Ue.length;qe<He;qe++){let Ge=Ue[qe],Tt=De[Ge.materialIndex];Tt&&Tt.visible&&f.push(A,Ae,Tt,H,Be.z,Ge)}}else De.visible&&f.push(A,Ae,De,H,Be.z,null)}}let _e=A.children;for(let Ae=0,De=_e.length;Ae<De;Ae++)Wn(_e[Ae],F,H,G)}function hu(A,F,H,G){let z=A.opaque,_e=A.transmissive,Ae=A.transparent;_.setupLightsView(H),Q===!0&&Ve.setGlobalState(x.clippingPlanes,H),_e.length>0&&Xp(z,_e,F,H),G&&be.viewport(S.copy(G)),z.length>0&&la(z,F,H),_e.length>0&&la(_e,F,H),Ae.length>0&&la(Ae,F,H),be.buffers.depth.setTest(!0),be.buffers.depth.setMask(!0),be.buffers.color.setMask(!0),be.setPolygonOffset(!1)}function Xp(A,F,H,G){if((H.isScene===!0?H.overrideMaterial:null)!==null)return;let _e=Ne.isWebGL2;Ee===null&&(Ee=new hi(1,1,{generateMipmaps:!0,type:Ce.has("EXT_color_buffer_half_float")?Er:Pi,minFilter:Li,samples:_e?4:0})),x.getDrawingBufferSize(Fe),_e?Ee.setSize(Fe.x,Fe.y):Ee.setSize(qa(Fe.x),qa(Fe.y));let Ae=x.getRenderTarget();x.setRenderTarget(Ee),x.getClearColor(j),L=x.getClearAlpha(),L<1&&x.setClearColor(16777215,.5),x.clear();let De=x.toneMapping;x.toneMapping=Ci,la(A,H,G),C.updateMultisampleRenderTarget(Ee),C.updateRenderTargetMipmap(Ee);let Ue=!1;for(let qe=0,He=F.length;qe<He;qe++){let Ge=F[qe],Tt=Ge.object,pn=Ge.geometry,Xt=Ge.material,ei=Ge.group;if(Xt.side===yt&&Tt.layers.test(G.layers)){let vt=Xt.side;Xt.side=Yt,Xt.needsUpdate=!0,uu(Tt,H,G,pn,Xt,ei),Xt.side=vt,Xt.needsUpdate=!0,Ue=!0}}Ue===!0&&(C.updateMultisampleRenderTarget(Ee),C.updateRenderTargetMipmap(Ee)),x.setRenderTarget(Ae),x.setClearColor(j,L),x.toneMapping=De}function la(A,F,H){let G=F.isScene===!0?F.overrideMaterial:null;for(let z=0,_e=A.length;z<_e;z++){let Ae=A[z],De=Ae.object,Ue=Ae.geometry,qe=G===null?Ae.material:G,He=Ae.group;De.layers.test(H.layers)&&uu(De,F,H,Ue,qe,He)}}function uu(A,F,H,G,z,_e){A.onBeforeRender(x,F,H,G,z,_e),A.modelViewMatrix.multiplyMatrices(H.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),z.onBeforeRender(x,F,H,G,A,_e),z.transparent===!0&&z.side===yt&&z.forceSinglePass===!1?(z.side=Yt,z.needsUpdate=!0,x.renderBufferDirect(H,F,G,z,A,_e),z.side=Yn,z.needsUpdate=!0,x.renderBufferDirect(H,F,G,z,A,_e),z.side=yt):x.renderBufferDirect(H,F,G,z,A,_e),A.onAfterRender(x,F,H,G,z,_e)}function ca(A,F,H){F.isScene!==!0&&(F=Le);let G=ze.get(A),z=_.state.lights,_e=_.state.shadowsArray,Ae=z.state.version,De=Me.getParameters(A,z.state,_e,F,H),Ue=Me.getProgramCacheKey(De),qe=G.programs;G.environment=A.isMeshStandardMaterial?F.environment:null,G.fog=F.fog,G.envMap=(A.isMeshStandardMaterial?k:M).get(A.envMap||G.environment),qe===void 0&&(A.addEventListener("dispose",le),qe=new Map,G.programs=qe);let He=qe.get(Ue);if(He!==void 0){if(G.currentProgram===He&&G.lightsStateVersion===Ae)return fu(A,De),He}else De.uniforms=Me.getUniforms(A),A.onBuild(H,De,x),A.onBeforeCompile(De,x),He=Me.acquireProgram(De,Ue),qe.set(Ue,He),G.uniforms=De.uniforms;let Ge=G.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(Ge.clippingPlanes=Ve.uniform),fu(A,De),G.needsLights=Kp(A),G.lightsStateVersion=Ae,G.needsLights&&(Ge.ambientLightColor.value=z.state.ambient,Ge.lightProbe.value=z.state.probe,Ge.directionalLights.value=z.state.directional,Ge.directionalLightShadows.value=z.state.directionalShadow,Ge.spotLights.value=z.state.spot,Ge.spotLightShadows.value=z.state.spotShadow,Ge.rectAreaLights.value=z.state.rectArea,Ge.ltc_1.value=z.state.rectAreaLTC1,Ge.ltc_2.value=z.state.rectAreaLTC2,Ge.pointLights.value=z.state.point,Ge.pointLightShadows.value=z.state.pointShadow,Ge.hemisphereLights.value=z.state.hemi,Ge.directionalShadowMap.value=z.state.directionalShadowMap,Ge.directionalShadowMatrix.value=z.state.directionalShadowMatrix,Ge.spotShadowMap.value=z.state.spotShadowMap,Ge.spotLightMatrix.value=z.state.spotLightMatrix,Ge.spotLightMap.value=z.state.spotLightMap,Ge.pointShadowMap.value=z.state.pointShadowMap,Ge.pointShadowMatrix.value=z.state.pointShadowMatrix),G.currentProgram=He,G.uniformsList=null,He}function du(A){if(A.uniformsList===null){let F=A.currentProgram.getUniforms();A.uniformsList=Ns.seqWithValue(F.seq,A.uniforms)}return A.uniformsList}function fu(A,F){let H=ze.get(A);H.outputColorSpace=F.outputColorSpace,H.batching=F.batching,H.instancing=F.instancing,H.instancingColor=F.instancingColor,H.skinning=F.skinning,H.morphTargets=F.morphTargets,H.morphNormals=F.morphNormals,H.morphColors=F.morphColors,H.morphTargetsCount=F.morphTargetsCount,H.numClippingPlanes=F.numClippingPlanes,H.numIntersection=F.numClipIntersection,H.vertexAlphas=F.vertexAlphas,H.vertexTangents=F.vertexTangents,H.toneMapping=F.toneMapping}function qp(A,F,H,G,z){F.isScene!==!0&&(F=Le),C.resetTextureUnits();let _e=F.fog,Ae=G.isMeshStandardMaterial?F.environment:null,De=T===null?x.outputColorSpace:T.isXRRenderTarget===!0?T.texture.colorSpace:Ft,Ue=(G.isMeshStandardMaterial?k:M).get(G.envMap||Ae),qe=G.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,He=!!H.attributes.tangent&&(!!G.normalMap||G.anisotropy>0),Ge=!!H.morphAttributes.position,Tt=!!H.morphAttributes.normal,pn=!!H.morphAttributes.color,Xt=Ci;G.toneMapped&&(T===null||T.isXRRenderTarget===!0)&&(Xt=x.toneMapping);let ei=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,vt=ei!==void 0?ei.length:0,Ke=ze.get(G),rl=_.state.lights;if(Q===!0&&(ge===!0||A!==v)){let bn=A===v&&G.id===D;Ve.setState(G,A,bn)}let wt=!1;G.version===Ke.__version?(Ke.needsLights&&Ke.lightsStateVersion!==rl.state.version||Ke.outputColorSpace!==De||z.isBatchedMesh&&Ke.batching===!1||!z.isBatchedMesh&&Ke.batching===!0||z.isInstancedMesh&&Ke.instancing===!1||!z.isInstancedMesh&&Ke.instancing===!0||z.isSkinnedMesh&&Ke.skinning===!1||!z.isSkinnedMesh&&Ke.skinning===!0||z.isInstancedMesh&&Ke.instancingColor===!0&&z.instanceColor===null||z.isInstancedMesh&&Ke.instancingColor===!1&&z.instanceColor!==null||Ke.envMap!==Ue||G.fog===!0&&Ke.fog!==_e||Ke.numClippingPlanes!==void 0&&(Ke.numClippingPlanes!==Ve.numPlanes||Ke.numIntersection!==Ve.numIntersection)||Ke.vertexAlphas!==qe||Ke.vertexTangents!==He||Ke.morphTargets!==Ge||Ke.morphNormals!==Tt||Ke.morphColors!==pn||Ke.toneMapping!==Xt||Ne.isWebGL2===!0&&Ke.morphTargetsCount!==vt)&&(wt=!0):(wt=!0,Ke.__version=G.version);let zi=Ke.currentProgram;wt===!0&&(zi=ca(G,F,z));let pu=!1,lr=!1,al=!1,Jt=zi.getUniforms(),Hi=Ke.uniforms;if(be.useProgram(zi.program)&&(pu=!0,lr=!0,al=!0),G.id!==D&&(D=G.id,lr=!0),pu||v!==A){Jt.setValue(B,"projectionMatrix",A.projectionMatrix),Jt.setValue(B,"viewMatrix",A.matrixWorldInverse);let bn=Jt.map.cameraPosition;bn!==void 0&&bn.setValue(B,Be.setFromMatrixPosition(A.matrixWorld)),Ne.logarithmicDepthBuffer&&Jt.setValue(B,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(G.isMeshPhongMaterial||G.isMeshToonMaterial||G.isMeshLambertMaterial||G.isMeshBasicMaterial||G.isMeshStandardMaterial||G.isShaderMaterial)&&Jt.setValue(B,"isOrthographic",A.isOrthographicCamera===!0),v!==A&&(v=A,lr=!0,al=!0)}if(z.isSkinnedMesh){Jt.setOptional(B,z,"bindMatrix"),Jt.setOptional(B,z,"bindMatrixInverse");let bn=z.skeleton;bn&&(Ne.floatVertexTextures?(bn.boneTexture===null&&bn.computeBoneTexture(),Jt.setValue(B,"boneTexture",bn.boneTexture,C)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}z.isBatchedMesh&&(Jt.setOptional(B,z,"batchingTexture"),Jt.setValue(B,"batchingTexture",z._matricesTexture,C));let ol=H.morphAttributes;if((ol.position!==void 0||ol.normal!==void 0||ol.color!==void 0&&Ne.isWebGL2===!0)&&P.update(z,H,zi),(lr||Ke.receiveShadow!==z.receiveShadow)&&(Ke.receiveShadow=z.receiveShadow,Jt.setValue(B,"receiveShadow",z.receiveShadow)),G.isMeshGouraudMaterial&&G.envMap!==null&&(Hi.envMap.value=Ue,Hi.flipEnvMap.value=Ue.isCubeTexture&&Ue.isRenderTargetTexture===!1?-1:1),lr&&(Jt.setValue(B,"toneMappingExposure",x.toneMappingExposure),Ke.needsLights&&Yp(Hi,al),_e&&G.fog===!0&&fe.refreshFogUniforms(Hi,_e),fe.refreshMaterialUniforms(Hi,G,K,V,Ee),Ns.upload(B,du(Ke),Hi,C)),G.isShaderMaterial&&G.uniformsNeedUpdate===!0&&(Ns.upload(B,du(Ke),Hi,C),G.uniformsNeedUpdate=!1),G.isSpriteMaterial&&Jt.setValue(B,"center",z.center),Jt.setValue(B,"modelViewMatrix",z.modelViewMatrix),Jt.setValue(B,"normalMatrix",z.normalMatrix),Jt.setValue(B,"modelMatrix",z.matrixWorld),G.isShaderMaterial||G.isRawShaderMaterial){let bn=G.uniformsGroups;for(let ll=0,jp=bn.length;ll<jp;ll++)if(Ne.isWebGL2){let mu=bn[ll];Ye.update(mu,zi),Ye.bind(mu,zi)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return zi}function Yp(A,F){A.ambientLightColor.needsUpdate=F,A.lightProbe.needsUpdate=F,A.directionalLights.needsUpdate=F,A.directionalLightShadows.needsUpdate=F,A.pointLights.needsUpdate=F,A.pointLightShadows.needsUpdate=F,A.spotLights.needsUpdate=F,A.spotLightShadows.needsUpdate=F,A.rectAreaLights.needsUpdate=F,A.hemisphereLights.needsUpdate=F}function Kp(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return T},this.setRenderTargetTextures=function(A,F,H){ze.get(A.texture).__webglTexture=F,ze.get(A.depthTexture).__webglTexture=H;let G=ze.get(A);G.__hasExternalTextures=!0,G.__hasExternalTextures&&(G.__autoAllocateDepthBuffer=H===void 0,G.__autoAllocateDepthBuffer||Ce.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),G.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(A,F){let H=ze.get(A);H.__webglFramebuffer=F,H.__useDefaultFramebuffer=F===void 0},this.setRenderTarget=function(A,F=0,H=0){T=A,E=F,w=H;let G=!0,z=null,_e=!1,Ae=!1;if(A){let Ue=ze.get(A);Ue.__useDefaultFramebuffer!==void 0?(be.bindFramebuffer(B.FRAMEBUFFER,null),G=!1):Ue.__webglFramebuffer===void 0?C.setupRenderTarget(A):Ue.__hasExternalTextures&&C.rebindTextures(A,ze.get(A.texture).__webglTexture,ze.get(A.depthTexture).__webglTexture);let qe=A.texture;(qe.isData3DTexture||qe.isDataArrayTexture||qe.isCompressedArrayTexture)&&(Ae=!0);let He=ze.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(He[F])?z=He[F][H]:z=He[F],_e=!0):Ne.isWebGL2&&A.samples>0&&C.useMultisampledRTT(A)===!1?z=ze.get(A).__webglMultisampledFramebuffer:Array.isArray(He)?z=He[H]:z=He,S.copy(A.viewport),N.copy(A.scissor),O=A.scissorTest}else S.copy($).multiplyScalar(K).floor(),N.copy(ie).multiplyScalar(K).floor(),O=pe;if(be.bindFramebuffer(B.FRAMEBUFFER,z)&&Ne.drawBuffers&&G&&be.drawBuffers(A,z),be.viewport(S),be.scissor(N),be.setScissorTest(O),_e){let Ue=ze.get(A.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+F,Ue.__webglTexture,H)}else if(Ae){let Ue=ze.get(A.texture),qe=F||0;B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,Ue.__webglTexture,H||0,qe)}D=-1},this.readRenderTargetPixels=function(A,F,H,G,z,_e,Ae){if(!(A&&A.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let De=ze.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Ae!==void 0&&(De=De[Ae]),De){be.bindFramebuffer(B.FRAMEBUFFER,De);try{let Ue=A.texture,qe=Ue.format,He=Ue.type;if(qe!==wn&&ae.convert(qe)!==B.getParameter(B.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Ge=He===Er&&(Ce.has("EXT_color_buffer_half_float")||Ne.isWebGL2&&Ce.has("EXT_color_buffer_float"));if(He!==Pi&&ae.convert(He)!==B.getParameter(B.IMPLEMENTATION_COLOR_READ_TYPE)&&!(He===li&&(Ne.isWebGL2||Ce.has("OES_texture_float")||Ce.has("WEBGL_color_buffer_float")))&&!Ge){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}F>=0&&F<=A.width-G&&H>=0&&H<=A.height-z&&B.readPixels(F,H,G,z,ae.convert(qe),ae.convert(He),_e)}finally{let Ue=T!==null?ze.get(T).__webglFramebuffer:null;be.bindFramebuffer(B.FRAMEBUFFER,Ue)}}},this.copyFramebufferToTexture=function(A,F,H=0){let G=Math.pow(2,-H),z=Math.floor(F.image.width*G),_e=Math.floor(F.image.height*G);C.setTexture2D(F,0),B.copyTexSubImage2D(B.TEXTURE_2D,H,0,0,A.x,A.y,z,_e),be.unbindTexture()},this.copyTextureToTexture=function(A,F,H,G=0){let z=F.image.width,_e=F.image.height,Ae=ae.convert(H.format),De=ae.convert(H.type);C.setTexture2D(H,0),B.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,H.flipY),B.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,H.premultiplyAlpha),B.pixelStorei(B.UNPACK_ALIGNMENT,H.unpackAlignment),F.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,G,A.x,A.y,z,_e,Ae,De,F.image.data):F.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,G,A.x,A.y,F.mipmaps[0].width,F.mipmaps[0].height,Ae,F.mipmaps[0].data):B.texSubImage2D(B.TEXTURE_2D,G,A.x,A.y,Ae,De,F.image),G===0&&H.generateMipmaps&&B.generateMipmap(B.TEXTURE_2D),be.unbindTexture()},this.copyTextureToTexture3D=function(A,F,H,G,z=0){if(x.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let _e=A.max.x-A.min.x+1,Ae=A.max.y-A.min.y+1,De=A.max.z-A.min.z+1,Ue=ae.convert(G.format),qe=ae.convert(G.type),He;if(G.isData3DTexture)C.setTexture3D(G,0),He=B.TEXTURE_3D;else if(G.isDataArrayTexture||G.isCompressedArrayTexture)C.setTexture2DArray(G,0),He=B.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}B.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,G.flipY),B.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,G.premultiplyAlpha),B.pixelStorei(B.UNPACK_ALIGNMENT,G.unpackAlignment);let Ge=B.getParameter(B.UNPACK_ROW_LENGTH),Tt=B.getParameter(B.UNPACK_IMAGE_HEIGHT),pn=B.getParameter(B.UNPACK_SKIP_PIXELS),Xt=B.getParameter(B.UNPACK_SKIP_ROWS),ei=B.getParameter(B.UNPACK_SKIP_IMAGES),vt=H.isCompressedTexture?H.mipmaps[z]:H.image;B.pixelStorei(B.UNPACK_ROW_LENGTH,vt.width),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,vt.height),B.pixelStorei(B.UNPACK_SKIP_PIXELS,A.min.x),B.pixelStorei(B.UNPACK_SKIP_ROWS,A.min.y),B.pixelStorei(B.UNPACK_SKIP_IMAGES,A.min.z),H.isDataTexture||H.isData3DTexture?B.texSubImage3D(He,z,F.x,F.y,F.z,_e,Ae,De,Ue,qe,vt.data):H.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),B.compressedTexSubImage3D(He,z,F.x,F.y,F.z,_e,Ae,De,Ue,vt.data)):B.texSubImage3D(He,z,F.x,F.y,F.z,_e,Ae,De,Ue,qe,vt),B.pixelStorei(B.UNPACK_ROW_LENGTH,Ge),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Tt),B.pixelStorei(B.UNPACK_SKIP_PIXELS,pn),B.pixelStorei(B.UNPACK_SKIP_ROWS,Xt),B.pixelStorei(B.UNPACK_SKIP_IMAGES,ei),z===0&&G.generateMipmaps&&B.generateMipmap(He),be.unbindTexture()},this.initTexture=function(A){A.isCubeTexture?C.setTextureCube(A,0):A.isData3DTexture?C.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?C.setTexture2DArray(A,0):C.setTexture2D(A,0),be.unbindTexture()},this.resetState=function(){E=0,w=0,T=null,be.reset(),Se.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ci}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=e===Wc?"display-p3":"srgb",t.unpackColorSpace=ot.workingColorSpace===Mo?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===ut?Zi:pf}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===Zi?ut:Ft}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}},dc=class extends Cr{};dc.prototype.isWebGL1Renderer=!0;var to=class i{constructor(e,t=1,n=1e3){this.isFog=!0,this.name="",this.color=new Re(e),this.near=t,this.far=n}clone(){return new i(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},ts=class extends bt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}},Pr=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=jl,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=Fn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Fn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Fn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},on=new R,Lr=class i{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)on.fromBufferAttribute(this,t),on.applyMatrix4(e),this.setXYZ(t,on.x,on.y,on.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)on.fromBufferAttribute(this,t),on.applyNormalMatrix(e),this.setXYZ(t,on.x,on.y,on.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)on.fromBufferAttribute(this,t),on.transformDirection(e),this.setXYZ(t,on.x,on.y,on.z);return this}setX(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=qn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=qn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=qn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=qn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array),r=lt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new Et(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new i(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}};var Dd=new R,Nd=new dt,Ud=new dt,tv=new R,Od=new ke,Ia=new R,Fl=new xn,Fd=new ke,Bl=new ui,no=class extends Oe{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=bu,this.bindMatrix=new ke,this.bindMatrixInverse=new ke,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new En),this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Ia),this.boundingBox.expandByPoint(Ia)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new xn),this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Ia),this.boundingSphere.expandByPoint(Ia)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Fl.copy(this.boundingSphere),Fl.applyMatrix4(s),e.ray.intersectsSphere(Fl)!==!1&&(Fd.copy(s).invert(),Bl.copy(e.ray).applyMatrix4(Fd),!(this.boundingBox!==null&&Bl.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Bl)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new dt,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);let r=1/e.manhattanLength();r!==1/0?e.multiplyScalar(r):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===bu?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Rm?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,s=this.geometry;Nd.fromBufferAttribute(s.attributes.skinIndex,e),Ud.fromBufferAttribute(s.attributes.skinWeight,e),Dd.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let r=0;r<4;r++){let o=Ud.getComponent(r);if(o!==0){let a=Nd.getComponent(r);Od.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(tv.copy(Dd).applyMatrix4(Od),o)}}return t.applyMatrix4(this.bindMatrixInverse)}boneTransform(e,t){return console.warn("THREE.SkinnedMesh: .boneTransform() was renamed to .applyBoneTransform() in r151."),this.applyBoneTransform(e,t)}},Ir=class extends bt{constructor(){super(),this.isBone=!0,this.type="Bone"}},fc=class extends jt{constructor(e=null,t=1,n=1,s,r,o,a,l,c=Ut,h=Ut,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},Bd=new ke,nv=new ke,io=class i{constructor(e=[],t=[]){this.uuid=Fn(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new ke)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let n=new ke;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let r=0,o=e.length;r<o;r++){let a=e[r]?e[r].matrixWorld:nv;Bd.multiplyMatrices(a,t[r]),Bd.toArray(n,r*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new i(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new fc(t,e,e,wn,li);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){let r=e.bones[n],o=t[r];o===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",r),o=new Ir),this.bones.push(o),this.boneInverses.push(new ke().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let s=0,r=t.length;s<r;s++){let o=t[s];e.bones.push(o.uuid);let a=n[s];e.boneInverses.push(a.toArray())}return e}},di=class extends Et{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Ts=new ke,kd=new ke,Da=[],zd=new En,iv=new ke,fr=new Oe,pr=new xn,Kn=class extends Oe{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new di(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,iv)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new En),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Ts),zd.copy(e.boundingBox).applyMatrix4(Ts),this.boundingBox.union(zd)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new xn),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Ts),pr.copy(e.boundingSphere).applyMatrix4(Ts),this.boundingSphere.union(pr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){let n=this.matrixWorld,s=this.count;if(fr.geometry=this.geometry,fr.material=this.material,fr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),pr.copy(this.boundingSphere),pr.applyMatrix4(n),e.ray.intersectsSphere(pr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ts),kd.multiplyMatrices(n,Ts),fr.matrixWorld=kd,fr.raycast(e,Da);for(let o=0,a=Da.length;o<a;o++){let l=Da[o];l.instanceId=r,l.object=this,t.push(l)}Da.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new di(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Dr=class extends yn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Re(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Hd=new R,Vd=new R,Gd=new ke,kl=new ui,Na=new xn,Ws=class extends bt{constructor(e=new At,t=new Dr){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)Hd.fromBufferAttribute(t,s-1),Vd.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=Hd.distanceTo(Vd);e.setAttribute("lineDistance",new st(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Na.copy(n.boundingSphere),Na.applyMatrix4(s),Na.radius+=r,e.ray.intersectsSphere(Na)===!1)return;Gd.copy(s).invert(),kl.copy(e.ray).applyMatrix4(Gd);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=new R,h=new R,u=new R,d=new R,p=this.isLineSegments?2:1,g=n.index,_=n.attributes.position;if(g!==null){let m=Math.max(0,o.start),y=Math.min(g.count,o.start+o.count);for(let x=m,b=y-1;x<b;x+=p){let E=g.getX(x),w=g.getX(x+1);if(c.fromBufferAttribute(_,E),h.fromBufferAttribute(_,w),kl.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let D=e.ray.origin.distanceTo(d);D<e.near||D>e.far||t.push({distance:D,point:u.clone().applyMatrix4(this.matrixWorld),index:x,face:null,faceIndex:null,object:this})}}else{let m=Math.max(0,o.start),y=Math.min(_.count,o.start+o.count);for(let x=m,b=y-1;x<b;x+=p){if(c.fromBufferAttribute(_,x),h.fromBufferAttribute(_,x+1),kl.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let w=e.ray.origin.distanceTo(d);w<e.near||w>e.far||t.push({distance:w,point:u.clone().applyMatrix4(this.matrixWorld),index:x,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}},Wd=new R,Xd=new R,so=class extends Ws{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)Wd.fromBufferAttribute(t,s),Xd.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Wd.distanceTo(Xd);e.setAttribute("lineDistance",new st(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},ro=class extends Ws{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}},Nr=class extends yn{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Re(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},qd=new ke,pc=new ui,Ua=new xn,Oa=new R,ao=class extends bt{constructor(e=new At,t=new Nr){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ua.copy(n.boundingSphere),Ua.applyMatrix4(s),Ua.radius+=r,e.ray.intersectsSphere(Ua)===!1)return;qd.copy(s).invert(),pc.copy(e.ray).applyMatrix4(qd);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,o.start),p=Math.min(c.count,o.start+o.count);for(let g=d,f=p;g<f;g++){let _=c.getX(g);Oa.fromBufferAttribute(u,_),Yd(Oa,_,l,s,e,t,this)}}else{let d=Math.max(0,o.start),p=Math.min(u.count,o.start+o.count);for(let g=d,f=p;g<f;g++)Oa.fromBufferAttribute(u,g),Yd(Oa,g,l,s,e,t,this)}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Yd(i,e,t,n,s,r,o){let a=pc.distanceSqToPoint(i);if(a<t){let l=new R;pc.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,object:o})}}var Ur=class extends jt{constructor(e,t,n,s,r,o,a,l,c){super(e,t,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Tn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){let n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],n,s=this.getPoint(0),r=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),r+=n.distanceTo(s),t.push(r),s=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){let n=this.getLengths(),s=0,r=n.length,o;t?o=t:o=e*n[r-1];let a=0,l=r-1,c;for(;a<=l;)if(s=Math.floor(a+(l-a)/2),c=n[s]-o,c<0)a=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,n[s]===o)return s/(r-1);let h=n[s],d=n[s+1]-h,p=(o-h)/d;return(s+p)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);let o=this.getPoint(s),a=this.getPoint(r),l=t||(o.isVector2?new he:new R);return l.copy(a).sub(o).normalize(),l}getTangentAt(e,t){let n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t){let n=new R,s=[],r=[],o=[],a=new R,l=new ke;for(let p=0;p<=e;p++){let g=p/e;s[p]=this.getTangentAt(g,new R)}r[0]=new R,o[0]=new R;let c=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let p=1;p<=e;p++){if(r[p]=r[p-1].clone(),o[p]=o[p-1].clone(),a.crossVectors(s[p-1],s[p]),a.length()>Number.EPSILON){a.normalize();let g=Math.acos(Ct(s[p-1].dot(s[p]),-1,1));r[p].applyMatrix4(l.makeRotationAxis(a,g))}o[p].crossVectors(s[p],r[p])}if(t===!0){let p=Math.acos(Ct(r[0].dot(r[e]),-1,1));p/=e,s[0].dot(a.crossVectors(r[0],r[e]))>0&&(p=-p);for(let g=1;g<=e;g++)r[g].applyMatrix4(l.makeRotationAxis(s[g],p*g)),o[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},Or=class extends Tn{constructor(e=0,t=0,n=1,s=1,r=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(e,t){let n=t||new he,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);let a=this.aStartAngle+e*r,l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,p=c-this.aY;l=d*h-p*u+this.aX,c=d*u+p*h+this.aY}return n.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},mc=class extends Or{constructor(e,t,n,s,r,o){super(e,t,n,n,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}};function Yc(){let i=0,e=0,t=0,n=0;function s(r,o,a,l){i=r,e=a,t=-3*r+3*o-2*a-l,n=2*r-2*o+a+l}return{initCatmullRom:function(r,o,a,l,c){s(o,a,c*(a-r),c*(l-o))},initNonuniformCatmullRom:function(r,o,a,l,c,h,u){let d=(o-r)/c-(a-r)/(c+h)+(a-o)/h,p=(a-o)/h-(l-o)/(h+u)+(l-a)/u;d*=h,p*=h,s(o,a,d,p)},calc:function(r){let o=r*r,a=o*r;return i+e*r+t*o+n*a}}}var Fa=new R,zl=new Yc,Hl=new Yc,Vl=new Yc,gc=class extends Tn{constructor(e=[],t=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=s}getPoint(e,t=new R){let n=t,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e,a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:l===0&&a===r-1&&(a=r-2,l=1);let c,h;this.closed||a>0?c=s[(a-1)%r]:(Fa.subVectors(s[0],s[1]).add(s[0]),c=Fa);let u=s[a%r],d=s[(a+1)%r];if(this.closed||a+2<r?h=s[(a+2)%r]:(Fa.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Fa),this.curveType==="centripetal"||this.curveType==="chordal"){let p=this.curveType==="chordal"?.5:.25,g=Math.pow(c.distanceToSquared(u),p),f=Math.pow(u.distanceToSquared(d),p),_=Math.pow(d.distanceToSquared(h),p);f<1e-4&&(f=1),g<1e-4&&(g=f),_<1e-4&&(_=f),zl.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,f,_),Hl.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,f,_),Vl.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,f,_)}else this.curveType==="catmullrom"&&(zl.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),Hl.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),Vl.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(zl.calc(l),Hl.calc(l),Vl.calc(l)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(new R().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function Kd(i,e,t,n,s){let r=(n-e)*.5,o=(s-t)*.5,a=i*i,l=i*a;return(2*t-2*n+r+o)*l+(-3*t+3*n-2*r-o)*a+r*i+t}function sv(i,e){let t=1-i;return t*t*e}function rv(i,e){return 2*(1-i)*i*e}function av(i,e){return i*i*e}function br(i,e,t,n){return sv(i,e)+rv(i,t)+av(i,n)}function ov(i,e){let t=1-i;return t*t*t*e}function lv(i,e){let t=1-i;return 3*t*t*i*e}function cv(i,e){return 3*(1-i)*i*i*e}function hv(i,e){return i*i*i*e}function Mr(i,e,t,n,s){return ov(i,e)+lv(i,t)+cv(i,n)+hv(i,s)}var oo=class extends Tn{constructor(e=new he,t=new he,n=new he,s=new he){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new he){let n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(Mr(e,s.x,r.x,o.x,a.x),Mr(e,s.y,r.y,o.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},_c=class extends Tn{constructor(e=new R,t=new R,n=new R,s=new R){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new R){let n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(Mr(e,s.x,r.x,o.x,a.x),Mr(e,s.y,r.y,o.y,a.y),Mr(e,s.z,r.z,o.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},lo=class extends Tn{constructor(e=new he,t=new he){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new he){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new he){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},xc=class extends Tn{constructor(e=new R,t=new R){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new R){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new R){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},co=class extends Tn{constructor(e=new he,t=new he,n=new he){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new he){let n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(br(e,s.x,r.x,o.x),br(e,s.y,r.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},yc=class extends Tn{constructor(e=new R,t=new R,n=new R){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new R){let n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(br(e,s.x,r.x,o.x),br(e,s.y,r.y,o.y),br(e,s.z,r.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},ho=class extends Tn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new he){let n=t,s=this.points,r=(s.length-1)*e,o=Math.floor(r),a=r-o,l=s[o===0?o:o-1],c=s[o],h=s[o>s.length-2?s.length-1:o+1],u=s[o>s.length-3?s.length-1:o+2];return n.set(Kd(a,l.x,c.x,h.x,u.x),Kd(a,l.y,c.y,h.y,u.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(s.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(new he().fromArray(s))}return this}},jd=Object.freeze({__proto__:null,ArcCurve:mc,CatmullRomCurve3:gc,CubicBezierCurve:oo,CubicBezierCurve3:_c,EllipseCurve:Or,LineCurve:lo,LineCurve3:xc,QuadraticBezierCurve:co,QuadraticBezierCurve3:yc,SplineCurve:ho}),vc=class extends Tn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new jd[n](t,e))}return this}getPoint(e,t){let n=e*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=n){let o=s[r]-n,a=this.curves[r],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,t)}r++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let n=0,s=this.curves.length;n<s;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],n;for(let s=0,r=this.curves;s<r.length;s++){let o=r[s],a=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,l=o.getPoints(a);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(t.push(h),n=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){let s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let s=e.curves[t];this.curves.push(new jd[s.type]().fromJSON(s))}return this}},bc=class extends vc{constructor(e){super(),this.type="Path",this.currentPoint=new he,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let n=new lo(this.currentPoint.clone(),new he(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,s){let r=new co(this.currentPoint.clone(),new he(e,t),new he(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(e,t,n,s,r,o){let a=new oo(this.currentPoint.clone(),new he(e,t),new he(n,s),new he(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),n=new ho(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,s,r,o){let a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+a,t+l,n,s,r,o),this}absarc(e,t,n,s,r,o){return this.absellipse(e,t,n,n,s,r,o),this}ellipse(e,t,n,s,r,o,a,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,n,s,r,o,a,l),this}absellipse(e,t,n,s,r,o,a,l){let c=new Or(e,t,n,s,r,o,a,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Mc=class i extends At{constructor(e=[new he(0,-.5),new he(.5,0),new he(0,.5)],t=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:s},t=Math.floor(t),s=Ct(s,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/t,u=new R,d=new he,p=new R,g=new R,f=new R,_=0,m=0;for(let y=0;y<=e.length-1;y++)switch(y){case 0:_=e[y+1].x-e[y].x,m=e[y+1].y-e[y].y,p.x=m*1,p.y=-_,p.z=m*0,f.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case e.length-1:l.push(f.x,f.y,f.z);break;default:_=e[y+1].x-e[y].x,m=e[y+1].y-e[y].y,p.x=m*1,p.y=-_,p.z=m*0,g.copy(p),p.x+=f.x,p.y+=f.y,p.z+=f.z,p.normalize(),l.push(p.x,p.y,p.z),f.copy(g)}for(let y=0;y<=t;y++){let x=n+y*h*s,b=Math.sin(x),E=Math.cos(x);for(let w=0;w<=e.length-1;w++){u.x=e[w].x*b,u.y=e[w].y,u.z=e[w].x*E,o.push(u.x,u.y,u.z),d.x=y/t,d.y=w/(e.length-1),a.push(d.x,d.y);let T=l[3*w+0]*b,D=l[3*w+1],v=l[3*w+0]*E;c.push(T,D,v)}}for(let y=0;y<t;y++)for(let x=0;x<e.length-1;x++){let b=x+y*e.length,E=b,w=b+e.length,T=b+e.length+1,D=b+1;r.push(E,w,D),r.push(T,D,w)}this.setIndex(r),this.setAttribute("position",new st(o,3)),this.setAttribute("uv",new st(a,2)),this.setAttribute("normal",new st(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.points,e.segments,e.phiStart,e.phiLength)}},Xs=class i extends Mc{constructor(e=1,t=1,n=4,s=8){let r=new bc;r.absarc(0,-t/2,e,Math.PI*1.5,0),r.absarc(0,t/2,e,0,Math.PI*.5),super(r.getPoints(n),s),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:n,radialSegments:s}}static fromJSON(e){return new i(e.radius,e.length,e.capSegments,e.radialSegments)}};var Lt=class i extends At{constructor(e=1,t=1,n=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],d=[],p=[],g=0,f=[],_=n/2,m=0;y(),o===!1&&(e>0&&x(!0),t>0&&x(!1)),this.setIndex(h),this.setAttribute("position",new st(u,3)),this.setAttribute("normal",new st(d,3)),this.setAttribute("uv",new st(p,2));function y(){let b=new R,E=new R,w=0,T=(t-e)/n;for(let D=0;D<=r;D++){let v=[],S=D/r,N=S*(t-e)+e;for(let O=0;O<=s;O++){let j=O/s,L=j*l+a,U=Math.sin(L),V=Math.cos(L);E.x=N*U,E.y=-S*n+_,E.z=N*V,u.push(E.x,E.y,E.z),b.set(U,T,V).normalize(),d.push(b.x,b.y,b.z),p.push(j,1-S),v.push(g++)}f.push(v)}for(let D=0;D<s;D++)for(let v=0;v<r;v++){let S=f[v][D],N=f[v+1][D],O=f[v+1][D+1],j=f[v][D+1];h.push(S,N,j),h.push(N,O,j),w+=6}c.addGroup(m,w,0),m+=w}function x(b){let E=g,w=new he,T=new R,D=0,v=b===!0?e:t,S=b===!0?1:-1;for(let O=1;O<=s;O++)u.push(0,_*S,0),d.push(0,S,0),p.push(.5,.5),g++;let N=g;for(let O=0;O<=s;O++){let L=O/s*l+a,U=Math.cos(L),V=Math.sin(L);T.x=v*V,T.y=_*S,T.z=v*U,u.push(T.x,T.y,T.z),d.push(0,S,0),w.x=U*.5+.5,w.y=V*.5*S+.5,p.push(w.x,w.y),g++}for(let O=0;O<s;O++){let j=E+O,L=N+O;b===!0?h.push(L,L+1,j):h.push(L+1,L,j),D+=3}c.addGroup(m,D,b===!0?1:2),m+=D}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},qs=class i extends Lt{constructor(e=1,t=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,e,t,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(e){return new i(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}};var uo=class i extends At{constructor(e=.5,t=1,n=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:o},n=Math.max(3,n),s=Math.max(1,s);let a=[],l=[],c=[],h=[],u=e,d=(t-e)/s,p=new R,g=new he;for(let f=0;f<=s;f++){for(let _=0;_<=n;_++){let m=r+_/n*o;p.x=u*Math.cos(m),p.y=u*Math.sin(m),l.push(p.x,p.y,p.z),c.push(0,0,1),g.x=(p.x/t+1)/2,g.y=(p.y/t+1)/2,h.push(g.x,g.y)}u+=d}for(let f=0;f<s;f++){let _=f*(n+1);for(let m=0;m<n;m++){let y=m+_,x=y,b=y+n+1,E=y+n+2,w=y+1;a.push(x,b,w),a.push(b,E,w)}}this.setIndex(a),this.setAttribute("position",new st(l,3)),this.setAttribute("normal",new st(c,3)),this.setAttribute("uv",new st(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}};var zn=class i extends At{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],u=new R,d=new R,p=[],g=[],f=[],_=[];for(let m=0;m<=n;m++){let y=[],x=m/n,b=0;m===0&&o===0?b=.5/t:m===n&&l===Math.PI&&(b=-.5/t);for(let E=0;E<=t;E++){let w=E/t;u.x=-e*Math.cos(s+w*r)*Math.sin(o+x*a),u.y=e*Math.cos(o+x*a),u.z=e*Math.sin(s+w*r)*Math.sin(o+x*a),g.push(u.x,u.y,u.z),d.copy(u).normalize(),f.push(d.x,d.y,d.z),_.push(w+b,1-x),y.push(c++)}h.push(y)}for(let m=0;m<n;m++)for(let y=0;y<t;y++){let x=h[m][y+1],b=h[m][y],E=h[m+1][y],w=h[m+1][y+1];(m!==0||o>0)&&p.push(x,b,w),(m!==n-1||l<Math.PI)&&p.push(b,E,w)}this.setIndex(p),this.setAttribute("position",new st(g,3)),this.setAttribute("normal",new st(f,3)),this.setAttribute("uv",new st(_,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}};var Fr=class i extends At{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);let o=[],a=[],l=[],c=[],h=new R,u=new R,d=new R;for(let p=0;p<=n;p++)for(let g=0;g<=s;g++){let f=g/s*r,_=p/n*Math.PI*2;u.x=(e+t*Math.cos(_))*Math.cos(f),u.y=(e+t*Math.cos(_))*Math.sin(f),u.z=t*Math.sin(_),a.push(u.x,u.y,u.z),h.x=e*Math.cos(f),h.y=e*Math.sin(f),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/s),c.push(p/n)}for(let p=1;p<=n;p++)for(let g=1;g<=s;g++){let f=(s+1)*p+g-1,_=(s+1)*(p-1)+g-1,m=(s+1)*(p-1)+g,y=(s+1)*p+g;o.push(f,_,y),o.push(_,m,y)}this.setIndex(o),this.setAttribute("position",new st(a,3)),this.setAttribute("normal",new st(l,3)),this.setAttribute("uv",new st(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}};var $e=class extends yn{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Re(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Re(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=mf,this.normalScale=new he(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},An=class extends $e{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new he(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Ct(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Re(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Re(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Re(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}};function Ba(i,e,t){return!i||!t&&i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function uv(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function dv(i){function e(s,r){return i[s]-i[r]}let t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function $d(i,e,t){let n=i.length,s=new i.constructor(n);for(let r=0,o=0;o!==n;++r){let a=t[r]*e;for(let l=0;l!==e;++l)s[o++]=i[a+l]}return s}function Tf(i,e,t,n){let s=1,r=i[0];for(;r!==void 0&&r[n]===void 0;)r=i[s++];if(r===void 0)return;let o=r[n];if(o!==void 0)if(Array.isArray(o))do o=r[n],o!==void 0&&(e.push(r.time),t.push.apply(t,o)),r=i[s++];while(r!==void 0);else if(o.toArray!==void 0)do o=r[n],o!==void 0&&(e.push(r.time),o.toArray(t,t.length)),r=i[s++];while(r!==void 0);else do o=r[n],o!==void 0&&(e.push(r.time),t.push(o)),r=i[s++];while(r!==void 0)}var Ii=class{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,s=t[n],r=t[n-1];e:{t:{let o;n:{i:if(!(e<s)){for(let a=n+2;;){if(s===void 0){if(e<r)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=t[++n],e<s)break t}o=t.length;break n}if(!(e>=r)){let a=t[1];e<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=t[--n-1],e>=r)break t}o=n,n=0;break n}break e}for(;n<o;){let a=n+o>>>1;e<t[a]?o=a:n=a+1}if(s=t[n],r=t[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s;for(let o=0;o!==s;++o)t[o]=n[r+o];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},wc=class extends Ii{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:As,endingEnd:As}}intervalChanged_(e,t,n){let s=this.parameterPositions,r=e-2,o=e+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Rs:r=e,a=2*t-n;break;case Ha:r=s.length-2,a=t+s[r]-s[r+1];break;default:r=e,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Rs:o=e,l=2*n-t;break;case Ha:o=1,l=n+s[1]-s[0];break;default:o=e-1,l=t}let c=(n-t)*.5,h=this.valueSize;this._weightPrev=c/(t-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,p=this._weightNext,g=(n-t)/(s-t),f=g*g,_=f*g,m=-d*_+2*d*f-d*g,y=(1+d)*_+(-1.5-2*d)*f+(-.5+d)*g+1,x=(-1-p)*_+(1.5+p)*f+.5*g,b=p*_-p*f;for(let E=0;E!==a;++E)r[E]=m*o[h+E]+y*o[c+E]+x*o[l+E]+b*o[u+E];return r}},fo=class extends Ii{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=(n-t)/(s-t),u=1-h;for(let d=0;d!==a;++d)r[d]=o[c+d]*u+o[l+d]*h;return r}},Sc=class extends Ii{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}},Rn=class{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Ba(t,this.TimeBufferType),this.values=Ba(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Ba(e.times,Array),values:Ba(e.values,Array)};let s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Sc(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new fo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new wc(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Bs:t=this.InterpolantFactoryMethodDiscrete;break;case Qi:t=this.InterpolantFactoryMethodLinear;break;case pl:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Bs;case this.InterpolantFactoryMethodLinear:return Qi;case this.InterpolantFactoryMethodSmooth:return pl}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e}return this}trim(e,t){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<e;)++r;for(;o!==-1&&n[o]>t;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),e=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),e=!1;break}o=l}if(s!==void 0&&uv(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===pl,r=e.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=e[a],h=e[a+1];if(c!==h&&(a!==1||c!==e[0]))if(s)l=!0;else{let u=a*n,d=u-n,p=u+n;for(let g=0;g!==n;++g){let f=t[u+g];if(f!==t[d+g]||f!==t[p+g]){l=!0;break}}}if(l){if(a!==o){e[o]=e[a];let u=a*n,d=o*n;for(let p=0;p!==n;++p)t[d+p]=t[u+p]}++o}}if(r>0){e[o]=e[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)t[l+c]=t[a+c];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,s}};Rn.prototype.TimeBufferType=Float32Array;Rn.prototype.ValueBufferType=Float32Array;Rn.prototype.DefaultInterpolation=Qi;var Di=class extends Rn{};Di.prototype.ValueTypeName="bool";Di.prototype.ValueBufferType=Array;Di.prototype.DefaultInterpolation=Bs;Di.prototype.InterpolantFactoryMethodLinear=void 0;Di.prototype.InterpolantFactoryMethodSmooth=void 0;var po=class extends Rn{};po.prototype.ValueTypeName="color";var fi=class extends Rn{};fi.prototype.ValueTypeName="number";var Ec=class extends Ii{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-t)/(s-t),c=e*a;for(let h=c+a;c!==h;c+=4)ct.slerpFlat(r,0,o,c-a,o,c,l);return r}},jn=class extends Rn{InterpolantFactoryMethodLinear(e){return new Ec(this.times,this.values,this.getValueSize(),e)}};jn.prototype.ValueTypeName="quaternion";jn.prototype.DefaultInterpolation=Qi;jn.prototype.InterpolantFactoryMethodSmooth=void 0;var Ni=class extends Rn{};Ni.prototype.ValueTypeName="string";Ni.prototype.ValueBufferType=Array;Ni.prototype.DefaultInterpolation=Bs;Ni.prototype.InterpolantFactoryMethodLinear=void 0;Ni.prototype.InterpolantFactoryMethodSmooth=void 0;var pi=class extends Rn{};pi.prototype.ValueTypeName="vector";var Ys=class{constructor(e,t=-1,n,s=Gc){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=Fn(),this.duration<0&&this.resetDuration()}static parse(e){let t=[],n=e.tracks,s=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(pv(n[o]).scale(s));let r=new this(e.name,e.duration,t,e.blendMode);return r.uuid=e.uuid,r}static toJSON(e){let t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let r=0,o=n.length;r!==o;++r)t.push(Rn.toJSON(n[r]));return s}static CreateFromMorphTargetSequence(e,t,n,s){let r=t.length,o=[];for(let a=0;a<r;a++){let l=[],c=[];l.push((a+r-1)%r,a,(a+1)%r),c.push(0,1,0);let h=dv(l);l=$d(l,1,h),c=$d(c,1,h),!s&&l[0]===0&&(l.push(r),c.push(c[0])),o.push(new fi(".morphTargetInfluences["+t[a].name+"]",l,c).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let s={},r=/^([\w-]*?)([\d]+)$/;for(let a=0,l=e.length;a<l;a++){let c=e[a],h=c.name.match(r);if(h&&h.length>1){let u=h[1],d=s[u];d||(s[u]=d=[]),d.push(c)}}let o=[];for(let a in s)o.push(this.CreateFromMorphTargetSequence(a,s[a],t,n));return o}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;let n=function(u,d,p,g,f){if(p.length!==0){let _=[],m=[];Tf(p,_,m,g),_.length!==0&&f.push(new u(d,_,m))}},s=[],r=e.name||"default",o=e.fps||30,a=e.blendMode,l=e.length||-1,c=e.hierarchy||[];for(let u=0;u<c.length;u++){let d=c[u].keys;if(!(!d||d.length===0))if(d[0].morphTargets){let p={},g;for(g=0;g<d.length;g++)if(d[g].morphTargets)for(let f=0;f<d[g].morphTargets.length;f++)p[d[g].morphTargets[f]]=-1;for(let f in p){let _=[],m=[];for(let y=0;y!==d[g].morphTargets.length;++y){let x=d[g];_.push(x.time),m.push(x.morphTarget===f?1:0)}s.push(new fi(".morphTargetInfluence["+f+"]",_,m))}l=p.length*o}else{let p=".bones["+t[u].name+"]";n(pi,p+".position",d,"pos",s),n(jn,p+".quaternion",d,"rot",s),n(pi,p+".scale",d,"scl",s)}}return s.length===0?null:new this(r,l,s,a)}resetDuration(){let e=this.tracks,t=0;for(let n=0,s=e.length;n!==s;++n){let r=this.tracks[n];t=Math.max(t,r.times[r.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}};function fv(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return fi;case"vector":case"vector2":case"vector3":case"vector4":return pi;case"color":return po;case"quaternion":return jn;case"bool":case"boolean":return Di;case"string":return Ni}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function pv(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");let e=fv(i.type);if(i.times===void 0){let t=[],n=[];Tf(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}var Ai={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}},Tc=class{constructor(e,t,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let p=c[u],g=c[u+1];if(p.global&&(p.lastIndex=0),p.test(h))return g}return null}}},mv=new Tc,mi=class{constructor(e){this.manager=e!==void 0?e:mv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};mi.DEFAULT_MATERIAL_NAME="__DEFAULT";var ai={},Ac=class extends Error{constructor(e,t){super(e),this.response=t}},Br=class extends mi{constructor(e){super(e)}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=Ai.get(e);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(ai[e]!==void 0){ai[e].push({onLoad:t,onProgress:n,onError:s});return}ai[e]=[],ai[e].push({onLoad:t,onProgress:n,onError:s});let o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),a=this.mimeType,l=this.responseType;fetch(o).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;let h=ai[e],u=c.body.getReader(),d=c.headers.get("Content-Length")||c.headers.get("X-File-Size"),p=d?parseInt(d):0,g=p!==0,f=0,_=new ReadableStream({start(m){y();function y(){u.read().then(({done:x,value:b})=>{if(x)m.close();else{f+=b.byteLength;let E=new ProgressEvent("progress",{lengthComputable:g,loaded:f,total:p});for(let w=0,T=h.length;w<T;w++){let D=h[w];D.onProgress&&D.onProgress(E)}m.enqueue(b),y()}})}}});return new Response(_)}else throw new Ac(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(h=>new DOMParser().parseFromString(h,a));case"json":return c.json();default:if(a===void 0)return c.text();{let u=/charset="?([^;"\s]*)"?/i.exec(a),d=u&&u[1]?u[1].toLowerCase():void 0,p=new TextDecoder(d);return c.arrayBuffer().then(g=>p.decode(g))}}}).then(c=>{Ai.add(e,c);let h=ai[e];delete ai[e];for(let u=0,d=h.length;u<d;u++){let p=h[u];p.onLoad&&p.onLoad(c)}}).catch(c=>{let h=ai[e];if(h===void 0)throw this.manager.itemError(e),c;delete ai[e];for(let u=0,d=h.length;u<d;u++){let p=h[u];p.onError&&p.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}};var Rc=class extends mi{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=Ai.get(e);if(o!==void 0)return r.manager.itemStart(e),setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o;let a=Tr("img");function l(){h(),Ai.add(e,this),t&&t(this),r.manager.itemEnd(e)}function c(u){h(),s&&s(u),r.manager.itemError(e),r.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),r.manager.itemStart(e),a.src=e,a}};var mo=class extends mi{constructor(e){super(e)}load(e,t,n,s){let r=new jt,o=new Rc(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){r.image=a,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}},Ks=class extends bt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Re(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}},kr=class extends Ks{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(bt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Re(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},Gl=new ke,Zd=new R,Jd=new R,zr=class{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new he(512,512),this.map=null,this.mapPass=null,this.matrix=new ke,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Rr,this._frameExtents=new he(1,1),this._viewportCount=1,this._viewports=[new dt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,n=this.matrix;Zd.setFromMatrixPosition(e.matrixWorld),t.position.copy(Zd),Jd.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Jd),t.updateMatrixWorld(),Gl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Gl),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Gl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Cc=class extends zr{constructor(){super(new Ot(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,n=ks*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height,r=e.distance||t.far;(n!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=n,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},go=class extends Ks{constructor(e,t,n=0,s=Math.PI/3,r=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(bt.DEFAULT_UP),this.updateMatrix(),this.target=new bt,this.distance=n,this.angle=s,this.penumbra=r,this.decay=o,this.map=null,this.shadow=new Cc}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},Qd=new ke,mr=new R,Wl=new R,Pc=class extends zr{constructor(){super(new Ot(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new he(4,2),this._viewportCount=6,this._viewports=[new dt(2,1,1,1),new dt(0,1,1,1),new dt(3,1,1,1),new dt(1,1,1,1),new dt(3,0,1,1),new dt(1,0,1,1)],this._cubeDirections=[new R(1,0,0),new R(-1,0,0),new R(0,0,1),new R(0,0,-1),new R(0,1,0),new R(0,-1,0)],this._cubeUps=[new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,0,1),new R(0,0,-1)]}updateMatrices(e,t=0){let n=this.camera,s=this.matrix,r=e.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),mr.setFromMatrixPosition(e.matrixWorld),n.position.copy(mr),Wl.copy(n.position),Wl.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(Wl),n.updateMatrixWorld(),s.makeTranslation(-mr.x,-mr.y,-mr.z),Qd.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Qd)}},Ui=class extends Ks{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new Pc}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},Lc=class extends zr{constructor(){super(new Vs(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},ns=class extends Ks{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(bt.DEFAULT_UP),this.updateMatrix(),this.target=new bt,this.shadow=new Lc}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var Oi=class{static decodeText(e){if(typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,s=e.length;n<s;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){let t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}};var _o=class extends mi{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=Ai.get(e);if(o!==void 0){if(r.manager.itemStart(e),o.then){o.then(c=>{t&&t(c),r.manager.itemEnd(e)}).catch(c=>{s&&s(c)});return}return setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o}let a={};a.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",a.headers=this.requestHeader;let l=fetch(e,a).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign(r.options,{colorSpaceConversion:"none"}))}).then(function(c){return Ai.add(e,c),t&&t(c),r.manager.itemEnd(e),c}).catch(function(c){s&&s(c),Ai.remove(e),r.manager.itemError(e),r.manager.itemEnd(e)});Ai.add(e,l),r.manager.itemStart(e)}};var xo=class{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=ef(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let t=ef();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}};function ef(){return(typeof performance>"u"?Date:performance).now()}var Ic=class{constructor(e,t,n){this.binding=e,this.valueSize=n;let s,r,o;switch(t){case"quaternion":s=this._slerp,r=this._slerpAdditive,o=this._setAdditiveIdentityQuaternion,this.buffer=new Float64Array(n*6),this._workIndex=5;break;case"string":case"bool":s=this._select,r=this._select,o=this._setAdditiveIdentityOther,this.buffer=new Array(n*5);break;default:s=this._lerp,r=this._lerpAdditive,o=this._setAdditiveIdentityNumeric,this.buffer=new Float64Array(n*5)}this._mixBufferRegion=s,this._mixBufferRegionAdditive=r,this._setIdentity=o,this._origIndex=3,this._addIndex=4,this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,this.useCount=0,this.referenceCount=0}accumulate(e,t){let n=this.buffer,s=this.valueSize,r=e*s+s,o=this.cumulativeWeight;if(o===0){for(let a=0;a!==s;++a)n[r+a]=n[a];o=t}else{o+=t;let a=t/o;this._mixBufferRegion(n,r,0,a,s)}this.cumulativeWeight=o}accumulateAdditive(e){let t=this.buffer,n=this.valueSize,s=n*this._addIndex;this.cumulativeWeightAdditive===0&&this._setIdentity(),this._mixBufferRegionAdditive(t,s,0,e,n),this.cumulativeWeightAdditive+=e}apply(e){let t=this.valueSize,n=this.buffer,s=e*t+t,r=this.cumulativeWeight,o=this.cumulativeWeightAdditive,a=this.binding;if(this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,r<1){let l=t*this._origIndex;this._mixBufferRegion(n,s,l,1-r,t)}o>0&&this._mixBufferRegionAdditive(n,s,this._addIndex*t,1,t);for(let l=t,c=t+t;l!==c;++l)if(n[l]!==n[l+t]){a.setValue(n,s);break}}saveOriginalState(){let e=this.binding,t=this.buffer,n=this.valueSize,s=n*this._origIndex;e.getValue(t,s);for(let r=n,o=s;r!==o;++r)t[r]=t[s+r%n];this._setIdentity(),this.cumulativeWeight=0,this.cumulativeWeightAdditive=0}restoreOriginalState(){let e=this.valueSize*3;this.binding.setValue(this.buffer,e)}_setAdditiveIdentityNumeric(){let e=this._addIndex*this.valueSize,t=e+this.valueSize;for(let n=e;n<t;n++)this.buffer[n]=0}_setAdditiveIdentityQuaternion(){this._setAdditiveIdentityNumeric(),this.buffer[this._addIndex*this.valueSize+3]=1}_setAdditiveIdentityOther(){let e=this._origIndex*this.valueSize,t=this._addIndex*this.valueSize;for(let n=0;n<this.valueSize;n++)this.buffer[t+n]=this.buffer[e+n]}_select(e,t,n,s,r){if(s>=.5)for(let o=0;o!==r;++o)e[t+o]=e[n+o]}_slerp(e,t,n,s){ct.slerpFlat(e,t,e,t,e,n,s)}_slerpAdditive(e,t,n,s,r){let o=this._workIndex*r;ct.multiplyQuaternionsFlat(e,o,e,t,e,n),ct.slerpFlat(e,t,e,t,e,o,s)}_lerp(e,t,n,s,r){let o=1-s;for(let a=0;a!==r;++a){let l=t+a;e[l]=e[l]*o+e[n+a]*s}}_lerpAdditive(e,t,n,s,r){for(let o=0;o!==r;++o){let a=t+o;e[a]=e[a]+e[n+o]*s}}},Kc="\\[\\]\\.:\\/",gv=new RegExp("["+Kc+"]","g"),jc="[^"+Kc+"]",_v="[^"+Kc.replace("\\.","")+"]",xv=/((?:WC+[\/:])*)/.source.replace("WC",jc),yv=/(WCOD+)?/.source.replace("WCOD",_v),vv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",jc),bv=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",jc),Mv=new RegExp("^"+xv+yv+vv+bv+"$"),wv=["material","materials","bones","map"],Dc=class{constructor(e,t,n){let s=n||ht.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},ht=class i{constructor(e,t,n){this.path=t,this.parsedPath=n||i.parseTrackName(t),this.node=i.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new i.Composite(e,t,n):new i(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(gv,"")}static parseTrackName(e){let t=Mv.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);wv.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===t||a.uuid===t)return a;let l=n(a.children);if(l)return l}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,n=t.objectName,s=t.propertyName,r=t.propertyIndex;if(e||(e=i.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}let o=e[s];if(o===void 0){let c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};ht.Composite=Dc;ht.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};ht.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};ht.prototype.GetterByBindingType=[ht.prototype._getValue_direct,ht.prototype._getValue_array,ht.prototype._getValue_arrayElement,ht.prototype._getValue_toArray];ht.prototype.SetterByBindingTypeAndVersioning=[[ht.prototype._setValue_direct,ht.prototype._setValue_direct_setNeedsUpdate,ht.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_array,ht.prototype._setValue_array_setNeedsUpdate,ht.prototype._setValue_array_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_arrayElement,ht.prototype._setValue_arrayElement_setNeedsUpdate,ht.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_fromArray,ht.prototype._setValue_fromArray_setNeedsUpdate,ht.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Nc=class{constructor(e,t,n=null,s=t.blendMode){this._mixer=e,this._clip=t,this._localRoot=n,this.blendMode=s;let r=t.tracks,o=r.length,a=new Array(o),l={endingStart:As,endingEnd:As};for(let c=0;c!==o;++c){let h=r[c].createInterpolant(null);a[c]=h,h.settings=l}this._interpolantSettings=l,this._interpolants=a,this._propertyBindings=new Array(o),this._cacheIndex=null,this._byClipCacheIndex=null,this._timeScaleInterpolant=null,this._weightInterpolant=null,this.loop=Vc,this._loopCount=-1,this._startTime=null,this.time=0,this.timeScale=1,this._effectiveTimeScale=1,this.weight=1,this._effectiveWeight=1,this.repetitions=1/0,this.paused=!1,this.enabled=!0,this.clampWhenFinished=!1,this.zeroSlopeAtStart=!0,this.zeroSlopeAtEnd=!0}play(){return this._mixer._activateAction(this),this}stop(){return this._mixer._deactivateAction(this),this.reset()}reset(){return this.paused=!1,this.enabled=!0,this.time=0,this._loopCount=-1,this._startTime=null,this.stopFading().stopWarping()}isRunning(){return this.enabled&&!this.paused&&this.timeScale!==0&&this._startTime===null&&this._mixer._isActiveAction(this)}isScheduled(){return this._mixer._isActiveAction(this)}startAt(e){return this._startTime=e,this}setLoop(e,t){return this.loop=e,this.repetitions=t,this}setEffectiveWeight(e){return this.weight=e,this._effectiveWeight=this.enabled?e:0,this.stopFading()}getEffectiveWeight(){return this._effectiveWeight}fadeIn(e){return this._scheduleFading(e,0,1)}fadeOut(e){return this._scheduleFading(e,1,0)}crossFadeFrom(e,t,n){if(e.fadeOut(t),this.fadeIn(t),n){let s=this._clip.duration,r=e._clip.duration,o=r/s,a=s/r;e.warp(1,o,t),this.warp(a,1,t)}return this}crossFadeTo(e,t,n){return e.crossFadeFrom(this,t,n)}stopFading(){let e=this._weightInterpolant;return e!==null&&(this._weightInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this}setEffectiveTimeScale(e){return this.timeScale=e,this._effectiveTimeScale=this.paused?0:e,this.stopWarping()}getEffectiveTimeScale(){return this._effectiveTimeScale}setDuration(e){return this.timeScale=this._clip.duration/e,this.stopWarping()}syncWith(e){return this.time=e.time,this.timeScale=e.timeScale,this.stopWarping()}halt(e){return this.warp(this._effectiveTimeScale,0,e)}warp(e,t,n){let s=this._mixer,r=s.time,o=this.timeScale,a=this._timeScaleInterpolant;a===null&&(a=s._lendControlInterpolant(),this._timeScaleInterpolant=a);let l=a.parameterPositions,c=a.sampleValues;return l[0]=r,l[1]=r+n,c[0]=e/o,c[1]=t/o,this}stopWarping(){let e=this._timeScaleInterpolant;return e!==null&&(this._timeScaleInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this}getMixer(){return this._mixer}getClip(){return this._clip}getRoot(){return this._localRoot||this._mixer._root}_update(e,t,n,s){if(!this.enabled){this._updateWeight(e);return}let r=this._startTime;if(r!==null){let l=(e-r)*n;l<0||n===0?t=0:(this._startTime=null,t=n*l)}t*=this._updateTimeScale(e);let o=this._updateTime(t),a=this._updateWeight(e);if(a>0){let l=this._interpolants,c=this._propertyBindings;switch(this.blendMode){case Bm:for(let h=0,u=l.length;h!==u;++h)l[h].evaluate(o),c[h].accumulateAdditive(a);break;case Gc:default:for(let h=0,u=l.length;h!==u;++h)l[h].evaluate(o),c[h].accumulate(s,a)}}}_updateWeight(e){let t=0;if(this.enabled){t=this.weight;let n=this._weightInterpolant;if(n!==null){let s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(this.stopFading(),s===0&&(this.enabled=!1))}}return this._effectiveWeight=t,t}_updateTimeScale(e){let t=0;if(!this.paused){t=this.timeScale;let n=this._timeScaleInterpolant;if(n!==null){let s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(this.stopWarping(),t===0?this.paused=!0:this.timeScale=t)}}return this._effectiveTimeScale=t,t}_updateTime(e){let t=this._clip.duration,n=this.loop,s=this.time+e,r=this._loopCount,o=n===Fm;if(e===0)return r===-1?s:o&&(r&1)===1?t-s:s;if(n===Hc){r===-1&&(this._loopCount=0,this._setEndings(!0,!0,!1));e:{if(s>=t)s=t;else if(s<0)s=0;else{this.time=s;break e}this.clampWhenFinished?this.paused=!0:this.enabled=!1,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e<0?-1:1})}}else{if(r===-1&&(e>=0?(r=0,this._setEndings(!0,this.repetitions===0,o)):this._setEndings(this.repetitions===0,!0,o)),s>=t||s<0){let a=Math.floor(s/t);s-=t*a,r+=Math.abs(a);let l=this.repetitions-r;if(l<=0)this.clampWhenFinished?this.paused=!0:this.enabled=!1,s=e>0?t:0,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e>0?1:-1});else{if(l===1){let c=e<0;this._setEndings(c,!c,o)}else this._setEndings(!1,!1,o);this._loopCount=r,this.time=s,this._mixer.dispatchEvent({type:"loop",action:this,loopDelta:a})}}else this.time=s;if(o&&(r&1)===1)return t-s}return s}_setEndings(e,t,n){let s=this._interpolantSettings;n?(s.endingStart=Rs,s.endingEnd=Rs):(e?s.endingStart=this.zeroSlopeAtStart?Rs:As:s.endingStart=Ha,t?s.endingEnd=this.zeroSlopeAtEnd?Rs:As:s.endingEnd=Ha)}_scheduleFading(e,t,n){let s=this._mixer,r=s.time,o=this._weightInterpolant;o===null&&(o=s._lendControlInterpolant(),this._weightInterpolant=o);let a=o.parameterPositions,l=o.sampleValues;return a[0]=r,l[0]=t,a[1]=r+e,l[1]=n,this}},Sv=new Float32Array(1),yo=class extends Bn{constructor(e){super(),this._root=e,this._initMemoryManager(),this._accuIndex=0,this.time=0,this.timeScale=1}_bindAction(e,t){let n=e._localRoot||this._root,s=e._clip.tracks,r=s.length,o=e._propertyBindings,a=e._interpolants,l=n.uuid,c=this._bindingsByRootAndName,h=c[l];h===void 0&&(h={},c[l]=h);for(let u=0;u!==r;++u){let d=s[u],p=d.name,g=h[p];if(g!==void 0)++g.referenceCount,o[u]=g;else{if(g=o[u],g!==void 0){g._cacheIndex===null&&(++g.referenceCount,this._addInactiveBinding(g,l,p));continue}let f=t&&t._propertyBindings[u].binding.parsedPath;g=new Ic(ht.create(n,p,f),d.ValueTypeName,d.getValueSize()),++g.referenceCount,this._addInactiveBinding(g,l,p),o[u]=g}a[u].resultBuffer=g.buffer}}_activateAction(e){if(!this._isActiveAction(e)){if(e._cacheIndex===null){let n=(e._localRoot||this._root).uuid,s=e._clip.uuid,r=this._actionsByClip[s];this._bindAction(e,r&&r.knownActions[0]),this._addInactiveAction(e,s,n)}let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];r.useCount++===0&&(this._lendBinding(r),r.saveOriginalState())}this._lendAction(e)}}_deactivateAction(e){if(this._isActiveAction(e)){let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];--r.useCount===0&&(r.restoreOriginalState(),this._takeBackBinding(r))}this._takeBackAction(e)}}_initMemoryManager(){this._actions=[],this._nActiveActions=0,this._actionsByClip={},this._bindings=[],this._nActiveBindings=0,this._bindingsByRootAndName={},this._controlInterpolants=[],this._nActiveControlInterpolants=0;let e=this;this.stats={actions:{get total(){return e._actions.length},get inUse(){return e._nActiveActions}},bindings:{get total(){return e._bindings.length},get inUse(){return e._nActiveBindings}},controlInterpolants:{get total(){return e._controlInterpolants.length},get inUse(){return e._nActiveControlInterpolants}}}}_isActiveAction(e){let t=e._cacheIndex;return t!==null&&t<this._nActiveActions}_addInactiveAction(e,t,n){let s=this._actions,r=this._actionsByClip,o=r[t];if(o===void 0)o={knownActions:[e],actionByRoot:{}},e._byClipCacheIndex=0,r[t]=o;else{let a=o.knownActions;e._byClipCacheIndex=a.length,a.push(e)}e._cacheIndex=s.length,s.push(e),o.actionByRoot[n]=e}_removeInactiveAction(e){let t=this._actions,n=t[t.length-1],s=e._cacheIndex;n._cacheIndex=s,t[s]=n,t.pop(),e._cacheIndex=null;let r=e._clip.uuid,o=this._actionsByClip,a=o[r],l=a.knownActions,c=l[l.length-1],h=e._byClipCacheIndex;c._byClipCacheIndex=h,l[h]=c,l.pop(),e._byClipCacheIndex=null;let u=a.actionByRoot,d=(e._localRoot||this._root).uuid;delete u[d],l.length===0&&delete o[r],this._removeInactiveBindingsForAction(e)}_removeInactiveBindingsForAction(e){let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];--r.referenceCount===0&&this._removeInactiveBinding(r)}}_lendAction(e){let t=this._actions,n=e._cacheIndex,s=this._nActiveActions++,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_takeBackAction(e){let t=this._actions,n=e._cacheIndex,s=--this._nActiveActions,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_addInactiveBinding(e,t,n){let s=this._bindingsByRootAndName,r=this._bindings,o=s[t];o===void 0&&(o={},s[t]=o),o[n]=e,e._cacheIndex=r.length,r.push(e)}_removeInactiveBinding(e){let t=this._bindings,n=e.binding,s=n.rootNode.uuid,r=n.path,o=this._bindingsByRootAndName,a=o[s],l=t[t.length-1],c=e._cacheIndex;l._cacheIndex=c,t[c]=l,t.pop(),delete a[r],Object.keys(a).length===0&&delete o[s]}_lendBinding(e){let t=this._bindings,n=e._cacheIndex,s=this._nActiveBindings++,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_takeBackBinding(e){let t=this._bindings,n=e._cacheIndex,s=--this._nActiveBindings,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_lendControlInterpolant(){let e=this._controlInterpolants,t=this._nActiveControlInterpolants++,n=e[t];return n===void 0&&(n=new fo(new Float32Array(2),new Float32Array(2),1,Sv),n.__cacheIndex=t,e[t]=n),n}_takeBackControlInterpolant(e){let t=this._controlInterpolants,n=e.__cacheIndex,s=--this._nActiveControlInterpolants,r=t[s];e.__cacheIndex=s,t[s]=e,r.__cacheIndex=n,t[n]=r}clipAction(e,t,n){let s=t||this._root,r=s.uuid,o=typeof e=="string"?Ys.findByName(s,e):e,a=o!==null?o.uuid:e,l=this._actionsByClip[a],c=null;if(n===void 0&&(o!==null?n=o.blendMode:n=Gc),l!==void 0){let u=l.actionByRoot[r];if(u!==void 0&&u.blendMode===n)return u;c=l.knownActions[0],o===null&&(o=c._clip)}if(o===null)return null;let h=new Nc(this,o,t,n);return this._bindAction(h,c),this._addInactiveAction(h,a,r),h}existingAction(e,t){let n=t||this._root,s=n.uuid,r=typeof e=="string"?Ys.findByName(n,e):e,o=r?r.uuid:e,a=this._actionsByClip[o];return a!==void 0&&a.actionByRoot[s]||null}stopAllAction(){let e=this._actions,t=this._nActiveActions;for(let n=t-1;n>=0;--n)e[n].stop();return this}update(e){e*=this.timeScale;let t=this._actions,n=this._nActiveActions,s=this.time+=e,r=Math.sign(e),o=this._accuIndex^=1;for(let c=0;c!==n;++c)t[c]._update(s,e,r,o);let a=this._bindings,l=this._nActiveBindings;for(let c=0;c!==l;++c)a[c].apply(o);return this}setTime(e){this.time=0;for(let t=0;t<this._actions.length;t++)this._actions[t].time=0;return this.update(e)}getRoot(){return this._root}uncacheClip(e){let t=this._actions,n=e.uuid,s=this._actionsByClip,r=s[n];if(r!==void 0){let o=r.knownActions;for(let a=0,l=o.length;a!==l;++a){let c=o[a];this._deactivateAction(c);let h=c._cacheIndex,u=t[t.length-1];c._cacheIndex=null,c._byClipCacheIndex=null,u._cacheIndex=h,t[h]=u,t.pop(),this._removeInactiveBindingsForAction(c)}delete s[n]}}uncacheRoot(e){let t=e.uuid,n=this._actionsByClip;for(let o in n){let a=n[o].actionByRoot,l=a[t];l!==void 0&&(this._deactivateAction(l),this._removeInactiveAction(l))}let s=this._bindingsByRootAndName,r=s[t];if(r!==void 0)for(let o in r){let a=r[o];a.restoreOriginalState(),this._removeInactiveBinding(a)}}uncacheAction(e,t){let n=this.existingAction(e,t);n!==null&&(this._deactivateAction(n),this._removeInactiveAction(n))}};var Hr=class{constructor(e,t,n=0,s=1/0){this.ray=new ui(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new Ar,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,n=[]){return Uc(e,this,n,t),n.sort(tf),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)Uc(e[s],this,n,t);return n.sort(tf),n}};function tf(i,e){return i.distance-e.distance}function Uc(i,e,t,n){if(i.layers.test(e.layers)&&i.raycast(e,t),n===!0){let s=i.children;for(let r=0,o=s.length;r<o;r++)Uc(s[r],e,t,!0)}}var Vr=class{constructor(e=1,t=0,n=0){return this.radius=e,this.phi=t,this.theta=n,this}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(Ct(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Oc}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Oc);function $c(i,e){if(e===ff)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===Gr||e===bo){let t=i.getIndex();if(t===null){let o=[],a=i.getAttribute("position");if(a!==void 0){for(let l=0;l<a.count;l++)o.push(l);i.setIndex(o),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}let n=t.count-2,s=[];if(e===Gr)for(let o=1;o<=n;o++)s.push(t.getX(0)),s.push(t.getX(o)),s.push(t.getX(o+1));else for(let o=0;o<n;o++)o%2===0?(s.push(t.getX(o)),s.push(t.getX(o+1)),s.push(t.getX(o+2))):(s.push(t.getX(o+2)),s.push(t.getX(o+1)),s.push(t.getX(o)));s.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");let r=i.clone();return r.setIndex(s),r.clearGroups(),r}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}var So=class extends mi{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new ih(t)}),this.register(function(t){return new dh(t)}),this.register(function(t){return new fh(t)}),this.register(function(t){return new ph(t)}),this.register(function(t){return new rh(t)}),this.register(function(t){return new ah(t)}),this.register(function(t){return new oh(t)}),this.register(function(t){return new lh(t)}),this.register(function(t){return new nh(t)}),this.register(function(t){return new ch(t)}),this.register(function(t){return new sh(t)}),this.register(function(t){return new uh(t)}),this.register(function(t){return new hh(t)}),this.register(function(t){return new eh(t)}),this.register(function(t){return new mh(t)}),this.register(function(t){return new gh(t)})}load(e,t,n,s){let r=this,o;if(this.resourcePath!=="")o=this.resourcePath;else if(this.path!==""){let c=Oi.extractUrlBase(e);o=Oi.resolveURL(c,this.path)}else o=Oi.extractUrlBase(e);this.manager.itemStart(e);let a=function(c){s?s(c):console.error(c),r.manager.itemError(e),r.manager.itemEnd(e)},l=new Br(this.manager);l.setPath(this.path),l.setResponseType("arraybuffer"),l.setRequestHeader(this.requestHeader),l.setWithCredentials(this.withCredentials),l.load(e,function(c){try{r.parse(c,o,function(h){t(h),r.manager.itemEnd(e)},a)}catch(h){a(h)}},n,a)}setDRACOLoader(e){return this.dracoLoader=e,this}setDDSLoader(){throw new Error('THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".')}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,s){let r,o={},a={},l=new TextDecoder;if(typeof e=="string")r=JSON.parse(e);else if(e instanceof ArrayBuffer)if(l.decode(new Uint8Array(e,0,4))===Lf){try{o[Ze.KHR_BINARY_GLTF]=new _h(e)}catch(u){s&&s(u);return}r=JSON.parse(o[Ze.KHR_BINARY_GLTF].content)}else r=JSON.parse(l.decode(e));else r=e;if(r.asset===void 0||r.asset.version[0]<2){s&&s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let c=new Sh(r,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let h=0;h<this.pluginCallbacks.length;h++){let u=this.pluginCallbacks[h](c);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),a[u.name]=u,o[u.name]=!0}if(r.extensionsUsed)for(let h=0;h<r.extensionsUsed.length;++h){let u=r.extensionsUsed[h],d=r.extensionsRequired||[];switch(u){case Ze.KHR_MATERIALS_UNLIT:o[u]=new th;break;case Ze.KHR_DRACO_MESH_COMPRESSION:o[u]=new xh(r,this.dracoLoader);break;case Ze.KHR_TEXTURE_TRANSFORM:o[u]=new yh;break;case Ze.KHR_MESH_QUANTIZATION:o[u]=new vh;break;default:d.indexOf(u)>=0&&a[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}c.setExtensions(o),c.setPlugins(a),c.parse(n,s)}parseAsync(e,t){let n=this;return new Promise(function(s,r){n.parse(e,t,s,r)})}};function Tv(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}var Ze={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"},eh=class{constructor(e){this.parser=e,this.name=Ze.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,s=t.length;n<s;n++){let r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n="light:"+e,s=t.cache.get(n);if(s)return s;let r=t.json,l=((r.extensions&&r.extensions[this.name]||{}).lights||[])[e],c,h=new Re(16777215);l.color!==void 0&&h.setRGB(l.color[0],l.color[1],l.color[2],Ft);let u=l.range!==void 0?l.range:0;switch(l.type){case"directional":c=new ns(h),c.target.position.set(0,0,-1),c.add(c.target);break;case"point":c=new Ui(h),c.distance=u;break;case"spot":c=new go(h),c.distance=u,l.spot=l.spot||{},l.spot.innerConeAngle=l.spot.innerConeAngle!==void 0?l.spot.innerConeAngle:0,l.spot.outerConeAngle=l.spot.outerConeAngle!==void 0?l.spot.outerConeAngle:Math.PI/4,c.angle=l.spot.outerConeAngle,c.penumbra=1-l.spot.innerConeAngle/l.spot.outerConeAngle,c.target.position.set(0,0,-1),c.add(c.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+l.type)}return c.position.set(0,0,0),c.decay=2,Bi(c,l),l.intensity!==void 0&&(c.intensity=l.intensity),c.name=t.createUniqueName(l.name||"light_"+e),s=Promise.resolve(c),t.cache.add(n,s),s}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,r=n.json.nodes[e],a=(r.extensions&&r.extensions[this.name]||{}).light;return a===void 0?null:this._loadLight(a).then(function(l){return n._getNodeRef(t.cache,a,l)})}},th=class{constructor(){this.name=Ze.KHR_MATERIALS_UNLIT}getMaterialType(){return Kt}extendParams(e,t,n){let s=[];e.color=new Re(1,1,1),e.opacity=1;let r=t.pbrMetallicRoughness;if(r){if(Array.isArray(r.baseColorFactor)){let o=r.baseColorFactor;e.color.setRGB(o[0],o[1],o[2],Ft),e.opacity=o[3]}r.baseColorTexture!==void 0&&s.push(n.assignTexture(e,"map",r.baseColorTexture,ut))}return Promise.all(s)}},nh=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name].emissiveStrength;return r!==void 0&&(t.emissiveIntensity=r),Promise.resolve()}},ih=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];if(o.clearcoatFactor!==void 0&&(t.clearcoat=o.clearcoatFactor),o.clearcoatTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatMap",o.clearcoatTexture)),o.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=o.clearcoatRoughnessFactor),o.clearcoatRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatRoughnessMap",o.clearcoatRoughnessTexture)),o.clearcoatNormalTexture!==void 0&&(r.push(n.assignTexture(t,"clearcoatNormalMap",o.clearcoatNormalTexture)),o.clearcoatNormalTexture.scale!==void 0)){let a=o.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new he(a,a)}return Promise.all(r)}},sh=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.iridescenceFactor!==void 0&&(t.iridescence=o.iridescenceFactor),o.iridescenceTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceMap",o.iridescenceTexture)),o.iridescenceIor!==void 0&&(t.iridescenceIOR=o.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),o.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=o.iridescenceThicknessMinimum),o.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=o.iridescenceThicknessMaximum),o.iridescenceThicknessTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceThicknessMap",o.iridescenceThicknessTexture)),Promise.all(r)}},rh=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_SHEEN}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[];t.sheenColor=new Re(0,0,0),t.sheenRoughness=0,t.sheen=1;let o=s.extensions[this.name];if(o.sheenColorFactor!==void 0){let a=o.sheenColorFactor;t.sheenColor.setRGB(a[0],a[1],a[2],Ft)}return o.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=o.sheenRoughnessFactor),o.sheenColorTexture!==void 0&&r.push(n.assignTexture(t,"sheenColorMap",o.sheenColorTexture,ut)),o.sheenRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"sheenRoughnessMap",o.sheenRoughnessTexture)),Promise.all(r)}},ah=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.transmissionFactor!==void 0&&(t.transmission=o.transmissionFactor),o.transmissionTexture!==void 0&&r.push(n.assignTexture(t,"transmissionMap",o.transmissionTexture)),Promise.all(r)}},oh=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_VOLUME}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];t.thickness=o.thicknessFactor!==void 0?o.thicknessFactor:0,o.thicknessTexture!==void 0&&r.push(n.assignTexture(t,"thicknessMap",o.thicknessTexture)),t.attenuationDistance=o.attenuationDistance||1/0;let a=o.attenuationColor||[1,1,1];return t.attenuationColor=new Re().setRGB(a[0],a[1],a[2],Ft),Promise.all(r)}},lh=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_IOR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name];return t.ior=r.ior!==void 0?r.ior:1.5,Promise.resolve()}},ch=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_SPECULAR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];t.specularIntensity=o.specularFactor!==void 0?o.specularFactor:1,o.specularTexture!==void 0&&r.push(n.assignTexture(t,"specularIntensityMap",o.specularTexture));let a=o.specularColorFactor||[1,1,1];return t.specularColor=new Re().setRGB(a[0],a[1],a[2],Ft),o.specularColorTexture!==void 0&&r.push(n.assignTexture(t,"specularColorMap",o.specularColorTexture,ut)),Promise.all(r)}},hh=class{constructor(e){this.parser=e,this.name=Ze.EXT_MATERIALS_BUMP}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return t.bumpScale=o.bumpFactor!==void 0?o.bumpFactor:1,o.bumpTexture!==void 0&&r.push(n.assignTexture(t,"bumpMap",o.bumpTexture)),Promise.all(r)}},uh=class{constructor(e){this.parser=e,this.name=Ze.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:An}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.anisotropyStrength!==void 0&&(t.anisotropy=o.anisotropyStrength),o.anisotropyRotation!==void 0&&(t.anisotropyRotation=o.anisotropyRotation),o.anisotropyTexture!==void 0&&r.push(n.assignTexture(t,"anisotropyMap",o.anisotropyTexture)),Promise.all(r)}},dh=class{constructor(e){this.parser=e,this.name=Ze.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,s=n.textures[e];if(!s.extensions||!s.extensions[this.name])return null;let r=s.extensions[this.name],o=t.options.ktx2Loader;if(!o){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,r.source,o)}},fh=class{constructor(e){this.parser=e,this.name=Ze.EXT_TEXTURE_WEBP,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],a=s.images[o.source],l=n.textureLoader;if(a.uri){let c=n.options.manager.getHandler(a.uri);c!==null&&(l=c)}return this.detectSupport().then(function(c){if(c)return n.loadTextureImage(e,o.source,l);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},ph=class{constructor(e){this.parser=e,this.name=Ze.EXT_TEXTURE_AVIF,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],a=s.images[o.source],l=n.textureLoader;if(a.uri){let c=n.options.manager.getHandler(a.uri);c!==null&&(l=c)}return this.detectSupport().then(function(c){if(c)return n.loadTextureImage(e,o.source,l);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},mh=class{constructor(e){this.name=Ze.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let s=n.extensions[this.name],r=this.parser.getDependency("buffer",s.buffer),o=this.parser.options.meshoptDecoder;if(!o||!o.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return r.then(function(a){let l=s.byteOffset||0,c=s.byteLength||0,h=s.count,u=s.byteStride,d=new Uint8Array(a,l,c);return o.decodeGltfBufferAsync?o.decodeGltfBufferAsync(h,u,d,s.mode,s.filter).then(function(p){return p.buffer}):o.ready.then(function(){let p=new ArrayBuffer(h*u);return o.decodeGltfBuffer(new Uint8Array(p),h,u,d,s.mode,s.filter),p})})}else return null}},gh=class{constructor(e){this.name=Ze.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;let s=t.meshes[n.mesh];for(let c of s.primitives)if(c.mode!==Pn.TRIANGLES&&c.mode!==Pn.TRIANGLE_STRIP&&c.mode!==Pn.TRIANGLE_FAN&&c.mode!==void 0)return null;let o=n.extensions[this.name].attributes,a=[],l={};for(let c in o)a.push(this.parser.getDependency("accessor",o[c]).then(h=>(l[c]=h,l[c])));return a.length<1?null:(a.push(this.parser.createNodeMesh(e)),Promise.all(a).then(c=>{let h=c.pop(),u=h.isGroup?h.children:[h],d=c[0].count,p=[];for(let g of u){let f=new ke,_=new R,m=new ct,y=new R(1,1,1),x=new Kn(g.geometry,g.material,d);for(let b=0;b<d;b++)l.TRANSLATION&&_.fromBufferAttribute(l.TRANSLATION,b),l.ROTATION&&m.fromBufferAttribute(l.ROTATION,b),l.SCALE&&y.fromBufferAttribute(l.SCALE,b),x.setMatrixAt(b,f.compose(_,m,y));for(let b in l)if(b==="_COLOR_0"){let E=l[b];x.instanceColor=new di(E.array,E.itemSize,E.normalized)}else b!=="TRANSLATION"&&b!=="ROTATION"&&b!=="SCALE"&&g.geometry.setAttribute(b,l[b]);bt.prototype.copy.call(x,g),this.parser.assignFinalMaterial(x),p.push(x)}return h.isGroup?(h.clear(),h.add(...p),h):p[0]}))}},Lf="glTF",Xr=12,Af={JSON:1313821514,BIN:5130562},_h=class{constructor(e){this.name=Ze.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,Xr),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==Lf)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");let s=this.header.length-Xr,r=new DataView(e,Xr),o=0;for(;o<s;){let a=r.getUint32(o,!0);o+=4;let l=r.getUint32(o,!0);if(o+=4,l===Af.JSON){let c=new Uint8Array(e,Xr+o,a);this.content=n.decode(c)}else if(l===Af.BIN){let c=Xr+o;this.body=e.slice(c,c+a)}o+=a}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}},xh=class{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=Ze.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,s=this.dracoLoader,r=e.extensions[this.name].bufferView,o=e.extensions[this.name].attributes,a={},l={},c={};for(let h in o){let u=Mh[h]||h.toLowerCase();a[u]=o[h]}for(let h in e.attributes){let u=Mh[h]||h.toLowerCase();if(o[h]!==void 0){let d=n.accessors[e.attributes[h]],p=$s[d.componentType];c[u]=p.name,l[u]=d.normalized===!0}}return t.getDependency("bufferView",r).then(function(h){return new Promise(function(u,d){s.decodeDracoFile(h,function(p){for(let g in p.attributes){let f=p.attributes[g],_=l[g];_!==void 0&&(f.normalized=_)}u(p)},a,c,Ft,d)})})}},yh=class{constructor(){this.name=Ze.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}},vh=class{constructor(){this.name=Ze.KHR_MESH_QUANTIZATION}},Eo=class extends Ii{constructor(e,t,n,s){super(e,t,n,s)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s*3+s;for(let o=0;o!==s;o++)t[o]=n[r+o];return t}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=a*2,c=a*3,h=s-t,u=(n-t)/h,d=u*u,p=d*u,g=e*c,f=g-c,_=-2*p+3*d,m=p-d,y=1-_,x=m-d+u;for(let b=0;b!==a;b++){let E=o[f+b+a],w=o[f+b+l]*h,T=o[g+b+a],D=o[g+b]*h;r[b]=y*E+x*w+_*T+m*D}return r}},Av=new ct,bh=class extends Eo{interpolate_(e,t,n,s){let r=super.interpolate_(e,t,n,s);return Av.fromArray(r).normalize().toArray(r),r}},Pn={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},$s={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Rf={9728:Ut,9729:cn,9984:za,9985:kc,9986:gr,9987:Li},Cf={33071:_n,33648:Sr,10497:Ji},Zc={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Mh={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},Fi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},Rv={CUBICSPLINE:void 0,LINEAR:Qi,STEP:Bs},Jc={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function Cv(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new $e({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:Yn})),i.DefaultMaterial}function is(i,e,t){for(let n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Bi(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function Pv(i,e,t){let n=!1,s=!1,r=!1;for(let c=0,h=e.length;c<h;c++){let u=e[c];if(u.POSITION!==void 0&&(n=!0),u.NORMAL!==void 0&&(s=!0),u.COLOR_0!==void 0&&(r=!0),n&&s&&r)break}if(!n&&!s&&!r)return Promise.resolve(i);let o=[],a=[],l=[];for(let c=0,h=e.length;c<h;c++){let u=e[c];if(n){let d=u.POSITION!==void 0?t.getDependency("accessor",u.POSITION):i.attributes.position;o.push(d)}if(s){let d=u.NORMAL!==void 0?t.getDependency("accessor",u.NORMAL):i.attributes.normal;a.push(d)}if(r){let d=u.COLOR_0!==void 0?t.getDependency("accessor",u.COLOR_0):i.attributes.color;l.push(d)}}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l)]).then(function(c){let h=c[0],u=c[1],d=c[2];return n&&(i.morphAttributes.position=h),s&&(i.morphAttributes.normal=u),r&&(i.morphAttributes.color=d),i.morphTargetsRelative=!0,i})}function Lv(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){let t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,s=t.length;n<s;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function Iv(i){let e,t=i.extensions&&i.extensions[Ze.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+Qc(t.attributes):e=i.indices+":"+Qc(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,s=i.targets.length;n<s;n++)e+=":"+Qc(i.targets[n]);return e}function Qc(i){let e="",t=Object.keys(i).sort();for(let n=0,s=t.length;n<s;n++)e+=t[n]+":"+i[t[n]]+";";return e}function wh(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function Dv(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":"image/png"}var Nv=new ke,Sh=class{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new Tv,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,s=!1,r=-1;typeof navigator<"u"&&(n=/^((?!chrome|android).)*safari/i.test(navigator.userAgent)===!0,s=navigator.userAgent.indexOf("Firefox")>-1,r=s?navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1]:-1),typeof createImageBitmap>"u"||n||s&&r<98?this.textureLoader=new mo(this.options.manager):this.textureLoader=new _o(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new Br(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,s=this.json,r=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(o){return o._markDefs&&o._markDefs()}),Promise.all(this._invokeAll(function(o){return o.beforeRoot&&o.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(o){let a={scene:o[0][s.scene||0],scenes:o[0],animations:o[1],cameras:o[2],asset:s.asset,parser:n,userData:{}};return is(r,a,s),Bi(a,s),Promise.all(n._invokeAll(function(l){return l.afterRoot&&l.afterRoot(a)})).then(function(){e(a)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let s=0,r=t.length;s<r;s++){let o=t[s].joints;for(let a=0,l=o.length;a<l;a++)e[o[a]].isBone=!0}for(let s=0,r=e.length;s<r;s++){let o=e[s];o.mesh!==void 0&&(this._addNodeRef(this.meshCache,o.mesh),o.skin!==void 0&&(n[o.mesh].isSkinnedMesh=!0)),o.camera!==void 0&&this._addNodeRef(this.cameraCache,o.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let s=n.clone(),r=(o,a)=>{let l=this.associations.get(o);l!=null&&this.associations.set(a,l);for(let[c,h]of o.children.entries())r(h,a.children[c])};return r(n,s),s.name+="_instance_"+e.uses[t]++,s}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let s=e(t[n]);if(s)return s}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let s=0;s<t.length;s++){let r=e(t[s]);r&&n.push(r)}return n}getDependency(e,t){let n=e+":"+t,s=this.cache.get(n);if(!s){switch(e){case"scene":s=this.loadScene(t);break;case"node":s=this._invokeOne(function(r){return r.loadNode&&r.loadNode(t)});break;case"mesh":s=this._invokeOne(function(r){return r.loadMesh&&r.loadMesh(t)});break;case"accessor":s=this.loadAccessor(t);break;case"bufferView":s=this._invokeOne(function(r){return r.loadBufferView&&r.loadBufferView(t)});break;case"buffer":s=this.loadBuffer(t);break;case"material":s=this._invokeOne(function(r){return r.loadMaterial&&r.loadMaterial(t)});break;case"texture":s=this._invokeOne(function(r){return r.loadTexture&&r.loadTexture(t)});break;case"skin":s=this.loadSkin(t);break;case"animation":s=this._invokeOne(function(r){return r.loadAnimation&&r.loadAnimation(t)});break;case"camera":s=this.loadCamera(t);break;default:if(s=this._invokeOne(function(r){return r!=this&&r.getDependency&&r.getDependency(e,t)}),!s)throw new Error("Unknown type: "+e);break}this.cache.add(n,s)}return s}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,s=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(s.map(function(r,o){return n.getDependency(e,o)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Ze.KHR_BINARY_GLTF].body);let s=this.options;return new Promise(function(r,o){n.load(Oi.resolveURL(t.uri,s.path),r,void 0,function(){o(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){let s=t.byteLength||0,r=t.byteOffset||0;return n.slice(r,r+s)})}loadAccessor(e){let t=this,n=this.json,s=this.json.accessors[e];if(s.bufferView===void 0&&s.sparse===void 0){let o=Zc[s.type],a=$s[s.componentType],l=s.normalized===!0,c=new a(s.count*o);return Promise.resolve(new Et(c,o,l))}let r=[];return s.bufferView!==void 0?r.push(this.getDependency("bufferView",s.bufferView)):r.push(null),s.sparse!==void 0&&(r.push(this.getDependency("bufferView",s.sparse.indices.bufferView)),r.push(this.getDependency("bufferView",s.sparse.values.bufferView))),Promise.all(r).then(function(o){let a=o[0],l=Zc[s.type],c=$s[s.componentType],h=c.BYTES_PER_ELEMENT,u=h*l,d=s.byteOffset||0,p=s.bufferView!==void 0?n.bufferViews[s.bufferView].byteStride:void 0,g=s.normalized===!0,f,_;if(p&&p!==u){let m=Math.floor(d/p),y="InterleavedBuffer:"+s.bufferView+":"+s.componentType+":"+m+":"+s.count,x=t.cache.get(y);x||(f=new c(a,m*p,s.count*p/h),x=new Pr(f,p/h),t.cache.add(y,x)),_=new Lr(x,l,d%p/h,g)}else a===null?f=new c(s.count*l):f=new c(a,d,s.count*l),_=new Et(f,l,g);if(s.sparse!==void 0){let m=Zc.SCALAR,y=$s[s.sparse.indices.componentType],x=s.sparse.indices.byteOffset||0,b=s.sparse.values.byteOffset||0,E=new y(o[1],x,s.sparse.count*m),w=new c(o[2],b,s.sparse.count*l);a!==null&&(_=new Et(_.array.slice(),_.itemSize,_.normalized));for(let T=0,D=E.length;T<D;T++){let v=E[T];if(_.setX(v,w[T*l]),l>=2&&_.setY(v,w[T*l+1]),l>=3&&_.setZ(v,w[T*l+2]),l>=4&&_.setW(v,w[T*l+3]),l>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}}return _})}loadTexture(e){let t=this.json,n=this.options,r=t.textures[e].source,o=t.images[r],a=this.textureLoader;if(o.uri){let l=n.manager.getHandler(o.uri);l!==null&&(a=l)}return this.loadTextureImage(e,r,a)}loadTextureImage(e,t,n){let s=this,r=this.json,o=r.textures[e],a=r.images[t],l=(a.uri||a.bufferView)+":"+o.sampler;if(this.textureCache[l])return this.textureCache[l];let c=this.loadImageSource(t,n).then(function(h){h.flipY=!1,h.name=o.name||a.name||"",h.name===""&&typeof a.uri=="string"&&a.uri.startsWith("data:image/")===!1&&(h.name=a.uri);let d=(r.samplers||{})[o.sampler]||{};return h.magFilter=Rf[d.magFilter]||cn,h.minFilter=Rf[d.minFilter]||Li,h.wrapS=Cf[d.wrapS]||Ji,h.wrapT=Cf[d.wrapT]||Ji,s.associations.set(h,{textures:e}),h}).catch(function(){return null});return this.textureCache[l]=c,c}loadImageSource(e,t){let n=this,s=this.json,r=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(u=>u.clone());let o=s.images[e],a=self.URL||self.webkitURL,l=o.uri||"",c=!1;if(o.bufferView!==void 0)l=n.getDependency("bufferView",o.bufferView).then(function(u){c=!0;let d=new Blob([u],{type:o.mimeType});return l=a.createObjectURL(d),l});else if(o.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");let h=Promise.resolve(l).then(function(u){return new Promise(function(d,p){let g=d;t.isImageBitmapLoader===!0&&(g=function(f){let _=new jt(f);_.needsUpdate=!0,d(_)}),t.load(Oi.resolveURL(u,r.path),g,void 0,p)})}).then(function(u){return c===!0&&a.revokeObjectURL(l),u.userData.mimeType=o.mimeType||Dv(o.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",l),u});return this.sourceCache[e]=h,h}assignTexture(e,t,n,s){let r=this;return this.getDependency("texture",n.index).then(function(o){if(!o)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(o=o.clone(),o.channel=n.texCoord),r.extensions[Ze.KHR_TEXTURE_TRANSFORM]){let a=n.extensions!==void 0?n.extensions[Ze.KHR_TEXTURE_TRANSFORM]:void 0;if(a){let l=r.associations.get(o);o=r.extensions[Ze.KHR_TEXTURE_TRANSFORM].extendTexture(o,a),r.associations.set(o,l)}}return s!==void 0&&(o.colorSpace=s),e[t]=o,o})}assignFinalMaterial(e){let t=e.geometry,n=e.material,s=t.attributes.tangent===void 0,r=t.attributes.color!==void 0,o=t.attributes.normal===void 0;if(e.isPoints){let a="PointsMaterial:"+n.uuid,l=this.cache.get(a);l||(l=new Nr,yn.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,l.sizeAttenuation=!1,this.cache.add(a,l)),n=l}else if(e.isLine){let a="LineBasicMaterial:"+n.uuid,l=this.cache.get(a);l||(l=new Dr,yn.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,this.cache.add(a,l)),n=l}if(s||r||o){let a="ClonedMaterial:"+n.uuid+":";s&&(a+="derivative-tangents:"),r&&(a+="vertex-colors:"),o&&(a+="flat-shading:");let l=this.cache.get(a);l||(l=n.clone(),r&&(l.vertexColors=!0),o&&(l.flatShading=!0),s&&(l.normalScale&&(l.normalScale.y*=-1),l.clearcoatNormalScale&&(l.clearcoatNormalScale.y*=-1)),this.cache.add(a,l),this.associations.set(l,this.associations.get(n))),n=l}e.material=n}getMaterialType(){return $e}loadMaterial(e){let t=this,n=this.json,s=this.extensions,r=n.materials[e],o,a={},l=r.extensions||{},c=[];if(l[Ze.KHR_MATERIALS_UNLIT]){let u=s[Ze.KHR_MATERIALS_UNLIT];o=u.getMaterialType(),c.push(u.extendParams(a,r,t))}else{let u=r.pbrMetallicRoughness||{};if(a.color=new Re(1,1,1),a.opacity=1,Array.isArray(u.baseColorFactor)){let d=u.baseColorFactor;a.color.setRGB(d[0],d[1],d[2],Ft),a.opacity=d[3]}u.baseColorTexture!==void 0&&c.push(t.assignTexture(a,"map",u.baseColorTexture,ut)),a.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,a.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(a,"metalnessMap",u.metallicRoughnessTexture)),c.push(t.assignTexture(a,"roughnessMap",u.metallicRoughnessTexture))),o=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(e,a)})))}r.doubleSided===!0&&(a.side=yt);let h=r.alphaMode||Jc.OPAQUE;if(h===Jc.BLEND?(a.transparent=!0,a.depthWrite=!1):(a.transparent=!1,h===Jc.MASK&&(a.alphaTest=r.alphaCutoff!==void 0?r.alphaCutoff:.5)),r.normalTexture!==void 0&&o!==Kt&&(c.push(t.assignTexture(a,"normalMap",r.normalTexture)),a.normalScale=new he(1,1),r.normalTexture.scale!==void 0)){let u=r.normalTexture.scale;a.normalScale.set(u,u)}if(r.occlusionTexture!==void 0&&o!==Kt&&(c.push(t.assignTexture(a,"aoMap",r.occlusionTexture)),r.occlusionTexture.strength!==void 0&&(a.aoMapIntensity=r.occlusionTexture.strength)),r.emissiveFactor!==void 0&&o!==Kt){let u=r.emissiveFactor;a.emissive=new Re().setRGB(u[0],u[1],u[2],Ft)}return r.emissiveTexture!==void 0&&o!==Kt&&c.push(t.assignTexture(a,"emissiveMap",r.emissiveTexture,ut)),Promise.all(c).then(function(){let u=new o(a);return r.name&&(u.name=r.name),Bi(u,r),t.associations.set(u,{materials:e}),r.extensions&&is(s,u,r),u})}createUniqueName(e){let t=ht.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,n=this.extensions,s=this.primitiveCache;function r(a){return n[Ze.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a,t).then(function(l){return Pf(l,a,t)})}let o=[];for(let a=0,l=e.length;a<l;a++){let c=e[a],h=Iv(c),u=s[h];if(u)o.push(u.promise);else{let d;c.extensions&&c.extensions[Ze.KHR_DRACO_MESH_COMPRESSION]?d=r(c):d=Pf(new At,c,t),s[h]={primitive:c,promise:d},o.push(d)}}return Promise.all(o)}loadMesh(e){let t=this,n=this.json,s=this.extensions,r=n.meshes[e],o=r.primitives,a=[];for(let l=0,c=o.length;l<c;l++){let h=o[l].material===void 0?Cv(this.cache):this.getDependency("material",o[l].material);a.push(h)}return a.push(t.loadGeometries(o)),Promise.all(a).then(function(l){let c=l.slice(0,l.length-1),h=l[l.length-1],u=[];for(let p=0,g=h.length;p<g;p++){let f=h[p],_=o[p],m,y=c[p];if(_.mode===Pn.TRIANGLES||_.mode===Pn.TRIANGLE_STRIP||_.mode===Pn.TRIANGLE_FAN||_.mode===void 0)m=r.isSkinnedMesh===!0?new no(f,y):new Oe(f,y),m.isSkinnedMesh===!0&&m.normalizeSkinWeights(),_.mode===Pn.TRIANGLE_STRIP?m.geometry=$c(m.geometry,bo):_.mode===Pn.TRIANGLE_FAN&&(m.geometry=$c(m.geometry,Gr));else if(_.mode===Pn.LINES)m=new so(f,y);else if(_.mode===Pn.LINE_STRIP)m=new Ws(f,y);else if(_.mode===Pn.LINE_LOOP)m=new ro(f,y);else if(_.mode===Pn.POINTS)m=new ao(f,y);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+_.mode);Object.keys(m.geometry.morphAttributes).length>0&&Lv(m,r),m.name=t.createUniqueName(r.name||"mesh_"+e),Bi(m,r),_.extensions&&is(s,m,_),t.assignFinalMaterial(m),u.push(m)}for(let p=0,g=u.length;p<g;p++)t.associations.set(u[p],{meshes:e,primitives:p});if(u.length===1)return r.extensions&&is(s,u[0],r),u[0];let d=new St;r.extensions&&is(s,d,r),t.associations.set(d,{meshes:e});for(let p=0,g=u.length;p<g;p++)d.add(u[p]);return d})}loadCamera(e){let t,n=this.json.cameras[e],s=n[n.type];if(!s){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Ot(It.radToDeg(s.yfov),s.aspectRatio||1,s.znear||1,s.zfar||2e6):n.type==="orthographic"&&(t=new Vs(-s.xmag,s.xmag,s.ymag,-s.ymag,s.znear,s.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Bi(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let s=0,r=t.joints.length;s<r;s++)n.push(this._loadNodeShallow(t.joints[s]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(s){let r=s.pop(),o=s,a=[],l=[];for(let c=0,h=o.length;c<h;c++){let u=o[c];if(u){a.push(u);let d=new ke;r!==null&&d.fromArray(r.array,c*16),l.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[c])}return new io(a,l)})}loadAnimation(e){let t=this.json,n=this,s=t.animations[e],r=s.name?s.name:"animation_"+e,o=[],a=[],l=[],c=[],h=[];for(let u=0,d=s.channels.length;u<d;u++){let p=s.channels[u],g=s.samplers[p.sampler],f=p.target,_=f.node,m=s.parameters!==void 0?s.parameters[g.input]:g.input,y=s.parameters!==void 0?s.parameters[g.output]:g.output;f.node!==void 0&&(o.push(this.getDependency("node",_)),a.push(this.getDependency("accessor",m)),l.push(this.getDependency("accessor",y)),c.push(g),h.push(f))}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l),Promise.all(c),Promise.all(h)]).then(function(u){let d=u[0],p=u[1],g=u[2],f=u[3],_=u[4],m=[];for(let y=0,x=d.length;y<x;y++){let b=d[y],E=p[y],w=g[y],T=f[y],D=_[y];if(b===void 0)continue;b.updateMatrix&&b.updateMatrix();let v=n._createAnimationTracks(b,E,w,T,D);if(v)for(let S=0;S<v.length;S++)m.push(v[S])}return new Ys(r,void 0,m)})}createNodeMesh(e){let t=this.json,n=this,s=t.nodes[e];return s.mesh===void 0?null:n.getDependency("mesh",s.mesh).then(function(r){let o=n._getNodeRef(n.meshCache,s.mesh,r);return s.weights!==void 0&&o.traverse(function(a){if(a.isMesh)for(let l=0,c=s.weights.length;l<c;l++)a.morphTargetInfluences[l]=s.weights[l]}),o})}loadNode(e){let t=this.json,n=this,s=t.nodes[e],r=n._loadNodeShallow(e),o=[],a=s.children||[];for(let c=0,h=a.length;c<h;c++)o.push(n.getDependency("node",a[c]));let l=s.skin===void 0?Promise.resolve(null):n.getDependency("skin",s.skin);return Promise.all([r,Promise.all(o),l]).then(function(c){let h=c[0],u=c[1],d=c[2];d!==null&&h.traverse(function(p){p.isSkinnedMesh&&p.bind(d,Nv)});for(let p=0,g=u.length;p<g;p++)h.add(u[p]);return h})}_loadNodeShallow(e){let t=this.json,n=this.extensions,s=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let r=t.nodes[e],o=r.name?s.createUniqueName(r.name):"",a=[],l=s._invokeOne(function(c){return c.createNodeMesh&&c.createNodeMesh(e)});return l&&a.push(l),r.camera!==void 0&&a.push(s.getDependency("camera",r.camera).then(function(c){return s._getNodeRef(s.cameraCache,r.camera,c)})),s._invokeAll(function(c){return c.createNodeAttachment&&c.createNodeAttachment(e)}).forEach(function(c){a.push(c)}),this.nodeCache[e]=Promise.all(a).then(function(c){let h;if(r.isBone===!0?h=new Ir:c.length>1?h=new St:c.length===1?h=c[0]:h=new bt,h!==c[0])for(let u=0,d=c.length;u<d;u++)h.add(c[u]);if(r.name&&(h.userData.name=r.name,h.name=o),Bi(h,r),r.extensions&&is(n,h,r),r.matrix!==void 0){let u=new ke;u.fromArray(r.matrix),h.applyMatrix4(u)}else r.translation!==void 0&&h.position.fromArray(r.translation),r.rotation!==void 0&&h.quaternion.fromArray(r.rotation),r.scale!==void 0&&h.scale.fromArray(r.scale);return s.associations.has(h)||s.associations.set(h,{}),s.associations.get(h).nodes=e,h}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],s=this,r=new St;n.name&&(r.name=s.createUniqueName(n.name)),Bi(r,n),n.extensions&&is(t,r,n);let o=n.nodes||[],a=[];for(let l=0,c=o.length;l<c;l++)a.push(s.getDependency("node",o[l]));return Promise.all(a).then(function(l){for(let h=0,u=l.length;h<u;h++)r.add(l[h]);let c=h=>{let u=new Map;for(let[d,p]of s.associations)(d instanceof yn||d instanceof jt)&&u.set(d,p);return h.traverse(d=>{let p=s.associations.get(d);p!=null&&u.set(d,p)}),u};return s.associations=c(r),r})}_createAnimationTracks(e,t,n,s,r){let o=[],a=e.name?e.name:e.uuid,l=[];Fi[r.path]===Fi.weights?e.traverse(function(d){d.morphTargetInfluences&&l.push(d.name?d.name:d.uuid)}):l.push(a);let c;switch(Fi[r.path]){case Fi.weights:c=fi;break;case Fi.rotation:c=jn;break;case Fi.position:case Fi.scale:c=pi;break;default:switch(n.itemSize){case 1:c=fi;break;case 2:case 3:default:c=pi;break}break}let h=s.interpolation!==void 0?Rv[s.interpolation]:Qi,u=this._getArrayFromAccessor(n);for(let d=0,p=l.length;d<p;d++){let g=new c(l[d]+"."+Fi[r.path],t.array,u,h);s.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),o.push(g)}return o}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let n=wh(t.constructor),s=new Float32Array(t.length);for(let r=0,o=t.length;r<o;r++)s[r]=t[r]*n;t=s}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){let s=this instanceof jn?bh:Eo;return new s(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}};function Uv(i,e,t){let n=e.attributes,s=new En;if(n.POSITION!==void 0){let a=t.json.accessors[n.POSITION],l=a.min,c=a.max;if(l!==void 0&&c!==void 0){if(s.set(new R(l[0],l[1],l[2]),new R(c[0],c[1],c[2])),a.normalized){let h=wh($s[a.componentType]);s.min.multiplyScalar(h),s.max.multiplyScalar(h)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;let r=e.targets;if(r!==void 0){let a=new R,l=new R;for(let c=0,h=r.length;c<h;c++){let u=r[c];if(u.POSITION!==void 0){let d=t.json.accessors[u.POSITION],p=d.min,g=d.max;if(p!==void 0&&g!==void 0){if(l.setX(Math.max(Math.abs(p[0]),Math.abs(g[0]))),l.setY(Math.max(Math.abs(p[1]),Math.abs(g[1]))),l.setZ(Math.max(Math.abs(p[2]),Math.abs(g[2]))),d.normalized){let f=wh($s[d.componentType]);l.multiplyScalar(f)}a.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(a)}i.boundingBox=s;let o=new xn;s.getCenter(o.center),o.radius=s.min.distanceTo(s.max)/2,i.boundingSphere=o}function Pf(i,e,t){let n=e.attributes,s=[];function r(o,a){return t.getDependency("accessor",o).then(function(l){i.setAttribute(a,l)})}for(let o in n){let a=Mh[o]||o.toLowerCase();a in i.attributes||s.push(r(n[o],a))}if(e.indices!==void 0&&!i.index){let o=t.getDependency("accessor",e.indices).then(function(a){i.setIndex(a)});s.push(o)}return ot.workingColorSpace!==Ft&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${ot.workingColorSpace}" not supported.`),Bi(i,e),Uv(i,e,t),Promise.all(s).then(function(){return e.targets!==void 0?Pv(i,e.targets,t):i})}var If={type:"change"},Eh={type:"start"},Df={type:"end"},To=new ui,Nf=new On,Ov=Math.cos(70*It.DEG2RAD),Ao=class extends Bn{constructor(e,t){super(),this.object=e,this.domElement=t,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new R,this.cursor=new R,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:un.ROTATE,MIDDLE:un.DOLLY,RIGHT:un.PAN},this.touches={ONE:Cn.ROTATE,TWO:Cn.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return a.phi},this.getAzimuthalAngle=function(){return a.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(P){P.addEventListener("keydown",ne),this._domElementKeyEvents=P},this.stopListenToKeyEvents=function(){this._domElementKeyEvents.removeEventListener("keydown",ne),this._domElementKeyEvents=null},this.saveState=function(){n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=function(){n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(If),n.update(),r=s.NONE},this.update=function(){let P=new R,J=new ct().setFromUnitVectors(e.up,new R(0,1,0)),ue=J.clone().invert(),ae=new R,Se=new ct,Ye=new R,et=2*Math.PI;return function(ce=null){let I=n.object.position;P.copy(I).sub(n.target),P.applyQuaternion(J),a.setFromVector3(P),n.autoRotate&&r===s.NONE&&N(v(ce)),n.enableDamping?(a.theta+=l.theta*n.dampingFactor,a.phi+=l.phi*n.dampingFactor):(a.theta+=l.theta,a.phi+=l.phi);let oe=n.minAzimuthAngle,le=n.maxAzimuthAngle;isFinite(oe)&&isFinite(le)&&(oe<-Math.PI?oe+=et:oe>Math.PI&&(oe-=et),le<-Math.PI?le+=et:le>Math.PI&&(le-=et),oe<=le?a.theta=Math.max(oe,Math.min(le,a.theta)):a.theta=a.theta>(oe+le)/2?Math.max(oe,a.theta):Math.min(le,a.theta)),a.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,a.phi)),a.makeSafe(),n.enableDamping===!0?n.target.addScaledVector(h,n.dampingFactor):n.target.add(h),n.target.sub(n.cursor),n.target.clampLength(n.minTargetRadius,n.maxTargetRadius),n.target.add(n.cursor),n.zoomToCursor&&w||n.object.isOrthographicCamera?a.radius=q(a.radius):a.radius=q(a.radius*c),P.setFromSpherical(a),P.applyQuaternion(ue),I.copy(n.target).add(P),n.object.lookAt(n.target),n.enableDamping===!0?(l.theta*=1-n.dampingFactor,l.phi*=1-n.dampingFactor,h.multiplyScalar(1-n.dampingFactor)):(l.set(0,0,0),h.set(0,0,0));let Pe=!1;if(n.zoomToCursor&&w){let Te=null;if(n.object.isPerspectiveCamera){let it=P.length();Te=q(it*c);let at=it-Te;n.object.position.addScaledVector(b,at),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let it=new R(E.x,E.y,0);it.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Pe=!0;let at=new R(E.x,E.y,0);at.unproject(n.object),n.object.position.sub(at).add(it),n.object.updateMatrixWorld(),Te=P.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),n.zoomToCursor=!1;Te!==null&&(this.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(Te).add(n.object.position):(To.origin.copy(n.object.position),To.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(To.direction))<Ov?e.lookAt(n.target):(Nf.setFromNormalAndCoplanarPoint(n.object.up,n.target),To.intersectPlane(Nf,n.target))))}else n.object.isOrthographicCamera&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/c)),n.object.updateProjectionMatrix(),Pe=!0);return c=1,w=!1,Pe||ae.distanceToSquared(n.object.position)>o||8*(1-Se.dot(n.object.quaternion))>o||Ye.distanceToSquared(n.target)>0?(n.dispatchEvent(If),ae.copy(n.object.position),Se.copy(n.object.quaternion),Ye.copy(n.target),!0):!1}}(),this.dispose=function(){n.domElement.removeEventListener("contextmenu",ye),n.domElement.removeEventListener("pointerdown",ze),n.domElement.removeEventListener("pointercancel",M),n.domElement.removeEventListener("wheel",te),n.domElement.removeEventListener("pointermove",C),n.domElement.removeEventListener("pointerup",M),n._domElementKeyEvents!==null&&(n._domElementKeyEvents.removeEventListener("keydown",ne),n._domElementKeyEvents=null)};let n=this,s={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},r=s.NONE,o=1e-6,a=new Vr,l=new Vr,c=1,h=new R,u=new he,d=new he,p=new he,g=new he,f=new he,_=new he,m=new he,y=new he,x=new he,b=new R,E=new he,w=!1,T=[],D={};function v(P){return P!==null?2*Math.PI/60*n.autoRotateSpeed*P:2*Math.PI/60/60*n.autoRotateSpeed}function S(P){let J=Math.abs(P)/(100*(window.devicePixelRatio|0));return Math.pow(.95,n.zoomSpeed*J)}function N(P){l.theta-=P}function O(P){l.phi-=P}let j=function(){let P=new R;return function(ue,ae){P.setFromMatrixColumn(ae,0),P.multiplyScalar(-ue),h.add(P)}}(),L=function(){let P=new R;return function(ue,ae){n.screenSpacePanning===!0?P.setFromMatrixColumn(ae,1):(P.setFromMatrixColumn(ae,0),P.crossVectors(n.object.up,P)),P.multiplyScalar(ue),h.add(P)}}(),U=function(){let P=new R;return function(ue,ae){let Se=n.domElement;if(n.object.isPerspectiveCamera){let Ye=n.object.position;P.copy(Ye).sub(n.target);let et=P.length();et*=Math.tan(n.object.fov/2*Math.PI/180),j(2*ue*et/Se.clientHeight,n.object.matrix),L(2*ae*et/Se.clientHeight,n.object.matrix)}else n.object.isOrthographicCamera?(j(ue*(n.object.right-n.object.left)/n.object.zoom/Se.clientWidth,n.object.matrix),L(ae*(n.object.top-n.object.bottom)/n.object.zoom/Se.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}}();function V(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c/=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function K(P){n.object.isPerspectiveCamera||n.object.isOrthographicCamera?c*=P:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function Y(P,J){if(!n.zoomToCursor)return;w=!0;let ue=n.domElement.getBoundingClientRect(),ae=P-ue.left,Se=J-ue.top,Ye=ue.width,et=ue.height;E.x=ae/Ye*2-1,E.y=-(Se/et)*2+1,b.set(E.x,E.y,1).unproject(n.object).sub(n.object.position).normalize()}function q(P){return Math.max(n.minDistance,Math.min(n.maxDistance,P))}function $(P){u.set(P.clientX,P.clientY)}function ie(P){Y(P.clientX,P.clientX),m.set(P.clientX,P.clientY)}function pe(P){g.set(P.clientX,P.clientY)}function X(P){d.set(P.clientX,P.clientY),p.subVectors(d,u).multiplyScalar(n.rotateSpeed);let J=n.domElement;N(2*Math.PI*p.x/J.clientHeight),O(2*Math.PI*p.y/J.clientHeight),u.copy(d),n.update()}function Q(P){y.set(P.clientX,P.clientY),x.subVectors(y,m),x.y>0?V(S(x.y)):x.y<0&&K(S(x.y)),m.copy(y),n.update()}function ge(P){f.set(P.clientX,P.clientY),_.subVectors(f,g).multiplyScalar(n.panSpeed),U(_.x,_.y),g.copy(f),n.update()}function Ee(P){Y(P.clientX,P.clientY),P.deltaY<0?K(S(P.deltaY)):P.deltaY>0&&V(S(P.deltaY)),n.update()}function we(P){let J=!1;switch(P.code){case n.keys.UP:P.ctrlKey||P.metaKey||P.shiftKey?O(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(0,n.keyPanSpeed),J=!0;break;case n.keys.BOTTOM:P.ctrlKey||P.metaKey||P.shiftKey?O(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(0,-n.keyPanSpeed),J=!0;break;case n.keys.LEFT:P.ctrlKey||P.metaKey||P.shiftKey?N(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(n.keyPanSpeed,0),J=!0;break;case n.keys.RIGHT:P.ctrlKey||P.metaKey||P.shiftKey?N(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):U(-n.keyPanSpeed,0),J=!0;break}J&&(P.preventDefault(),n.update())}function Fe(P){if(T.length===1)u.set(P.pageX,P.pageY);else{let J=Qe(P),ue=.5*(P.pageX+J.x),ae=.5*(P.pageY+J.y);u.set(ue,ae)}}function Be(P){if(T.length===1)g.set(P.pageX,P.pageY);else{let J=Qe(P),ue=.5*(P.pageX+J.x),ae=.5*(P.pageY+J.y);g.set(ue,ae)}}function Le(P){let J=Qe(P),ue=P.pageX-J.x,ae=P.pageY-J.y,Se=Math.sqrt(ue*ue+ae*ae);m.set(0,Se)}function Je(P){n.enableZoom&&Le(P),n.enablePan&&Be(P)}function B(P){n.enableZoom&&Le(P),n.enableRotate&&Fe(P)}function Gt(P){if(T.length==1)d.set(P.pageX,P.pageY);else{let ue=Qe(P),ae=.5*(P.pageX+ue.x),Se=.5*(P.pageY+ue.y);d.set(ae,Se)}p.subVectors(d,u).multiplyScalar(n.rotateSpeed);let J=n.domElement;N(2*Math.PI*p.x/J.clientHeight),O(2*Math.PI*p.y/J.clientHeight),u.copy(d)}function Ce(P){if(T.length===1)f.set(P.pageX,P.pageY);else{let J=Qe(P),ue=.5*(P.pageX+J.x),ae=.5*(P.pageY+J.y);f.set(ue,ae)}_.subVectors(f,g).multiplyScalar(n.panSpeed),U(_.x,_.y),g.copy(f)}function Ne(P){let J=Qe(P),ue=P.pageX-J.x,ae=P.pageY-J.y,Se=Math.sqrt(ue*ue+ae*ae);y.set(0,Se),x.set(0,Math.pow(y.y/m.y,n.zoomSpeed)),V(x.y),m.copy(y);let Ye=(P.pageX+J.x)*.5,et=(P.pageY+J.y)*.5;Y(Ye,et)}function be(P){n.enableZoom&&Ne(P),n.enablePan&&Ce(P)}function gt(P){n.enableZoom&&Ne(P),n.enableRotate&&Gt(P)}function ze(P){n.enabled!==!1&&(T.length===0&&(n.domElement.setPointerCapture(P.pointerId),n.domElement.addEventListener("pointermove",C),n.domElement.addEventListener("pointerup",M)),Ie(P),P.pointerType==="touch"?Me(P):k(P))}function C(P){n.enabled!==!1&&(P.pointerType==="touch"?fe(P):se(P))}function M(P){Ve(P),T.length===0&&(n.domElement.releasePointerCapture(P.pointerId),n.domElement.removeEventListener("pointermove",C),n.domElement.removeEventListener("pointerup",M)),n.dispatchEvent(Df),r=s.NONE}function k(P){let J;switch(P.button){case 0:J=n.mouseButtons.LEFT;break;case 1:J=n.mouseButtons.MIDDLE;break;case 2:J=n.mouseButtons.RIGHT;break;default:J=-1}switch(J){case un.DOLLY:if(n.enableZoom===!1)return;ie(P),r=s.DOLLY;break;case un.ROTATE:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enablePan===!1)return;pe(P),r=s.PAN}else{if(n.enableRotate===!1)return;$(P),r=s.ROTATE}break;case un.PAN:if(P.ctrlKey||P.metaKey||P.shiftKey){if(n.enableRotate===!1)return;$(P),r=s.ROTATE}else{if(n.enablePan===!1)return;pe(P),r=s.PAN}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Eh)}function se(P){switch(r){case s.ROTATE:if(n.enableRotate===!1)return;X(P);break;case s.DOLLY:if(n.enableZoom===!1)return;Q(P);break;case s.PAN:if(n.enablePan===!1)return;ge(P);break}}function te(P){n.enabled===!1||n.enableZoom===!1||r!==s.NONE||(P.preventDefault(),n.dispatchEvent(Eh),Ee(P),n.dispatchEvent(Df))}function ne(P){n.enabled===!1||n.enablePan===!1||we(P)}function Me(P){switch(ee(P),T.length){case 1:switch(n.touches.ONE){case Cn.ROTATE:if(n.enableRotate===!1)return;Fe(P),r=s.TOUCH_ROTATE;break;case Cn.PAN:if(n.enablePan===!1)return;Be(P),r=s.TOUCH_PAN;break;default:r=s.NONE}break;case 2:switch(n.touches.TWO){case Cn.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Je(P),r=s.TOUCH_DOLLY_PAN;break;case Cn.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;B(P),r=s.TOUCH_DOLLY_ROTATE;break;default:r=s.NONE}break;default:r=s.NONE}r!==s.NONE&&n.dispatchEvent(Eh)}function fe(P){switch(ee(P),r){case s.TOUCH_ROTATE:if(n.enableRotate===!1)return;Gt(P),n.update();break;case s.TOUCH_PAN:if(n.enablePan===!1)return;Ce(P),n.update();break;case s.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;be(P),n.update();break;case s.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;gt(P),n.update();break;default:r=s.NONE}}function ye(P){n.enabled!==!1&&P.preventDefault()}function Ie(P){T.push(P.pointerId)}function Ve(P){delete D[P.pointerId];for(let J=0;J<T.length;J++)if(T[J]==P.pointerId){T.splice(J,1);return}}function ee(P){let J=D[P.pointerId];J===void 0&&(J=new he,D[P.pointerId]=J),J.set(P.pageX,P.pageY)}function Qe(P){let J=P.pointerId===T[0]?T[1]:T[0];return D[J]}n.domElement.addEventListener("contextmenu",ye),n.domElement.addEventListener("pointerdown",ze),n.domElement.addEventListener("pointercancel",M),n.domElement.addEventListener("wheel",te,{passive:!1}),this.update()}};var Ro=class extends ts{constructor(e=null){super();let t=new Pt;t.deleteAttribute("uv");let n=new $e({side:Yt}),s=new $e,r=5;e!==null&&e._useLegacyLights===!1&&(r=900);let o=new Ui(16777215,r,28,2);o.position.set(.418,16.199,.3),this.add(o);let a=new Oe(t,n);a.position.set(-.757,13.219,.717),a.scale.set(31.713,28.305,28.591),this.add(a);let l=new Oe(t,s);l.position.set(-10.906,2.009,1.846),l.rotation.set(0,-.195,0),l.scale.set(2.328,7.905,4.651),this.add(l);let c=new Oe(t,s);c.position.set(-5.607,-.754,-.758),c.rotation.set(0,.994,0),c.scale.set(1.97,1.534,3.955),this.add(c);let h=new Oe(t,s);h.position.set(6.167,.857,7.803),h.rotation.set(0,.561,0),h.scale.set(3.927,6.285,3.687),this.add(h);let u=new Oe(t,s);u.position.set(-2.017,.018,6.124),u.rotation.set(0,.333,0),u.scale.set(2.002,4.566,2.064),this.add(u);let d=new Oe(t,s);d.position.set(2.291,-.756,-2.621),d.rotation.set(0,-.286,0),d.scale.set(1.546,1.552,1.496),this.add(d);let p=new Oe(t,s);p.position.set(-2.193,-.369,-5.547),p.rotation.set(0,.516,0),p.scale.set(3.875,3.487,2.986),this.add(p);let g=new Oe(t,Zs(50));g.position.set(-16.116,14.37,8.208),g.scale.set(.1,2.428,2.739),this.add(g);let f=new Oe(t,Zs(50));f.position.set(-16.109,18.021,-8.207),f.scale.set(.1,2.425,2.751),this.add(f);let _=new Oe(t,Zs(17));_.position.set(14.904,12.198,-1.832),_.scale.set(.15,4.265,6.331),this.add(_);let m=new Oe(t,Zs(43));m.position.set(-.462,8.89,14.52),m.scale.set(4.38,5.441,.088),this.add(m);let y=new Oe(t,Zs(20));y.position.set(3.235,11.486,-12.541),y.scale.set(2.5,2,.1),this.add(y);let x=new Oe(t,Zs(100));x.position.set(0,20,0),x.scale.set(1,.1,1),this.add(x)}dispose(){let e=new Set;this.traverse(t=>{t.isMesh&&(e.add(t.geometry),e.add(t.material))});for(let t of e)t.dispose()}};function Zs(i){let e=new Kt;return e.color.setScalar(i),e}var jr={oldcity:{dir:"",mr:"\u0936\u0928\u093F\u0935\u093E\u0930 \u0935\u093E\u0921\u093E",en:"Shaniwar Wada and old Pune",coord:"18.5195\xB0 N, 73.8553\xB0 E",blurb:"Shaniwar Wada, Lal Mahal, Kasba and Dagdusheth Ganpati, Tulshibaug, Laxmi Road, the Mandai, the wadas, Omkareshwar"},deccan:{dir:"deccan/",mr:"\u0921\u0947\u0915\u094D\u0915\u0928, \u092B\u0930\u094D\u0917\u094D\u092F\u0941\u0938\u0928 \u0935 \u091C\u0902\u0917\u0932\u0940 \u092E\u0939\u093E\u0930\u093E\u091C \u0930\u0938\u094D\u0924\u093E",en:"Deccan, FC Road and JM Road",coord:"18.5200\xB0 N, 73.8463\xB0 E",blurb:"Fergusson College\u2019s Main Building and gate, the shops of FC Road and JM Road, Pataleshwar cave temple, Balgandharva Rangmandir, Sambhaji Udyan metro, the river and Lakdi Pul",start:"pataleshwar",parts:[{file:"wada_ground.glb.txt",mb:1.6},{file:"wada_city.glb.txt",mb:2},{file:"wada_grounds.glb.txt",mb:.3},{file:"wada_life.glb.txt",mb:1.4},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.8,metro:!0},{file:"wada_market.glb.txt",mb:.2},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:2.2}],views:[{id:"pataleshwar",cam:"Cam_Pataleshwar",label:"Pataleshwar caves"},{id:"pataleshwar-above",cam:"Cam_PataleshwarAbove",label:"Pataleshwar from above"},{id:"fergusson",cam:"Cam_Fergusson",label:"Fergusson College"},{id:"fcroad",cam:"Cam_FCRoad",label:"FC Road"},{id:"jmroad",cam:"Cam_JMRoad",label:"JM Road"},{id:"balgandharva",cam:"Cam_Balgandharva",label:"Balgandharva Rangmandir"},{id:"metro",cam:"Cam_Metro",label:"Sambhaji Udyan metro"},{id:"lakdipul",cam:"Cam_LakdiPul",label:"Lakdi Pul"},{id:"omkareshwar",cam:"Cam_Omkareshwar",label:"Omkareshwar Mandir"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Pataleshwar caves",mr:"\u092A\u093E\u0924\u093E\u0933\u0947\u0936\u094D\u0935\u0930 \u0932\u0947\u0923\u0940",en:"Pataleshwar cave temple",bearing:200,r:55,h:30,note:"An 8th-century cave temple to Shiva, cut out of the basalt rock, with a round Nandi pavilion in its sunken courtyard."},{land:"Fergusson College",mr:"\u092B\u0930\u094D\u0917\u094D\u092F\u0941\u0938\u0928 \u092E\u0939\u093E\u0935\u093F\u0926\u094D\u092F\u093E\u0932\u092F",en:"Fergusson College",bearing:20,r:75,h:34,note:"Founded in 1885 by the Deccan Education Society of Tilak and Agarkar: its Main Building of grey basalt has timber galleries, a gabled front with a rose window and a corner tower."},{land:"FC Road",mr:"\u092B\u0930\u094D\u0917\u094D\u092F\u0941\u0938\u0928 \u0930\u0938\u094D\u0924\u093E",en:"Fergusson College Road",bearing:100,r:70,h:35,note:"FC Road, the college road: street shopping, caf\xE9s and students from the Deccan Gymkhana corner up past the college gate."},{land:"JM Road",mr:"\u091C\u0902\u0917\u0932\u0940 \u092E\u0939\u093E\u0930\u093E\u091C \u0930\u0938\u094D\u0924\u093E",en:"Jangli Maharaj Road",bearing:120,r:70,h:35,note:"The shopping street of Deccan, named after the saint whose temple stands beside the caves."},{land:"Balgandharva Rangmandir",mr:"\u092C\u093E\u0932\u0917\u0902\u0927\u0930\u094D\u0935 \u0930\u0902\u0917\u092E\u0902\u0926\u093F\u0930",en:"Balgandharva Rangmandir",bearing:330,r:70,h:32,note:"The city\u2019s best-known theatre, named after the singer-actor Bal Gandharva."},{land:"Omkareshwar Mandir",mr:"\u0913\u0902\u0915\u093E\u0930\u0947\u0936\u094D\u0935\u0930 \u092E\u0902\u0926\u093F\u0930",en:"Omkareshwar Mandir",bearing:120,r:75,h:38,note:"The Peshwa-era Shiva temple on the far bank of the Mutha, with its painted shikhara and ghats."}],landView:{"Pataleshwar caves":"pataleshwar","JM Road":"jmroad","Balgandharva Rangmandir":"balgandharva","Fergusson College":"fergusson","FC Road":"fcroad","Omkareshwar Mandir":"omkareshwar","Chhatrapati Sambhaji Udyan metro":"metro"}},south:{dir:"south/",mr:"\u092A\u0930\u094D\u0935\u0924\u0940, \u0938\u093E\u0930\u0938\u092C\u093E\u0917 \u0935 \u0938\u094D\u0935\u093E\u0930\u0917\u0947\u091F",en:"Parvati, Sarasbaug and Swargate",coord:"18.4992\xB0 N, 73.8520\xB0 E",blurb:"Parvati Hill with its stairway and temples, Sarasbaug\u2019s temple on its island, Swargate\u2019s bus stands and metro hub",start:"parvati-hill",parts:[{file:"wada_ground.glb.txt",mb:1.5},{file:"wada_city.glb.txt",mb:.4},{file:"wada_grounds.glb.txt",mb:.2},{file:"wada_life.glb.txt",mb:1.2},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.1,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.6}],views:[{id:"parvati-hill",cam:"Cam_ParvatiHill",label:"Parvati Hill"},{id:"parvati-stairs",cam:"Cam_ParvatiStairs",label:"Parvati stairway"},{id:"parvati",cam:"Cam_Parvati",label:"Parvati temples"},{id:"sarasbaug",cam:"Cam_Sarasbaug",label:"Sarasbaug temple"},{id:"sarasbaug-gate",cam:"Cam_SarasbaugGate",label:"Sarasbaug island"},{id:"swargate",cam:"Cam_Swargate",label:"Swargate hub"},{id:"ststand",cam:"Cam_STStand",label:"ST stand"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Parvati",mr:"\u092A\u0930\u094D\u0935\u0924\u0940",en:"Parvati Hill",bearing:60,r:140,h:95,note:"The Peshwas\u2019 hilltop temples above the city, reached by a long stone stairway. The Devdeveshwar temple dates from 1749."},{land:"Sarasbaug",mr:"\u0938\u093E\u0930\u0938\u092C\u093E\u0917",en:"Sarasbaug",bearing:30,r:60,h:30,note:"A garden laid out by the Peshwas round a lake; the temple of Shri Siddhivinayak stands on its island."},{land:"Swargate",mr:"\u0938\u094D\u0935\u093E\u0930\u0917\u0947\u091F",en:"Swargate",bearing:200,r:90,h:45,note:"Pune\u2019s great bus hub: State Transport buses to the whole state, city buses, and the metro\u2019s new terminus."}],landView:{Parvati:"parvati",Sarasbaug:"sarasbaug",Swargate:"swargate"}},coep:{dir:"coep/",mr:"\u0936\u093F\u0935\u093E\u091C\u0940\u0928\u0917\u0930, \u0938\u0940\u0913\u0908\u092A\u0940 \u0935 \u0938\u0902\u0917\u092E",en:"COEP, Sangam and Shivajinagar",coord:"18.5300\xB0 N, 73.8555\xB0 E",blurb:"COEP\u2019s Gothic main building and boat club, the old Sangam bridge at the confluence, the creeper-clad District Court, Shivajinagar station with its suburban trains",start:"coep",parts:[{file:"wada_ground.glb.txt",mb:1.3},{file:"wada_city.glb.txt",mb:.9},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:1.7},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1.5,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.9},{file:"wada_railway.glb.txt",mb:1.5}],views:[{id:"coep",cam:"Cam_COEP",label:"COEP main building"},{id:"court",cam:"Cam_DistrictCourt",label:"District Court"},{id:"sangam",cam:"Cam_SangamBridge",label:"Sangam Bridge"},{id:"railbridge",cam:"Cam_RailBridge",label:"Railway bridge"},{id:"boatclub",cam:"Cam_BoatClub",label:"COEP Boat Club"},{id:"station",cam:"Cam_RailPlatform",label:"Shivajinagar station"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"COEP main building",mr:"\u0938\u0940\u0913\u0908\u092A\u0940 \u092E\u0941\u0916\u094D\u092F \u0907\u092E\u093E\u0930\u0924",en:"COEP main building",bearing:60,r:75,h:38,note:"The College of Engineering, Pune, founded in 1854. Its Victorian Gothic main building is of grey basalt, with a tower in the corner between its wings."},{land:"Sangam Bridge",mr:"\u0938\u0902\u0917\u092E \u092A\u0942\u0932",en:"Sangam Bridge",bearing:200,r:115,h:32,note:"The old stone bridge near the confluence (sangam) of the Mula and the Mutha. The railway\u2019s girder bridge runs beside it."},{land:"District Court",mr:"\u091C\u093F\u0932\u094D\u0939\u093E \u0935 \u0938\u0924\u094D\u0930 \u0928\u094D\u092F\u093E\u092F\u093E\u0932\u092F",en:"District and Sessions Court",bearing:340,r:95,h:42,note:"Pune\u2019s District and Sessions Court at Shivajinagar, its stone walls famously grown over with creeper."},{land:"COEP Boat Club",mr:"\u0938\u0940\u0913\u0908\u092A\u0940 \u092C\u094B\u091F \u0915\u094D\u0932\u092C",en:"COEP Boat Club",bearing:45,r:75,h:28,note:"The college\u2019s rowing club on the river, home of its annual regatta."},{land:"Shivajinagar station",mr:"\u0936\u093F\u0935\u093E\u091C\u0940\u0928\u0917\u0930 \u0930\u0947\u0932\u094D\u0935\u0947 \u0938\u094D\u0925\u093E\u0928\u0915",en:"Shivajinagar station",bearing:250,r:120,h:45,note:"A station on the Mumbai\u2013Pune main line, where the suburban trains between Pune and Lonavala stop."}],landView:{"COEP main building":"coep","District Court":"court","Sangam Bridge":"sangam","COEP Boat Club":"boatclub","Shivajinagar station":"station"}},east:{dir:"east/",mr:"\u092A\u0941\u0923\u0947 \u0938\u094D\u091F\u0947\u0936\u0928, \u0938\u0938\u0942\u0928 \u0935 \u0932\u093E\u0932 \u0926\u0947\u090A\u0933",en:"Pune Station, Sassoon and Lal Deool",coord:"18.5240\xB0 N, 73.8740\xB0 E",blurb:"Pune Junction with its yards and suburban trains, Sassoon Hospital\u2019s Gothic stone building and clock tower, the red-brick Ohel David Synagogue (Lal Deool), the Aqua Line metro",start:"station",parts:[{file:"wada_ground.glb.txt",mb:1.7},{file:"wada_city.glb.txt",mb:1.6},{file:"wada_grounds.glb.txt",mb:.2},{file:"wada_life.glb.txt",mb:2.2},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.6,metro:!0},{file:"wada_market.glb.txt",mb:.2},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:3.1},{file:"wada_railway.glb.txt",mb:2.7}],views:[{id:"station",cam:"Cam_PuneStation",label:"Pune Junction"},{id:"platform",cam:"Cam_RailPlatform",label:"Platforms"},{id:"sassoon",cam:"Cam_Sassoon",label:"Sassoon Hospital"},{id:"sassoon-tower",cam:"Cam_SassoonTower",label:"Sassoon clock tower"},{id:"laldeool",cam:"Cam_LalDeool",label:"Lal Deool"},{id:"councilhall",cam:"Cam_CouncilHall",label:"Council Hall"},{id:"councilgate",cam:"Cam_CouncilGate",label:"Council Hall gate"},{id:"metro",cam:"Cam_Metro",label:"Pune Railway Station metro"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Pune Junction",mr:"\u092A\u0941\u0923\u0947 \u091C\u0902\u0915\u094D\u0936\u0928",en:"Pune Junction",bearing:180,r:120,h:45,note:"Pune\u2019s main railway station and junction: long white-and-red buildings beside the platforms, suburban trains to Lonavala and express trains across India."},{land:"Sassoon Hospital",mr:"\u0938\u0938\u0942\u0928 \u0930\u0941\u0917\u094D\u0923\u093E\u0932\u092F",en:"Sassoon Hospital",bearing:70,r:90,h:40,note:"The city\u2019s great public hospital, begun in the 1860s with a gift from David Sassoon: grey stone, long arcaded verandahs and a clock tower."},{land:"Ohel David Synagogue",mr:"\u0932\u093E\u0932 \u0926\u0947\u090A\u0933",en:"Ohel David Synagogue (Lal Deool)",bearing:200,r:70,h:32,note:"Called Lal Deool, the Red Temple, for its red brick: the synagogue built by David Sassoon in the 1860s, with its tall tower."},{land:"Council Hall",mr:"\u0915\u094C\u0928\u094D\u0938\u093F\u0932 \u0939\u0949\u0932",en:"Council Hall",bearing:200,r:90,h:38,note:"Built in the 1870s for the Bombay Legislative Council, which met in Poona during the monsoon; today the office of the Divisional Commissioner."},{land:"Pune Railway Station metro",mr:"\u092A\u0941\u0923\u0947 \u0930\u0947\u0932\u094D\u0935\u0947 \u0938\u094D\u091F\u0947\u0936\u0928 \u092E\u0947\u091F\u094D\u0930\u094B",en:"Pune Railway Station metro",bearing:330,r:110,h:45,note:"The Aqua Line\u2019s elevated station beside the railway yards."}],landView:{"Pune Junction":"station","Sassoon Hospital":"sassoon","Ohel David Synagogue":"laldeool","Pune Railway Station metro":"metro","Council Hall":"councilhall"}},camp:{dir:"camp/",mr:"\u0915\u0945\u092E\u094D\u092A: \u0938\u0947\u0902\u091F \u092E\u0947\u0930\u0940 \u091A\u0930\u094D\u091A \u0935 \u092E\u0939\u093E\u0924\u094D\u092E\u093E \u0917\u093E\u0902\u0927\u0940 \u0930\u0938\u094D\u0924\u093E",en:"Camp: St. Mary\u2019s Church and MG Road",coord:"18.5155\xB0 N, 73.8853\xB0 E",blurb:"The Cantonment: St. Mary\u2019s Church, the shops of MG Road and East Street, and the National War Memorial of the Southern Command",start:"stmarys",parts:[{file:"wada_ground.glb.txt",mb:1.4},{file:"wada_city.glb.txt",mb:4.5},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.7},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.4}],views:[{id:"stmarys",cam:"Cam_StMarys",label:"St. Mary\u2019s Church"},{id:"mgroad",cam:"Cam_MGRoad",label:"MG Road"},{id:"warmemorial",cam:"Cam_WarMemorial",label:"War Memorial"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"St. Mary's Church",mr:"\u0938\u0947\u0902\u091F \u092E\u0947\u0930\u0940 \u091A\u0930\u094D\u091A",en:"St. Mary\u2019s Church",bearing:200,r:70,h:32,note:"Founded in 1825 for the garrison, the oldest church of the Deccan, its \u201Cmother church\u201D, modelled on St Martin-in-the-Fields in London."},{land:"MG Road",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u0917\u093E\u0902\u0927\u0940 \u0930\u0938\u094D\u0924\u093E",en:"MG Road (Main Street)",bearing:120,r:70,h:35,note:"Camp\u2019s Main Street: old shopfronts, bakeries, caf\xE9s and the evening crowds of the Cantonment."},{land:"National War Memorial",mr:"\u0930\u093E\u0937\u094D\u091F\u094D\u0930\u0940\u092F \u092F\u0941\u0926\u094D\u0927 \u0938\u094D\u092E\u093E\u0930\u0915",en:"National War Memorial, Southern Command",bearing:160,r:70,h:30,note:"Dedicated to the soldiers who fell after Independence, and paid for by the contributions of Pune\u2019s citizens."}],landView:{"St. Mary's Church":"stmarys","MG Road":"mgroad","National War Memorial":"warmemorial"}},bund:{dir:"bund/",mr:"\u092C\u0902\u0921 \u0917\u093E\u0930\u094D\u0921\u0928 \u0935 \u092B\u093F\u091F\u094D\u091D\u0917\u0947\u0930\u093E\u0932\u094D\u0921 \u092A\u0942\u0932",en:"Bund Garden and Fitzgerald Bridge",coord:"18.5418\xB0 N, 73.8860\xB0 E",blurb:"The Mula-Mutha at Bund Garden: the old stone Fitzgerald Bridge of 1867, the riverside garden, the Aqua Line\u2019s Bund Garden metro and Koregaon Park",start:"fitzgerald",parts:[{file:"wada_ground.glb.txt",mb:1.1},{file:"wada_city.glb.txt",mb:2.5},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:6.5},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1.1,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.2}],views:[{id:"fitzgerald",cam:"Cam_Fitzgerald",label:"Fitzgerald Bridge"},{id:"fitzgerald-deck",cam:"Cam_FitzgeraldDeck",label:"On the old bridge"},{id:"bundgarden",cam:"Cam_BundGarden",label:"Bund Garden"},{id:"metro",cam:"Cam_Metro",label:"Bund Garden metro"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Fitzgerald Bridge",mr:"\u092B\u093F\u091F\u094D\u091D\u0917\u0947\u0930\u093E\u0932\u094D\u0921 \u092A\u0942\u0932",en:"Fitzgerald Bridge",bearing:250,r:110,h:35,note:"Built of basalt in 1867, its arches carried the road across the Mula-Mutha for a century and a half; today it is a bridge for walkers beside the new road bridges."},{land:"Bund Garden",mr:"\u092C\u0902\u0921 \u0917\u093E\u0930\u094D\u0921\u0928",en:"Bund Garden (Mahatma Gandhi Udyan)",bearing:160,r:80,h:32,note:"The riverside garden named after the bund, the weir across the river, where Pune\u2019s families come out in the evening."}],landView:{"Fitzgerald Bridge":"fitzgerald","Bund Garden":"bundgarden"}},agakhan:{dir:"agakhan/",mr:"\u0906\u0917\u093E \u0916\u093E\u0928 \u092A\u0945\u0932\u0947\u0938",en:"Aga Khan Palace",coord:"18.5523\xB0 N, 73.9015\xB0 E",blurb:"The palace of Sultan Muhammed Shah Aga Khan III, where Mahatma Gandhi, Kasturba Gandhi and Mahadev Desai were interned, with its lawns and the samadhis",start:"agakhan",parts:[{file:"wada_ground.glb.txt",mb:1.1},{file:"wada_city.glb.txt",mb:2.2},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.4},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:.5,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:1.8}],views:[{id:"agakhan",cam:"Cam_AgaKhan",label:"Aga Khan Palace"},{id:"agakhan-side",cam:"Cam_AgaKhanSide",label:"The arcades"},{id:"samadhi",cam:"Cam_Samadhi",label:"The samadhis"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Aga Khan Palace",mr:"\u0906\u0917\u093E \u0916\u093E\u0928 \u092A\u0945\u0932\u0947\u0938",en:"Aga Khan Palace",bearing:70,r:95,h:40,note:"Built in 1892 by Sultan Muhammed Shah Aga Khan III; Mahatma Gandhi, Kasturba Gandhi and Mahadev Desai were interned here in 1942\u201344, and it is now a memorial to Gandhi."},{land:"Kasturba Gandhi Samadhi",mr:"\u0915\u0938\u094D\u0924\u0941\u0930\u092C\u093E \u0917\u093E\u0902\u0927\u0940 \u0938\u092E\u093E\u0927\u0940",en:"The samadhis of Kasturba Gandhi and Mahadev Desai",bearing:120,r:35,h:16,note:"Kasturba Gandhi and Mahadev Desai died here during the internment; their samadhis stand in the garden, beside a memorial holding some of Mahatma Gandhi\u2019s ashes."}],landView:{"Aga Khan Palace":"agakhan","Kasturba Gandhi Samadhi":"samadhi"}},wanowrie:{dir:"wanowrie/",mr:"\u0936\u093F\u0902\u0926\u0947 \u091B\u0924\u094D\u0930\u0940, \u0935\u093E\u0928\u0935\u0921\u0940",en:"Shinde Chhatri, Wanowrie",coord:"18.4916\xB0 N, 73.8972\xB0 E",blurb:"The memorial of Mahadji Shinde: the carved sandstone hall with its coloured glass and the Shiva temple with its spire of gilt finials, in the lanes of Wanowrie",start:"shinde",parts:[{file:"wada_ground.glb.txt",mb:.9},{file:"wada_city.glb.txt",mb:2.4},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.3},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.7}],views:[{id:"shinde",cam:"Cam_ShindeChhatri",label:"Shinde Chhatri"},{id:"shikhara",cam:"Cam_ShindeShikhara",label:"The temple\u2019s spire"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Shinde Chhatri",mr:"\u0936\u093F\u0902\u0926\u0947 \u091B\u0924\u094D\u0930\u0940",en:"Shinde Chhatri",bearing:30,r:70,h:32,note:"The memorial of Mahadji Shinde, the great Maratha general, who was cremated here in 1794: the Shiva temple he built, and the hall of carved sandstone added by his descendants."}],landView:{"Shinde Chhatri":"shinde"}},empress:{dir:"empress/",mr:"\u090F\u092E\u094D\u092A\u094D\u0930\u0947\u0938 \u0917\u093E\u0930\u094D\u0921\u0928 \u0935 \u0930\u0947\u0938\u0915\u094B\u0930\u094D\u0938",en:"Empress Garden and the Race Course",coord:"18.5125\xB0 N, 73.8963\xB0 E",blurb:"The Empress Botanical Garden\u2019s old trees and avenues, and the Pune Race Course of the Royal Western India Turf Club with its colonial grandstand",start:"empress",parts:[{file:"wada_ground.glb.txt",mb:.8},{file:"wada_city.glb.txt",mb:2.2},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.3},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:2.7},{file:"wada_railway.glb.txt",mb:.2}],views:[{id:"empress",cam:"Cam_Empress",label:"Empress Garden"},{id:"racecourse",cam:"Cam_RaceCourse",label:"The home straight"},{id:"grandstand",cam:"Cam_Grandstand",label:"The grandstand"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Empress Garden",mr:"\u090F\u092E\u094D\u092A\u094D\u0930\u0947\u0938 \u0917\u093E\u0930\u094D\u0921\u0928",en:"Empress Botanical Garden",bearing:200,r:260,h:120,note:"A botanical garden laid out in the 1830s and named after Queen Victoria, Empress of India: avenues under huge old trees, bamboo groves and lawns."},{land:"Pune Race Course",mr:"\u092A\u0941\u0923\u0947 \u0930\u0947\u0938\u0915\u094B\u0930\u094D\u0938",en:"Pune Race Course",bearing:220,r:420,h:180,note:"The race course of the Royal Western India Turf Club, where the monsoon racing season has been held since the 1830s; its colonial grandstand looks over the members\u2019 lawn."}],landView:{"Empress Garden":"empress","Pune Race Course":"racecourse"}},university:{dir:"university/",mr:"\u091A\u0924\u0941\u0903\u0936\u0943\u0902\u0917\u0940 \u0935 \u092A\u0941\u0923\u0947 \u0935\u093F\u0926\u094D\u092F\u093E\u092A\u0940\u0920",en:"Chaturshringi and Pune University",coord:"18.5465\xB0 N, 73.8273\xB0 E",blurb:"Chaturshringi temple on its hill above Senapati Bapat Road \u2014 the red gate, the long stairway and the painted spire \u2014 and Savitribai Phule Pune University\u2019s Main Building, the old Government House with its tall tower",start:"chaturshringi",parts:[{file:"wada_ground.glb.txt",mb:1.9},{file:"wada_city.glb.txt",mb:2.4},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.6},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1.2,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:4.3}],views:[{id:"chaturshringi",cam:"Cam_Chaturshringi",label:"Chaturshringi gate"},{id:"ct-stairs",cam:"Cam_ChaturshringiStairs",label:"The temple stairs"},{id:"ct-temple",cam:"Cam_ChaturshringiTemple",label:"Chaturshringi Mandir"},{id:"university",cam:"Cam_University",label:"University Main Building"},{id:"uni-tower",cam:"Cam_UniversityTower",label:"The tower"},{id:"uni-porch",cam:"Cam_UniversityPorch",label:"The east porch"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Chaturshringi Temple",mr:"\u091A\u0924\u0941\u0903\u0936\u0943\u0902\u0917\u0940 \u092E\u0902\u0926\u093F\u0930",en:"Chaturshringi Temple",bearing:80,r:260,h:150,note:"The temple of the goddess Chaturshringi on the slope of a hill of four peaks: from the red gate on Senapati Bapat Road more than two hundred steps climb to her shrine. The story goes that the merchant Durlabhsheth Pitambardas Mahajan built it after the goddess appeared to him in a dream; its Navratri fair fills the road every autumn."},{land:"Pune University",mr:"\u0938\u093E\u0935\u093F\u0924\u094D\u0930\u0940\u092C\u093E\u0908 \u092B\u0941\u0932\u0947 \u092A\u0941\u0923\u0947 \u0935\u093F\u0926\u094D\u092F\u093E\u092A\u0940\u0920",en:"Savitribai Phule Pune University",bearing:280,r:230,h:110,note:"The Main Building was built between 1864 and 1871 as Government House, the monsoon residence of the Governor of Bombay: an Italianate palace of dark basalt with a tall tower. Since 1949 it has housed the University of Pune, renamed after Savitribai Phule in 2014."}],landView:{"Chaturshringi Temple":"chaturshringi","Pune University":"university"}},kalyani:{dir:"kalyani/",mr:"\u0915\u0932\u094D\u092F\u093E\u0923\u0940 \u0928\u0917\u0930",en:"Kalyani Nagar: Cerebrum IT Park, DMart and Cybage",coord:"18.5470\xB0 N, 73.9080\xB0 E",blurb:"Kalyani Nagar\u2019s glass office blocks of Cerebrum IT Park, the DMart store and its busy forecourt, the Cybage towers with their fountain, and every shop, caf\xE9 and clinic signed with its real name",start:"dmart",parts:[{file:"wada_ground.glb.txt",mb:2.3},{file:"wada_city.glb.txt",mb:1.9},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.3},{file:"wada_movers.glb.txt",mb:1.6,movers:!0},{file:"wada_metro.glb.txt",mb:1.2,metro:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:8}],views:[{id:"dmart",cam:"Cam_DMart",label:"DMart"},{id:"cerebrum",cam:"Cam_Cerebrum",label:"Cerebrum IT Park"},{id:"b2",cam:"Cam_CerebrumB2",label:"Cerebrum B2"},{id:"b2-top",cam:"Cam_CerebrumB2Top",label:"B2 from above"},{id:"cybage",cam:"Cam_Cybage",label:"Cybage Towers"},{id:"cy-plaza",cam:"Cam_CybagePlaza",label:"Cybage fountain"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"DMart",mr:"\u0921\u0940-\u092E\u093E\u0930\u094D\u091F",en:"DMart, Kalyani Nagar",bearing:20,r:160,h:80,note:"The supermarket on the lower floors of Cerebrum IT Park\u2019s eastern block on Central Avenue, with shoppers\u2019 cars and scooters packed in front."},{land:"Cerebrum IT Park",mr:"\u0938\u0947\u0930\u0947\u092C\u094D\u0930\u092E \u0906\u092F\u091F\u0940 \u092A\u093E\u0930\u094D\u0915",en:"Cerebrum IT Park",bearing:10,r:230,h:110,note:"An IT park of glass office blocks on Central Avenue in Kalyani Nagar, among the offices that have made this side of Pune a hub of software firms."},{land:"Cybage",mr:"\u0938\u093E\u092F\u092C\u0947\u091C",en:"Cybage Towers",bearing:200,r:220,h:120,note:"Cybage Software\u2019s campus in Kalyani Nagar: two blue glass towers round a fountain, with a multi-level car park behind."}],landView:{DMart:"dmart","Cerebrum IT Park":"cerebrum",Cybage:"cybage"}},ftii:{dir:"ftii/",mr:"\u090F\u092B\u091F\u0940\u0906\u092F\u0906\u092F \u0935 \u0935\u0947\u0924\u093E\u0933 \u091F\u0947\u0915\u0921\u0940",en:"FTII and Vetal Hill",coord:"18.5195\xB0 N, 73.8210\xB0 E",blurb:"The Film and Television Institute of India in the old Prabhat Film Company studios on Law College Road \u2014 Studio 1 with its tutari emblem, the Main Theatre and the Wisdom Tree \u2014 and the scrub forest of Vetal Tekdi with its shrine and flooded quarry",start:"ftii",parts:[{file:"wada_ground.glb.txt",mb:4.6},{file:"wada_city.glb.txt",mb:7},{file:"wada_grounds.glb.txt",mb:.6},{file:"wada_life.glb.txt",mb:.1},{file:"wada_movers.glb.txt",mb:1.5,movers:!0},{file:"wada_metro.glb.txt",mb:1,metro:!0},{file:"wada_market.glb.txt",mb:.2},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.3}],views:[{id:"ftii",cam:"Cam_FTII",label:"FTII gate"},{id:"prabhat",cam:"Cam_PrabhatStudio",label:"Prabhat Studio 1"},{id:"vetal",cam:"Cam_VetalHill",label:"Vetal Hill"},{id:"quarry",cam:"Cam_VetalQuarry",label:"The quarry"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"FTII",mr:"\u090F\u092B\u091F\u0940\u0906\u092F\u0906\u092F",en:"Film and Television Institute of India",bearing:160,r:220,h:110,note:"India\u2019s national film school, set up in 1960 in the studios of the Prabhat Film Company, which V. Shantaram and his partners had moved to Pune in 1933. Students still shoot on Prabhat\u2019s old stage and gather under the Wisdom Tree."},{land:"Vetal Hill",mr:"\u0935\u0947\u0924\u093E\u0933 \u091F\u0947\u0915\u0921\u0940",en:"Vetal Tekdi",bearing:120,r:420,h:220,note:"The highest hill within the city, a green island of scrub forest where Pune walks at dawn. On the top stands the little shrine of Vetal Baba; on its flank, a flooded quarry under walls of basalt."}],landView:{FTII:"ftii","Vetal Hill":"vetal"}},pashan:{dir:"pashan/",mr:"\u092A\u093E\u0937\u093E\u0923 \u0924\u0932\u093E\u0935",en:"Pashan Lake",coord:"18.5340\xB0 N, 73.7850\xB0 E",blurb:"The reservoir on the Ram Nadi with its two wooded islands, rowing boats drawn up at the lakeside park, and the egrets, herons and ducks that make it a favourite place for watching birds",start:"pashan",parts:[{file:"wada_ground.glb.txt",mb:1.6},{file:"wada_city.glb.txt",mb:3.3},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:1},{file:"wada_movers.glb.txt",mb:1.5,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.4}],views:[{id:"pashan",cam:"Cam_PashanLake",label:"Pashan Lake"},{id:"birds",cam:"Cam_PashanBirds",label:"The birding point"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Pashan Lake",mr:"\u092A\u093E\u0937\u093E\u0923 \u0924\u0932\u093E\u0935",en:"Pashan Lake",bearing:200,r:380,h:170,note:"A reservoir made by damming the Ram Nadi in British times. Its islands and reedy shallows draw egrets, herons and ducks all year, and migrant birds in winter."}],landView:{"Pashan Lake":"pashan"}},phule:{dir:"phule/",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u092B\u0941\u0932\u0947 \u0935\u093E\u0921\u093E, \u0917\u0902\u091C \u092A\u0947\u0920",en:"Phule Wada, Ganj Peth",coord:"18.5065\xB0 N, 73.8633\xB0 E",blurb:"The house of Jyotirao and Savitribai Phule with its walled garden, well and Jyotiba Phule\u2019s samadhi, in the lanes of Ganj Peth",start:"phulewada",parts:[{file:"wada_ground.glb.txt",mb:1.2},{file:"wada_city.glb.txt",mb:3.3},{file:"wada_grounds.glb.txt",mb:.1},{file:"wada_life.glb.txt",mb:.5},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_market.glb.txt",mb:.1},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:.2}],views:[{id:"phulewada",cam:"Cam_PhuleWada",label:"Mahatma Phule Wada"},{id:"samadhi",cam:"Cam_PhuleSamadhi",label:"Phule samadhi"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"}],stops:[{land:"Mahatma Phule Wada",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u092B\u0941\u0932\u0947 \u0935\u093E\u0921\u093E",en:"Mahatma Phule Wada",bearing:120,r:45,h:24,note:"The house where Jyotirao and Savitribai Phule lived and worked, pioneers of schools for girls and of social reform; now a national memorial, with Jyotiba Phule\u2019s samadhi in its garden."}],landView:{"Mahatma Phule Wada":"phulewada"}}},Gn=(()=>{let i=null;try{i=new URLSearchParams(location.search).get("place")}catch{}let e=/(?:^|[#&])place=([\w-]+)/.exec(location.hash);return e&&e[1]||i||"oldcity"})(),In=jr[Gn]||jr.oldcity,ss=In.dir,ko=In.parts||[{file:"wada_ground.glb.txt",mb:2.3},{file:"wada_city.glb.txt",mb:3},{file:"wada_grounds.glb.txt",mb:3.9},{file:"wada_life.glb.txt",mb:1.5},{file:"wada_statues.glb.txt",mb:1.2},{file:"wada_movers.glb.txt",mb:.8,movers:!0},{file:"wada_metro.glb.txt",mb:1,metro:!0},{file:"wada_market.glb.txt",mb:.8},{file:"wada_props.glb.txt",mb:1.3,props:!0},{file:"wada_oldcity.glb.txt",mb:5.4}],$r=In.views||[{id:"gate",cam:"Cam_Gate",label:"Dilli Darwaza"},{id:"street",cam:"Cam_Street",label:"Market street"},{id:"lane",cam:"Cam_Lane",label:"Old-city lane"},{id:"fort",cam:"Cam_Fort",label:"Fort"},{id:"aerial",cam:"Cam_Aerial",label:"Whole area"},{id:"river",cam:"Cam_River",label:"Mutha river"},{id:"lalmahal",cam:"Cam_LalMahal",label:"Lal Mahal"},{id:"lalmahal-street",cam:"Cam_StreetView_LalMahal",label:"Lal Mahal corner"},{id:"dagdusheth",cam:"Cam_Dagdusheth",label:"Dagdusheth Ganpati"},{id:"streetview",cam:"Cam_StreetView",label:"Junction (Street View)"},{id:"metro",cam:"Cam_Metro",label:"PMC Bhavan metro"},{id:"kasba",cam:"Cam_KasbaPeth",label:"Kasba Peth metro"},{id:"tulshibaug",cam:"Cam_Tulshibaug",label:"Tulshibaug Ram Mandir"},{id:"market",cam:"Cam_Market",label:"Tulshibaug market"},{id:"vishrambaug",cam:"Cam_Vishrambaug",label:"Vishrambaug Wada"},{id:"nana",cam:"Cam_NanaWada",label:"Nana Wada"},{id:"bhide",cam:"Cam_BhideWada",label:"Bhide Wada"},{id:"omkareshwar",cam:"Cam_Omkareshwar",label:"Omkareshwar Mandir"},{id:"laxmi",cam:"Cam_LaxmiRoad",label:"Laxmi Road"},{id:"kasbaganpati",cam:"Cam_KasbaGanpati",label:"Kasba Ganpati"},{id:"mandai",cam:"Cam_Mandai",label:"Mahatma Phule Mandai"},{id:"balgandharva",cam:"Cam_Balgandharva",label:"Balgandharva Rangmandir"},{id:"kesari",cam:"Cam_KesariWada",label:"Kesari Wada"},{id:"kesari-street",cam:"Cam_KesariWadaStreet",label:"Kesari Wada gate"},{id:"kelkar",cam:"Cam_KelkarMuseum",label:"Kelkar Museum"}],ar={day:{top:5211849,bg:11124694,sun:16773858,sunI:3,el:55,az:215,sky:12900334,ground:9075298,hemiI:1.3,night:0,lamp:0,pool:0,exp:1,fog:[700,2800],flood:0,lit:1},evening:{top:3886982,bg:13998702,sun:16749904,sunI:2.2,el:8,az:290,sky:15116934,ground:4864560,hemiI:.6,night:.4,lamp:2.5,pool:90,exp:1.1,fog:[500,2200],flood:.35,lit:.6},night:{top:66056,bg:197899,sun:9349375,sunI:.16,el:45,az:150,sky:1120812,ground:328966,hemiI:.2,night:1,lamp:8,pool:210,exp:1.25,fog:[45,380],flood:1,lit:.85}},fn=matchMedia("(prefers-reduced-motion: reduce)").matches,Vn=matchMedia("(pointer: coarse)").matches,me=i=>document.getElementById(i),Vt=me("scene"),Ht;try{Ht=new Cr({canvas:Vt,antialias:!0,powerPreference:"high-performance"})}catch(i){throw me("status").textContent="This browser cannot show 3D graphics (WebGL is off or unsupported). Try a recent Chrome, Edge, Firefox or Safari.",i}Ht.setPixelRatio(Math.min(window.devicePixelRatio||1,Vn?1.5:2));Ht.outputColorSpace=ut;Ht.toneMapping=Bc;Ht.shadowMap.enabled=!0;Ht.shadowMap.type=Fc;Ht.shadowMap.autoUpdate=!1;var op=1,Oh=0,mt=new ts;mt.fog=new to(11124694,700,2800);var xe=new Ot(55,1,.1,6e3);xe.position.set(300,250,300);var nt=new Ao(xe,Vt);nt.enableDamping=!0;nt.dampingFactor=.06;nt.maxPolarAngle=Math.PI*.66;nt.minDistance=2;nt.maxDistance=2600;nt.zoomSpeed=2.4;nt.zoomToCursor=!0;Vt.addEventListener("wheel",i=>{if(tt!=="orbit"||i.deltaY>=0||xe.position.distanceTo(nt.target)>12)return;let t=new R;xe.getWorldDirection(t);let n=Math.min(25,3+Math.abs(i.deltaY)*.04);nt.target.addScaledVector(t,n),xe.position.addScaledVector(t,n*.6)},{passive:!0});var os=new kr(12900334,7035461,1.1);mt.add(os);var nn=new ns(16777215,3);nn.castShadow=!0;nn.shadow.mapSize.set(Vn?1024:2048,Vn?1024:2048);nn.shadow.camera.near=1;nn.shadow.camera.far=1600;nn.shadow.bias=-5e-4;mt.add(nn,nn.target);var Qs={top:{value:new Re(5211849)},horizon:{value:new Re(11124694)},sunDir:{value:new R(0,1,0)},sunCol:{value:new Re(16773858)},moonDir:{value:new R(-.4,.55,-.73).normalize()},night:{value:0}},Jo=new Oe(new zn(5e3,48,24),new kn({uniforms:Qs,side:Yt,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vDir; void main() { vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",fragmentShader:`
    uniform vec3 top, horizon, sunDir, sunCol, moonDir; uniform float night; varying vec3 vDir;
    float hash(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
    void main() {
      vec3 d = normalize(vDir);
      float h = d.y;
      vec3 col = mix(horizon, top, smoothstep(0.0, 0.55, h));
      float sd = max(dot(d, normalize(sunDir)), 0.0);
      col += sunCol * (pow(sd, 900.0) * 6.0 + pow(sd, 12.0) * 0.18) * (1.0 - night) * step(-0.02, h);
      if (night > 0.5) {
        vec3 q = floor(d * 420.0);
        float st = step(0.9975, hash(q)) * smoothstep(0.04, 0.3, h);
        col += vec3(0.85, 0.9, 1.0) * st * (0.6 + 0.4 * hash(q + 7.0));
        float md = dot(d, moonDir);
        col = mix(col, vec3(0.92, 0.92, 0.86), smoothstep(0.99955, 0.99975, md));
        col += vec3(0.25, 0.3, 0.42) * pow(max(md, 0.0), 60.0) * 0.6;
      }
      gl_FragColor = vec4(col, 1.0);
      #include <colorspace_fragment>
    }`}));Jo.renderOrder=-1;Jo.frustumCulled=!1;mt.add(Jo);var lp=8,Fh=[];for(let i=0;i<lp;i++){let e=new Ui(16762510,0,32,2);mt.add(e),Fh.push(e)}var Zt={uNight:{value:0},uFlood:{value:0},uLitCut:{value:1},uTime:{value:0}},cp=`
#ifdef USE_INSTANCING
vec3 wp0 = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz;
#else
vec3 wp0 = (modelMatrix * vec4(transformed, 1.0)).xyz;
#endif
float ph = wp0.x * 0.37 + wp0.z * 0.29;
float gust = 0.35 + 0.65 * pow(0.5 + 0.5 * sin(uTime * 0.23 + wp0.x * 0.004 + wp0.z * 0.003), 3.0);`,Kh=`
totalEmissiveRadiance += diffuseColor.rgb * vec3(1.0, 0.74, 0.46) * uFlood * 0.8 * clamp(1.2 - vWPos.y / 18.0, 0.25, 1.0)
  * (0.72 + 0.28 * sin(vWPos.x * 0.45) * sin(vWPos.z * 0.45));   // separate beams from the ground`,jh=`
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }`;function Fv(){let i=new $e({vertexColors:!0,roughness:.88,flatShading:!0});return i.defines={USE_UV:""},i.customProgramCacheKey=()=>"facade",i.onBeforeCompile=e=>{e.uniforms.uNight=Zt.uNight,e.uniforms.uLitCut=Zt.uLitCut,e.fragmentShader=e.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;
uniform float uLitCut;
const float GF = 3.8;   // ground-floor height (m)
const float FH = 3.2;   // upper floor height (m)
${jh}`).replace("#include <color_fragment>",`#include <color_fragment>
float shopFlag = vColor.a;
diffuseColor.a = 1.0;
float hgt = 1.0 - vUv.y;             // metres above the street (glTF flips V)
float along = vUv.x;                 // metres along the wall
float upper = step(GF, hgt);
float fz = fract((hgt - GF) / FH);
float fu = fract(along / 3.0);
float aa = clamp(1.6 - max(fwidth(along / 3.0), fwidth(hgt / FH)) * 4.0, 0.0, 1.0);   // fade tiny patterns
float winRaw = upper * step(0.28, fz) * step(fz, 0.80) * step(0.30, fu) * step(fu, 0.70);
float win = winRaw * aa;
float band = upper * step(fz, 0.07) * aa;
float gu = fract(along / 3.6);
float shut = shopFlag * step(0.15, hgt) * step(hgt, GF - 0.9) * step(0.06, gu) * step(gu, 0.94);
float ribs = fract(hgt * 9.0) * 0.25;
vec3 wallCol = diffuseColor.rgb * mix(1.0, 0.75, band);
wallCol *= mix(1.0, 0.82, (1.0 - clamp(hgt / 7.0, 0.0, 1.0)) * 0.7);
wallCol = mix(wallCol, mix(vec3(0.30, 0.31, 0.32), vec3(0.42, 0.43, 0.44), ribs), shut);
wallCol = mix(wallCol, vec3(0.035, 0.045, 0.055), win);
wallCol *= mix(1.0, 0.78, upper * (1.0 - aa));      // far away: windows blend into a darker wall
diffuseColor.rgb = wallCol;
float lit = winRaw * step(uLitCut, hash12(vec2(floor(along / 3.0), floor((hgt - GF) / FH)) + vColor.rg * 97.0));
float shopLit = shut * step(0.5, hash12(vec2(floor(along / 3.6), 7.0) + vColor.gb * 53.0));`).replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
roughnessFactor = mix(roughnessFactor, 0.25, win);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += (vec3(1.0, 0.72, 0.42) * lit * 1.5 + vec3(0.9, 0.55, 0.25) * shopLit * 0.6) * pow(uNight, 1.6);`)},i}function Bv(){let i=new $e({vertexColors:!0,roughness:.85,flatShading:!0});return i.customProgramCacheKey=()=>"wash",i.onBeforeCompile=e=>{e.uniforms.uFlood=Zt.uFlood,e.vertexShader=e.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),e.fragmentShader=e.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;`).replace("#include <color_fragment>",`#include <color_fragment>
float code = vColor.a;
diffuseColor.a = 1.0;
vec3 tint = code > 0.965 ? vec3(1.0, 0.74, 0.46) : (code > 0.895 ? vec3(0.80, 0.90, 1.0)
          : clamp(abs(mod(code / 0.9 * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0) * 1.3);
if (code < 0.895) diffuseColor.rgb *= mix(vec3(1.0), tint / max(max(tint.r, tint.g), max(tint.b, 0.001)), uFlood * 0.8);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
vec3 lit = code > 0.895 ? 0.06 + 0.38 * diffuseColor.rgb : diffuseColor.rgb * 0.85;   // white light: pale walls must not burn out
totalEmissiveRadiance += lit * tint * uFlood * clamp(1.25 - vWPos.y / 20.0, 0.3, 1.0)
  * (0.75 + 0.25 * sin(vWPos.x * 0.45) * sin(vWPos.z * 0.45));`)},i}function qr(i,e,t=1,n=!0){let s=new $e({vertexColors:!0,roughness:.9,flatShading:!0}),r=(Math.min(i,e)*.045/i).toFixed(4),o=(Math.min(i,e)*.045/e).toFixed(4);return s.customProgramCacheKey=()=>`masonry-${i}-${e}-${t}-${n}`,s.onBeforeCompile=a=>{a.uniforms.uFlood=Zt.uFlood,a.vertexShader=a.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),a.fragmentShader=a.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;${jh}`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>${n?Kh:""}`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;
vec3 fn = normalize(cross(dFdx(vWPos), dFdy(vWPos)));
float s = abs(fn.x) > abs(fn.z) ? vWPos.z : vWPos.x;
float t = abs(fn.y) > 0.8 ? vWPos.z : vWPos.y;
float row = floor(t / ${e.toFixed(3)});
float bx = s / ${i.toFixed(3)} + mod(row, 2.0) * 0.5;
float fx = fract(bx), fy = fract(t / ${e.toFixed(3)});
float aa = clamp(1.5 - max(fwidth(bx), fwidth(t / ${e.toFixed(3)})) * 3.0, 0.0, 1.0);
float joint = (1.0 - step(${r}, fx) * step(fx, 1.0 - ${r}) * step(${o}, fy) * step(fy, 1.0 - ${o})) * aa;
vec3 base = diffuseColor.rgb * ${t.toFixed(2)} * mix(0.7, 1.0, smoothstep(0.0, 2.8, vWPos.y));   // darker at the foot
float vert = 1.0 - step(0.8, abs(fn.y));                         // walls (1) or paving (0)
vec3 block = base * mix(1.0, mix(0.78, 1.22, hash12(vec2(floor(bx), row))), aa * mix(0.35, 1.0, vert));
diffuseColor.rgb = mix(block, base * 1.12, joint * mix(0.4, 1.0, vert));
float lane = hash12(vec2(floor(s * 1.4), 11.0));                 // rain streaks running down from the top
float streak = step(0.7, lane) * (0.55 + 0.45 * sin(t * 0.35 + lane * 40.0)) * vert;
float blotch = hash12(floor(vec2(s, t) * 0.35));
diffuseColor.rgb *= (1.0 - 0.16 * streak) * mix(0.9, 1.06, blotch);`)},s}function Uf(i,e,t){let n=new $e({vertexColors:!0,roughness:e,metalness:t,flatShading:!0});return t>.5&&(n.envMap=ir,n.envMapIntensity=.5),n.customProgramCacheKey=()=>"surface-"+i,n.onBeforeCompile=s=>{s.uniforms.uFlood=Zt.uFlood,s.vertexShader=s.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`);let r=i==="wood"?`
vec3 fn = normalize(cross(dFdx(vWPos), dFdy(vWPos)));
float s = abs(fn.x) > abs(fn.z) ? vWPos.z : vWPos.x;
float t = vWPos.y;
float plank = floor(s / 0.28);
float g = fract(s / 0.28);
float joint = 1.0 - smoothstep(0.0, 0.04, g) * smoothstep(1.0, 0.96, g);
float grain = 0.5 + 0.5 * sin(s * 150.0 + sin(t * 2.7 + plank * 1.7) * 3.0 + plank * 9.0);
diffuseColor.rgb *= mix(0.86, 1.12, grain) * mix(0.9, 1.08, hash12(vec2(plank, 3.0))) * (1.0 - 0.55 * joint);`:`
float rust = smoothstep(0.45, 0.9, hash12(floor(vWPos.xz * 7.0 + vWPos.y * 5.0)));
diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.28, 0.11, 0.05), rust * 0.75);
roughnessFactor = mix(roughnessFactor, 0.95, rust);`;s.fragmentShader=s.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;${jh}`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>${r}`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>${Kh}`)},n}var Qo=new $e({color:16769720,emissive:16762510,emissiveIntensity:0,side:yt}),na=new $e({vertexColors:!0,roughness:.5,emissive:16764826,emissiveIntensity:0,flatShading:!0});na.side=yt;na.customProgramCacheKey=()=>"glow";na.onBeforeCompile=i=>{i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
vec2 pp = vec2(vWPos.x + vWPos.z, vWPos.y) * 3.2;
float perf = smoothstep(0.34, 0.26, length(fract(pp) - 0.5)) * clamp(1.4 - fwidth(pp.x) * 2.5, 0.0, 1.0);
totalEmissiveRadiance *= mix(vec3(1.0), diffuseColor.rgb * 1.5, 0.55) * (0.45 + 0.75 * perf);`)};var el=new $e({color:5900293,emissive:16718344,emissiveIntensity:.4,side:yt}),ir=new Gs(Ht).fromScene(new Ro,.04).texture;function $h(i,e,t){let n=new $e({vertexColors:!0,metalness:i,roughness:e,envMap:ir,envMapIntensity:t});return n.customProgramCacheKey=()=>"shiny",n.onBeforeCompile=s=>{s.uniforms.uFlood=Zt.uFlood,s.fragmentShader=s.fragmentShader.replace("#include <common>",`#include <common>
uniform float uFlood;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += diffuseColor.rgb * uFlood * 0.55;`)},n}var kv=$h(.85,.38,.9),zv=$h(1,.22,1.2),Hv=$h(1,.04,1.4),Zh=new $e({vertexColors:!0,roughness:.85,side:yt,flatShading:!0});Zh.customProgramCacheKey=()=>"cloth";Zh.onBeforeCompile=i=>{i.uniforms.uTime=Zt.uTime,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <project_vertex>",`#include <project_vertex>
#ifdef USE_COLOR_ALPHA
float wgt = 1.0 - color.a;
#else
float wgt = 0.0;
#endif
${cp}
vec3 off = vec3(sin(uTime * 2.3 + ph) * 0.17, 0.0, sin(uTime * 1.9 + ph * 1.4) * 0.12) * wgt * (0.4 + gust);
off.y = abs(off.x) * 0.3;
mvPosition.xyz += (viewMatrix * vec4(off, 0.0)).xyz;
gl_Position = projectionMatrix * mvPosition;`),i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};var tl=new $e({vertexColors:!0,roughness:.9,flatShading:!0});tl.customProgramCacheKey=()=>"tree";tl.onBeforeCompile=i=>{i.uniforms.uTime=Zt.uTime,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <project_vertex>",`#include <project_vertex>
${cp}
float wgt = pow(clamp((wp0.y - 1.5) / 9.0, 0.0, 1.0), 1.5);
float sway = (sin(uTime * 1.1 + ph) * 0.13 + sin(uTime * 2.9 + ph * 2.3) * 0.05) * (0.3 + gust * 1.2) + gust * 0.12;
vec3 off = vec3(0.8, 0.0, 0.45) * sway * wgt;
mvPosition.xyz += (viewMatrix * vec4(off, 0.0)).xyz;
gl_Position = projectionMatrix * mvPosition;`),i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};var Jh=new $e({vertexColors:!0,roughness:.8,flatShading:!0,side:yt});Jh.customProgramCacheKey=()=>"lit";Jh.onBeforeCompile=i=>{i.uniforms.uNight=Zt.uNight,i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += diffuseColor.rgb * vec3(1.2, 0.95, 0.65) * pow(uNight, 1.4) * 0.32;`)};var Qh=new $e({vertexColors:!0,roughness:.6,flatShading:!0});Qh.customProgramCacheKey=()=>"nightlight";Qh.onBeforeCompile=i=>{i.uniforms.uNight=Zt.uNight,i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
uniform float uNight;`).replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;
vec3 lightCol = diffuseColor.rgb;
diffuseColor.rgb *= mix(0.25, 1.0, uNight);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += lightCol * 0.85 * pow(uNight, 1.2);`)};var eu=new $e({vertexColors:!0,metalness:.9,roughness:.22,envMap:ir,envMapIntensity:1.2,flatShading:!0});eu.customProgramCacheKey=()=>"steel";eu.onBeforeCompile=i=>{i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};var tu=new $e({vertexColors:!0,metalness:.45,roughness:.3,envMap:ir,envMapIntensity:.8,flatShading:!0});tu.customProgramCacheKey=()=>"train";tu.onBeforeCompile=i=>{i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)};function Vv(i,e){let t=new $e({vertexColors:!0,roughness:.7,flatShading:!0});return t.customProgramCacheKey=()=>"walker",t.onBeforeCompile=n=>{n.uniforms.uHip={value:i},n.uniforms.uShoulder={value:e},n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
attribute float aStep;
uniform float uHip;
uniform float uShoulder;
vec3 swingAbout(vec3 p, float pivot, float a) {
  float c = cos(a), s = sin(a), ry = p.y - pivot;
  return vec3(p.x * c - ry * s, p.x * s + ry * c + pivot, p.z);
}`).replace("#include <begin_vertex>",`#include <begin_vertex>
#ifdef USE_COLOR_ALPHA
float limb = floor(color.a * 5.0 + 0.5);
#else
float limb = 5.0;
#endif
float sw = sin(aStep);
if (limb > 3.5 && limb < 4.5) transformed = swingAbout(transformed, uHip, sw * 0.42);
else if (limb > 2.5 && limb < 3.5) transformed = swingAbout(transformed, uHip, -sw * 0.42);
else if (limb > 1.5 && limb < 2.5) transformed = swingAbout(transformed, uShoulder, -sw * 0.30);
else if (limb > 0.5 && limb < 1.5) transformed = swingAbout(transformed, uShoulder, sw * 0.30);
transformed.y += abs(cos(aStep)) * 0.025;`),n.fragmentShader=n.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`)},t}var Gv=/^(Landmark_Paint|Gate_(CarvedWood|Plaster|Roof|Wood|Iron)|Grounds_Statue)$/,Th={},Ah=new Map,Rh=new Map;function Wv(i,e){let t=i.uuid+":"+e;if(!Rh.has(t)){let n=i.clone();n.onBeforeCompile=i.onBeforeCompile,i.customProgramCacheKey&&(n.customProgramCacheKey=i.customProgramCacheKey),n.polygonOffset=!0,n.polygonOffsetFactor=-e,n.polygonOffsetUnits=-2*e,Rh.set(t,n)}return Rh.get(t)}function hp(i,e){if(e.attributes.normal||i.flatShading)return i;if(!Ah.has(i)){let t=i.clone();t.flatShading=!0,t.onBeforeCompile=i.onBeforeCompile;let n=i.customProgramCacheKey?i.customProgramCacheKey():"std";t.customProgramCacheKey=()=>n+"-flat",Ah.set(i,t)}return Ah.get(i)}function Xv(){let i=new $e({vertexColors:!0,roughness:.95,flatShading:!0,side:yt});return i.customProgramCacheKey=()=>"sleepers",i.onBeforeCompile=e=>{e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      {
        float k = vColor.a * 25.0;
        float w = max(fwidth(k), 1e-4);
        float f = fract(k);
        float on = clamp((0.1785 - abs(f - 0.1785)) / w + 0.5, 0.0, 1.0);
        on = mix(on, 0.357, smoothstep(0.2, 0.7, w));          // far off: the average, no shimmer
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.55, 0.535, 0.50), on);
      }
      diffuseColor.a = 1.0;`)},i}function qv(){let i=new $e({vertexColors:!0,roughness:.8,flatShading:!0});return i.customProgramCacheKey=()=>"creeper",i.onBeforeCompile=e=>{e.vertexShader=e.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),e.fragmentShader=e.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
float h3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
float vn(vec3 p) {
  vec3 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(h3(i), h3(i + vec3(1.0, 0.0, 0.0)), f.x), mix(h3(i + vec3(0.0, 1.0, 0.0)), h3(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
             mix(mix(h3(i + vec3(0.0, 0.0, 1.0)), h3(i + vec3(1.0, 0.0, 1.0)), f.x), mix(h3(i + vec3(0.0, 1.0, 1.0)), h3(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}`).replace("#include <color_fragment>",`#include <color_fragment>
{
  vec3 q = vWPos * 6.5;
  float a = vn(q), b = vn(q * 2.7 + 7.3), c = vn(q * 0.45 - 3.1);
  float leaf = smoothstep(0.32, 0.78, a * 0.55 + b * 0.45);
  vec3 pat = mix(diffuseColor.rgb * 0.32, diffuseColor.rgb * vec3(1.35, 1.5, 1.05), leaf) * (0.75 + 0.5 * c);
  float far = clamp(length(fwidth(q)) * 0.9, 0.0, 1.0);          // far off: the average tone, no shimmer
  diffuseColor.rgb = mix(pat, diffuseColor.rgb * (0.82 + 0.25 * c), far);
}
diffuseColor.a = 1.0;`)},i}function zo(i){if(Th[i])return Th[i];let e;if(i==="Statue_Bronze")e=kv;else if(i==="Statue_Gold")e=zv;else if(i==="Grounds_Mirror")e=Hv;else if(i==="City_Facade")e=Fv();else if(i==="Wada_Brick")e=qr(.3,.1,1.3);else if(i==="Wada_Basalt")e=qr(.9,.45,1.9);else if(i==="Wada_PaleStone")e=qr(.75,.4,1.5);else if(i==="City_RoofTile")e=qr(.3,.16,1,!1);else if(i==="Gate_Roof")e=qr(.28,.15,1,!0);else if(i==="Gate_Wood"||i==="Gate_CarvedWood")e=Uf("wood",.85,0);else if(i==="Gate_Iron")e=Uf("iron",.45,.85);else if(i==="City_Lamp")e=Qo;else if(i==="City_TailLamp")e=el;else if(i==="Metro_Glow")e=na;else if(i==="Metro_Train")e=tu;else if(i==="Market_Cloth")e=Zh;else if(i==="Market_Shiny")e=eu;else if(i==="Market_Lit")e=Jh;else if(i==="Market_GlowLight")e=Qh;else if(i==="Old_Wash")e=Bv();else if(i==="Railway_Sleepers")e=Xv();else if(i==="Old_Creeper")e=qv();else{let t={City_Water:.3,Grounds_Water:.25,Gate_Iron:.45,City_Metal:.5,Grounds_Metal:.45,Life_Paint:.55,City_Sign:.5,Metro_Metal:.4,Metro_Concrete:.8,Old_Glass:.12,Railway_Metal:.38,Railway_Glass:.1,Railway_Train:.42}[i]??.9,n={Gate_Iron:.9,City_Metal:.7,Grounds_Metal:.6,City_Water:.1,Metro_Metal:.65,Old_Glass:.6,Railway_Metal:.6,Railway_Glass:.6,Railway_Train:.2}[i]??0;e=new $e({vertexColors:!0,roughness:t,metalness:n,flatShading:!0}),/^(Metro|Railway)_/.test(i)&&(e.side=yt),n>=.5&&(e.envMap=ir,e.envMapIntensity=.6),/Water/.test(i)&&(e.color.setRGB(.4,.47,.38),e.roughness=.3,e.metalness=0,e.envMap=ir,e.envMapIntensity=.14,e.side=yt);let s=Gv.test(i);e.customProgramCacheKey=()=>s?"plain-floodlit":"plain",e.onBeforeCompile=r=>{r.fragmentShader=r.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
diffuseColor.a = 1.0;`),s&&(r.uniforms.uFlood=Zt.uFlood,r.vertexShader=r.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <project_vertex>",`#include <project_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),r.fragmentShader=r.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform float uFlood;`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>${Kh}`))}}return Th[i]=e,e}var up=new So,Ho=ko.map(()=>0),Of=ko.reduce((i,e)=>i+e.mb,0);function Vo(){let i=Ho.reduce((e,t)=>e+t,0);me("bar").style.width=`${Math.min(100,i/Of*100).toFixed(1)}%`,me("status").textContent=`Loading the city\u2026 ${i.toFixed(1)} of ${Of.toFixed(1)} MB`}var dp={},Fo=null,Bo=null,Go={},nu=[],Bh=0,kh=[],fp=[],Ff=/^(Ground|City_Roads|City_Plinths|Gate_Steps|Gate_Block|Grounds_(Amphitheatre|Street|LalMahal|Dagdusheth|Fountains|Palace)|Market_RamMandir|Metro_Entrances|Railway_(Platforms|Station))/;async function Yv(i,e){let t=await fetch(ss+i.file);if(!t.ok)throw new Error(i.file);let n=Number(t.headers.get("content-length"))||i.mb*1e6;if(!t.body||!t.body.getReader){let c=await t.text();return Ho[e]=i.mb,Vo(),c}let s=t.body.getReader(),r=[],o=0;for(;;){let{done:c,value:h}=await s.read();if(c)break;r.push(h),o+=h.length,Ho[e]=Math.min(i.mb,o/n*i.mb),Vo()}let a=new Uint8Array(o),l=0;for(let c of r)a.set(c,l),l+=c.length;return new TextDecoder().decode(a)}function pp(i){let e=atob(i.trim()),t=new Uint8Array(e.length);for(let n=0;n<e.length;n++)t[n]=e.charCodeAt(n);return t.buffer}async function Bf(i,e){let t;try{let s=pp(await Yv(i,e));t=await up.parseAsync(s,"")}catch{throw new Error(i.file.replace(".glb.txt",""))}if(Ho[e]=i.mb,Vo(),i.movers)return Fo=t.scene,t;if(i.props)return Bo=t.scene,t;let n=[];t.scene.traverse(s=>{if(s.isCamera&&(dp[s.name]=s),s.isMesh){let r=s.material?.name||"",o=s.geometry;o.attributes.color_1&&iu(o.attributes.color)&&o.setAttribute("color",o.attributes.color_1),s.material=hp(zo(r),s.geometry),/^Grounds_Trees/.test(s.name+" "+(s.parent?.name||""))&&r==="Grounds_Paint"&&(s.material=tl,gb(s));let a=/City_(Roads|Water|Green)|^Ground/.test(s.name)&&!/^Ground_Hills/.test(s.name)||/City_(Asphalt|Paving|Water|Grass|Ground)/.test(r);s.castShadow=!a&&!/Cable/.test(r),s.receiveShadow=!0,/^City_(Roads|Water|Green)/.test(s.name)&&(s.material=Wv(s.material,/^City_Roads/.test(s.name)?2:1)),r==="City_Lamp"&&!/^Life_/.test(s.name+(s.parent?.name||""))&&Kv(s),(Ff.test(s.name)||Ff.test(s.parent?.name||""))&&fp.push(s),/^Life_/.test(s.name+(s.parent?.name||""))||xp.push(s)}/^(Metro|Railway)_Car_(Front|Middle|Motor)$/.test(s.name)&&n.push(s)});for(let s of n)s.parent.remove(s),Go[s.name]=s;return mt.add(t.scene),t}function iu(i){if(!i)return!0;let e=Math.min(i.count,200);for(let t=0;t<e;t++)if(i.getX(t)<.99||i.getY(t)<.99||i.getZ(t)<.99)return!1;return!0}function Kv(i){i.updateWorldMatrix(!0,!1);let e=i.geometry.attributes.position,t=new Set,n=new R;for(let s=0;s<e.count;s++){n.fromBufferAttribute(e,s).applyMatrix4(i.matrixWorld);let r=`${Math.round(n.x/3)},${Math.round(n.z/3)}`;t.has(r)||(t.add(r),kh.push(new R(n.x,n.y-.4,n.z)))}}var or="day",Zr=new R;function mp(i){or=i;let e=ar[i];mt.background=new Re(e.bg),Qs.top.value.set(e.top),Qs.horizon.value.set(e.bg),Qs.sunCol.value.set(e.sun),Qs.night.value=e.night,mt.fog.color.set(e.bg),mt.fog.near=e.fog[0],mt.fog.far=e.fog[1],Zt.uFlood.value=e.flood,Zt.uLitCut.value=e.lit,nn.color.set(e.sun),nn.intensity=e.sunI,os.color.set(e.sky),os.groundColor.set(e.ground),os.intensity=e.hemiI,Zt.uNight.value=e.night,Qo.emissiveIntensity=Math.max(e.lamp,.6),el.emissiveIntensity=e.night>.5?4:e.night>0?1.8:.5,na.emissiveIntensity=e.night>.5?1.1:e.night>0?.45:0,Bh=e.night>.5?.85:e.night>0?.45:0;for(let s of nu)s.material.emissiveIntensity=Bh;Ht.toneMappingExposure=e.exp;let t=It.degToRad(e.el),n=It.degToRad(e.az);Zr.set(Math.sin(n)*Math.cos(t),Math.sin(t),-Math.cos(n)*Math.cos(t)),Qs.sunDir.value.copy(Zr);for(let s of document.querySelectorAll("#tod button"))s.setAttribute("aria-pressed",String(s.dataset.tod===i));zh=0}var zh=0;function jv(i,e){if(i-zh<400)return;zh=i;let t=ar[or].pool;if(!t||!kh.length){Fh.forEach(s=>s.intensity=0);return}let n=kh.map(s=>[s.distanceToSquared(e),s]).sort((s,r)=>s[0]-r[0]).slice(0,lp);Fh.forEach((s,r)=>{n[r]?(s.position.copy(n[r][1]),s.intensity=t):s.intensity=0})}var tt="orbit",nl=!1,W={yaw:0,pitch:0,tyaw:0,tpitch:0,pos:new R,keys:new Set,floor:0,lastProbe:0,runLock:!1},$v=2.5,gp=7.5,sr=1.7,Mt=null;function Zv(i){let e=dp[i.cam];if(!e)return null;e.updateWorldMatrix(!0,!1);let t=new R,n=new ct;e.getWorldPosition(t),e.getWorldQuaternion(n);let s=new R(0,0,-1).applyQuaternion(n),r=t.y>50?Math.max(200,t.y*1.3):30;return{pos:t,dir:s,target:t.clone().addScaledVector(s,r)}}function il(i,e=!1){let t=$r.find(r=>r.id===i)||$r[3],n=Zv(t);if(!n)return;Ip(n,t);for(let r of document.querySelectorAll("#views button"))r.setAttribute("aria-pressed",String(r.dataset.view===t.id));let s="#"+t.id+(Gn!=="oldcity"||/place=/.test(location.hash)?"&place="+Gn:"");try{location.hash!==s&&history.replaceState(null,"",s)}catch{}if(tt==="walk"&&n.pos.y<5){W.pos.copy(n.pos),W.pos.y=sn(W.pos.x,W.pos.z)+sr,W.yaw=W.tyaw=Math.atan2(-n.dir.x,-n.dir.z),W.pitch=W.tpitch=0;return}tt==="walk"&&ls("orbit",!1),e||fn?(xe.position.copy(n.pos),nt.target.copy(n.target),nt.update(),Mt=null):ia(n.pos,n.target)}function ia(i,e,t={}){let n=xe.position.clone(),s=nt.target.clone(),r=n.distanceTo(i)+.5*s.distanceTo(e),o=t.arc??Math.min(220,r*.32);Mt={t:0,dur:t.dur??It.clamp(1.3+r/380,1.3,5),arc:o,fromPos:n,fromTarget:s,toPos:i.clone(),toTarget:e.clone(),done:t.done}}function ls(i,e=!0){tt=i;for(let t of document.querySelectorAll("#mode button"))t.setAttribute("aria-pressed",String(t.dataset.mode===i));if(me("pad").hidden=!(i==="walk"&&Vn),i==="walk"){Mt=null,nt.enabled=!1;let t=new R;xe.getWorldDirection(t),e&&(xe.position.y>4+sn(xe.position.x,xe.position.z)?W.pos.copy(nt.target):W.pos.copy(xe.position),W.pos.y=sn(W.pos.x,W.pos.z)+sr),W.yaw=W.tyaw=Math.atan2(-t.x,-t.z),W.pitch=W.tpitch=0}else{Qn()&&document.exitPointerLock(),W.glide=null;let t=new R(-Math.sin(W.yaw),0,-Math.cos(W.yaw));e&&nt.target.copy(xe.position).addScaledVector(t,20).setY(1.5),nt.enabled=!0}sl()}function sl(){let i=me("hint");tt==="walk"?i.innerHTML=Vn?"<strong>Walking</strong>. Hold the arrows to walk, tap \u26A1 to run, drag to look around, double-tap a spot to go there.":Qn()?"<strong>Mouse-look</strong>: move the mouse to look, hold the left button (or W) to walk, right button to step back, double-click to go where the circle points. <strong>Esc</strong> to free the mouse.":"<strong>Walking</strong>: the view follows your mouse. W A S D to walk, Shift to run. <strong>Click</strong> for full mouse-look, double-click a spot to go there.":i.innerHTML=nl?Vn?"<strong>Pan</strong>: drag to move across the city, pinch to zoom.":"<strong>Pan</strong>: drag to move across the city, scroll to zoom, right-drag to turn.":Vn?"Drag to look around, pinch to zoom, two fingers to move. Double-tap a spot to go there.":"Drag to look around (at street level the view turns where you stand), scroll to zoom, right-drag to move. Double-click a spot to go there."}var Wo=.0024,vn=null,Zn=null,er=null,Qn=()=>document.pointerLockElement===Vt;function Ch(i,e){W.tyaw-=i*Wo,W.tpitch=It.clamp(W.tpitch-e*Wo,-1.25,1.25)}function Jv(i,e){let t=nt.target.clone().sub(xe.position),n=Math.max(4,t.length()),s=Math.atan2(t.x,t.z),r=Math.asin(It.clamp(t.y/n,-1,1));s-=i*Wo,r=It.clamp(r-e*Wo,-1.2,1.2),t.set(Math.sin(s)*Math.cos(r),Math.sin(r),Math.cos(s)*Math.cos(r)).multiplyScalar(n),nt.target.copy(xe.position).add(t)}Vt.addEventListener("pointerdown",i=>{if(tt==="walk"){if(W.glide=null,Qn()){i.button===0&&W.keys.add("mf"),i.button===2&&W.keys.add("mb");return}vn={x:i.clientX,y:i.clientY,x0:i.clientX,y0:i.clientY,id:i.pointerId,type:i.pointerType},Vt.setPointerCapture(i.pointerId);return}!nl&&i.button===0&&xe.position.y<9&&i.isPrimary&&(Zn={x:i.clientX,y:i.clientY,id:i.pointerId},nt.enableRotate=!1,Mt=null)},!0);Vt.addEventListener("pointermove",i=>{if(tt==="walk"){if(Qn()){Ch(i.movementX||0,i.movementY||0);return}if(vn&&i.pointerId===vn.id){Ch(i.clientX-vn.x,i.clientY-vn.y),vn.x=i.clientX,vn.y=i.clientY;return}i.pointerType==="mouse"&&i.buttons===0&&(er&&Ch((i.clientX-er.x)*.9,(i.clientY-er.y)*.9),er={x:i.clientX,y:i.clientY});return}Zn&&i.pointerId===Zn.id&&(Jv(i.clientX-Zn.x,i.clientY-Zn.y),Zn.x=i.clientX,Zn.y=i.clientY)});Vt.addEventListener("pointerleave",()=>{er=null});var _p=i=>{if(vn&&i.pointerId===vn.id){if(Math.hypot(i.clientX-vn.x0,i.clientY-vn.y0)<5&&vn.type==="mouse"&&i.type==="pointerup"&&tt==="walk"&&!Qn()&&Vt.requestPointerLock)try{let t=Vt.requestPointerLock();t&&t.catch&&t.catch(()=>{})}catch{}vn=null}Zn&&i.pointerId===Zn.id&&(Zn=null,nt.enableRotate=!0),i.button===0&&W.keys.delete("mf"),i.button===2&&W.keys.delete("mb")};Vt.addEventListener("pointerup",_p);Vt.addEventListener("pointercancel",_p);Vt.addEventListener("contextmenu",i=>{tt==="walk"&&Qn()&&i.preventDefault()});document.addEventListener("pointerlockchange",()=>{me("crosshair").hidden=!Qn(),Qn()||(W.keys.delete("mf"),W.keys.delete("mb")),er=null,sl()});var kf=new Hr,xp=[];Vt.addEventListener("dblclick",i=>{let e=Vt.getBoundingClientRect(),t=Qn()?new he(0,0):new he((i.clientX-e.left)/e.width*2-1,-((i.clientY-e.top)/e.height)*2+1);W.keys.delete("mf"),kf.setFromCamera(t,xe);let n=kf.intersectObjects(xp,!1)[0];if(!n)return;let s=n.point.clone();if(tt==="walk"){let l=n.face?n.face.normal.clone().transformDirection(n.object.matrixWorld):new R(0,1,0);Math.abs(l.y)<.5&&s.addScaledVector(new R(l.x,0,l.z).normalize(),1.2);let c=new R(s.x,W.pos.y,s.z),h=c.distanceTo(W.pos);h>.5&&(W.glide={from:W.pos.clone(),to:c,t:0,dur:Math.min(8,.6+h/4)});return}rt.on&&aa();let r=xe.position.clone().sub(s),o=It.clamp(r.length()*.45,6,90),a=s.clone().add(r.normalize().multiplyScalar(o));a.y=Math.max(a.y,s.y+1.6),ia(a,s,{arc:0})});var Xo={KeyW:"f",ArrowUp:"f",KeyS:"b",ArrowDown:"b",KeyA:"l",ArrowLeft:"l",KeyD:"r",ArrowRight:"r"};window.addEventListener("keydown",i=>{i.target.closest&&i.target.closest("button")||(Xo[i.code]&&tt==="walk"&&(W.keys.add(Xo[i.code]),i.preventDefault()),i.key==="Shift"&&W.keys.add("run"))});window.addEventListener("keyup",i=>{Xo[i.code]&&W.keys.delete(Xo[i.code]),i.key==="Shift"&&W.keys.delete("run")});window.addEventListener("blur",()=>W.keys.clear());for(let i of document.querySelectorAll("#pad button[data-move]")){let e=n=>{n.preventDefault(),W.keys.add(i.dataset.move),i.classList.add("on")},t=()=>{W.keys.delete(i.dataset.move),i.classList.remove("on")};i.addEventListener("pointerdown",e),i.addEventListener("pointerup",t),i.addEventListener("pointerleave",t),i.addEventListener("pointercancel",t)}me("tod").addEventListener("click",i=>{let e=i.target.closest("button");e&&mp(e.dataset.tod)});me("mode").addEventListener("click",i=>{let e=i.target.closest("button");e&&e.dataset.mode!==tt&&ls(e.dataset.mode)});var su=me("views");for(let i of $r){let e=document.createElement("button");e.type="button",e.dataset.view=i.id,e.textContent=i.label,e.setAttribute("aria-pressed","false"),e.addEventListener("click",()=>il(i.id)),su.appendChild(e)}if(Gn!=="oldcity"){let i=document.querySelector(".brand");i.querySelector(".mr").textContent=In.mr,i.querySelector(".en").textContent=In.en,i.querySelector(".coord").textContent=In.coord,document.title=In.en+" 3D"}function Qv(i){if(i===Gn){sa(!1);return}location.hash="place="+i,setTimeout(()=>location.reload(),400)}function sa(i){me("placesPanel").hidden=!i,me("placesBtn").setAttribute("aria-expanded",String(i)),i&&me("placesList").querySelector('[aria-current="true"]')?.focus()}for(let[i,e]of Object.entries(jr)){let t=document.createElement("button");t.type="button",t.className="placeItem",t.setAttribute("aria-current",String(i===Gn)),t.innerHTML='<span class="pm" lang="mr"></span><span class="pe"></span><span class="pb"></span>',t.querySelector(".pm").textContent=e.mr,t.querySelector(".pe").textContent=e.en,t.querySelector(".pb").textContent=e.blurb,t.addEventListener("click",()=>Qv(i)),me("placesList").append(t)}me("placesBtn").addEventListener("click",()=>sa(me("placesPanel").hidden));Object.keys(jr).length<2&&(me("placesBtn").hidden=!0);me("placesClose").addEventListener("click",()=>sa(!1));window.addEventListener("keydown",i=>{i.key==="Escape"&&!me("placesPanel").hidden&&sa(!1)});window.addEventListener("hashchange",()=>{let i=(/(?:^|[#&])place=([\w-]+)/.exec(location.hash)||[])[1]||"oldcity";if(i!==Gn&&jr[i]){location.reload();return}let e=location.hash.slice(1).split("&")[0];$r.some(t=>t.id===e)&&il(e)});function yp(){let i=window.innerWidth,e=window.innerHeight;try{Yo()}catch{}Ht.setSize(i,e,!1),xe.aspect=i/Math.max(1,e),xe.fov=xe.aspect<1?72:55,xe.updateProjectionMatrix(),ra()}function ra(){document.documentElement.style.setProperty("--hud-h",`${me("hudBottom").offsetHeight+34}px`)}window.addEventListener("resize",yp);yp();var xi=me("radarCanvas"),eb=xi.getContext("2d"),ft=null,_i=!1,Hh=0,vp=null;function sn(i,e){let t=vp;if(!t)return 0;let n=(i-t.x0)/t.cell,s=(e-t.z0)/t.cell;if(n<0||s<0||n>=t.nx-1||s>=t.nz-1)return 0;let r=Math.floor(n),o=Math.floor(s),a=n-r,l=s-o,c=t.h,h=t.nx;return(c[o*h+r]*(1-a)+c[o*h+r+1]*a)*(1-l)+(c[(o+1)*h+r]*(1-a)+c[(o+1)*h+r+1]*a)*l}var tb=fetch(ss+"wada_map.json").then(i=>i.ok?i.json():null).then(i=>{if(i){i.bc=i.buildings.map(e=>{let t=0,n=0;for(let s=0;s<e.length;s+=2)t+=e[s],n+=e[s+1];return[t/(e.length/2),n/(e.length/2)]}),ft=i,vp=i&&i.terrain?i.terrain:null;for(let e of i.landmarks)/Ganpati|Mandir|Temple/i.test(e.name)&&nr.temples.push({x:e.x,z:e.z}),/Ganpati|Mandir|Darwaza|Lal Mahal|Mandai|Laxmi Road/i.test(e.name)&&nr.markets.push({x:e.x,z:e.z});for(let e of i.water)for(let t=0;t<e.length;t+=8)nr.river.push({x:e[t],z:e[t+1]})}}).catch(()=>{});me("radar").addEventListener("click",i=>{let e=xi.getBoundingClientRect(),t=xi.width/Math.max(1,e.width),n=(i.clientX-e.left)*t-xi.width/2,s=(i.clientY-e.top)*t-xi.height/2,r=null,o=16*t;for(let a of Wh){let l=Math.hypot(a.X-n,a.Y-s);l<o&&(o=l,r=a)}if(r&&i.detail!==0&&!Z.on){let a=Fb[r.name];rt.on&&aa(),a?il(a):ia(new R(r.x+60,50,r.z+60),new R(r.x,8,r.z));return}_i=!_i,Hh=0});function nb(i,e,t){if(i-Hh<66)return;Hh=i;let n=xi.clientWidth;if(!n)return;let s=Math.min(window.devicePixelRatio||1,2),r=Math.round(n*s);xi.width!==r&&(xi.width=xi.height=r);let o=r/2,a=eb,l=xe.position.y>60,c=_i?600:l?Math.min(600,150+xe.position.y*.5):150,h=(o-4*s)/c,u=_i?0:e.x,d=_i?0:e.z,p=_i?0:t;me("radarTag").textContent=_i?"Tap a place to fly there":`Radar \xB7 ${Math.round(c)} m`,a.save(),a.clearRect(0,0,r,r),a.beginPath(),a.arc(o,o,o-s,0,Math.PI*2),a.clip(),a.fillStyle="rgba(2, 14, 12, 0.88)",a.fillRect(0,0,r,r),a.translate(o,o),a.rotate(p);let g=(E,w,T)=>Math.abs(E-u)<c+T&&Math.abs(w-d)<c+T,f=E=>{a.beginPath();for(let w=0;w<E.length;w+=2){let T=(E[w]-u)*h,D=(E[w+1]-d)*h;w===0?a.moveTo(T,D):a.lineTo(T,D)}a.closePath()};if(ft){a.fillStyle="rgba(0, 150, 190, 0.38)";for(let E of ft.water)f(E),a.fill();a.fillStyle="rgba(0, 170, 90, 0.20)";for(let E of ft.green)f(E),a.fill();a.strokeStyle="rgba(0, 255, 190, 0.32)",a.fillStyle="rgba(0, 255, 190, 0.05)",a.lineWidth=s*.8,ft.buildings.forEach((E,w)=>{let T=ft.bc[w];g(T[0],T[1],40)&&(f(E),a.fill(),a.stroke())}),a.lineCap="round";for(let[E,w,T,D,v,S]of ft.roads)!g(E,w,60)&&!g(T,D,60)||(a.strokeStyle=S===0?"rgba(0, 229, 255, 0.9)":"rgba(0, 229, 255, 0.35)",a.lineWidth=Math.max(s,Math.min(v*h*.7,7*s)),a.beginPath(),a.moveTo((E-u)*h,(w-d)*h),a.lineTo((T-u)*h,(D-d)*h),a.stroke());ft.fort.length&&(a.shadowColor="#ffb347",a.shadowBlur=8*s,a.strokeStyle="#ffc06a",a.lineWidth=2.4*s,f(ft.fort),a.stroke(),a.shadowBlur=0)}a.restore(),a.save(),a.translate(o,o),a.strokeStyle="rgba(0, 255, 170, 0.16)",a.lineWidth=s;for(let E of[.33,.66])a.beginPath(),a.arc(0,0,(o-4*s)*E,0,Math.PI*2),a.stroke();if(!fn){let E=i/1e3*1.3;a.fillStyle="rgba(0, 255, 170, 0.10)",a.beginPath(),a.moveTo(0,0),a.arc(0,0,o,E-.55,E),a.closePath(),a.fill(),a.strokeStyle="rgba(120, 255, 210, 0.55)",a.lineWidth=1.2*s,a.beginPath(),a.moveTo(0,0),a.lineTo(Math.cos(E)*o,Math.sin(E)*o),a.stroke()}let _=(E,w)=>{let T=(E-u)*h,D=(w-d)*h;return[T*Math.cos(p)-D*Math.sin(p),T*Math.sin(p)+D*Math.cos(p)]};if(ft){let E=.5+.5*Math.sin(i/300);a.font=`${10*s}px Inter, system-ui, sans-serif`,a.textAlign="center",Wh=[];for(let w of ft.landmarks){let[T,D]=_(w.x,w.z);Math.hypot(T,D)>o-6*s||(Wh.push({X:T,Y:D,name:w.name,x:w.x,z:w.z}),a.fillStyle=`rgba(255, 190, 90, ${.35+.4*E})`,a.beginPath(),a.arc(T,D,(4+3*E)*s,0,Math.PI*2),a.fill(),a.fillStyle="#ffd08a",a.beginPath(),a.arc(T,D,2.4*s,0,Math.PI*2),a.fill(),a.fillStyle="rgba(255, 225, 170, 0.95)",a.fillText(w.name,T,D-7*s))}}if(Z.on&&Z.spot){let[E,w]=_(Z.spot.x,Z.spot.z),T=Math.hypot(E,w),D=o-11*s,v=.5+.5*Math.sin(i/220);if(a.save(),a.shadowColor="#ffc35a",a.shadowBlur=12*s,a.fillStyle="#ffd36b",T>D)E*=D/T,w*=D/T,a.translate(E,w),a.rotate(Math.atan2(w,E)),a.beginPath(),a.moveTo(8*s,0),a.lineTo(-5*s,6*s),a.lineTo(-5*s,-6*s),a.closePath(),a.fill();else{a.strokeStyle=`rgba(255, 211, 107, ${.4+.5*v})`,a.lineWidth=2*s,a.beginPath(),a.arc(E,w,(8+5*v)*s,0,Math.PI*2),a.stroke(),a.translate(E,w),a.beginPath();for(let S=0;S<10;S++){let N=-Math.PI/2+S*Math.PI/5,O=(S%2?2.6:6.5)*s;S?a.lineTo(Math.cos(N)*O,Math.sin(N)*O):a.moveTo(Math.cos(N)*O,Math.sin(N)*O)}a.closePath(),a.fill()}a.restore()}let[m,y]=_i?_(e.x,e.z):[0,0],x=_i?-t:0;a.save(),a.translate(m,y),a.rotate(x),a.fillStyle="rgba(125, 255, 208, 0.12)",a.beginPath(),a.moveTo(0,0),a.arc(0,0,34*s,-Math.PI/2-.5,-Math.PI/2+.5),a.closePath(),a.fill(),a.shadowColor="#7dffd0",a.shadowBlur=8*s,a.fillStyle="#eafff7",a.beginPath(),a.moveTo(0,-8*s),a.lineTo(5.5*s,6*s),a.lineTo(0,3*s),a.lineTo(-5.5*s,6*s),a.closePath(),a.fill(),a.restore();let b=-Math.PI/2+p;a.fillStyle="#7dffd0",a.font=`600 ${10*s}px Inter, system-ui, sans-serif`,a.textAlign="center",a.textBaseline="middle",a.fillText("N",Math.cos(b)*(o-10*s),Math.sin(b)*(o-10*s)),a.restore(),a.beginPath(),a.arc(o,o,o-s,0,Math.PI*2),a.strokeStyle="rgba(125, 255, 208, 0.75)",a.lineWidth=1.5*s,a.stroke()}var zf={scooter:{v:7.5,minW:3},motorbike:{v:8.5,minW:3},delivery:{v:8,minW:3},auto:{v:6.5,minW:5},hatch:{v:7.2,minW:6.5},sedan:{v:7.6,minW:6.5},cab:{v:7.4,minW:6.5},suv:{v:7.6,minW:7},bus:{v:5.5,minW:9},shuttle:{v:6.5,minW:8}},Vh=Vn?260:450,ib=2*Math.PI/1.4,dn=null,xt=[];function bp(i){let e=i.geometry,t=e.attributes.position,n=new Float32Array(t.count*3),s=new R;for(let a=0;a<t.count;a++)s.fromBufferAttribute(t,a).applyMatrix4(i.matrixWorld),n[a*3]=s.x,n[a*3+1]=s.y,n[a*3+2]=s.z;let r=new At;r.setAttribute("position",new Et(n,3));let o=e.attributes.color;return e.attributes.color_1&&iu(o)&&(o=e.attributes.color_1),o&&r.setAttribute("color",o),e.index&&r.setIndex(e.index),r}function sb(i){if(!Fo||!i||!i.nodes||!i.nodes.length)return;Fo.updateMatrixWorld(!0);let e=i.nodes,t=e.length/3,n=i.edges.length/5,s={nodes:e,ea:new Int32Array(n),eb:new Int32Array(n),ew:new Float32Array(n),ek:new Uint8Array(n),efp:new Uint8Array(n),elen:new Float32Array(n),adj:Array.from({length:t},()=>[]),centre:i.centre||[0,0],leash:i.leash||260,gates:[],homes:i.homes||[[...i.centre||[0,0],i.leash||260]]};for(let f=0;f<n;f++){let _=i.edges[f*5],m=i.edges[f*5+1];s.ea[f]=_,s.eb[f]=m,s.ew[f]=i.edges[f*5+2],s.ek[f]=i.edges[f*5+3],s.efp[f]=i.edges[f*5+4],s.elen[f]=Math.max(.05,Math.hypot(e[m*3]-e[_*3],e[m*3+2]-e[_*3+2])),s.adj[_].push(f),s.adj[m].push(f)}s.cgrid=new Map;for(let f=0;f<n;f++){if(s.ek[f]!==0||s.ew[f]<3)continue;let _=s.ea[f],m=s.eb[f];for(let y=Math.floor(Math.min(e[_*3],e[m*3])/20);y<=Math.floor(Math.max(e[_*3],e[m*3])/20);y++)for(let x=Math.floor(Math.min(e[_*3+2],e[m*3+2])/20);x<=Math.floor(Math.max(e[_*3+2],e[m*3+2])/20);x++){let b=y+","+x;s.cgrid.has(b)||s.cgrid.set(b,[]),s.cgrid.get(b).push(f)}}let r=1/0,o=-1/0,a=1/0,l=-1/0;for(let f=0;f<t;f++)r=Math.min(r,e[f*3]),o=Math.max(o,e[f*3]),a=Math.min(a,e[f*3+2]),l=Math.max(l,e[f*3+2]);for(let f=0;f<t;f++){if(s.adj[f].length!==1||s.ek[s.adj[f][0]]!==0||s.ew[s.adj[f][0]]<5)continue;let _=e[f*3],m=e[f*3+2];(_-r<3||o-_<3||m-a<3||l-m<3)&&s.gates.push(f)}let c=i.protos.map(f=>{let _=Fo.getObjectByName(f.name),m=[];return _&&_.traverse(y=>{y.isMesh&&m.push({geo:bp(y),mat:y.material?.name||""})}),{p:f,parts:m,members:[],meshes:[],step:null}}),h=[],u=f=>{c[f.pid]&&c[f.pid].parts.length&&(c[f.pid].members.push(f),h.push(f))};for(let f=0;f<i.vehicles.length;f+=6){let[_,m,y,x,b,E]=i.vehicles.slice(f,f+6),w=i.protos[_];if(!w||m>=n)continue;let T=zf[w.kind]||zf.hatch;u({pid:_,car:!0,e:m,dir:x,s:y*s.elen[m],near:E|0,lane:It.clamp(b/Math.max(1,s.ew[m]/2),.25,.9),vmax:T.v*(.85+Math.random()*.3),minW:T.minW,v:T.v*.6,hl:w.half[0],hw:w.half[1],stuck:0,ignore:0,x:0,y:0,z:0,dx:1,dz:0,rx:0,ry:0,rz:0,hx:1,hz:0,snap:!0})}let d=i.people||[],p=0,g=0;for(let f=0;f<d.length;f+=5){let[_,m,y,x,b]=d.slice(f,f+5),E=i.protos[_];if(!E)continue;let w=m,T=-y,D=Math.cos(b),v=-Math.sin(b);if(x<.6){let S=E.type==="v",N=E.half?.[0]||.5,O=E.half?.[1]||.3,j=S?N:E.type==="g"?.45:.3,L=Sp(s,w,T,j,S?O:null);if(!L){g++;continue}(L.x!==w||L.z!==T)&&p++,w=L.x,T=L.z,L.turn&&(D=L.ux,v=L.uz)}E.type==="v"&&xt.push(w,T,(E.half?.[0]||1.5)+.7),u({pid:_,still:!0,car:!1,x:w,y:x,z:T,rx:w,ry:x,rz:T,hx:D,hz:v,step:0,phase:Math.random()*6.28,v:0})}console.info(`traffic: ${p} people and parked vehicles moved out of the lanes, ${g} left out`);for(let f=0;f<i.walkers.length;f+=7){let[_,m,y,x,b,E,w]=i.walkers.slice(f,f+7),T=i.protos[_];!T||m>=n||u({pid:_,car:!1,e:m,dir:x,s:y*s.elen[m],near:w|0,side:b,jit:E,v:(T.kind==="child"?1:1.05)+Math.random()*.45,step:Math.random()*6.28,x:0,y:0,z:0,dx:1,dz:0,rx:0,ry:0,rz:0,hx:1,hz:0,snap:!0})}for(let f of c){let _=f.members.length;if(!_)continue;let m=null;for(let y of f.parts){let x;y.mat==="City_Lamp"?x=Qo:y.mat==="City_TailLamp"?x=el:f.p.type==="p"?x=f.walkMat||(f.walkMat=Vv(f.p.hip,f.p.shoulder)):(f.p.type==="s"||f.p.type,x=zo("Life_Paint")),f.p.type==="p"&&(f.step=f.step||new di(new Float32Array(_),1),y.geo.setAttribute("aStep",f.step));let b=new Kn(y.geo,x,_);m?b.instanceMatrix=m:m=b.instanceMatrix,b.instanceMatrix.setUsage(Wr),b.frustumCulled=!1,b.castShadow=y.mat!=="City_Lamp"&&y.mat!=="City_TailLamp",b.receiveShadow=!0,b.count=0,mt.add(b),f.meshes.push(b)}f.matrix=m}dn={G:s,groups:c,movers:h,cars:h.filter(f=>f.car),grid:new Map,pgrid:new Map},window.__wada=()=>({movers:h.length,cars:dn.cars.length,drawn:c.reduce((f,_)=>f+(_.meshes[0]?.count||0),0),moving:dn.cars.filter(f=>f.v>1).length,trains:Jr.map(f=>`${f.state} s=${f.s.toFixed(0)}/${f.L.toFixed(0)} v=${f.v.toFixed(1)} vis=${f.cars.filter(_=>_.visible).length}`),boards:nu.length,coaches:Object.keys(Go)}),window.__wadaCam=()=>({mode:tt,x:+xe.position.x.toFixed(2),y:+xe.position.y.toFixed(2),z:+xe.position.z.toFixed(2),yaw:+W.yaw.toFixed(3),tyaw:+W.tyaw.toFixed(3),tx:+nt.target.x.toFixed(2),tz:+nt.target.z.toFixed(2),wx:+W.pos.x.toFixed(2),wz:+W.pos.z.toFixed(2),glide:!!W.glide,flight:!!Mt}),window.__wadaLook=(f,_,m,y,x,b)=>{tt==="walk"&&ls("orbit",!1),xe.position.set(f,_,m),nt.target.set(y,x,b),nt.update()},window.__wadaTrainNow=(f=0,_=0)=>{let m=Jr[f];m&&(m.state="run",m.s=_,m.v=12,m.stopFront=m.stopBase,m.dwell=0)};for(let f of h)f.still||Ep(s,f)}var rb=(()=>{let i=document.createElement("canvas");i.width=64,i.height=128;let e=i.getContext("2d"),t=e.createRadialGradient(32,112,4,32,70,70);t.addColorStop(0,"rgba(255,236,200,0.95)"),t.addColorStop(.45,"rgba(255,214,160,0.35)"),t.addColorStop(1,"rgba(255,200,140,0)"),e.fillStyle=t,e.fillRect(0,0,64,128);let n=new Ur(i);return n.colorSpace=ut,n})(),ab=new es(2.6,7.5).rotateX(-Math.PI/2).rotateY(-Math.PI/2).translate(3.75,.07,0),Mp=new Kt({map:rb,transparent:!0,depthWrite:!1,blending:wr,opacity:0,fog:!0}),wp=220,yi=new Kn(ab,Mp,wp);yi.frustumCulled=!1;yi.count=0;yi.renderOrder=2;yi.instanceMatrix.setUsage(Wr);mt.add(yi);function ob(i){let e=ar[or].night;if(Mp.opacity=e*.55,!dn||e<=0){yi.count=0;return}let t=yi.instanceMatrix.array,n=0;for(let s of dn.cars){if(n>=wp)break;let r=s.rx-i.x,o=s.rz-i.z;if(r*r+o*o>200*200)continue;let a=n*16,l=s.hx,c=s.hz,h=s.rx+l*s.hl,u=s.rz+c*s.hl;t[a]=l,t[a+1]=0,t[a+2]=c,t[a+3]=0,t[a+4]=0,t[a+5]=1,t[a+6]=0,t[a+7]=0,t[a+8]=-c,t[a+9]=0,t[a+10]=l,t[a+11]=0,t[a+12]=h,t[a+13]=s.ry,t[a+14]=u,t[a+15]=1,n++}yi.count=n,yi.instanceMatrix.needsUpdate=!0}function lb(i,e){let t=i.ew[e.e],n=e.hw||.86,s=i.efp[e.e]?t/2-.2:t/2-1.3,r=n+.06;return Math.min(Math.max(r,s-n-.05),Math.max(r,e.lane*t/2))}function cb(i,e){let t=i.ew[e],n=i.efp[e]?t/2-.2:t/2-1.3,s=t>=9?1.27:t>=6.5?.86:t>=5?.66:.35;return Math.max(2*s+.06,n-.05)}function Sp(i,e,t,n,s){let r=null,o=Math.floor(e/20),a=Math.floor(t/20),l=i.nodes;for(let p=o-1;p<=o+1;p++)for(let g=a-1;g<=a+1;g++)for(let f of i.cgrid.get(p+","+g)||[]){let _=i.ea[f],m=i.eb[f],y=l[_*3],x=l[_*3+2],b=l[m*3]-y,E=l[m*3+2]-x,w=b*b+E*E||1e-9,T=Math.max(0,Math.min(1,((e-y)*b+(t-x)*E)/w)),D=y+b*T,v=x+E*T,S=Math.hypot(e-D,t-v);(!r||S<r.d)&&(r={e:f,d:S,qx:D,qz:v,ux:b/Math.sqrt(w),uz:E/Math.sqrt(w)})}if(!r)return{x:e,z:t,turn:!1};let c=cb(i,r.e)+.05;if(r.d-n>=c)return{x:e,z:t,turn:!1};let h=e-r.qx,u=t-r.qz,d=Math.hypot(h,u);d>.001?(h/=d,u/=d):(h=-r.uz,u=r.ux);for(let[p,g]of[[n,!1],[s,!0]]){if(p==null)continue;let f=c+p,_=r.qx+h*f,m=r.qz+u*f;if(ea(_,m,!1))return{x:_,z:m,turn:g,ux:r.ux,uz:r.uz}}return null}function hb(i,e){let t=e.e,n=i.ew[t];return i.ek[t]!==0?e.jit*n*.25*e.side:i.efp[t]?(n/2+1.2+e.jit*.6)*e.side:Math.max(.3,n/2-.55+e.jit*.2)*e.side}function Ep(i,e){let t=e.e,n=i.nodes,s=e.dir>0?i.ea[t]:i.eb[t],r=e.dir>0?i.eb[t]:i.ea[t],o=i.elen[t],a=(n[r*3]-n[s*3])/o,l=(n[r*3+2]-n[s*3+2])/o,c=e.car?lb(i,e):hb(i,e),h=Math.min(e.s,o);e.dx=a,e.dz=l,e.x=n[s*3]+a*h+l*c,e.z=n[s*3+2]+l*h-a*c;let u=n[s*3+1]+(n[r*3+1]-n[s*3+1])*(h/o);e.car||(u=i.efp[t]&&h>3.5&&h<o-3.5?u+.14:Math.max(.03,u)),e.y=u,e.snap&&(e.rx=e.x,e.ry=e.y,e.rz=e.z,e.hx=a,e.hz=l,e.snap=!1)}function ub(i,e){let t=e.e,n=i.nodes,s=i.elen[t],r=e.dir>0?i.eb[t]:i.ea[t],o=e.dir>0?i.ea[t]:i.eb[t],a=(n[r*3]-n[o*3])/s,l=(n[r*3+2]-n[o*3+2])/s,c=[],h=0,u=Math.hypot(n[r*3]-i.centre[0],n[r*3+2]-i.centre[1]);for(let g of i.adj[r]){if(g===t||e.car&&(i.ek[g]!==0||i.ew[g]<e.minW))continue;let f=i.ea[g]===r?i.eb[g]:i.ea[g],_=i.elen[g],m=(n[f*3]-n[r*3])/_,y=(n[f*3+2]-n[r*3+2])/_,x=(e.car?Math.min(i.ew[g],14):1)*Math.max(.05,1.15+m*a+y*l);if(e.near){let b=i.homes[(e.near|0)-1]||i.homes[0],E=Math.hypot(n[f*3]-b[0],n[f*3+2]-b[1]),w=Math.hypot(n[r*3]-b[0],n[r*3+2]-b[1]);E>b[2]&&E>w&&(x*=.05)}c.push(g),c.push(x),h+=x}if(e.s-=s,!c.length){if(e.car&&i.gates.length&&i.gates.includes(r)){let g=i.gates[Math.floor(Math.random()*i.gates.length)];e.e=i.adj[g][0],e.dir=i.ea[e.e]===g?1:-1,e.s=0,e.snap=!0;return}e.dir=-e.dir,e.s=0;return}let d=Math.random()*h,p=c[0];for(let g=0;g<c.length&&(p=c[g],d-=c[g+1],!(d<=0));g+=2);e.dir=i.ea[p]===r?1:-1,e.e=p,e.s=Math.max(0,e.s)}function Tp(i,e,t){if(!dn)return;fn&&(i=0);let{G:n,groups:s,movers:r,cars:o,grid:a}=dn;a.clear();let l=12;for(let g=0;g<o.length;g++){let f=o[g],_=(Math.floor(f.x/l)+500)*2e3+Math.floor(f.z/l)+500,m=a.get(_);m||a.set(_,m=[]),m.push(g)}let c=dn.pgrid;c.clear();for(let g of r){if(g.car||g.still)continue;let f=(Math.floor(g.x/l)+500)*2e3+Math.floor(g.z/l)+500,_=c.get(f);_||c.set(f,_=[]),_.push(g)}let h=[];if(re.ready){re.guide?.root.visible&&h.push(re.guide.root.position);for(let g of re.extras)g.root.visible&&h.push(g.root.position)}let u=tt==="walk"?W.pos:null;for(let g=0;g<o.length;g++){let f=o[g],_=99;if(f.ignore<=0){let x=Math.floor(f.x/l)+500,b=Math.floor(f.z/l)+500;for(let E=-1;E<=1;E++)for(let w=-1;w<=1;w++){let T=a.get((x+E)*2e3+b+w);if(T)for(let v of T){if(v===g)continue;let S=o[v],N=S.x-f.x,O=S.z-f.z,j=N*f.dx+O*f.dz;j<=0||j>22||S.dx*f.dx+S.dz*f.dz<-.5||Math.abs(N*f.dz-O*f.dx)>f.hw+S.hw+.12||(_=Math.min(_,j-f.hl-S.hl))}let D=c.get((x+E)*2e3+b+w);if(D)for(let v of D){let S=v.x-f.x,N=v.z-f.z,O=S*f.dx+N*f.dz;O<=0||O>14||Math.abs(S*f.dz-N*f.dx)>f.hw+.3||(_=Math.min(_,O-f.hl-.45))}}for(let E of h){let w=E.x-f.x,T=E.z-f.z,D=w*f.dx+T*f.dz;D>0&&D<16&&Math.abs(w*f.dz-T*f.dx)<f.hw+.45&&(_=Math.min(_,D-f.hl-.5))}if(u){let E=u.x-f.x,w=u.z-f.z,T=E*f.dx+w*f.dz;T>0&&T<22&&Math.abs(E*f.dz-w*f.dx)<f.hw+.6&&(_=Math.min(_,T-f.hl-.4))}}let m=f.vmax*(n.ew[f.e]<6?.65:1),y=Math.min(m,Math.max(0,(_-1.2)*1.3));if(f.v+=It.clamp(y-f.v,-7*i,2.2*i),f.v<.25?f.stuck+=i:f.stuck=0,f.stuck>4&&!(u&&_<3)){let x=f.x-e.x,b=f.z-e.z;x*x+b*b>8100?(f.ignore=2.5,f.stuck=0):f.stuck>12&&(f.dir=-f.dir,f.s=Math.max(0,n.elen[f.e]-f.s),f.stuck=0,f.v=0)}f.ignore-=i}let d=t/1e3;for(let g of r){if(g.still){g.step=.22*Math.sin(d*.7+g.phase);continue}g.s+=g.v*i;for(let b=0;b<4&&g.s>n.elen[g.e];b++)ub(n,g);Ep(n,g),g.car||(g.step+=g.v*i*ib);let f=Math.min(1,i*(g.car?5:6));g.rx+=(g.x-g.rx)*f,g.ry+=(g.y-g.ry)*f,g.rz+=(g.z-g.rz)*f;let _=g.dx,m=g.dz;g.hx*_+g.hz*m<-.9&&(_-=g.hz*.6,m+=g.hx*.6);let y=Math.min(1,i*(g.car?4:6));g.hx+=(_-g.hx)*y,g.hz+=(m-g.hz)*y;let x=Math.hypot(g.hx,g.hz)||1;g.hx/=x,g.hz/=x}let p=Vh*Vh;for(let g of s){if(!g.matrix)continue;let f=g.matrix.array,_=g.step?g.step.array:null,m=0;for(let y of g.members){let x=y.rx-e.x,b=y.rz-e.z;if(x*x+b*b>p)continue;let E=m*16;f[E]=y.hx,f[E+1]=0,f[E+2]=y.hz,f[E+3]=0,f[E+4]=0,f[E+5]=1,f[E+6]=0,f[E+7]=0,f[E+8]=-y.hz,f[E+9]=0,f[E+10]=y.hx,f[E+11]=0,f[E+12]=y.rx,f[E+13]=y.ry,f[E+14]=y.rz,f[E+15]=1,_&&(_[m]=y.step),m++}g.matrix.needsUpdate=!0,g.step&&(g.step.needsUpdate=!0);for(let y of g.meshes)y.count=m}}function db(i){if(!Bo||!i)return;Bo.updateMatrixWorld(!0);let e=new ke,t=new ct,n=new R,s=new R,r=new R(0,1,0),o=0,a=0;for(let[l,c]of Object.entries(i)){let h=Bo.getObjectByName(l);if(!h||!c.length)continue;let u=/^Prop_Tree_/.test(l);if(dn&&/^Prop_(Old_(scooter|motorbike|Cart|auto|Shop)|Shop_)/.test(l)){let d=/scooter|motorbike/.test(l),p=/auto/.test(l),g=/Cart/.test(l),f=d?.95:p?1.5:g?1:.9,_=d?.38:p?.7:null,m=[];for(let y of c){if(y[2]>.6){m.push(y);continue}let x=Sp(dn.G,y[0],-y[1],f,_);if(!x){a++;continue}let b=y.slice();(x.x!==y[0]||x.z!==-y[1])&&(o++,b[0]=x.x,b[1]=-x.z),x.turn&&(b[3]=Math.atan2(-x.uz,x.ux)),m.push(b),(d||p||g)&&xt.push(x.x,x.z,(x.turn?_:f)+.7)}if(c=m,!c.length)continue}if(h.traverse(d=>{if(!d.isMesh)return;let p=d.material?.name||"",g=bp(d),f=new Kn(g,u&&p==="Grounds_Paint"?tl:hp(zo(p),g),c.length);c.forEach(([_,m,y,x,b,E,w],T)=>{n.set(_,y,-m),t.setFromAxisAngle(r,x),s.set(b,w,E),f.setMatrixAt(T,e.compose(n,t,s))}),f.castShadow=p!=="City_Lamp",f.receiveShadow=!0,f.computeBoundingSphere(),mt.add(f)}),u)for(let d of c)Kr.push(new R(d[0]+(Math.random()-.5)*4,5+Math.random()*3.5,-d[1]+(Math.random()-.5)*4))}console.info(`props: ${o} parked bikes, carts and stalls moved out of the lanes, ${a} left out`)}var ru=42,au=new At;au.setAttribute("position",new st([0,0,-.16,-.32,.02,.02,0,0,.06,0,0,-.16,0,0,.06,.32,.02,.02,0,-.03,-.18,0,.03,.14,0,-.03,.16],3));au.computeVertexNormals();var ou=new $e({color:4869461,roughness:.8,side:yt});ou.customProgramCacheKey=()=>"bird";ou.onBeforeCompile=i=>{i.uniforms.uTime=Zt.uTime,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <begin_vertex>",`#include <begin_vertex>
float bph = float(gl_InstanceID) * 1.37;
float glide = step(0.35, sin(uTime * 0.6 + bph * 0.5));
float beat = sin(uTime * 14.0 + bph) * (1.0 - glide) + 0.15 * glide;
transformed.y += beat * abs(position.x) * 0.9;`)};var rs=new Kn(au,ou,ru);rs.frustumCulled=!1;rs.instanceMatrix.setUsage(Wr);mt.add(rs);var fb=Array.from({length:ru},(i,e)=>({r:30+Math.random()*45,h:18+Math.random()*26,w:(.16+Math.random()*.08)*(e%7===0?-1:1),a:Math.random()*6.28,bob:Math.random()*6.28,s:1.6+Math.random()*.6})),pb=new ke,Hf=new ct,Vf=new R,Gf=new R;function mb(i,e){if(rs.visible=ar[or].night<.5,!rs.visible)return;let t=5,n=10;for(let s=0;s<ru;s++){let r=fb[s];r.a+=r.w*i;let o=Math.sin(e*.13+r.bob)*12;Vf.set(t+Math.cos(r.a)*(r.r+o),r.h+Math.sin(e*.7+r.bob)*3,n+Math.sin(r.a)*(r.r+o));let a=-Math.sin(r.a)*Math.sign(r.w),l=Math.cos(r.a)*Math.sign(r.w);Hf.setFromAxisAngle(new R(0,1,0),Math.atan2(a,l)),Gf.setScalar(r.s),rs.setMatrixAt(s,pb.compose(Vf,Hf,Gf))}rs.instanceMatrix.needsUpdate=!0}var Kr=[];function gb(i){i.updateWorldMatrix(!0,!1);let e=i.geometry.attributes.position,t=new R;for(let n=0;n<e.count;n+=97)t.fromBufferAttribute(e,n).applyMatrix4(i.matrixWorld),t.y>4&&Kr.push(t.clone())}var lu=36,_b=new es(.09,.06),xb=new $e({color:7309868,roughness:.8,side:yt}),Ln=new Kn(_b,xb,lu);Ln.instanceMatrix.setUsage(Wr);Ln.frustumCulled=!1;Ln.count=0;mt.add(Ln);var yb=Array.from({length:lu},()=>({p:new R,wait:Math.random()*20,spin:0,ph:Math.random()*6})),Co=[7309868,9083445,11901498,10251050,6257962],Wf=new ke,Xf=new ct,qf=new zs,vb=new R(1,1,1);function bb(i,e,t){if(!Kr.length)return;let n=0;for(let s=0;s<lu;s++){let r=yb[s];if(r.wait>0){if(r.wait-=i,r.wait<=0){let o=null;for(let a=0;a<12;a++){let l=Kr[Math.floor(Math.random()*Kr.length)];if(Math.abs(l.x-e.x)<70&&Math.abs(l.z-e.z)<70){o=l;break}}if(!o){r.wait=2+Math.random()*4;continue}r.p.copy(o),r.spin=Math.random()*6,r.ph=Math.random()*6,Ln.setColorAt(s,new Re(Co[s%Co.length])),Ln.instanceColor&&(Ln.instanceColor.needsUpdate=!0)}continue}if(r.p.y-=i*(.55+.25*Math.sin(t*1.7+r.ph)),r.p.x+=i*(.35+.5*Math.sin(t*.9+r.ph)),r.p.z+=i*.25*Math.cos(t*1.3+r.ph),r.spin+=i*2.4,r.p.y<.05){r.wait=6+Math.random()*18;continue}qf.set(Math.sin(r.spin)*1.2,r.spin*.7,Math.cos(r.spin*.8)),Xf.setFromEuler(qf),Wf.compose(r.p,Xf,vb),Ln.setMatrixAt(n,Wf),n!==s&&Ln.instanceColor&&Ln.setColorAt(n,new Re(Co[s%Co.length])),n++}Ln.count=n,Ln.instanceMatrix.needsUpdate=!0}var Jr=[],Ap=16.7,Mb=1,wb=20,Sb=95;function Yf(i,e="metro"){if(!i||!i.tracks)return;let t=i.sequence||["Metro_Car_Front","Metro_Car_Middle","Metro_Car_Front"];if(!t.every(r=>Go[r]))return;let n=i.car_length||21.6,s=t.length;i.tracks.forEach((r,o)=>{let a=r.pts.map(([d,p,g])=>new R(d,p,g)),l=[0];for(let d=1;d<a.length;d++)l.push(l[d-1]+a[d].distanceTo(a[d-1]));let c=[];for(let d=0;d<s;d++){let p=new St,g=Go[t[d]].clone();if(d===s-1&&s>1&&/Front/.test(t[d])){let f=new St;f.rotation.y=Math.PI,f.add(g),p.add(f)}else p.add(g);p.visible=!1,mt.add(p),c.push(p)}let h=l[l.length-1],u=r.stop!=null?r.stop+n*s/2+.3*(s-1):null;Jr.push({pts:a,dist:l,L:h,CAR:n,cars:c,n:s,kind:e,stopFront:u,stopBase:u,state:"wait",clock:(e==="metro"?6:14)+o*(e==="metro"?55:70),s:0,v:0,dwell:0,cruise:i.cruise||Ap,accel:i.accel||Mb,dwellTime:i.dwell||wb,gap:i.gap||Sb})})}function Kf(i,e,t){let{pts:n,dist:s}=i;if(e<=0)return t.copy(n[0]);if(e>=i.L)return t.copy(n[n.length-1]);let r=0,o=s.length-1;for(;o-r>1;){let a=r+o>>1;s[a]<e?r=a:o=a}return t.lerpVectors(n[r],n[o],(e-s[r])/Math.max(1e-6,s[o]-s[r]))}var Po=new R,Lo=new R;function Eb(i){for(let e of Jr){if(e.state==="wait"&&(e.clock-=i,e.clock<=0&&(e.state="run",e.s=0,e.dwell=0,e.stopFront=e.stopBase,e.v=e.stopFront!=null?Math.min(e.cruise,Math.sqrt(2*e.accel*Math.max(1,e.stopFront))):e.cruise)),e.state==="run"){if(e.dwell>0)e.dwell-=i,e.dwell<=0&&(e.stopFront=null);else if(e.stopFront!=null){let t=e.stopFront-e.s;e.v=Math.min(e.cruise,e.v+e.accel*i,Math.sqrt(2*e.accel*Math.max(0,t))),t<=.05&&(e.v=0,e.s=e.stopFront,e.dwell=e.dwellTime)}else e.v=Math.min(e.cruise,e.v+e.accel*i);e.s+=e.v*i,e.s-e.n*(e.CAR+.3)>e.L&&(e.state="wait",e.clock=e.gap+Math.random()*30)}e.cars.forEach((t,n)=>{let s=e.s-n*(e.CAR+.3),r=s-e.CAR/2;t.visible=e.state==="run"&&r>0&&r<e.L,t.visible&&(Kf(e,s-3.2,Po),Kf(e,s-e.CAR+3.2,Lo),t.position.addVectors(Po,Lo).multiplyScalar(.5),t.rotation.set(0,Math.atan2(-(Po.z-Lo.z),Po.x-Lo.x),0))})}}var jf={"metro-aqua":{bg:"#0a7f99",fg:"#ffffff",band:"#ffffff"},"metro-purple":{bg:"#5b2a86",fg:"#ffffff",band:"#ffffff"},street:{bg:"#1d4f9c",fg:"#ffffff",band:"#ffffff"},temple:{bg:"#8a1c12",fg:"#ffd27a",band:"#ffd27a"},shop:{bg:"#f2c230",fg:"#5a1208",band:"#5a1208"},heritage:{bg:"#3b2414",fg:"#f3e2b5",band:"#c9a45c"},jeweller:{bg:"#5e0b10",fg:"#f6cf6a",band:"#f6cf6a"},banner:{bg:"#f7f3e8",fg:"#7a1414",band:"#1d4f9c"},board:{bg:"#151311",fg:"#f4f1ea",band:"#f4f1ea"},gate:{bg:"#ecd3cb",fg:"#7a3b1c",band:"#c86a2c"},balg:{bg:"#6b6527",fg:"#ffffff",band:"#6b6527"},kelkar:{bg:"#ffffff",fg:"#7a1414",band:"#a01818"},welcome:{bg:"#f3d21c",fg:"#c8102e",band:"#1d3f9c"},station:{bg:"#f6c90e",fg:"#111111",band:"#111111"},college:{bg:"#f4f2ec",fg:"#1c2a5a",band:"#1c2a5a"},plaque:{bg:"#f1efe8",fg:"#161616",band:"#161616"},phule:{bg:"#7d6d5c",fg:"#fbfaf5",band:"#7d6d5c"},empress:{bg:"#fbfbf7",fg:"#1d6b2a",band:"#1d6b2a"},dmart:{bg:"#00703c",fg:"#ffffff",band:"#f7c600"},cybage:{bg:"#ffffff",fg:"#1d4f9c",band:"#ffffff"},cerebrum:{bg:"#2b2f36",fg:"#ffffff",band:"#2b2f36"},cerebrumstone:{bg:"#d4bb94",fg:"#3b3430",band:"#d4bb94"},stanchart:{bg:"#0473ea",fg:"#ffffff",band:"#38d200"},dmartwall:{bg:"#e2d9ba",fg:"#22704a",band:"#e2d9ba"}},$f=[["#f2c230","#5a1208"],["#b3161b","#fff3d6"],["#0f5e3c","#fff7e0"],["#173d7a","#ffffff"],["#ffffff","#b3161b"],["#e86a12","#ffffff"],["#5b1f63","#ffe9a8"]];async function Tb(i){if(!i||!i.length)return;try{await document.fonts.load('64px "Tiro Devanagari Marathi"')}catch{}let e=2048,t=[],n=null,s=0,r=0,o=0,a=()=>{let l=document.createElement("canvas");l.width=l.height=e,n={cv:l,g:l.getContext("2d"),quads:[]},t.push(n),s=0,r=0,o=0};a();for(let l of i){let c=jf[l.style]||jf.street;if(l.style==="shop"){let _=$f[(l.tone||0)%$f.length];c={bg:_[0],fg:_[1],band:_[1]}}let h=/^metro|temple|heritage|banner|board|gate|balg|kelkar|welcome|dmart|cybage|cerebrum|stanchart/.test(l.style)?128:72,u=Math.min(e,Math.max(h,Math.round(h*l.w/l.h)));s+u>e&&(s=0,r+=o+2,o=0),r+h>e&&a();let d=n.g;d.save(),d.translate(s,r),d.fillStyle=c.bg,d.fillRect(0,0,u,h);let p=Math.max(2,h*.05);d.strokeStyle=c.band,d.lineWidth=p,d.strokeRect(p,p,u-2*p,h-2*p),d.fillStyle=c.fg,d.textAlign="center",d.textBaseline="middle";let g=l.text&&l.text_mr,f=(_,m,y,x)=>{let b=y;for(d.font=m.replace("$",b);b>8&&d.measureText(_).width>u*.88;)b-=1,d.font=m.replace("$",b);d.fillText(_,u/2,x)};l.text_mr&&f(l.text_mr,'600 $px "Tiro Devanagari Marathi", "Noto Sans Devanagari", "Mangal", serif',Math.round(h*(g?.42:.6)),h*(g?.37:.53)),l.text&&f(l.text,"600 $px Inter, system-ui, sans-serif",Math.round(h*(g?.27:.5)),h*(g?.77:.52)),d.restore(),n.quads.push({lb:l,u0:s/e,v0:1-(r+h)/e,u1:(s+u)/e,v1:1-r/e}),s+=u+2,o=Math.max(o,h)}for(let l of t){let c=[],h=[],u=[],d=[],p=(y,x,b,E,w,T,D,v,S)=>{let N=w,O=-E,j=S?-1:1,L=c.length/3,U=[[-1,-1],[1,-1],[1,1],[-1,1]];for(let[V,K]of U)c.push(y+N*V*j*T/2,x+K*D/2,b+O*V*j*T/2),u.push(E*j,0,w*j),h.push(V<0?v.u0:v.u1,K<0?v.v0:v.v1);d.push(L,L+1,L+2,L,L+2,L+3)};for(let y of l.quads){let x=y.lb,b=x.nx,E=-x.ny;p(x.x,x.z,-x.y,b,E,x.w,x.h,y,!1),x.back&&p(x.x-b*.04,x.z,-x.y-E*.04,-b,-E,x.w,x.h,y,!0)}let g=new At;g.setAttribute("position",new st(c,3)),g.setAttribute("normal",new st(u,3)),g.setAttribute("uv",new st(h,2)),g.setIndex(d);let f=new Ur(l.cv);f.colorSpace=ut,f.anisotropy=4;let _=new $e({map:f,emissiveMap:f,emissive:16777215,emissiveIntensity:Bh,roughness:.55}),m=new Oe(g,_);m.receiveShadow=!0,mt.add(m),nu.push(m)}}var ve={ctx:null,on:!1,nodes:{},next:{},last:0};function Gh(i,e,t){let n=i.createBuffer(1,i.sampleRate*e,i.sampleRate),s=n.getChannelData(0),r=0;for(let o=0;o<s.length;o++){let a=Math.random()*2-1;t?(r=(r+.02*a)/1.02,s[o]=r*3.5):s[o]=a}return n}function Ph(i,e,t,n,s){let r=i.createBufferSource();r.buffer=e,r.loop=!0;let o=i.createBiquadFilter();o.type=t,o.frequency.value=n,o.Q.value=s;let a=i.createGain();return a.gain.value=0,r.connect(o).connect(a).connect(ve.master),r.start(),a}function Ab(){if(!ve.ctx){let i=window.AudioContext||window.webkitAudioContext;if(!i)return!1;let e=ve.ctx=new i;ve.master=e.createGain(),ve.master.gain.value=.9;let t=e.createDynamicsCompressor();ve.master.connect(t).connect(e.destination);let n=Gh(e,4,!0),s=Gh(e,4,!1);ve.nodes.traffic=Ph(e,n,"lowpass",520,.4),ve.nodes.crowd=Ph(e,s,"bandpass",900,.6),ve.nodes.river=Ph(e,s,"lowpass",1400,.3);let r=e.createOscillator();r.type="sawtooth",r.frequency.value=95;let o=e.createBiquadFilter();o.type="lowpass",o.frequency.value=300,ve.nodes.metro=e.createGain(),ve.nodes.metro.gain.value=0,r.connect(o).connect(ve.nodes.metro).connect(ve.master),r.start(),ve.nodes.metroOsc=r}return ve.ctx.resume(),!0}function qo(i,e,t){let n=ve.ctx;for(let[s,r,o]of[[1,1,3.2],[2,.55,2.2],[2.76,.45,1.7],[5.4,.25,.9],[8.93,.12,.5]]){let a=n.createOscillator();a.type="sine",a.frequency.value=t*s*(1+(Math.random()-.5)*.004);let l=n.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(e*r,i+.006),l.gain.exponentialRampToValueAtTime(1e-4,i+o),a.connect(l).connect(ve.master),a.start(i),a.stop(i+o+.05)}}function Rb(i,e){let t=ve.ctx,n=330+Math.random()*160,s=.18+Math.random()*.35;for(let r of[1,1.26]){let o=t.createOscillator();o.type="square",o.frequency.value=n*r;let a=t.createBiquadFilter();a.type="lowpass",a.frequency.value=1800;let l=t.createGain();l.gain.setValueAtTime(1e-4,i),l.gain.exponentialRampToValueAtTime(e,i+.02),l.gain.setValueAtTime(e,i+s),l.gain.exponentialRampToValueAtTime(1e-4,i+s+.06),o.connect(a).connect(l).connect(ve.master),o.start(i),o.stop(i+s+.1)}}function Cb(i,e){let t=ve.ctx,n=t.createOscillator(),s=t.createGain();n.type="sine",n.frequency.setValueAtTime(110,i),n.frequency.exponentialRampToValueAtTime(55,i+.18),s.gain.setValueAtTime(1e-4,i),s.gain.exponentialRampToValueAtTime(e,i+.01),s.gain.exponentialRampToValueAtTime(1e-4,i+.35),n.connect(s).connect(ve.master),n.start(i),n.stop(i+.4)}function Pb(i,e,t){let n=ve.ctx,s=n.createOscillator(),r=n.createGain();if(s.type="sine",t){s.frequency.value=4300+Math.random()*300;for(let o=0;o<4;o++)r.gain.setValueAtTime(1e-4,i+o*.06),r.gain.exponentialRampToValueAtTime(e,i+o*.06+.01),r.gain.exponentialRampToValueAtTime(1e-4,i+o*.06+.045);s.start(i),s.stop(i+.3)}else{let o=2400+Math.random()*1800;s.frequency.setValueAtTime(o,i),s.frequency.exponentialRampToValueAtTime(o*(1.3+Math.random()*.5),i+.08),s.frequency.exponentialRampToValueAtTime(o*.9,i+.16),r.gain.setValueAtTime(1e-4,i),r.gain.exponentialRampToValueAtTime(e,i+.02),r.gain.exponentialRampToValueAtTime(1e-4,i+.17),s.start(i),s.stop(i+.2)}s.connect(r).connect(ve.master)}var nr={temples:[],markets:[],river:[]};function Lb(i,e){if(!ft)return 200;let t=1e9;for(let[n,s,r,o,a,l]of ft.roads){if(l!==0||a<5||Math.abs(n-i)>120&&Math.abs(r-i)>120||Math.abs(s-e)>120&&Math.abs(o-e)>120)continue;let c=r-n,h=o-s,u=c*c+h*h||1,d=Math.max(0,Math.min(1,((i-n)*c+(e-s)*h)/u));t=Math.min(t,Math.hypot(n+c*d-i,s+h*d-e)-a/2)}return Math.max(0,t)}function Lh(i,e,t){let n=1e9;for(let s of i)n=Math.min(n,Math.hypot(s.x-e,s.z-t));return n}function Ib(i,e){if(!ve.on||!ve.ctx||i-ve.last<250)return;ve.last=i;let t=ve.ctx,n=t.currentTime,r=1/(1+Math.max(0,e.y-2)/40),o=ar[or].night,a=Lb(e.x,e.z),l=(.55-o*.3)*r/(1+a/18);ve.nodes.traffic.gain.setTargetAtTime(.1*l+.012,n,.6);let c=Lh(nr.temples,e.x,e.z),h=Lh(nr.markets,e.x,e.z);ve.nodes.crowd.gain.setTargetAtTime(.035*r*(1-o*.5)/(1+Math.min(h,c)/35),n,.8),ve.nodes.river.gain.setTargetAtTime(.03*r/(1+Lh(nr.river,e.x,e.z)/25),n,.8);let u=0;for(let g of Jr){if(g.state!=="run"||g.v<.5)continue;let f=g.cars[1].visible?g.cars[1].position:null;f&&(u=Math.max(u,g.v/Ap/(1+f.distanceTo(e)/40)))}ve.nodes.metro.gain.setTargetAtTime(.05*u*r,n,.3),ve.nodes.metroOsc.frequency.setTargetAtTime(70+u*90,n,.3);let d=(g,f,_)=>(ve.next[g]||(ve.next[g]=n+f+Math.random()*(_-f)),n>=ve.next[g]),p=(g,f,_)=>{ve.next[g]=n+f+Math.random()*(_-f)};if(c<160&&d("bell",2.5,7)){let g=.22*r/(1+c/25),f=620+Math.random()*260;qo(n+.02,g,f),Math.random()<.5&&qo(n+.45+Math.random()*.3,g*.8,f),p("bell",3,9)}if(o>.3&&c<140&&d("aarti",6,14)){let g=.2*r/(1+c/30);for(let f=0;f<8;f++)Cb(n+.05+f*.42+f%2*.06,g*(f%2?.6:1));p("aarti",18,35)}if(d("horn",5,14)&&(l>.05&&Math.random()<.7&&Rb(n+.01,.03*l/.55),p("horn",5,16+o*20)),d("bird",1.5,5)){let g=(o>.5?.012:.02)*r;for(let f=0;f<(o>.5?2:1+Math.floor(Math.random()*3));f++)Pb(n+f*.22,g,o>.5);p("bird",o>.5?.8:2,o>.5?2.5:7)}}me("sound").addEventListener("click",()=>{if(ve.on)ve.on=!1,ve.master&&(ve.master.gain.value=0);else{if(!Ab()){me("soundLabel").textContent="No sound here";return}ve.on=!0,ve.master.gain.value=.9}me("sound").setAttribute("aria-pressed",String(ve.on)),me("sound").setAttribute("aria-label",ve.on?"Sound on. Tap to turn it off.":"Sound off. Tap for temple bells, traffic and birds.")});document.addEventListener("visibilitychange",()=>{ve.ctx&&(document.hidden?ve.ctx.suspend():ve.on&&ve.ctx.resume())});var Hn=In.stops||[{land:"Shaniwar Wada",mr:"\u0936\u0928\u093F\u0935\u093E\u0930 \u0935\u093E\u0921\u093E",en:"Shaniwar Wada",bearing:200,r:150,h:95,note:"Seat of the Peshwas, completed in 1732 for Bajirao I. The palace inside burned in 1828; the walls and gates still stand."},{land:"Dilli Darwaza",mr:"\u0926\u093F\u0932\u094D\u0932\u0940 \u0926\u0930\u0935\u093E\u091C\u093E",en:"Dilli Darwaza",bearing:340,r:55,h:22,note:"The main gate faces north, towards Delhi. Its doors carry rows of iron spikes against war elephants."},{land:"Bajirao I statue",mr:"\u0925\u094B\u0930\u0932\u0947 \u092C\u093E\u091C\u0940\u0930\u093E\u0935 \u092A\u0947\u0936\u0935\u0947",en:"Bajirao I on horseback",bearing:20,r:30,h:12,note:"The equestrian statue of Bajirao I stands in the garden before the main gate."},{land:"Lal Mahal",mr:"\u0932\u093E\u0932 \u092E\u0939\u093E\u0932",en:"Lal Mahal",bearing:120,r:60,h:30,note:"Rebuilt on the site of the house where Shivaji Maharaj grew up with Jijabai."},{land:"Kasba Ganpati",mr:"\u0917\u094D\u0930\u093E\u092E\u0926\u0948\u0935\u0924 \u0936\u094D\u0930\u0940 \u0915\u0938\u092C\u093E \u0917\u0923\u092A\u0924\u0940",en:"Kasba Ganpati",bearing:250,r:40,h:20,note:"Pune\u2019s guardian deity, the first of the city\u2019s honoured Ganpatis, whose temple Jijabai is said to have built. The timber front has three storeys of carved galleries."},{land:"Nana Wada",mr:"\u0928\u093E\u0928\u093E \u0935\u093E\u0921\u093E",en:"Nana Wada",bearing:75,r:55,h:26,note:"Built in 1780 by Nana Phadnavis, the Peshwas\u2019 chief minister; it later housed a school. Its whitewashed front with cusped niches faces Shivaji Road."},{land:"Dagdusheth Ganpati",mr:"\u0936\u094D\u0930\u0940\u092E\u0902\u0924 \u0926\u0917\u0921\u0942\u0936\u0947\u0920 \u0939\u0932\u0935\u093E\u0908 \u0917\u0923\u092A\u0924\u0940",en:"Dagdusheth Halwai Ganpati",bearing:60,r:55,h:26,note:"Pune\u2019s best-known Ganesh temple, founded by the sweet-maker Dagdusheth Gadve."},{land:"Bhide Wada",mr:"\u092D\u093F\u0921\u0947 \u0935\u093E\u0921\u093E",en:"Bhide Wada",bearing:250,r:45,h:24,note:"Here, in 1848, Savitribai and Jyotirao Phule opened their first school for girls. A national memorial is being built on the site."},{land:"Kesari Wada",mr:"\u0915\u0947\u0938\u0930\u0940 \u0935\u093E\u0921\u093E",en:"Kesari Wada",bearing:30,r:50,h:28,note:"Lokmanya Tilak\u2019s home, where he edited his papers Kesari and Maratha. His house in the courtyard is now a museum."},{land:"Laxmi Road",mr:"\u0932\u0915\u094D\u0937\u094D\u092E\u0940 \u0930\u0938\u094D\u0924\u093E",en:"Laxmi Road",bearing:160,r:60,h:28,note:"Pune\u2019s busiest shopping street: jewellers, sari and cloth shops, hawkers and rows of scooters."},{land:"Vishrambaug Wada",mr:"\u0935\u093F\u0936\u094D\u0930\u093E\u092E\u092C\u093E\u0917 \u0935\u093E\u0921\u093E",en:"Vishrambaug Wada",bearing:80,r:60,h:30,note:"Built in 1807 for Peshwa Bajirao II, famed for its carved teak balcony. It houses a post office and a museum."},{land:"Tulshibaug Ram Mandir",mr:"\u0924\u0941\u0933\u0936\u0940\u092C\u093E\u0917 \u0930\u093E\u092E \u092E\u0902\u0926\u093F\u0930",en:"Tulshibaug Ram Mandir",bearing:110,r:70,h:45,note:"An 18th-century Ram temple with a tall spire, at the heart of the Tulshibaug market lanes."},{land:"Mahatma Phule Mandai",mr:"\u092E\u0939\u093E\u0924\u094D\u092E\u093E \u092B\u0941\u0932\u0947 \u092E\u0902\u0921\u0908",en:"Mahatma Phule Mandai",bearing:30,r:75,h:40,note:"Pune\u2019s great vegetable market hall, opened in 1886, with its tall octagonal central tower."},{land:"Omkareshwar Mandir",mr:"\u0913\u0902\u0915\u093E\u0930\u0947\u0936\u094D\u0935\u0930 \u092E\u0902\u0926\u093F\u0930",en:"Omkareshwar Mandir",bearing:120,r:75,h:38,note:"An 18th-century Shiva temple of the Peshwa era on the Mutha, with a tall painted shikhara and ghats down to the river."},{land:"Balgandharva Rangmandir",mr:"\u092C\u093E\u0932\u0917\u0902\u0927\u0930\u094D\u0935 \u0930\u0902\u0917\u092E\u0902\u0926\u093F\u0930",en:"Balgandharva Rangmandir",bearing:330,r:70,h:32,note:"The city\u2019s best-known theatre, named after the singer-actor Bal Gandharva, at the head of JM Road across the river from the old city."},{land:"PMC Bhavan metro",mr:"\u092A\u0941\u0923\u0947 \u092E\u0928\u092A\u093E \u092E\u0947\u091F\u094D\u0930\u094B \u0938\u094D\u0925\u093E\u0928\u0915",en:"PMC Bhavan metro station",bearing:150,r:90,h:40,note:"Aqua Line station by the Mutha river. Its facade borrows the cusped arches of Pune\u2019s old wadas."}],rt={on:!1,i:0,playing:!0,phase:"fly",t:0,DWELL:7,angle:0};function Db(i){let e=ft?.landmarks.find(r=>r.name===i.land);if(!e)return null;let t=It.degToRad(i.bearing),n=new R(e.x,i.h>60?6:8,e.z);return{pos:n.clone().add(new R(Math.sin(t)*i.r,i.h,-Math.cos(t)*i.r)),target:n}}function Nb(i){let e=Hn[i];me("tourMr").textContent=e.mr,me("tourEn").textContent=e.en,me("tourNote").textContent=e.note,me("tourCount").textContent=`${i+1} / ${Hn.length}`}function rr(i){rt.i=(i+Hn.length)%Hn.length;let e=Db(Hn[rt.i]);Nb(rt.i),e&&(tt==="walk"&&ls("orbit",!1),rt.phase="fly",rt.t=0,rt.angle=0,ia(e.pos,e.target,{arc:Math.min(90,xe.position.distanceTo(e.pos)*.16),dur:fn?.01:void 0,done:()=>{rt.phase="dwell",rt.t=0}}))}function Ub(){ft&&(rt.on=!0,rt.playing=!0,me("tour").hidden=!1,document.body.classList.add("touring"),ra(),me("tourPlay").innerHTML="&#10073;&#10073;",me("tourPlay").setAttribute("aria-label","Pause the tour"),rr(0))}function aa(){rt.on=!1,me("tour").hidden=!0,document.body.classList.remove("touring"),ra()}function Ob(i){if(!(!rt.on||rt.phase!=="dwell"||Mt)){if(!fn){let e=i*It.degToRad(5),t=xe.position.clone().sub(nt.target);t.applyAxisAngle(new R(0,1,0),e),xe.position.copy(nt.target).add(t)}rt.playing&&(rt.t+=i,rt.t>rt.DWELL&&rr(rt.i+1))}}me("tourNext").addEventListener("click",()=>rr(rt.i+1));me("tourPrev").addEventListener("click",()=>rr(rt.i-1));me("tourEnd").addEventListener("click",aa);me("tourPlay").addEventListener("click",()=>{rt.playing=!rt.playing,me("tourPlay").innerHTML=rt.playing?"&#10073;&#10073;":"&#9654;",me("tourPlay").setAttribute("aria-label",rt.playing?"Pause the tour":"Continue the tour")});Vt.addEventListener("pointerdown",()=>{rt.on&&rt.playing&&me("tourPlay").click()});window.addEventListener("keydown",i=>{rt.on&&(i.key==="Escape"&&aa(),i.key==="ArrowRight"&&tt!=="walk"&&rr(rt.i+1),i.key==="ArrowLeft"&&tt!=="walk"&&rr(rt.i-1))});{let i=document.createElement("button");i.type="button",i.className="tourBtn",i.textContent="\u2708 Aerial tour",i.setAttribute("aria-label","Aerial tour of all the places, one stop at a time"),i.addEventListener("click",Ub),su.prepend(i)}var Fb=In.landView||{"Shaniwar Wada":"fort","Dilli Darwaza":"gate","Bajirao I statue":"streetview","Lal Mahal":"lalmahal","Dagdusheth Ganpati":"dagdusheth","Tulshibaug Ram Mandir":"tulshibaug","PMC Bhavan metro":"metro","Vishrambaug Wada":"vishrambaug","Nana Wada":"nana","Bhide Wada":"bhide","Omkareshwar Mandir":"omkareshwar","Laxmi Road":"laxmi","Kasba Ganpati":"kasbaganpati","Mahatma Phule Mandai":"mandai","Balgandharva Rangmandir":"balgandharva","Kesari Wada":"kesari","Kelkar Museum":"kelkar"},Wh=[];function Bb(i){nl=i,me("hand").setAttribute("aria-pressed",String(i)),nt.mouseButtons=i?{LEFT:un.PAN,MIDDLE:un.DOLLY,RIGHT:un.ROTATE}:{LEFT:un.ROTATE,MIDDLE:un.DOLLY,RIGHT:un.PAN},nt.touches=i?{ONE:Cn.PAN,TWO:Cn.DOLLY_ROTATE}:{ONE:Cn.ROTATE,TWO:Cn.DOLLY_PAN},i&&tt==="walk"&&ls("orbit"),sl()}nt.screenSpacePanning=!1;me("hand").addEventListener("click",()=>Bb(!nl));var tn={level:Vn?1:0,frames:0,time:0,calm:0},kb=[26e5,17e5,11e5,75e4];function Yo(){let i=tn.level;Vh=[450,300,220,180][i];let e=Math.max(1,Vt.clientWidth*Vt.clientHeight),t=Math.min(window.devicePixelRatio||1,[2,1.5,1.25,1][i],Math.sqrt(kb[i]/e));if(Ht.setPixelRatio(Math.max(.6,t)),op=[1,1,2,3][i],dn)for(let n of dn.groups)for(let s of n.meshes)s.castShadow=i===0&&s.material!==Qo&&s.material!==el}function zb(i){if(tn.frames++,tn.time+=i,tn.time<2)return;let e=tn.frames/tn.time;tn.frames=0,tn.time=0,!document.hidden&&(e<40&&tn.level<3?(tn.level++,tn.calm=0,Yo()):e>57&&tn.level>(Vn?1:0)?++tn.calm>=3&&(tn.level--,tn.calm=0,Yo()):tn.calm=0)}var Hb=new xo,Zf=new Hr(new R,new R(0,-1,0),0,8),$n=new R,re={guide:null,extras:[],pairs:[],pending:null,spot:null,t:0,ready:!1,view:null,greeted:new Set,said:-99,bubble:null,bubbleUntil:0},Jf=["point_up","thumbs_up","victory","think","present","stop","temple","surprised","wave","talk","talk","laugh","clap","look_around","phone"],Vb=new Set(["wave","namaste","present","talk","point_up","thumbs_up","victory","stop","clap","laugh"]),Rp={look_around:0,laugh:.15,namaste:.25,phone:.35,walk_phone:0,think:.6,temple:.6},Cp={namaste:[["\u0928\u092E\u0938\u094D\u0915\u093E\u0930!","Welcome to {place}."]],wave:[["\u0928\u092E\u0938\u094D\u0915\u093E\u0930!","Hello! Come, let me show you round."],["\u091A\u0932\u093E!","Come along!"]],point_up:[["\u0935\u0930 \u092A\u093E\u0939\u093E!","Look up there!"]],present:[["\u0939\u0947 \u092A\u093E\u0939\u093E!","Here it is: {view}."]],thumbs_up:[["\u091B\u093E\u0928!","Lovely, isn\u2019t it?"]],victory:[["\u092E\u0938\u094D\u0924!","A perfect spot for a photo!"]],think:[["\u0939\u092E\u094D\u092E\u2026","Let me remember the story\u2026"]],surprised:[["\u0905\u0930\u0947 \u0935\u093E!","Wow, look at that!"]],stop:[["\u0925\u093E\u0902\u092C\u093E!","Wait here a moment."]],temple:[["\u0932\u0915\u094D\u0937\u093E\u0924 \u0920\u0947\u0935\u093E!","Remember this one!"]],talk:[["\u0910\u0915\u093E\u2026","{fact}"]],laugh:[["\u0939\u093E \u0939\u093E!","Ha ha!"]],clap:[["\u0935\u093E!","Bravo!"]],look_around:[["\u0915\u093F\u0924\u0940 \u0938\u0941\u0902\u0926\u0930!","How beautiful it is here!"]],phone:[["\u0939\u0945\u0932\u094B?","Hello? Yes, I\u2019m at {place}. Come over!"]]},Gb={E1:"office",E2:"western",E3:"saree",E4:"elder",E5:"student"},$t=new R,Io=new R,Qf=new R,Do=new R,No=new ct,Uo=new ct,ep=new R(1,0,0),tp=new R(0,1,0);function Ko(i,e,t){let n=!1;for(let s=0,r=t.length-2;s<t.length;r=s,s+=2){let o=t[s],a=t[s+1],l=t[r],c=t[r+1];a>e!=c>e&&i<(l-o)*(e-a)/(c-a)+o&&(n=!n)}return n}var Js=null;function Pp(i,e){if(!Js){Js=new Map;for(let t of ft.roads||[]){let[n,s,r,o,a]=t;for(let l=Math.floor((Math.min(n,r)-a)/30);l<=Math.floor((Math.max(n,r)+a)/30);l++)for(let c=Math.floor((Math.min(s,o)-a)/30);c<=Math.floor((Math.max(s,o)+a)/30);c++){let h=l+","+c;Js.has(h)||Js.set(h,[]),Js.get(h).push(t)}}}return Js.get(Math.floor(i/30)+","+Math.floor(e/30))||[]}function vi(i,e,t=!1){if(!ft)return!0;for(let n=0;n<ft.buildings.length;n++){let s=ft.bc[n];if(!(Math.abs(s[0]-i)>40||Math.abs(s[1]-e)>40)&&Ko(i,e,ft.buildings[n]))return!1}for(let n of ft.water||[])if(Ko(i,e,n))return!1;for(let n=0;n<xt.length;n+=3)if(Math.abs(xt[n]-i)<xt[n+2]&&Math.abs(xt[n+1]-e)<xt[n+2])return!1;if(t)for(let n of Pp(i,e)){let[s,r,o,a,l]=n;if(Math.min(s,o)-l>i||Math.max(s,o)+l<i||Math.min(r,a)-l>e||Math.max(r,a)+l<e)continue;let c=o-s,h=a-r,u=c*c+h*h||1,d=Math.max(0,Math.min(1,((i-s)*c+(e-r)*h)/u));if(Math.hypot(s+c*d-i,r+h*d-e)<l/2+.5)return!1}return!0}function Nt(i,e,t=!1,n=.35){let s=i.clips[e];if(!s)return 0;let r=i.mixer.clipAction(s);return r.reset(),r.timeScale=1,r.setLoop(t?Vc:Hc,1/0),r.clampWhenFinished=!t,r.enabled=!0,r.setEffectiveWeight(1),i.cur&&i.cur!==r&&r.crossFadeFrom(i.cur,n,!1),r.play(),i.cur=r,i.act=e,s.duration}function Ih(i,e){let t=null;return i.traverse(n=>{!t&&n.isBone&&n.name.replace(/[.\s]/g,"")===e&&(t=n)}),t}async function Wb(){try{let i=await fetch("wada_characters.glb.txt");if(!i.ok)return;let e=await up.parseAsync(pp(await i.text()),""),t=new $e({vertexColors:!0,roughness:.72,metalness:0}),n=new $e({vertexColors:!0,roughness:.12,metalness:.5}),s=new Pt(.068,.142,.009),r=new es(.06,.128),o=new $e({color:1447964,roughness:.35,metalness:.3}),a=new Kt({color:10273791}),l=[];e.scene.traverse(h=>{if(/^Char_(G|E\d)$/.test(h.name)&&l.push(h),h.isMesh){let u=h.geometry;u.attributes.color_1&&iu(u.attributes.color)&&u.setAttribute("color",u.attributes.color_1),h.material=/Glass/.test(h.material?.name||"")?n:t,h.castShadow=!0,h.receiveShadow=!0,h.frustumCulled=!1}});for(let h of l){let u=h.name.slice(5),d=u+"_",p={};for(let _ of e.animations)_.name.startsWith(d)&&(p[_.name.slice(d.length)]=_);h.removeFromParent(),h.position.set(0,0,0),h.visible=!1,mt.add(h);let g={root:h,clips:p,id:u,kind:Gb[u]||"guide",mixer:new yo(h),cur:null,act:"",mode:"idle",until:0,yaw:0,ang:Math.random()*6.28,dirSign:Math.random()<.5?-1:1,r:5,centre:new R,target:new R,lastWave:-99,lastGreet:-99,n:0,head:Ih(h,d+"head"),neck:Ih(h,d+"neck"),lookW:0,lookYaw:0,lookPitch:0,glance:!1,glanceUntil:0,turning:!1,faceCam:!1,phone:null,pair:null,walkClip:u==="E5"?"walk_phone":"walk",pace:u==="E4"?.82:1,speed:u==="E4"?1:1.25,pa:new R,pb:new R},f=Ih(h,d+"handR");if(f){let _=new St,m=new Oe(r,a);m.position.z=-.0047,m.rotation.y=Math.PI,_.add(new Oe(s,o),m),_.position.set(0,.07,-.021),_.visible=!1,f.add(_),g.phone=_}d==="G_"?re.guide=g:re.extras.push(g)}let c=Object.fromEntries(re.extras.map(h=>[h.id,h]));for(let[h,u]of[["E1","E2"],["E3","E4"]]){if(!c[h]||!c[u])continue;let d={members:[c[h],c[u]],state:"apart",next:0,end:0,talker:null,turnEnd:0,phase:"talk",giveUp:0};c[h].pair=c[u].pair=d,re.pairs.push(d)}re.bubble=document.getElementById("bubble"),re.ready=!!re.guide,window.__wadaCast=()=>({guide:re.guide&&{mode:re.guide.mode,act:re.guide.act,vis:re.guide.root.visible,x:+re.guide.root.position.x.toFixed(2),z:+re.guide.root.position.z.toFixed(2),look:[+re.guide.lookYaw.toFixed(2),+re.guide.lookPitch.toFixed(2)],phone:!!re.guide.phone?.visible},extras:re.extras.map(h=>`${h.id}:${h.mode}/${h.act}${h.root.visible?"":" (hidden)"}${h.phone?.visible?" +phone":""}`),pairs:re.pairs.map(h=>h.state),bubble:re.bubble.hidden?"":re.bubble.textContent}),window.__wadaAct=h=>Qr(re.guide,h),window.__wadaCastDbg=()=>({t:+re.t.toFixed(2),spot:!!re.spot,ex:re.extras.map(h=>[h.id,h.mode,+h.until.toFixed(1),h.root.visible,+h.root.position.distanceTo(xe.position).toFixed(1)]),pairs:re.pairs.map(h=>[h.state,+h.next.toFixed(1)])}),window.__wadaNearGuide=(h=3,u=0)=>{let d=re.guide,p=d.root.position,g=Math.sin(d.yaw),f=Math.cos(d.yaw);window.__wadaLook(p.x+g*h+f*u,p.y+1.55,p.z+f*h-g*u,p.x,p.y+1.25,p.z)},window.__wadaMeet=()=>re.pairs.map(h=>{h.next=0;for(let u of h.members)u.until=0;return h.state}),re.pending&&Ip(...re.pending)}catch{}}function ki(i,e,t=1){let n=e-i.yaw;n=Math.atan2(Math.sin(n),Math.cos(n)),i.yaw+=n*t,i.root.rotation.y=i.yaw}function Lp(i,e,t){if(!i.head||!i.neck||(i.lookW+=(t-i.lookW)*Math.min(1,e*3),i.lookW<.01&&Math.abs(i.lookYaw)<.01))return;i.root.updateMatrixWorld(),$t.copy(xe.position),i.root.worldToLocal($t);let n=$t.x,s=$t.y-1.6,r=$t.z,o=Math.atan2(n,r),a=-Math.atan2(s,Math.hypot(n,r));Math.abs(o)>2&&(o=0,a=0),o=It.clamp(o,-1.15,1.15)*i.lookW,a=It.clamp(a,-.5,.35)*i.lookW;let l=Math.min(1,e*5);i.lookYaw+=(o-i.lookYaw)*l,i.lookPitch+=(a-i.lookPitch)*l;let c=i.lookBase||(i.lookBase={neck:new ct,head:new ct,neckSet:new ct,headSet:new ct,set:!1});(!c.set||!i.neck.quaternion.equals(c.neckSet))&&c.neck.copy(i.neck.quaternion),(!c.set||!i.head.quaternion.equals(c.headSet))&&c.head.copy(i.head.quaternion),No.setFromAxisAngle(tp,i.lookYaw*.4),Uo.setFromAxisAngle(ep,i.lookPitch*.4),i.neck.quaternion.copy(c.neck).multiply(No).multiply(Uo),No.setFromAxisAngle(tp,i.lookYaw*.6),Uo.setFromAxisAngle(ep,i.lookPitch*.6),i.head.quaternion.copy(c.head).multiply(No).multiply(Uo),c.neckSet.copy(i.neck.quaternion),c.headSet.copy(i.head.quaternion),c.set=!0}function Xb(){if(!Hn.length)return"This is one of Pune\u2019s best-loved places.";let i=re.view?.id,e=(re.view?.label||"").toLowerCase(),n=(Hn.find(s=>In.landView?.[s.land]===i)||Hn.find(s=>e&&(e.includes(s.en.toLowerCase())||s.en.toLowerCase().includes(e)))||Hn[Math.floor(Math.random()*Hn.length)]).note.split(/(?<=[.!?])\s/)[0];return n.length>150&&(n=n.slice(0,n.lastIndexOf(" ",146))+"\u2026"),n}function qb(i){let e=Cp[i],t=re.bubble;if(!e||!t)return;let[n,s]=e[Math.floor(Math.random()*e.length)],r=(In.en||"").split(/[:,]/)[0].trim(),o=re.view?.label||r;t.querySelector(".mr").textContent=n,t.querySelector(".en").textContent=s.replace("{place}",r).replace("{view}",o).replace("{fact}",()=>Xb()),t.hidden=!1,re.bubbleUntil=re.t+(i==="talk"?6:3.6),re.said=re.t}function np(){let i=re.bubble,e=re.guide;if(!i||i.hidden)return;if(re.t>re.bubbleUntil||!e.root.visible){i.classList.remove("on"),(re.t>re.bubbleUntil+.4||!e.root.visible)&&(i.hidden=!0);return}$t.copy(e.root.position),$t.y+=2;let t=$t.distanceTo(xe.position);if($t.project(xe),$t.z>1||Math.abs($t.x)>1.02||$t.y>1.02||$t.y<-1||t>90){i.classList.remove("on");return}let n=(i.offsetWidth||200)/2+8,s=Math.min(innerWidth-n,Math.max(n,($t.x*.5+.5)*innerWidth)),r=(-$t.y*.5+.5)*innerHeight;i.style.transform=`translate(${s.toFixed(1)}px, ${r.toFixed(1)}px) translate(-50%, -100%)`,i.classList.add("on")}function Qr(i,e){i.mode="gesture",i.until=re.t+Nt(i,e)-.25,Vb.has(e)&&(i.turning=!0),Cp[e]&&re.t-re.said>6&&(e==="namaste"||e==="talk"||e==="phone"||Math.random()<.65)&&qb(e)}function Ip(i,e){if(!re.ready){re.pending=[i,e];return}re.view=e||null,re.bubble&&(re.bubble.hidden=!0,re.bubble.classList.remove("on")),re.bubbleUntil=0;let t=[re.guide,...re.extras],n=i.pos,s=i.dir.clone();if(s.y=0,n.y-sn(n.x,n.z)>30||s.lengthSq()<1e-6){for(let f of t)f.root.visible=!1;re.spot=null;return}s.normalize();let o=new R(-s.z,0,s.x),a=document.getElementById("views"),l=a?a.getBoundingClientRect().top:innerHeight*.75,c=1-2*Math.max(.3,Math.min(.92,(l-12)/innerHeight)),h=(f,_)=>{let m=xe.clone();m.position.copy(n),m.lookAt(f),m.updateMatrixWorld(!0),m.updateProjectionMatrix();for(let y of[.32,-.32,.18])for(let x=5;x<=45;x*=1.15){let b=n.clone().addScaledVector(s,x).addScaledVector(o,y*x);b.y=sn(b.x,b.z);let E=b.clone().project(m),w=b.clone().add(new R(0,1.8,0)).project(m);if(E.y>c&&w.y<.95&&Math.abs(E.x)<.8&&E.z<1&&vi(b.x,b.z,_))return b}return null},u=h(i.target,!0)||h(i.target,!1);if(!u){let f=i.target.clone().sub(n),_=f.length(),m=Math.atan2(f.y,Math.hypot(f.x,f.z)),y=Math.max(.07,m-.12);if(y<m){let x=n.clone().addScaledVector(s,Math.cos(y)*_).add(new R(0,Math.sin(y)*_,0));u=h(x,!0)||h(x,!1),u&&i.target.copy(x)}}if(!u){for(let f of t)f.root.visible=!1;re.spot=null;return}u.y=sn(u.x,u.z),re.spot=u;let d=re.guide;d.root.position.copy(u),d.root.visible=!0,ki(d,Math.atan2(n.x-u.x,n.z-u.z));let p=!re.greeted.has(Gn);re.greeted.add(Gn),re.said=-99,Qr(d,p?"namaste":Math.random()<.6?"present":"wave"),d.lastWave=re.t;let g=0;for(let f of re.pairs)f.state="apart",f.next=re.t+5+Math.random()*8+6*re.pairs.indexOf(f);for(let f of re.extras){let _=!1,m=f.pair&&f.pair.members[1]===f&&f.pair.members[0].root.visible?f.pair.members[0]:null;for(let w=0;w<60&&!_;w++){let T=w>=30,D=w<45,v=Math.random()*6.28,S=m&&w<20?3+Math.random()*5:T?6+Math.random()*30:9+Math.random()*14,N=(m&&w<20?m.centre:u).clone().add(new R(Math.cos(v)*S,0,Math.sin(v)*S));if(N.clone().sub(n).dot(s)<(T?-4:2))continue;let O=T?4+Math.random()*5:6+Math.random()*8,j=Math.random()*Math.PI,L=Math.cos(j),U=Math.sin(j);_=!0;for(let V=0;V<=10&&_;V++){let K=-O+2*O*V/10;vi(N.x+L*K,N.z+U*K,D)||(_=!1)}_&&(f.centre.copy(N),f.r=O,f.pa.set(N.x-L*O,0,N.z-U*O),f.pb.set(N.x+L*O,0,N.z+U*O))}if(f.root.visible=_,!_)continue;let y=Math.random(),x=f.pa.x+(f.pb.x-f.pa.x)*y,b=f.pa.z+(f.pb.z-f.pa.z)*y;f.root.position.set(x,sn(x,b),b);let E=f.dirSign>0?f.pb:f.pa;ki(f,Math.atan2(E.x-x,E.z-b)),f.mode="walk",f.faceCam=!1,f.until=re.t+6+Math.random()*10+g*2,Nt(f,f.walkClip,!0,.2),f.cur.time=Math.random()*.9,f.cur.timeScale=f.pace,g++}}function Dp(i,e){Io.set(-Math.sin(W.yaw),0,-Math.cos(W.yaw)),Qf.set(-Io.z,0,Io.x);let t=null;for(let[o,a]of[[1.3,1.7],[-1.3,1.7],[1.5,.5],[-1.5,.5]])if(Do.copy(W.pos).addScaledVector(Qf,o).addScaledVector(Io,a),vi(Do.x,Do.z)){t=Do;break}if(!t)return!1;t.y=sn(t.x,t.z);let n=$t.copy(t).sub(i.root.position);n.y=0;let s=n.length();if(!i.root.visible||s>30)return i.root.position.copy(t),i.root.visible=!0,re.spot||(re.spot=t.clone()),i.mode="idle",i.until=re.t+1.5,Nt(i,"idle",!0),!0;let r=W.keys.size>0||!!W.glide;if(i.mode==="follow"?s>.12:s>(r?.6:1.8)){i.mode!=="follow"&&(i.mode="follow",Nt(i,"walk",!0,.25));let o=Math.min(Z.on?10:9,Math.max(.9,s*1.8));return n.multiplyScalar(Math.min(s,o*e)/s),i.root.position.add(n),i.root.position.y=sn(i.root.position.x,i.root.position.z),ki(i,Math.atan2(n.x,n.z),Math.min(1,e*8)),i.cur&&(i.cur.timeScale=It.clamp(o/1.2,.7,3.2)),!0}return i.mode==="follow"&&(i.mode="idle",i.until=re.t+1.5+Math.random()*2,Nt(i,"idle",!0)),!1}function Yb(i,e,t,n){if(tt==="walk"&&Dp(i,e))return;if(i.mode==="walk"){let a=i.target.clone().sub(i.root.position);a.y=0;let l=a.length();l<.08?(i.mode="idle",i.until=t+.8,Nt(i,"idle",!0)):(a.multiplyScalar(Math.min(l,1.2*e)/l),i.root.position.add(a),i.root.position.y=sn(i.root.position.x,i.root.position.z),ki(i,Math.atan2(a.x,a.z),Math.min(1,e*8)));return}let s=Math.atan2(n.x-i.root.position.x,n.z-i.root.position.z),r=Math.atan2(Math.sin(s-i.yaw),Math.cos(s-i.yaw));Math.abs(r)>.75&&(i.turning=!0),i.turning&&(ki(i,s,Math.min(1,e*3)),Math.abs(r)<.1&&(i.turning=!1));let o=i.root.position.distanceTo(n)<9;if(tt!=="walk"&&o&&i.mode==="idle"&&t-i.lastWave>25)Qr(i,Math.random()<.5?"wave":"namaste"),i.lastWave=t;else if(t>i.until){if(i.mode==="gesture")i.mode="idle",i.until=t+(fn?1e9:1.6+Math.random()*2.6),Nt(i,"idle",!0);else if(!fn){if(i.n++,tt!=="walk"&&i.n%5===0){let l=new R(-(n.z-i.root.position.z),0,n.x-i.root.position.x).normalize(),c=re.spot.clone().addScaledVector(l,(Math.random()<.5?-1:1)*(1.5+Math.random()*2.5));if(vi(c.x,c.z)){i.target.copy(c),i.mode="walk",Nt(i,"walk",!0);return}}let a=Jf[Math.floor(Math.random()*Jf.length)];a===i.act&&(a="talk"),Qr(i,a)}}}function Dh(i,e,t,n){let s=$t.copy(e).sub(i.root.position);s.y=0;let r=s.length();return r<.06?!0:(s.multiplyScalar(Math.min(r,t*n)/r),i.root.position.add(s),i.root.position.y=sn(i.root.position.x,i.root.position.z),ki(i,Math.atan2(s.x,s.z),Math.min(1,n*8)),!1)}function Xh(i,e){i.mode="walk",i.faceCam=!1,Nt(i,i.walkClip,!0),i.cur.timeScale=i.pace,i.until=e+10+Math.random()*14}function Kb(i,e){let t=i.root.position;for(let s=0;s<12;s++){let r=Math.random()*6.28,o=Math.cos(r),a=Math.sin(r),l=10+Math.random()*14,c=!0;for(let h=1;h<=8&&c;h++)vi(t.x+o*l*h/8,t.z+a*l*h/8,!0)||(c=!1);if(c){i.pa.set(t.x,0,t.z),i.pb.set(t.x+o*l,0,t.z+a*l),i.centre.copy(i.pa).add(i.pb).multiplyScalar(.5),i.r=l/2,i.dirSign=1,Xh(i,e);return}}let n=t.distanceTo(i.pa)<t.distanceTo(i.pb);i.target.copy(n?i.pa:i.pb),i.dirSign=n?1:-1,Xh(i,e),i.mode="return"}function jb(i,e){let[t,n]=i.members,s=t.root.position.distanceTo(n.root.position),r=n.root.position.clone().sub(t.root.position).setY(0).normalize(),o=l=>vi(l.x,l.z)&&vi(l.x+r.x*.7,l.z+r.z*.7)&&vi(l.x-r.x*.7,l.z-r.z*.7),a=[t.root.position.clone().add(n.root.position).multiplyScalar(.5),t.root.position.clone(),n.root.position.clone()].find(o);return s>40||!a?!1:(t.target.copy(a).addScaledVector(r,-.55),n.target.copy(a).addScaledVector(r,.55),t.mode=n.mode="goto",i.state="meeting",i.giveUp=e+30,!0)}function ip(i,e){i.state="apart",i.next=e+25+Math.random()*25;for(let t of i.members)Kb(t,e)}function $b(i,e){let[t,n]=i.members;if(i.state==="meeting")t.mode==="wait"&&n.mode==="wait"?(i.state="chat",i.end=e+15+Math.random()*12,i.talker=Math.random()<.5?t:n,i.phase="talk",i.turnEnd=e+3+Math.random()*3,t.mode=n.mode="chat",Nt(i.talker,"talk",!0),Nt(i.talker===t?n:t,"idle",!0)):e>i.giveUp&&ip(i,e);else if(i.state==="chat"){if(e>i.end){ip(i,e);return}if(e<i.turnEnd)return;let s=i.talker===t?n:t;if(i.phase==="talk"&&Math.random()<.4)i.phase="laugh",Nt(s,"laugh"),Nt(i.talker,Math.random()<.5?"laugh":"idle",!1),i.turnEnd=e+2.7;else{i.phase="talk",i.talker=s,Nt(s,"talk",!0);let r=s===t?n:t,o=Math.random();Nt(r,o<.15?"thumbs_up":o<.3?"think":"idle",o>=.3),i.turnEnd=e+3+Math.random()*3.5}}}function Zb(i,e,t,n){let s=i.root.position.distanceTo(n),r=n.y-sn(n.x,n.z)<5;switch(i.mode){case"walk":{if(Dh(i,i.dirSign>0?i.pb:i.pa,i.speed,e)){i.dirSign=-i.dirSign,i.mode="act",i.faceCam=!1,!fn&&Math.random()<.55?i.until=t+Nt(i,i.kind==="student"?"phone":"look_around")-.2:(Nt(i,"idle",!0),i.until=t+1.2+Math.random()*2.5);break}if(fn)break;if(r&&s<6.5&&t-i.lastGreet>45&&(i.lastGreet=t,Math.random()<.6)){i.mode="act",i.faceCam=!0,i.until=t+Nt(i,i.kind==="elder"||i.kind==="saree"?"namaste":"wave")-.2;break}if(t>i.until){let a=i.pair;if(a&&a.state==="apart"&&t>a.next&&a.members.every(l=>l.root.visible&&l.mode==="walk")){if(jb(a,t))break;a.next=t+8}i.kind==="student"||Math.random()<.6?(i.mode="act",i.until=t+Nt(i,i.kind==="student"?"phone":"look_around")-.2):i.until=t+8+Math.random()*10}break}case"goto":Dh(i,i.target,i.speed,e)&&(i.mode="wait",Nt(i,"idle",!0));break;case"return":Dh(i,i.target,i.speed,e)&&(i.mode="walk");break;case"wait":case"chat":{let a=i.pair.members[0]===i?i.pair.members[1]:i.pair.members[0];ki(i,Math.atan2(a.root.position.x-i.root.position.x,a.root.position.z-i.root.position.z),Math.min(1,e*4)),i.pair.members[0]===i&&$b(i.pair,t);break}case"act":i.faceCam&&ki(i,Math.atan2(n.x-i.root.position.x,n.z-i.root.position.z),Math.min(1,e*4)),t>i.until&&Xh(i,t);break}t>i.glanceUntil&&(i.glance=Math.random()<.35,i.glanceUntil=t+2+Math.random()*3);let o=s<8&&i.mode!=="chat"&&i.mode!=="wait"&&(i.mode==="act"||i.glance);Lp(i,e,o?Rp[i.act]??.75:0)}function sp(i){i.phone&&(i.phone.visible=i.act==="walk_phone"||i.act==="phone"&&!!i.cur&&i.cur.time>.4&&i.cur.time<5.6)}function Jb(i){if(!re.ready)return;let e=re.guide;if(tt==="walk"&&!re.spot&&Dp(e,i),!re.spot){np();return}re.t+=i;let t=re.t,n=xe.position;e.root.visible&&e.root.position.distanceTo(n)<160&&(e.mixer.update(i),Yb(e,i,t,n),Lp(e,i,e.mode==="follow"?.55:Rp[e.act]??1),sp(e));for(let s of re.extras)s.root.visible&&(s.root.position.distanceTo(n)>160&&s.mode==="walk"||(s.mixer.update(i),Zb(s,i,t,n),sp(s)));np()}var qh={oldcity:{mr:"\u091C\u0941\u0928\u094D\u092F\u093E \u092A\u0941\u0923\u094D\u092F\u093E\u091A\u093E \u0916\u091C\u093F\u0928\u093E",en:"Treasures of Old Pune",intro:"Ten treasures lie hidden at the landmarks of old Pune, from the Peshwas\u2019 great gate to the market hall. Follow each clue to a glowing beam of light, pick up the treasure and answer a question about the place.",start:{x:1.7,z:-140},items:[{land:"Dilli Darwaza",obj:"spike",mr:"\u0926\u0930\u0935\u093E\u091C\u093E\u091A\u093E \u0916\u093F\u0933\u093E",name:"An iron gate spike",clue:"Start at the great north gate of the Peshwas\u2019 fort, straight ahead of you.",fact:"Dilli Darwaza faces north, towards Delhi. Its doors carry rows of iron spikes against war elephants.",q:"Why do the doors of Dilli Darwaza carry rows of iron spikes?",a:["To stop war elephants ramming them","To hang lamps at festivals","To keep birds off the doors"]},{land:"Kasba Ganpati",obj:"flower",mr:"\u091C\u093E\u0938\u094D\u0935\u0902\u0926\u0940\u091A\u0947 \u092B\u0942\u0932",name:"A red hibiscus",clue:"Go east to the temple of the city\u2019s guardian Ganpati, the one honoured first of all.",fact:"Kasba Ganpati is Pune\u2019s gramadaivat, its guardian deity, the first of its honoured Ganpatis. Jijabai is said to have built the temple.",q:"What is Kasba Ganpati to the people of Pune?",a:["The city\u2019s guardian deity, honoured first","The newest temple in the city","A god of the river Mutha"]},{land:"Lal Mahal",obj:"plough",mr:"\u0938\u094B\u0928\u094D\u092F\u093E\u091A\u093E \u0928\u093E\u0902\u0917\u0930",name:"The golden plough",clue:"Close by stands the red palace where a great king spent his boyhood.",fact:"Lal Mahal is rebuilt on the site of the house where Shivaji Maharaj grew up with his mother Jijabai. The story goes that she had the ruined town\u2019s land ploughed with a golden plough to bring it back to life.",q:"Who grew up at Lal Mahal?",a:["Shivaji Maharaj, with his mother Jijabai","Bajirao I","Lokmanya Tilak"]},{land:"Nana Wada",obj:"quill",mr:"\u0928\u093E\u0928\u093E\u0902\u091A\u0940 \u0932\u0947\u0916\u0923\u0940",name:"The minister\u2019s quill",clue:"Find the mansion of the Peshwas\u2019 shrewd chief minister, its white front set with cusped niches.",fact:"Nana Wada was built in 1780 by Nana Phadnavis, the Peshwas\u2019 chief minister. It later housed a school.",q:"Who built Nana Wada in 1780?",a:["Nana Phadnavis, the Peshwas\u2019 chief minister","Dagdusheth Gadve, a sweet-maker","Jyotirao Phule"]},{land:"Dagdusheth Ganpati",obj:"pedha",mr:"\u092A\u0947\u0922\u094D\u092F\u093E\u0902\u091A\u0947 \u0924\u093E\u091F",name:"A plate of pedhas",clue:"Head south to Pune\u2019s best-known Ganesh temple, founded by a man who made sweets.",fact:"Shrimant Dagdusheth Halwai Ganpati was founded by Dagdusheth Gadve, a halwai: a maker of sweets.",q:"What was Dagdusheth Gadve\u2019s trade?",a:["He made sweets (a halwai)","He was a goldsmith","He was a soldier of the Peshwas"]},{land:"Bhide Wada",obj:"slate",mr:"\u092A\u093E\u091F\u0940 \u0906\u0923\u093F \u0916\u0921\u0942",name:"A slate and chalk",clue:"A few steps on, find the wada where girls first went to school in Pune.",fact:"At Bhide Wada, in 1848, Savitribai and Jyotirao Phule opened their first school for girls.",q:"What did Savitribai and Jyotirao Phule open at Bhide Wada in 1848?",a:["Their first school for girls","Pune\u2019s first post office","A printing press"]},{land:"Laxmi Road",obj:"anklet",mr:"\u091A\u093E\u0902\u0926\u0940\u091A\u0947 \u092A\u0948\u0902\u091C\u0923",name:"A silver anklet",clue:"Make for the city\u2019s busiest shopping street, lined with jewellers and sari shops.",fact:"Laxmi Road is Pune\u2019s busiest shopping street: jewellers, sari and cloth shops, hawkers and rows of scooters.",q:"What is Laxmi Road best known for?",a:["Shopping: jewellers, saris and cloth","Its railway station","Temples along the river"]},{land:"Tulshibaug Ram Mandir",obj:"tulsi",mr:"\u0924\u0941\u0933\u0936\u0940\u091A\u0940 \u0921\u0939\u093E\u0933\u0940",name:"A sprig of tulsi",clue:"Follow the market lanes to an 18th-century temple with a tall spire, named after a garden of tulsi.",fact:"Tulshibaug Ram Mandir is an 18th-century temple of Shri Ram with a tall spire, at the heart of the Tulshibaug market lanes.",q:"To whom is the temple at Tulshibaug dedicated?",a:["Shri Ram","Shri Ganesh","Lord Shiva"]},{land:"Vishrambaug Wada",obj:"rosette",mr:"\u0938\u093E\u0917\u0935\u093E\u0928\u0940 \u0928\u0915\u094D\u0937\u0940",name:"A carved teak flower",clue:"Go west to the last Peshwa\u2019s mansion, famed for its carved wooden balcony.",fact:"Vishrambaug Wada was built in 1807 for Peshwa Bajirao II and is famed for its carved teak balcony. It houses a post office and a museum.",q:"Vishrambaug Wada was built in 1807 for whom?",a:["Peshwa Bajirao II","Shivaji Maharaj","The British Collector of Pune"]},{land:"Mahatma Phule Mandai",obj:"weight",mr:"\u092E\u0902\u0921\u0908\u091A\u0947 \u0935\u091C\u0928",name:"The market\u2019s brass weight",clue:"Last of all: the great market hall with an eight-sided tower.",fact:"Mahatma Phule Mandai, Pune\u2019s great vegetable market hall, opened in 1886 with its tall octagonal central tower.",q:"What is sold in the Mandai\u2019s great hall, opened in 1886?",a:["Vegetables, fruit and flowers","Cars and scooters","Only books"]}]}},zt=qh[Gn]||null,Z={on:!1,i:0,score:0,secs:0,right:0,hints:0,hinted:!1,spot:null,beacon:null,card:!1,picked:null,lastHud:0,answered:!1},Np="wada-hunt-"+Gn,Qb=/(?:^|[#&])play(?:&|$)/.test(location.hash),jo=null,gi=.35;function Up(){if(!ft)return null;let i=32,e=new Map,t=n=>{let s=1/0,r=1/0,o=-1/0,a=-1/0;for(let c=0;c<n.length;c+=2)s=Math.min(s,n[c]),o=Math.max(o,n[c]),r=Math.min(r,n[c+1]),a=Math.max(a,n[c+1]);let l={p:n,x0:s,z0:r,x1:o,z1:a,water:!1};for(let c=Math.floor(s/i);c<=Math.floor(o/i);c++)for(let h=Math.floor(r/i);h<=Math.floor(a/i);h++){let u=c+","+h;e.has(u)||e.set(u,[]),e.get(u).push(l)}return l};for(let n of ft.buildings)t(n);for(let n of ft.water||[])t(n).water=!0;return{cell:i,grid:e}}var tr={x:0,z:0};function eM(i,e,t){let n=1/0;for(let s=0,r=t.length-2;s<t.length;r=s,s+=2){let o=t[r],a=t[r+1],l=t[s]-o,c=t[s+1]-a,h=Math.max(0,Math.min(1,((i-o)*l+(e-a)*c)/(l*l+c*c||1e-9))),u=o+l*h,d=a+c*h,p=(i-u)*(i-u)+(e-d)*(e-d);p<n&&(n=p,tr.x=u,tr.z=d)}return n}function Op(i,e){for(let[t,n,s,r,o]of Pp(i,e)){if(Math.min(t,s)-o>i||Math.max(t,s)+o<i||Math.min(n,r)-o>e||Math.max(n,r)+o<e)continue;let a=s-t,l=r-n,c=Math.max(0,Math.min(1,((i-t)*a+(e-n)*l)/(a*a+l*l||1)));if(Math.hypot(t+a*c-i,n+l*c-e)<o/2+.5)return!0}return!1}function Fp(i){let e=jo||(jo=Up());if(!e)return!1;let t=!1;for(let n=0;n<3;n++){let s=!1,r=Math.floor(i.x/e.cell),o=Math.floor(i.z/e.cell),a=new Set;for(let l=r-1;l<=r+1;l++)for(let c=o-1;c<=o+1;c++)for(let h of e.grid.get(l+","+c)||[]){if(a.has(h)||(a.add(h),i.x<h.x0-gi||i.x>h.x1+gi||i.z<h.z0-gi||i.z>h.z1+gi))continue;let u=Ko(i.x,i.z,h.p),d=eM(i.x,i.z,h.p);if(!u&&d>=gi*gi||h.water&&Op(i.x,i.z))continue;let p=Math.sqrt(d),g=1,f=0;p>1e-5&&(g=(i.x-tr.x)/p,f=(i.z-tr.z)/p,u&&(g=-g,f=-f)),i.x=tr.x+g*gi,i.z=tr.z+f*gi,s=t=!0}for(let l=0;l<xt.length;l+=3){let c=Math.max(.5,(xt[l+2]-.7)*.75)+gi,h=i.x-xt[l],u=i.z-xt[l+1],d=Math.hypot(h,u);d>=c||d<1e-5||(i.x=xt[l]+h/d*c,i.z=xt[l+1]+u/d*c,s=t=!0)}if(!s)break}return t}function ea(i,e,t=!0){let n=jo||(jo=Up());if(!n)return!0;for(let s of n.grid.get(Math.floor(i/n.cell)+","+Math.floor(e/n.cell))||[])if(!(i<s.x0||i>s.x1||e<s.z0||e>s.z1)&&Ko(i,e,s.p)&&!(s.water&&Op(i,e)))return!1;for(let s=0;t&&s<xt.length;s+=3)if(Math.abs(xt[s]-i)<xt[s+2]&&Math.abs(xt[s+1]-e)<xt[s+2])return!1;return!0}function Bp(i){let e=ft.landmarks.find(a=>a.name===i);if(!e)return null;let t=null;for(let[a,l,c,h]of ft.roads){let u=c-a,d=h-l,p=Math.max(0,Math.min(1,((e.x-a)*u+(e.z-l)*d)/(u*u+d*d||1e-9))),g=a+u*p,f=l+d*p,_=Math.hypot(e.x-g,e.z-f);t&&_>=t.d||ea(g,f)&&(t={d:_,x:g,z:f})}if(!t)return{x:e.x,z:e.z};let n=Math.hypot(e.x-t.x,e.z-t.z);if(n<1)return{x:t.x,z:t.z};let s=(e.x-t.x)/n,r=(e.z-t.z)/n,o=0;for(;o<n-1&&ea(t.x+s*(o+1.5),t.z+r*(o+1.5));)o+=.5;return{x:t.x+s*Math.max(0,o-1),z:t.z+r*Math.max(0,o-1)}}function Dt(i,e=.3,t=.5,n=.4){return new $e({color:i,emissive:i,emissiveIntensity:e,metalness:t,roughness:n})}function tM(i){let e=new St,t=(s,r,o=0,a=0,l=0,c=0,h=0,u=0)=>{let d=new Oe(s,r);return d.position.set(o,a,l),d.rotation.set(c,h,u),e.add(d),d},n=15250757;switch(i){case"spike":{t(new qs(.11,.62,14),Dt(7041400,.2,.85,.35),0,.33,0),t(new Lt(.22,.26,.09,20),Dt(n),0,0,0);break}case"flower":{let s=Dt(14165547,.35,0,.6);for(let r=0;r<5;r++){let o=r*Math.PI*2/5;t(new zn(.15,12,8),s,Math.cos(o)*.17,0,Math.sin(o)*.17,0,-o,0).scale.set(1.35,.32,.9)}t(new Lt(.016,.016,.34,6),Dt(16765498,.5,0,.5),0,.15,.04,.35,0,0),e.rotation.x=.55;break}case"plough":{let s=Dt(n,.35,.8,.3);t(new Pt(.95,.06,.06),s,0,.12,0,0,0,.3),t(new Pt(.06,.5,.06),s,-.3,.12,0,0,0,-.35),t(new qs(.08,.32,8),s,.3,-.12,0,0,0,-2.1),t(new Pt(.05,.3,.05),s,.22,-.02,0,0,0,.1);break}case"quill":{t(new qs(.035,.22,8),Dt(n,.35,.8,.3),0,-.38,0,Math.PI,0,0),t(new Lt(.012,.012,.75,6),Dt(14274744,.25,0,.6),0,-.02,0),t(new zn(.12,14,10),Dt(16183782,.3,0,.6),0,.1,0).scale.set(.65,2.6,.12),e.rotation.z=.45;break}case"pedha":{t(new Lt(.34,.3,.04,28),Dt(n,.3,.8,.3),0,-.04,0);let s=Dt(15323030,.22,0,.8);for(let[r,o]of[[0,0],[.15,.08],[-.15,.08],[0,-.16],[.15,-.09],[-.15,-.09],[0,.17]])t(new zn(.075,12,8),s,r,.02,o).scale.set(1,.55,1);e.rotation.x=.55;break}case"slate":{t(new Pt(.58,.44,.04),Dt(9067051,.2,0,.7),0,0,0),t(new Pt(.48,.34,.046),Dt(2503224,.1,0,.9),0,0,0);let s=Dt(16777215,.6,0,.9);t(new Pt(.26,.025,.05),s,-.05,.08,.002),t(new Pt(.18,.025,.05),s,-.09,0,.002),t(new Pt(.22,.025,.05),s,-.07,-.08,.002),t(new Lt(.02,.02,.16,8),s,.17,-.12,.04,0,0,1.3);break}case"anklet":{let s=Dt(14672872,.3,.9,.25);t(new Fr(.26,.03,10,40),s,0,0,0);for(let r=0;r<12;r++){let o=r/12*Math.PI*2;t(new zn(.04,8,6),s,Math.cos(o)*.26,Math.sin(o)*.26-.05,0)}break}case"tulsi":{t(new Lt(.16,.12,.22,18),Dt(n,.3,.8,.3),0,-.22,0),t(new Lt(.012,.012,.5,6),Dt(5982762,.15,0,.8),0,.1,0);let s=Dt(4164142,.3,0,.7);for(let r=0;r<14;r++){let o=r*2.4,a=-.05+r*.03;t(new zn(.05,8,6),s,Math.cos(o)*.07,a,Math.sin(o)*.07,0,-o,0).scale.set(1.4,.4,.8)}break}case"rosette":{t(new Lt(.1,.1,.08,16),Dt(11565626,.3,.1,.6),0,0,0,Math.PI/2,0,0);let s=Dt(9065763,.28,.1,.6);for(let r=0;r<8;r++){let o=r*Math.PI/4;t(new zn(.11,10,8),s,Math.cos(o)*.19,Math.sin(o)*.19,0,0,0,o).scale.set(1.5,.7,.35)}break}default:{let s=Dt(13212220,.3,.8,.35);t(new Lt(.16,.22,.26,22),s,0,-.08,0),t(new Fr(.08,.02,8,22),s,0,.12,0)}}return e}function nM(i,e){let t=new St;t.position.set(i.x,sn(i.x,i.z),i.z);let n=tM(e);n.scale.setScalar(1.5),n.position.y=1.3,t.add(n);let s=90,r=new Lt(.45,.85,s,20,8,!0);r.translate(0,s/2,0);let o=r.attributes.position,a=new Float32Array(o.count*4);for(let h=0;h<o.count;h++)a.set([1,.72,.3,Math.pow(1-o.getY(h)/s,1.7)],h*4);r.setAttribute("color",new Et(a,4));let l=new Oe(r,new Kt({vertexColors:!0,transparent:!0,opacity:.55,blending:wr,depthWrite:!1,side:yt,fog:!1}));t.add(l);let c=new Oe(new uo(.95,1.2,48),new Kt({color:16761690,transparent:!0,opacity:.85,side:yt,depthWrite:!1,fog:!1}));return c.rotation.x=-Math.PI/2,c.position.y=.07,t.add(c),t.userData={item:n,beam:l,ring:c},mt.add(t),t}function Yh(i){i&&(mt.remove(i),i.traverse(e=>{e.isMesh&&(e.geometry.dispose(),e.material.dispose())}))}function cu(){Yh(Z.beacon),Z.beacon=null,Z.picked&&(Yh(Z.picked.b),Z.picked=null)}function $o(i){if(!ve.on||!ve.ctx)return;let e=ve.ctx,t=e.currentTime+.02,n=(s,r,o,a,l)=>{let c=e.createOscillator();c.type=a,c.frequency.value=s;let h=e.createGain();h.gain.setValueAtTime(1e-4,r),h.gain.exponentialRampToValueAtTime(l,r+.012),h.gain.exponentialRampToValueAtTime(1e-4,r+o),c.connect(h).connect(ve.master),c.start(r),c.stop(r+o+.05)};i==="found"&&([523.3,659.3,784,1046.5].forEach((s,r)=>n(s,t+r*.08,.45,"triangle",.15)),qo(t+.36,.1,880)),i==="right"&&(n(659.3,t,.25,"sine",.2),n(987.8,t+.12,.5,"sine",.2)),i==="wrong"&&(n(233,t,.3,"triangle",.12),n(196,t+.16,.45,"triangle",.12)),i==="win"&&([523.3,659.3,784,1046.5,784,1046.5].forEach((s,r)=>n(s,t+r*.12,.6,"triangle",.15)),qo(t+.8,.18,440))}function cs(i,e,t){if(!re.ready||!re.guide)return;let n=re.guide;i&&n.root.visible&&Qr(n,i);let s=re.bubble;s&&(s.querySelector(".mr").textContent=e,s.querySelector(".en").textContent=t,s.hidden=!1,re.bubbleUntil=re.t+4.5,re.said=re.t)}var Jn=me("huntCard");function kp(i){return(Hn.find(e=>e.land===i)||{}).mr||""}function Zo(i){return i=Math.round(i),`${Math.floor(i/60)}:${String(i%60).padStart(2,"0")}`}function zp(){try{return JSON.parse(localStorage.getItem(Np)||"null")}catch{return null}}function ta(i,e="button"){Qn()&&document.exitPointerLock(),W.keys.clear(),Jn.innerHTML=i,Jn.hidden=!1,Z.card=!0,me("hunt").hidden=!0,me("toast").hidden=!0,Jn.querySelector(e)?.focus()}function as(){Jn.hidden=!0,Jn.innerHTML="",Z.card=!1,Z.on&&(me("hunt").hidden=!1),Vt.focus()}function hn(i){return String(i).replace(/[&<>"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[e])}function Hp(){if(!zt){ta(`<div class="hc-kicker">Heritage hunt</div>
      <h2><span class="mr" lang="mr">${hn(qh.oldcity.mr)}</span> ${hn(qh.oldcity.en)}</h2>
      <p>The hunt is set in the old city round Shaniwar Wada. Go there to play?</p>
      <div class="hc-btns"><button type="button" class="primary" data-act="go">Go to the old city</button>
      <button type="button" data-act="close">Not now</button></div>`);return}let i=zp(),e=Vn?"Hold the arrows to walk, tap \u26A1 to run, drag to look round, double-tap a spot to go there.":"W A S D or the arrow keys to walk, Shift to run, move the mouse to look round, double-click a spot to go there.";ta(`<div class="hc-kicker">Heritage hunt \xB7 ${zt.items.length} treasures</div>
    <h2><span class="mr" lang="mr">${hn(zt.mr)}</span> ${hn(zt.en)}</h2>
    <p>${hn(zt.intro)}</p>
    <p class="hc-small">${hn(e)} The radar points to each treasure; a hint names the place for 20 points.
    ${ve.on?"":"Turn on <strong>Sound</strong> for chimes and bells."}</p>
    ${i?`<p class="hc-small">Your best: <strong>${i.score}</strong> points in ${Zo(i.secs)}.</p>`:""}
    <div class="hc-btns"><button type="button" class="primary" data-act="start">Start the hunt</button>
    <button type="button" data-act="close">Not now</button></div>`)}function iM(){if(!zt||!ft)return;as(),rt.on&&aa(),me("placesPanel").hidden||sa(!1),cu(),Object.assign(Z,{on:!0,i:0,score:0,secs:0,right:0,hints:0,hinted:!1,picked:null,answered:!1,lastT:0}),document.body.classList.add("hunting"),me("hunt").hidden=!1,ra();let i=zt.start,e=Bp(zt.items[0].land)||{x:i.x,z:i.z+30},t=new R(i.x,sn(i.x,i.z)+sr,i.z),n=new R(e.x,t.y,e.z);Vp(0);let s=()=>{W.pos.copy(t),ls("walk",!1),cs("namaste","\u091A\u0932\u093E!","Let\u2019s find the treasures of old Pune. Your first clue is on the card.")};tt==="walk"&&ls("orbit",!1),ia(t,n,{dur:fn?.01:void 0,done:s})}function Vp(i){Z.i=i,Z.hinted=!1,Z.answered=!1,cu();let e=zt.items[i];Z.spot=Bp(e.land),Z.spot&&(Z.beacon=nM(Z.spot,e.obj)),me("huntItem").innerHTML=`<span class="mr" lang="mr">${hn(e.mr)}</span> ${hn(e.name)}`,me("huntClue").textContent=e.clue,me("huntWhere").textContent="",oa(!0)}function oa(i){let e=performance.now();if(!i&&e-Z.lastHud<120||(Z.lastHud=e,me("huntStep").textContent=`${Z.i+1} / ${zt.items.length}`,me("huntScore").textContent=`\u2605 ${Z.score}`,me("huntTime").textContent=Zo(Z.secs),!Z.spot))return;let t=tt==="walk"?W.pos:xe.position,n=Z.spot.x-t.x,s=Z.spot.z-t.z,r=Math.hypot(n,s),o=new R;xe.getWorldDirection(o);let a=Math.atan2(o.x*s-o.z*n,o.x*n+o.z*s);me("huntArrow").style.transform=`rotate(${a.toFixed(3)}rad)`,me("huntDist").textContent=r<10?"Here!":`${r<100?Math.round(r):Math.round(r/10)*10} m`,me("huntWhere").textContent=tt!=="walk"?"Tap Walk to go on":Z.hinted?`It is ${zt.items[Z.i].land} (${kp(zt.items[Z.i].land)})`:""}function sM(){let i=zt.items[Z.i];Z.score+=50,Z.picked={t:0,b:Z.beacon},Z.beacon=null,$o("found"),cs(Math.random()<.5?"clap":"surprised","\u0938\u093E\u092A\u0921\u0932\u093E!",`You found it: ${i.name.toLowerCase()}!`);let e=i.a.map((t,n)=>({a:t,k:n})).sort(()=>Math.random()-.5);setTimeout(()=>{ta(`<div class="hc-kicker">Treasure ${Z.i+1} of ${zt.items.length} found \xB7 +50</div>
      <h2><span class="mr" lang="mr">${hn(i.mr)}</span> ${hn(i.name)}</h2>
      <p class="hc-small">at ${hn(i.land)} <span lang="mr">${hn(kp(i.land))}</span></p>
      <p class="hc-q">${hn(i.q)}</p>
      <div class="hc-opts">${e.map((t,n)=>`<button type="button" data-k="${t.k}"><span class="n">${n+1}</span>${hn(t.a)}</button>`).join("")}</div>
      <div class="hc-after" hidden></div>`,".hc-opts button")},fn?50:700)}function rM(i){if(Z.answered)return;Z.answered=!0;let e=zt.items[Z.i],t=i===0;t?(Z.score+=100,Z.right++,$o("right"),cs("thumbs_up","\u092C\u0930\u094B\u092C\u0930!","Right answer!")):($o("wrong"),cs("think","\u0939\u092E\u094D\u092E\u2026","Not quite. Now you know!"));for(let r of Jn.querySelectorAll(".hc-opts button"))r.disabled=!0,+r.dataset.k==0?r.classList.add("right"):+r.dataset.k===i&&r.classList.add("wrong");let n=Z.i===zt.items.length-1,s=Jn.querySelector(".hc-after");s.innerHTML=`<p class="hc-res">${t?"<strong>Right!</strong> +100":"<strong>Not this time.</strong>"}</p>
    <p>${hn(e.fact)}</p>
    <div class="hc-btns"><button type="button" class="primary" data-act="${n?"finish":"next"}">${n?"See your score":"Next clue"}</button></div>`,s.hidden=!1,s.querySelector("button").focus(),oa(!0)}function aM(){let i=Math.max(0,Math.round((1200-Z.secs)/4));Z.score+=i;let e=zt.items.length,t=Z.score>=1400?3:Z.score>=1e3?2:1,n=zp(),s=!n||Z.score>n.score;if(s)try{localStorage.setItem(Np,JSON.stringify({score:Z.score,secs:Math.round(Z.secs),right:Z.right}))}catch{}$o("win"),cs("victory","\u0936\u093E\u092C\u094D\u092C\u093E\u0938!","You found every treasure of old Pune!"),Gp(!1),ta(`<div class="hc-kicker">Heritage hunt complete</div>
    <h2><span class="mr" lang="mr">\u0936\u093E\u092C\u094D\u092C\u093E\u0938!</span> All ${e} treasures found</h2>
    <div class="hc-stars" aria-label="${t} of 3 stars">${"\u2605".repeat(t)}<span>${"\u2605".repeat(3-t)}</span></div>
    <p class="hc-score"><strong>${Z.score}</strong> points</p>
    <p class="hc-small">${Z.right} of ${e} answers right \xB7 time ${Zo(Z.secs)} (time bonus +${i})${Z.hints?` \xB7 ${Z.hints} hint${Z.hints>1?"s":""}`:""}</p>
    <p class="hc-small">${s?"A new best score!":`Your best: ${n.score} points in ${Zo(n.secs)}.`}</p>
    <div class="hc-btns"><button type="button" class="primary" data-act="start">Play again</button>
    <button type="button" data-act="close">Explore freely</button></div>`)}function Gp(i=!0){Z.on=!1,Z.spot=null,cu(),me("hunt").hidden=!0,document.body.classList.remove("hunting"),ra(),i&&as()}function oM(i){if(!Z.on)return;let e=Z.picked;if(e){let{item:r,beam:o,ring:a}=e.b.userData;e.t+=i,r.position.y=1.3+e.t*3,r.rotation.y+=i*12,r.scale.setScalar(1.5*Math.max(.01,1-e.t/.8)),o.material.opacity=Math.max(0,.55*(1-e.t/.6)),a.material.opacity=Math.max(0,.85*(1-e.t/.5)),e.t>.9&&(Yh(e.b),Z.picked=null)}let t=Z.beacon;if(t&&!fn){let{item:r,beam:o,ring:a}=t.userData,l=performance.now()/1e3;r.rotation.y+=i*1.4,r.position.y=1.3+Math.sin(l*2.2)*.12,a.scale.setScalar(1+.12*Math.sin(l*3)),o.material.opacity=.45+.12*Math.sin(l*1.7)}let n=performance.now()/1e3,s=Z.lastT?Math.min(1,n-Z.lastT):0;Z.lastT=n,!Z.card&&(Z.secs+=s,oa(!1),Z.beacon&&tt==="walk"&&Z.spot&&Math.hypot(W.pos.x-Z.spot.x,W.pos.z-Z.spot.z)<3.2&&sM())}Jn.addEventListener("click",i=>{let e=i.target.closest("button");if(!e)return;if(e.dataset.k!==void 0){rM(+e.dataset.k);return}let t=e.dataset.act;t==="start"?iM():t==="close"?as():t==="go"?(location.hash="play&place=oldcity",setTimeout(()=>location.reload(),300)):t==="next"?(as(),Vp(Z.i+1),cs("point_up","\u092A\u0941\u0922\u091A\u093E!","On to the next clue!")):t==="finish"?(as(),aM()):t==="quit"?Gp(!0):t==="keep"&&as()});window.addEventListener("keydown",i=>{if(!Jn.hidden)if(/^[1-3]$/.test(i.key)){let e=Jn.querySelectorAll(".hc-opts button")[+i.key-1];e&&!e.disabled&&(e.click(),i.preventDefault())}else i.key==="Escape"&&!Z.on&&as()},!0);me("playBtn").addEventListener("click",()=>{if(Z.on){oa(!0);return}Hp()});me("huntHint").addEventListener("click",()=>{if(!Z.on||Z.hinted)return;Z.hinted=!0,Z.hints++,Z.score=Math.max(0,Z.score-20);let i=zt.items[Z.i];cs("point_up","\u0924\u093F\u0925\u0947!",`Over there: ${i.land}.`),oa(!0)});me("huntQuit").addEventListener("click",()=>{Z.on&&ta(`<h2>Stop the hunt?</h2><p>You have found ${Z.i} of ${zt.items.length} treasures; your progress will be lost.</p>
    <div class="hc-btns"><button type="button" class="primary" data-act="keep">Keep playing</button>
    <button type="button" data-act="quit">Stop</button></div>`)});window.__wadaTraffic=(i=0,e=120)=>{if(!dn)return null;let t=(tt==="walk"?W.pos:$n).clone();for(let d=0;d<i;d++)Tp(.05,t,performance.now()+d*50);let{cars:n,movers:s}=dn,r=n.filter(d=>Math.hypot(d.x-t.x,d.z-t.z)<e),o=(d,p,g,f,_,m)=>{let y=_-g,x=m-f,b=Math.max(0,Math.min(1,((d-g)*y+(p-f)*x)/(y*y+x*x||1e-9)));return Math.hypot(g+y*b-d,f+x*b-p)},a=d=>{let p=Math.max(0,d.hl-d.hw);return[d.x-d.dx*p,d.z-d.dz*p,d.x+d.dx*p,d.z+d.dz*p]},l=0,c=0,h=0,u=0;for(let d=0;d<r.length;d++){let p=a(r[d]);for(let g=d+1;g<r.length;g++){let f=a(r[g]);Math.min(o(p[0],p[1],...f),o(p[2],p[3],...f),o(f[0],f[1],...p),o(f[2],f[3],...p))<r[d].hw+r[g].hw-.15&&l++}for(let g of s)g.car||Math.abs(g.x-r[d].x)>8||Math.abs(g.z-r[d].z)>8||o(g.x,g.z,...p)<r[d].hw+.15&&(g.still?h++:c++);for(let g=0;g<xt.length;g+=3)Math.abs(xt[g]-r[d].x)>8||Math.abs(xt[g+1]-r[d].z)>8||o(xt[g],xt[g+1],...p)<r[d].hw+Math.max(.3,(xt[g+2]-.7)*.4)&&u++}return{cars:r.length,carCar:l,carWalker:c,carStanding:h,carParked:u,parked:xt.length/3}};window.__wadaPitch=i=>(W.tpitch=i,W.pitch);window.__wadaHunt=(i,e,t,n)=>{if(i==="near"&&Z.spot&&W.pos.set(Z.spot.x+7,W.pos.y,Z.spot.z+7),i==="at"&&Z.spot&&W.pos.set(Z.spot.x,W.pos.y,Z.spot.z),i==="to"&&W.pos.set(e,W.pos.y,t),i==="sim"){let[s,r]=n,o=new R(e,0,t);for(let a=0;a<600;a++){let l=s-o.x,c=r-o.z,h=Math.hypot(l,c);if(h<.3)break;o.x+=l/h*.25,o.z+=c/h*.25,Fp(o)}return{end:[+o.x.toFixed(2),+o.z.toFixed(2)],free:ea(o.x,o.z),left:+Math.hypot(s-o.x,r-o.z).toFixed(1)}}return{on:Z.on,i:Z.i,score:Z.score,secs:Math.round(Z.secs),card:Z.card,mode:tt,spot:Z.spot&&[+Z.spot.x.toFixed(1),+Z.spot.z.toFixed(1)],pos:[+W.pos.x.toFixed(2),+W.pos.z.toFixed(2)],open:vi(W.pos.x,W.pos.z),free:ea(W.pos.x,W.pos.z),fl:Mt&&+Mt.t.toFixed(2),frame:Oh}};{let i=me("padRun");i.addEventListener("click",()=>{W.runLock=!W.runLock,i.setAttribute("aria-pressed",String(W.runLock)),i.classList.toggle("on",W.runLock)})}var rp=(()=>{let i=new ts,e=new kr(16777215,9075298,1.2),t=new ns(16777215,1.5);i.add(e,t,t.target);let n=(D,v=.75)=>new $e({color:D,roughness:v,metalness:0}),s=n(11039567,.6),r=n(4026014),o=n(15328472),a=n(3159099,.85),l=n(2759698,.5),c=n(1380622,.9),h=new St;i.add(h);let u=D=>{let v=new St,S=new St;S.rotation.z=D*-1.1,v.add(S);let N=(O,j,L,U,V,K=Math.PI/2,Y=0,q=0)=>{let $=new Oe(O,j);return $.position.set(L,U,V),$.rotation.set(K,Y,q),S.add($),$};N(new Lt(.043,.052,.3,14),r,0,0,-.14),N(new Lt(.047,.047,.036,14),o,0,0,-.29),N(new Lt(.029,.033,.05,12),s,0,0,-.325),N(new Pt(.074,.028,.085),s,0,-.004,-.39,0);for(let O=0;O<4;O++)N(new Xs(.0085,.042-Math.abs(O-1.5)*.006,3,6),s,-.027+O*.018,-.014,-.452+Math.abs(O-1.5)*.006,Math.PI/2+.55);return N(new Xs(.0095,.036,3,6),s,D*-.043,.004,-.372,Math.PI/2,0,D*.9),h.add(v),v},d=[u(-1),u(1)],p=new St,g=new Kt({colorWrite:!1,depthWrite:!1}),f=D=>{let v=new St;v.position.set(D*.11,.93,-.12);let S=new Oe(new Lt(.078,.066,.47,12),g);S.position.y=-.235;let N=new St;N.position.y=-.47;let O=new Oe(new Lt(.063,.05,.4,12,1,!0),a);O.position.y=-.2;let j=new Oe(new Pt(.1,.075,.27),l);j.position.set(0,-.415,-.06);let L=new Oe(new Lt(.05,.05,.1,12,1,!1,0,Math.PI),l);L.rotation.set(0,0,Math.PI/2),L.position.set(0,-.415,-.195);let U=new Oe(new Pt(.106,.022,.31),c);U.position.set(0,-.452,-.07),v.add(S,N),N.add(O,j,L,U);for(let V of[S,O,j,L,U])V.castShadow=!0;return p.add(v),{hip:v,knee:N}},_=[f(-1),f(1)],m=new Oe(new Xs(.19,.42,4,10),g);m.position.y=1.2;let y=new Oe(new zn(.12,10,8),g);y.position.y=1.62,m.castShadow=y.castShadow=!0,p.add(m,y),p.visible=!1,mt.add(p);let x={phase:0,amp:0,run:0,t:0,bx:.2,by:-.3,hudAt:0,hudF:.2};function b(){let D=performance.now();D-x.hudAt>500&&(x.hudAt=D,x.hudF=Math.min(.42,(me("hudBottom").offsetHeight+8)/Math.max(1,innerHeight)));let v=Math.tan(It.degToRad(xe.fov/2)),S=.45;x.by=(-1+2*x.hudF)*S*v-.1,x.bx=Math.min(.21,.6*S*v*xe.aspect)}function E(D){if(!ve.on||!ve.ctx)return;let v=ve.ctx,S=v.currentTime+.01,N=v.createBufferSource();N.buffer=ve.stepBuf||(ve.stepBuf=Gh(v,.2,!1));let O=v.createBiquadFilter();O.type="bandpass",O.frequency.value=600+Math.random()*500,O.Q.value=.8;let j=v.createGain();j.gain.setValueAtTime(1e-4,S),j.gain.exponentialRampToValueAtTime(D,S+.008),j.gain.exponentialRampToValueAtTime(1e-4,S+.11),N.connect(O).connect(j).connect(ve.master),N.start(S,Math.random()*.05),N.stop(S+.14);let L=v.createOscillator();L.type="sine",L.frequency.setValueAtTime(120,S),L.frequency.exponentialRampToValueAtTime(55,S+.08);let U=v.createGain();U.gain.setValueAtTime(1e-4,S),U.gain.exponentialRampToValueAtTime(D*.9,S+.006),U.gain.exponentialRampToValueAtTime(1e-4,S+.09),L.connect(U).connect(ve.master),L.start(S),L.stop(S+.11)}function w(D,v,S){let N=v/Math.max(D,1e-4),O=S&&N>gp*.5;x.amp+=((N<.2?0:1)-x.amp)*Math.min(1,D*7),x.run+=((O?1:0)-x.run)*Math.min(1,D*5),x.t+=D;let j=x.phase;x.phase+=v/(O?2.2:1.05)*Math.PI,N>.3&&Math.floor(x.phase/Math.PI)!==Math.floor(j/Math.PI)&&E(O?.2:.12);let L=fn?0:x.amp,U=Math.sin(x.phase),V=Math.cos(x.phase),K=x.run;b();for(let Y=0;Y<2;Y++){let q=(Y===0?U:-U)*L,$=d[Y],ie=Y===0?-1:1,pe=Math.sin(x.t*1.7)*.004;$.position.set(ie*(x.bx-K*.02),x.by+q*(.03+K*.03)+K*.03+pe,-.04-q*(.15+K*.07)),$.rotation.set(.3+K*.35+q*(.16+K*.16),ie*-.14,0)}for(let Y=0;Y<2;Y++){let q=x.phase+(Y===0?0:Math.PI),$=_[Y];$.hip.rotation.x=Math.sin(q)*(.42+K*.25)*L,$.knee.rotation.x=-Math.max(0,Math.cos(q))*(.7+K*.6)*L}return p.visible=!0,p.position.set(W.pos.x,W.pos.y-sr,W.pos.z),p.rotation.y=W.yaw,{y:(Math.abs(U)-.5)*(.055+K*.04)*L,x:U*.016*L,roll:U*(.006+K*.004)*L}}function T(){if(!(tt==="walk")){p.visible=!1;return}h.position.copy(xe.position),h.quaternion.copy(xe.quaternion),e.color.copy(os.color),e.groundColor.copy(os.groundColor),e.intensity=os.intensity*1.1+.4*Zt.uNight.value,t.color.copy(nn.color),t.intensity=nn.intensity*.55,t.position.copy(xe.position).addScaledVector(Zr,10),t.target.position.copy(xe.position),Ht.autoClear=!1,Ht.clearDepth(),Ht.render(i,xe),Ht.autoClear=!0}return{step:w,render:T}})(),Nh=0,lM=new R(0,1,0),Oo=new R,Uh=new R,Yr=new R,ap=i=>i*i*i*(i*(i*6-15)+10);function Wp(i){let e=Hb.getDelta(),t=Math.min(.05,e),n=Math.min(.1,e);if(zb(e),Oh++,Mt){Mt.t=Math.min(1,Mt.t+n/(Mt.dur||1.4));let c=Mt.t,h=ap(c),u=ap(Math.min(1,c*1.08));if(xe.position.lerpVectors(Mt.fromPos,Mt.toPos,h),xe.position.y+=(Mt.arc||0)*Math.sin(Math.PI*h),nt.target.lerpVectors(Mt.fromTarget,Mt.toTarget,u),c>=1){let d=Mt.done;Mt=null,d&&d()}}if(tt==="walk"){let c=W.keys.has("run")||W.runLock,h=(c?gp:$v)*(Z.on?1.2:1),u=Math.min(1,t*14);W.yaw+=(W.tyaw-W.yaw)*u,W.pitch+=(W.tpitch-W.pitch)*u;let d=new R(-Math.sin(W.yaw),0,-Math.cos(W.yaw)),p=new R(-d.z,0,d.x),g=new R;(W.keys.has("f")||W.keys.has("mf"))&&g.add(d),(W.keys.has("b")||W.keys.has("mb"))&&g.sub(d),W.keys.has("r")&&g.add(p),W.keys.has("l")&&g.sub(p);let f=W.pos.x,_=W.pos.z;if(Z.card)W.glide=null;else if(g.lengthSq())W.glide=null,W.pos.addScaledVector(g.normalize(),h*t);else if(W.glide){let y=W.glide;y.t=Math.min(1,y.t+t/y.dur);let x=y.t<.5?2*y.t*y.t:1-(-2*y.t+2)**2/2;W.pos.x=y.from.x+(y.to.x-y.from.x)*x,W.pos.z=y.from.z+(y.to.z-y.from.z)*x,y.t>=1&&(W.glide=null)}if(Z.on&&Fp(W.pos)&&W.glide&&(W.glide=null),i-W.lastProbe>100){W.lastProbe=i,Zf.ray.origin.set(W.pos.x,W.pos.y-sr+.75,W.pos.z);let y=Zf.intersectObjects(fp,!1)[0];W.floor=y?y.point.y:sn(W.pos.x,W.pos.z)}W.pos.y+=(W.floor+sr-W.pos.y)*Math.min(1,t*8);let m=rp.step(t,Math.hypot(W.pos.x-f,W.pos.z-_),c);xe.position.copy(W.pos),xe.position.y+=m.y,xe.position.x+=p.x*m.x,xe.position.z+=p.z*m.x,xe.rotation.set(W.pitch,W.yaw,m.roll,"YXZ"),$n.copy(W.pos)}else{nt.dampingFactor=1-Math.pow(1-.06,n*60),nt.update();let c=sn(xe.position.x,xe.position.z)+1.2;xe.position.y<c&&(xe.position.y=c),$n.copy(nt.target)}let s=Mt?Mt.toTarget:$n,r=xe.position.distanceTo($n),a=(Mt?!0:Nh===650?r>300:r>380)?650:170;if(a!==Nh){let c=nn.shadow.camera;c.left=c.bottom=-a,c.right=c.top=a,c.updateProjectionMatrix(),Nh=a}{let c=2*a/nn.shadow.mapSize.x;Yr.copy(Zr).normalize(),Oo.crossVectors(lM,Yr).normalize(),Uh.crossVectors(Yr,Oo);let h=Math.round(s.dot(Oo)/c)*c,u=Math.round(s.dot(Uh)/c)*c;nn.target.position.copy(Oo).multiplyScalar(h).addScaledVector(Uh,u).addScaledVector(Yr,s.dot(Yr)),nn.position.copy(nn.target.position).addScaledVector(Zr,700)}Oh%op===0&&(Ht.shadowMap.needsUpdate=!0),jv(i,$n),Ib(i,xe.position),Ob(t),oM(t),Tp(t,tt==="walk"?W.pos:$n,i),ob(tt==="walk"?W.pos:$n),fn||(Eb(t),Zt.uTime.value=i/1e3,bb(t,tt==="walk"?W.pos:$n,i/1e3),mb(t,i/1e3)),Jb(t);let l=new R;xe.getWorldDirection(l),nb(i,tt==="walk"?W.pos:xe.position.y>60?$n:xe.position,Math.atan2(-l.x,-l.z)),Jo.position.copy(xe.position);{let c=ar[or].fog,h=Math.max(0,xe.position.y-20);mt.fog.near=c[0]+h*.9,mt.fog.far=c[1]+h*3.2}Ht.render(mt,xe),rp.render(),requestAnimationFrame(Wp)}mp("day");sl();Vo();Promise.all(ko.map((i,e)=>i.movers||i.metro?Bf(i,e).catch(()=>null):Bf(i,e))).then(async()=>{try{let t=await fetch(ss+"wada_traffic.json");if(t.ok){let n=await t.json();await tb,sb(n)}}catch{}try{let t=await fetch(ss+"wada_metro.json");t.ok&&Yf(await t.json())}catch{}if(ko.some(t=>/railway/.test(t.file)))try{let t=await fetch(ss+"wada_railway.json");t.ok&&Yf(await t.json(),"rail")}catch{}try{let t=await fetch(ss+"wada_props.json");t.ok&&db(await t.json())}catch{}Yo();{let t=[];mt.traverse(n=>{n.visible||(t.push(n),n.visible=!0)});try{Ht.compile(mt,xe)}catch{}for(let n of t)n.visible=!1;Ht.shadowMap.needsUpdate=!0}fetch(ss+"wada_labels.json").then(t=>t.ok?t.json():null).then(Tb).catch(()=>{});let i=location.hash.slice(1).split("&")[0];il($r.some(t=>t.id===i)?i:In.start||"fort",!0),me("loader").classList.add("done"),Wb(),Qb&&Hp();let e=!1;try{e=localStorage.getItem("wada-tip")==="1",localStorage.setItem("wada-tip","1")}catch{}if(!e){me("toast").hidden=!1;let t=()=>{me("toast").hidden=!0};me("toastClose").addEventListener("click",t),setTimeout(t,12e3),me("tod").addEventListener("click",t,{once:!0}),su.addEventListener("click",t,{once:!0})}requestAnimationFrame(Wp)}).catch(i=>{me("status").textContent=`Part of the city (${i.message}) did not load. Reload the page to try again.`});
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
